# -*- coding: utf-8 -*-
"""
Escape from Tarkov MMO Economic Engine
Logic, balance formulas, PMC buffs, Hideout, Warehouses, Combat & Persistence.
"""

import json
import os
import time
import random
import math

DB_FILE = "database.json"
ITEMS_FILE = "items_data.json"

# Load 500+ items catalog
if os.path.exists(ITEMS_FILE):
    with open(ITEMS_FILE, "r", encoding="utf-8") as f:
        ITEMS_LIST = json.load(f)
else:
    ITEMS_LIST = []
ITEMS_BY_ID = {item["id"]: item for item in ITEMS_LIST}

# 10 Signature PMCs + 11th "Revenant"
PMC_DEFINITIONS = {
    "Viper": {
        "name": "Viper",
        "icon": "⚡",
        "desc": "Кулдаун после рейдов и кулдаун ЧВК снижен на 15%.",
        "buff": "cooldown_reduction",
        "val": 0.15
    },
    "Nomad": {
        "name": "Nomad",
        "icon": "🏹",
        "desc": "Стоимость отправки Диких в платные рейды снижена на 20%.",
        "buff": "scav_discount",
        "val": 0.20
    },
    "Ronin": {
        "name": "Ronin",
        "icon": "⚔️",
        "desc": "+15% к шансу победить в PvP-зоне 'Даркзон'.",
        "buff": "pvp_bonus",
        "val": 0.15
    },
    "Specter": {
        "name": "Specter",
        "icon": "👁️",
        "desc": "+10% к шансу найти предметы редкости Legendary и Epic в рейдах/поставках.",
        "buff": "loot_bonus",
        "val": 0.10
    },
    "Ares": {
        "name": "Ares",
        "icon": "🛡️",
        "desc": "Вместимость всех 4 специализированных складов увеличена на 20%.",
        "buff": "warehouse_bonus",
        "val": 0.20
    },
    "Zenith": {
        "name": "Zenith",
        "icon": "⚡",
        "desc": "Пассивный майнинг Биткоинов ускорен на 15%.",
        "buff": "btc_bonus",
        "val": 0.15
    },
    "Fenrir": {
        "name": "Fenrir",
        "icon": "🐺",
        "desc": "При моментальной продаже вещей Прапору он платит 40% стоимости вместо 30%.",
        "buff": "prapor_bonus",
        "val": 0.40
    },
    "Stalker": {
        "name": "Stalker",
        "icon": "☢️",
        "desc": "Время ожидания Контрабандных Поставок снижено на 20%.",
        "buff": "supply_speed",
        "val": 0.20
    },
    "Siren": {
        "name": "Siren",
        "icon": "🧜",
        "desc": "Налог на P2P-барахолке снижен с 10% до 5%.",
        "buff": "market_tax",
        "val": 0.05
    },
    "Pharaoh": {
        "name": "Pharaoh",
        "icon": "👑",
        "desc": "Пассивный доход со всех 4 Теневых Бизнесов увеличен на 15%.",
        "buff": "business_income",
        "val": 0.15
    },
    "Revenant": {
        "name": "Revenant",
        "icon": "💀",
        "desc": "Эксклюзив @revenuts: Все 10 баффов одновременно! Ранг: 💀 [ADMIN] 💰 REVENANT GD 💰 💀",
        "buff": "all",
        "val": 1.0
    }
}

# Hideout Upgrade Costs (1 -> 10)
HIDEOUT_UPGRADE_COSTS = {
    1: 75000,       # 1 -> 2
    2: 250000,      # 2 -> 3
    3: 750000,      # 3 -> 4
    4: 2000000,     # 4 -> 5
    5: 5500000,     # 5 -> 6
    6: 15000000,    # 6 -> 7
    7: 40000000,    # 7 -> 8
    8: 100000000,   # 8 -> 9
    9: 250000000    # 9 -> 10
}

# 10 Hideout Modules
MODULE_NAMES = {
    "generator": "Генератор",
    "ammo_bench": "Патронный станок",
    "mining_farm": "Майнинг-ферма (BTC)",
    "medblock": "Медблок",
    "workbench": "Верстак",
    "lavatory": "Санузел",
    "nutrition": "Пищеблок",
    "rest_space": "Зона отдыха",
    "water_collector": "Водосборник",
    "intel_center": "Разведцентр"
}

# 4 Shadow Businesses with balanced progression
BUSINESS_CONFIG = {
    "topography": {
        "name": "🖨️ Подпольная Топография",
        "tagline": "Печать карт выходов и поддельных пропусков Terragroup",
        "costs": [25000, 45000, 85000, 160000, 300000, 550000, 950000, 1650000, 2800000, 4800000],
        "income": [0, 3500, 6800, 12500, 22000, 37000, 60000, 95000, 145000, 215000, 310000]
    },
    "buyers_net": {
        "name": "🏪 Сеть Скупщиков",
        "tagline": "Агентура ломбардов и перепродажа редкого армейского хабара",
        "costs": [60000, 110000, 210000, 390000, 720000, 1300000, 2350000, 4200000, 7500000, 13000000],
        "income": [0, 6500, 12800, 23500, 41000, 68000, 110000, 175000, 270000, 405000, 600000]
    },
    "chem_lab": {
        "name": "🧪 Хим-Лаборатория",
        "tagline": "Синтез боевых стимуляторов SJ6, пропитала и спец-морфина",
        "costs": [150000, 290000, 550000, 1050000, 1950000, 3600000, 6600000, 12000000, 21500000, 38000000],
        "income": [0, 14000, 27500, 51000, 92000, 160000, 270000, 440000, 700000, 1080000, 1650000]
    },
    "smuggling": {
        "name": "🚚 Контрабандный Трафик",
        "tagline": "Трансграничный трафик тяжелого вооружения и военных контейнеров",
        "costs": [400000, 800000, 1600000, 3200000, 6400000, 12500000, 24000000, 45000000, 82000000, 150000000],
        "income": [0, 32000, 65000, 125000, 235000, 425000, 740000, 1250000, 2050000, 3300000, 5200000]
    }
}

BUSINESS_NAMES = {k: v["name"] for k, v in BUSINESS_CONFIG.items()}

# Base warehouse capacities
BASE_WAREHOUSE_CAPS = {
    "weapons": (10, 5),      # base 10, +5 per level
    "armor": (10, 5),        # base 10, +5 per level
    "gear": (15, 5),         # base 15, +5 per level
    "components": (20, 10)   # base 20, +10 per level
}

WAREHOUSE_NAMES = {
    "weapons": "Оружейный склад",
    "armor": "Броне-ангар",
    "gear": "Вещевой склад",
    "components": "Склад компонентов"
}

# Warehouse upgrade cost formula: base 35k, +80% per lvl
def get_warehouse_upgrade_cost(current_lvl):
    if current_lvl >= 10:
        return None
    costs = [0, 35000, 80000, 180000, 400000, 900000, 2000000, 4500000, 10000000, 25000000]
    return costs[current_lvl] if current_lvl < len(costs) else 50000000

# Module & Business upgrade cost: 50,000 base, +50% per level
def get_module_upgrade_cost(current_lvl):
    if current_lvl >= 10:
        return None
    cost = 50000 * ((1.5) ** current_lvl)
    return int(round(cost / 250.0) * 250)

# Supply Channel Upgrade costs (1 to 10)
SUPPLY_CHANNEL_COSTS = {
    1: 30000,
    2: 60000,
    3: 120000,
    4: 250000,
    5: 500000,
    6: 1000000,
    7: 2000000,
    8: 4000000,
    9: 8000000
}

# Bitcoin Dynamic Exchange Rate (~500,000 ₽)
def get_current_btc_rate():
    t = time.time()
    # Gentle wave between 470,000 and 535,000 rubles
    variation = math.sin(t / 1800.0) * 32000 + math.cos(t / 4200.0) * 15000
    return int(round((500000 + variation) / 100.0) * 100)

# Business Upgrade Cost by specific business tier (1 to 10)
def get_business_upgrade_cost(biz_key, current_lvl):
    if current_lvl >= 10:
        return None
    b_conf = BUSINESS_CONFIG.get(biz_key)
    if not b_conf:
        return None
    costs = b_conf["costs"]
    if current_lvl < len(costs):
        return costs[current_lvl]
    return None

# Hourly Rubles from Businesses (supports both (biz_key, level) and (level) fallback)
def get_business_hourly_income(biz_or_level, level=None):
    if level is None:
        lvl = biz_or_level
        table = [0, 4500, 9500, 18000, 32000, 55000, 90000, 145000, 225000, 340000, 500000]
        return table[min(lvl, 10)] if lvl > 0 else 0

    biz_key = biz_or_level
    if level <= 0:
        return 0
    b_conf = BUSINESS_CONFIG.get(biz_key)
    if not b_conf:
        table = [0, 4500, 9500, 18000, 32000, 55000, 90000, 145000, 225000, 340000, 500000]
        return table[min(level, 10)]
    return b_conf["income"][min(level, 10)]

# Hourly BTC from Mining Farm (0.01 to 0.10 BTC/hour)
def get_mining_hourly_btc(level):
    if level <= 0:
        return 0.0
    return round(0.01 + (min(level, 10) - 1) * 0.01, 4)

def has_buff(user, buff_name):
    pmc = user.get("pmc_signature")
    if pmc == "Revenant" or user.get("username", "").lower().lstrip("@") == "revenuts":
        return True
    defin = PMC_DEFINITIONS.get(pmc, {})
    return defin.get("buff") == buff_name

def get_warehouse_capacity(user, category):
    base, per_lvl = BASE_WAREHOUSE_CAPS.get(category, (15, 5))
    lvl = user.get("warehouses", {}).get(category, 1)
    cap = base + (lvl - 1) * per_lvl
    if has_buff(user, "warehouse_bonus"):
        cap = int(math.ceil(cap * 1.20))
    return cap

def get_warehouse_count(user, category):
    stash = user.get("stash", [])
    count = 0
    for itm in stash:
        info = ITEMS_BY_ID.get(itm.get("item_id"), {})
        if info.get("category") == category:
            count += 1
    return count

def can_store_item(user, item_id):
    info = ITEMS_BY_ID.get(item_id, {})
    cat = info.get("category", "gear")
    cap = get_warehouse_capacity(user, cat)
    cnt = get_warehouse_count(user, cat)
    return cnt < cap

# Database management
def load_db():
    if not os.path.exists(DB_FILE):
        init_db = {
            "users": {},
            "p2p_market": [],
            "active_duels": {},
            "airdrop": {"active": False, "last_spawn": 0, "chat_id": None, "message_id": None}
        }
        save_db(init_db)
        return init_db
    try:
        with open(DB_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"users": {}, "p2p_market": [], "active_duels": {}, "airdrop": {}}

def save_db(data):
    tmp = DB_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DB_FILE)

# Starter profile builder
def create_new_player(user_id, username, pmc_signature):
    now = int(time.time())
    is_rev = (username or "").lower().lstrip("@") == "revenuts"
    if is_rev and not pmc_signature:
        pmc_signature = "Revenant"

    player = {
        "user_id": user_id,
        "username": username or f"PMC_{user_id}",
        "pmc_signature": pmc_signature,
        "registered_at": now,
        "money": 50000,
        "btc": 0.0,
        "hideout_lvl": 1,
        "supply_channel_lvl": 1,
        "modules": {k: (1 if k == "generator" else 0) for k in MODULE_NAMES},
        "businesses": {k: 0 for k in BUSINESS_NAMES},
        "warehouses": {k: 1 for k in BASE_WAREHOUSE_CAPS},
        "stash": [
            {"uid": f"{now}_1", "item_id": "toz_106_common", "equipped_to": None},
            {"uid": f"{now}_2", "item_id": "ak74m_common", "equipped_to": None},
            {"uid": f"{now}_3", "item_id": "ai2_medkit_common", "equipped_to": None},
            {"uid": f"{now}_4", "item_id": "ai2_medkit_common", "equipped_to": None},
            {"uid": f"{now}_5", "item_id": "bandage_common", "equipped_to": None},
            {"uid": f"{now}_6", "item_id": "splint_common", "equipped_to": None},
            {"uid": f"{now}_7", "item_id": "ammo_545_bt_rare", "equipped_to": None}
        ],
        "squad": [
            {"id": 1, "type": "scav", "name": "Дикий #1", "weapon_uid": None, "armor_uid": None}
        ],
        "active_delivery": None,
        "last_income_claim": now,
        "last_raid_time": 0,
        "stats": {
            "raids_count": 0,
            "pvp_wins": 0,
            "pvp_losses": 0,
            "airdrop_looted": 0
        }
    }
    return player

# Squad power & armor calculation
def calculate_squad_power(user):
    squad = user.get("squad", [])
    stash = {itm["uid"]: itm for itm in user.get("stash", [])}
    total_power = 0
    total_armor = 0

    for fighter in squad:
        base_power = 10 if fighter.get("type") == "scav" else 25
        base_armor = 5

        w_uid = fighter.get("weapon_uid")
        if w_uid and w_uid in stash:
            item_id = stash[w_uid].get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            base_power += info.get("combat", 0)

        a_uid = fighter.get("armor_uid")
        if a_uid and a_uid in stash:
            item_id = stash[a_uid].get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            base_armor += info.get("armor", 0)

        total_power += base_power
        total_armor += base_armor

    # Boss relics bonuses from stash!
    for itm in user.get("stash", []):
        iid = itm.get("item_id")
        if iid == "tagilla_sledgehammer_legendary":
            total_power += 20
        elif iid == "killa_helmet_legendary":
            total_armor += 30
        elif iid == "glukhar_cap_legendary":
            total_power += 15
            total_armor += 25

    return total_power, total_armor
