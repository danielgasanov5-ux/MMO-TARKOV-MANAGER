# -*- coding: utf-8 -*-
"""
ESCAPE FROM TARKOV MMO ECONOMIC MANAGER TELEGRAM BOT
Built with pyTelegramBotAPI (telebot).
Monolithic, hardened against time exploits, full inline UI navigation.
"""

import os
import sys
import time
import random
import json
import logging
from datetime import datetime

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import telebot
from telebot import types

from tarkov_engine import (
    load_db, save_db, create_new_player,
    PMC_DEFINITIONS, HIDEOUT_UPGRADE_COSTS, MODULE_NAMES, BUSINESS_NAMES, BUSINESS_CONFIG,
    WAREHOUSE_NAMES, BASE_WAREHOUSE_CAPS,
    get_warehouse_upgrade_cost, get_module_upgrade_cost, get_business_upgrade_cost, SUPPLY_CHANNEL_COSTS,
    get_current_btc_rate, get_business_hourly_income, get_mining_hourly_btc,
    has_buff, get_warehouse_capacity, get_warehouse_count, can_store_item,
    calculate_squad_power, ITEMS_BY_ID, ITEMS_LIST
)
from loot_generator import (
    roll_supply_item, generate_airdrop_loot, simulate_raid, RAID_LOCATIONS,
    CONTAINER_DEFINITIONS, generate_container_loot
)

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
if not BOT_TOKEN:
    print("[WARNING] BOT_TOKEN is not set in environment or Secrets!")
    print("Please set BOT_TOKEN in your environment or Secrets before starting the bot.")

bot = telebot.TeleBot(BOT_TOKEN if BOT_TOKEN else "DUMMY_TOKEN_PLEASE_SET_BOT_TOKEN", parse_mode="HTML")

# Helper: format rubles
def fmt_rub(val):
    return f"{int(val):,} ₽".replace(",", " ")

def is_admin(user_id, username):
    u = (username or "").lower().lstrip("@")
    return u == "revenuts"

def get_player(user_id, username=None):
    db = load_db()
    uid = str(user_id)
    if uid in db["users"]:
        u = db["users"][uid]
        if username and u.get("username") != username:
            u["username"] = username
            save_db(db)
        return u, db
    return None, db

# ----------------- MAIN KEYBOARDS -----------------

def get_main_menu_markup(user):
    markup = types.InlineKeyboardMarkup(row_width=2)
    b_profile = types.InlineKeyboardButton("👤 Профиль ЧВК", callback_data="menu_profile")
    b_squad = types.InlineKeyboardButton("🪖 Мой Отряд", callback_data="menu_squad")
    b_stash = types.InlineKeyboardButton("📦 Склады и Схрон", callback_data="menu_stash")
    b_market = types.InlineKeyboardButton("🏪 Барахолка и Торговцы", callback_data="menu_market")
    b_hideout = types.InlineKeyboardButton("🏚️ Убежище и Бизнес", callback_data="menu_hideout")
    b_supply = types.InlineKeyboardButton("🚚 Контрабанда", callback_data="menu_supply")
    b_raids = types.InlineKeyboardButton("⚔️ Рейды в Тарков", callback_data="menu_raids")
    b_darkzone = types.InlineKeyboardButton("💀 Даркзон (PvP)", callback_data="menu_darkzone")
    b_income = types.InlineKeyboardButton("🎁 Собрать Доход", callback_data="claim_income")
    b_containers = types.InlineKeyboardButton("🧰 Военные Кейсы", callback_data="menu_containers")
    b_airdrop = types.InlineKeyboardButton("📦 Эирдроп Зоны", callback_data="menu_airdrop")

    markup.add(b_profile, b_squad)
    markup.add(b_stash, b_market)
    markup.add(b_hideout, b_supply)
    markup.add(b_raids, b_darkzone)
    markup.add(b_income, b_containers)
    markup.add(b_airdrop)

    if is_admin(user["user_id"], user.get("username")):
        markup.add(types.InlineKeyboardButton("👑 Admin-панель (@revenuts)", callback_data="menu_admin"))

    return markup

# ----------------- START & PMC SELECTION -----------------

@bot.message_handler(commands=['start', 'help'])
def cmd_start(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    player, db = get_player(user_id, username)

    # If player does not exist or has no PMC chosen yet
    if not player or not player.get("pmc_signature"):
        txt = (
            "<b>⚔️ ДОБРО ПОЖАЛОВАТЬ В ТАРКОВ: МЕНЕДЖЕР ЧВК</b>\n\n"
            "Норвинская область охвачена войной. Прежде чем выйти в рейд и развернуть Убежище, "
            "<b>вы обязаны навсегда выбрать своего Сигнатурного ЧВК</b>.\n\n"
            "Каждый ЧВК дает нерушимый пассивный бафф вашей военной корпорации:\n\n"
        )
        for key, p in PMC_DEFINITIONS.items():
            if key == "Revenant":
                continue
            txt += f"{p['icon']} <b>{p['name']}</b>: {p['desc']}\n"

        markup = types.InlineKeyboardMarkup(row_width=2)
        buttons = []
        for key, p in PMC_DEFINITIONS.items():
            if key == "Revenant":
                continue
            buttons.append(types.InlineKeyboardButton(f"{p['icon']} {p['name']}", callback_data=f"select_pmc_{key}"))

        # Add buttons in pairs
        for i in range(0, len(buttons), 2):
            markup.row(*buttons[i:i+2])

        if is_admin(user_id, username):
            markup.add(types.InlineKeyboardButton("💀 REVENANT [ADMIN EXCLUSIVE]", callback_data="select_pmc_Revenant"))

        bot.send_message(message.chat.id, txt, reply_markup=markup)
        return

    # Registered player -> Main menu
    show_main_menu(message.chat.id, player)

def show_main_menu(chat_id, user, message_id=None):
    pow_val, arm_val = calculate_squad_power(user)
    pmc = user.get("pmc_signature", "Viper")
    pmc_icon = PMC_DEFINITIONS.get(pmc, {}).get("icon", "🎖️")

    rank_title = "Рядовой ЧВК"
    if is_admin(user["user_id"], user.get("username")) or pmc == "Revenant":
        rank_title = "💀 [ADMIN] 💰 REVENANT GD 💰 💀"
    elif user.get("hideout_lvl", 1) >= 8:
        rank_title = "Генерал Норвинского Сектора"
    elif user.get("hideout_lvl", 1) >= 5:
        rank_title = "Командир Синдиката"
    elif user.get("hideout_lvl", 1) >= 3:
        rank_title = "Опытный Наемник"

    txt = (
        f"<b>🏢 ШТАБ-КВАРТИРА ЧВК: {user.get('username', 'Оператор')}</b>\n"
        f"Статус: <b>{rank_title}</b>\n"
        f"Сигнатурный ЧВК: {pmc_icon} <b>{pmc}</b>\n"
        f"────────────────────────\n"
        f"💰 Баланс: <b>{fmt_rub(user.get('money', 0))}</b> | 🪙 BTC: <b>{user.get('btc', 0):.4f}</b>\n"
        f"🪖 Отряд: <b>{len(user.get('squad', []))}/5 бойцов</b>\n"
        f"⚔️ Огневая мощь: <b>{pow_val}</b> | 🛡️ Броня: <b>{arm_val}</b>\n"
        f"🏚️ Убежище: <b>Уровень {user.get('hideout_lvl', 1)}/10</b>\n"
        f"────────────────────────\n"
        f"<i>Выберите действие в меню ниже:</i>"
    )
    markup = get_main_menu_markup(user)
    if message_id:
        try:
            bot.edit_message_text(txt, chat_id, message_id, reply_markup=markup)
            return
        except Exception:
            pass
    bot.send_message(chat_id, txt, reply_markup=markup)

# ----------------- CALLBACK QUERY DISPATCHER -----------------

@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    user_id = call.from_user.id
    username = call.from_user.username or call.from_user.first_name
    data = call.data
    chat_id = call.message.chat.id
    msg_id = call.message.message_id

    # 1. PMC Selection
    if data.startswith("select_pmc_"):
        pmc_key = data.replace("select_pmc_", "")
        if pmc_key == "Revenant" and not is_admin(user_id, username):
            bot.answer_callback_query(call.id, "❌ ЧВК Revenant доступен только @revenuts!", show_alert=True)
            return

        db = load_db()
        player = create_new_player(user_id, username, pmc_key)
        db["users"][str(user_id)] = player
        save_db(db)

        p_info = PMC_DEFINITIONS.get(pmc_key, {})
        bot.answer_callback_query(call.id, f"✅ Вы выбрали ЧВК {pmc_key}!")
        bot.send_message(
            chat_id,
            f"🎉 <b>Добро пожаловать на службу, ЧВК {pmc_key}!</b>\n\n"
            f"{p_info.get('icon', '🎖️')} <b>Ваш бонус:</b> {p_info.get('desc')}\n\n"
            f"Вам выдано стартовое снаряжение со стоимостью:\n"
            f"• 💰 <b>50 000 ₽</b> наличными\n"
            f"• 🪖 <b>1 Нанятый боец</b> (Дикий #1)\n"
            f"• 🔫 <b>АК-74М</b> — {fmt_rub(38000)}\n"
            f"• 🔫 <b>ТОЗ-106</b> — {fmt_rub(9500)}\n"
            f"• 💊 <b>Аптечка АИ-2 (2 шт)</b> — {fmt_rub(24000)}\n"
            f"• 🩹 <b>Бинт и медицинская шина</b> — {fmt_rub(14000)}\n"
            f"• 📦 <b>Патроны 5.45x39 БТ (120 шт)</b> — {fmt_rub(48000)}\n"
            f"• 🏢 <b>4 склада снабжения</b> 1-го уровня"
        )
        show_main_menu(chat_id, player)
        return

    player, db = get_player(user_id, username)
    if not player:
        bot.answer_callback_query(call.id, "⚠️ Начните игру через /start", show_alert=True)
        return

    # Navigation
    if data == "main_menu":
        bot.answer_callback_query(call.id)
        show_main_menu(chat_id, player, msg_id)
        return

    # Profile
    elif data == "menu_profile":
        bot.answer_callback_query(call.id)
        handle_menu_profile(chat_id, msg_id, player)
        return

    # Squad & Recruitment
    elif data == "menu_squad":
        bot.answer_callback_query(call.id)
        handle_menu_squad(chat_id, msg_id, player)
        return

    elif data == "hire_scav":
        handle_hire_fighter(call, player, db, "scav", 2500)
        return

    elif data == "hire_pmc":
        handle_hire_fighter(call, player, db, "pmc", 25000)
        return

    elif data == "auto_equip_squad":
        handle_auto_equip(call, player, db)
        return

    elif data == "squad_select_custom":
        handle_custom_equip_list(chat_id, msg_id, player)
        return

    elif data.startswith("equip_fighter_"):
        f_id = int(data.replace("equip_fighter_", ""))
        handle_fighter_loadout_view(chat_id, msg_id, player, f_id)
        return

    elif data.startswith("choose_weapon_"):
        f_id = int(data.replace("choose_weapon_", ""))
        handle_choose_item_slot(chat_id, msg_id, player, f_id, "weapons")
        return

    elif data.startswith("choose_armor_"):
        f_id = int(data.replace("choose_armor_", ""))
        handle_choose_item_slot(chat_id, msg_id, player, f_id, "armor")
        return

    elif data.startswith("apply_equip_"):
        # format: apply_equip_<fighter_id>_<uid>
        parts = data.split("_")
        f_id = int(parts[2])
        uid = parts[3]
        handle_apply_equip(call, player, db, f_id, uid)
        return

    elif data.startswith("unequip_fighter_"):
        f_id = int(data.replace("unequip_fighter_", ""))
        handle_unequip_fighter(call, player, db, f_id)
        return

    elif data == "dismiss_squad":
        handle_dismiss_squad(call, player, db)
        return

    # Warehouses & Stash
    elif data == "menu_stash":
        bot.answer_callback_query(call.id)
        handle_menu_stash(chat_id, msg_id, player)
        return

    elif data.startswith("view_wh_"):
        cat = data.replace("view_wh_", "")
        handle_view_warehouse(chat_id, msg_id, player, cat)
        return

    elif data == "upgrade_warehouses_menu":
        bot.answer_callback_query(call.id)
        handle_upgrade_warehouses_menu(chat_id, msg_id, player)
        return

    elif data.startswith("upg_wh_"):
        cat = data.replace("upg_wh_", "")
        handle_upgrade_warehouse_action(call, player, db, cat)
        return

    elif data == "prapor_buyout_menu":
        bot.answer_callback_query(call.id)
        handle_prapor_menu(chat_id, msg_id, player)
        return

    elif data.startswith("sell_prapor_"):
        uid = data.replace("sell_prapor_", "")
        handle_sell_to_prapor(call, player, db, uid)
        return

    elif data == "prapor_sell_all_junk":
        handle_prapor_sell_all_junk(call, player, db)
        return

    elif data.startswith("inspect_item_"):
        uid = data.replace("inspect_item_", "")
        bot.answer_callback_query(call.id)
        handle_inspect_item(chat_id, msg_id, player, uid)
        return

    elif data == "menu_containers":
        bot.answer_callback_query(call.id)
        handle_menu_containers(chat_id, msg_id, player)
        return

    elif data.startswith("open_cnt_"):
        cid = data.replace("open_cnt_", "")
        handle_open_container(call, player, db, cid)
        return

    # Hideout & Businesses
    elif data == "menu_hideout":
        bot.answer_callback_query(call.id)
        handle_menu_hideout(chat_id, msg_id, player)
        return

    elif data == "upgrade_hideout":
        handle_upgrade_hideout(call, player, db)
        return

    elif data == "menu_modules":
        bot.answer_callback_query(call.id)
        handle_menu_modules(chat_id, msg_id, player)
        return

    elif data.startswith("upg_mod_"):
        mod_key = data.replace("upg_mod_", "")
        handle_upgrade_module(call, player, db, mod_key)
        return

    elif data == "menu_businesses":
        bot.answer_callback_query(call.id)
        handle_menu_businesses(chat_id, msg_id, player)
        return

    elif data.startswith("upg_biz_"):
        biz_key = data.replace("upg_biz_", "")
        handle_upgrade_business(call, player, db, biz_key)
        return

    # Passive income claim
    elif data == "claim_income":
        handle_claim_income(call, player, db)
        return

    # Supplies / Contraband
    elif data == "menu_supply":
        bot.answer_callback_query(call.id)
        handle_menu_supply(chat_id, msg_id, player)
        return

    elif data == "order_supply_ground":
        handle_order_supply(call, player, db, "ground", 15000, 1800)
        return

    elif data == "order_supply_sea":
        handle_order_supply(call, player, db, "sea", 50000, 7200)
        return

    elif data == "claim_supply":
        handle_claim_supply(call, player, db)
        return

    elif data == "upgrade_supply_channel":
        handle_upgrade_supply_channel(call, player, db)
        return

    # Market & Flea
    elif data == "menu_market":
        bot.answer_callback_query(call.id)
        handle_menu_market(chat_id, msg_id, player)
        return

    elif data.startswith("market_cat_"):
        cat_name = data.replace("market_cat_", "")
        handle_market_catalog(chat_id, msg_id, player, cat_name, page=1)
        return

    elif data.startswith("market_page_"):
        # format: market_page_<cat>_<page>
        parts = data.split("_")
        cat_name = parts[2]
        page = int(parts[3])
        handle_market_catalog(chat_id, msg_id, player, cat_name, page)
        return

    elif data == "market_sell_btc":
        handle_sell_btc(call, player, db)
        return

    elif data == "market_p2p":
        handle_p2p_market(chat_id, msg_id, player, db)
        return

    elif data.startswith("buy_p2p_"):
        lot_id = data.replace("buy_p2p_", "")
        handle_buy_p2p_lot(call, player, db, lot_id)
        return

    elif data == "p2p_list_menu":
        bot.answer_callback_query(call.id)
        handle_p2p_list_menu(chat_id, msg_id, player)
        return

    elif data.startswith("p2p_list_"):
        uid = data.replace("p2p_list_", "")
        handle_p2p_list_action(call, player, db, uid)
        return

    # Raids
    elif data == "menu_raids":
        bot.answer_callback_query(call.id)
        handle_menu_raids(chat_id, msg_id, player)
        return

    elif data.startswith("start_raid_"):
        loc_key = data.replace("start_raid_", "")
        handle_start_raid(call, player, db, loc_key)
        return

    # Darkzone PvP
    elif data == "menu_darkzone":
        bot.answer_callback_query(call.id)
        handle_menu_darkzone(chat_id, msg_id, player, db)
        return

    elif data.startswith("create_duel_"):
        bet = int(data.replace("create_duel_", ""))
        handle_create_duel(call, player, db, bet)
        return

    elif data.startswith("accept_duel_"):
        duel_id = data.replace("accept_duel_", "")
        handle_accept_duel(call, player, db, duel_id)
        return

    # Airdrop
    elif data == "menu_airdrop":
        bot.answer_callback_query(call.id)
        handle_menu_airdrop(chat_id, msg_id, player, db)
        return

    elif data == "loot_airdrop_box":
        handle_loot_airdrop(call, player, db)
        return

    # Admin Panel
    elif data == "menu_admin":
        if not is_admin(user_id, username):
            bot.answer_callback_query(call.id, "❌ Доступ запрещен!", show_alert=True)
            return
        bot.answer_callback_query(call.id)
        handle_menu_admin(chat_id, msg_id, player)
        return

    elif data.startswith("admin_action_"):
        act = data.replace("admin_action_", "")
        handle_admin_action(call, player, db, act)
        return

# ----------------- SECTION 1: PROFILE -----------------

def handle_menu_profile(chat_id, msg_id, player):
    pmc = player.get("pmc_signature", "Viper")
    p_info = PMC_DEFINITIONS.get(pmc, {})
    pow_val, arm_val = calculate_squad_power(player)
    st = player.get("stats", {})

    rank_title = "Рядовой ЧВК"
    if is_admin(player["user_id"], player.get("username")) or pmc == "Revenant":
        rank_title = "💀 [ADMIN] 💰 REVENANT GD 💰 💀"
    elif player.get("hideout_lvl", 1) >= 8:
        rank_title = "Генерал Норвинского Сектора"
    elif player.get("hideout_lvl", 1) >= 5:
        rank_title = "Командир Синдиката"
    elif player.get("hideout_lvl", 1) >= 3:
        rank_title = "Опытный Наемник"

    txt = (
        f"<b>👤 ДОСЬЕ ОПЕРАТОРА: @{player.get('username', 'Unknown')}</b>\n"
        f"Воинский ранг: <b>{rank_title}</b>\n"
        f"────────────────────────\n"
        f"Сигнатурный ЧВК: {p_info.get('icon', '🎖️')} <b>{pmc}</b>\n"
        f"Пассивный навык: <i>{p_info.get('desc')}</i>\n"
        f"────────────────────────\n"
        f"💰 Финансы: <b>{fmt_rub(player.get('money', 0))}</b>\n"
        f"🪙 Биткоины: <b>{player.get('btc', 0):.4f} BTC</b>\n"
        f"🪖 Бойцов в отряде: <b>{len(player.get('squad', []))}/5</b>\n"
        f"⚔️ Огневая мощь: <b>{pow_val}</b>\n"
        f"🛡️ Суммарная броня: <b>{arm_val}</b>\n"
        f"📦 Предметов в схроне: <b>{len(player.get('stash', []))} шт.</b>\n"
        f"────────────────────────\n"
        f"📊 <b>Боевая статистика:</b>\n"
        f"• Рейдов завершено: {st.get('raids_count', 0)}\n"
        f"• Побед в Даркзоне: {st.get('pvp_wins', 0)}\n"
        f"• Поражений в Даркзоне: {st.get('pvp_losses', 0)}\n"
        f"• Залутано Эирдропов: {st.get('airdrop_looted', 0)}"
    )
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

# ----------------- SECTION 2: SQUAD & GEAR -----------------

def handle_menu_squad(chat_id, msg_id, player):
    squad = player.get("squad", [])
    stash = {itm["uid"]: itm for itm in player.get("stash", [])}
    pow_val, arm_val = calculate_squad_power(player)

    txt = (
        f"<b>🪖 ЛИЧНЫЙ ОТРЯД ЧВК ({len(squad)}/5)</b>\n"
        f"Суммарная мощь оружия: <b>+{pow_val}</b> | Броня: <b>+{arm_val}</b>\n"
        f"────────────────────────\n"
    )
    if not squad:
        txt += "<i>У вас пока нет нанятых бойцов. Наймите Дикого или ЧВК ниже.</i>\n"
    else:
        for idx, f in enumerate(squad, 1):
            f_type = "Дикий" if f.get("type") == "scav" else "ЧВК"
            w_name = "Кулаки"
            a_name = "Гражданская одежда"
            if f.get("weapon_uid") and f["weapon_uid"] in stash:
                w_item = ITEMS_BY_ID.get(stash[f["weapon_uid"]]["item_id"], {})
                w_name = f"{w_item.get('name', 'Оружие')} (+{w_item.get('combat', 0)})"
            if f.get("armor_uid") and f["armor_uid"] in stash:
                a_item = ITEMS_BY_ID.get(stash[f["armor_uid"]]["item_id"], {})
                a_name = f"{a_item.get('name', 'Броня')} (+{a_item.get('armor', 0)})"

            txt += (
                f"<b>Боец #{idx} [{f_type}]</b>\n"
                f"• 🔫 Оружие: <i>{w_name}</i>\n"
                f"• 🛡️ Броня: <i>{a_name}</i>\n\n"
            )

    txt += (
        "<i>Экипированные предметы резервируются на Складе. "
        "В случае поражения в Даркзоне отряд погибает, а надетое снаряжение сгорает навсегда!</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if len(squad) < 5:
        markup.add(
            types.InlineKeyboardButton("➕ Нанять Дикого | 2,500 ₽", callback_data="hire_scav"),
            types.InlineKeyboardButton("➕ Нанять ЧВК | 25,000 ₽", callback_data="hire_pmc")
        )
    else:
        markup.add(types.InlineKeyboardButton("⚠️ Отряд полон (5/5 бойцов)", callback_data="none"))

    if squad:
        markup.add(types.InlineKeyboardButton("📦 Снарядить Всё Автоматом", callback_data="auto_equip_squad"))
        markup.add(types.InlineKeyboardButton("🎒 Надеть Выборочно", callback_data="squad_select_custom"))
        markup.add(types.InlineKeyboardButton("❌ Распустить Весь Отряд", callback_data="dismiss_squad"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_hire_fighter(call, player, db, f_type, cost):
    if len(player.get("squad", [])) >= 5:
        bot.answer_callback_query(call.id, "❌ В отряде уже максимум 5 бойцов!", show_alert=True)
        return

    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно средств! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    new_id = len(player.get("squad", [])) + 1
    fighter_name = f"Дикий #{new_id}" if f_type == "scav" else f"ЧВК #{new_id}"
    player["squad"].append({
        "id": new_id,
        "type": f_type,
        "name": fighter_name,
        "weapon_uid": None,
        "armor_uid": None
    })
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Вы наняли {fighter_name} за {fmt_rub(cost)}!")
    handle_menu_squad(call.message.chat.id, call.message.message_id, player)

def handle_auto_equip(call, player, db):
    squad = player.get("squad", [])
    if not squad:
        bot.answer_callback_query(call.id, "❌ В отряде нет бойцов!", show_alert=True)
        return

    stash = player.get("stash", [])
    # Find free weapons and armors
    free_weapons = []
    free_armors = []

    for itm in stash:
        if itm.get("equipped_to") is None:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            if info.get("category") == "weapons":
                free_weapons.append((info.get("combat", 0), itm))
            elif info.get("category") == "armor":
                free_armors.append((info.get("armor", 0), itm))

    free_weapons.sort(key=lambda x: x[0], reverse=True)
    free_armors.sort(key=lambda x: x[0], reverse=True)

    w_idx = 0
    a_idx = 0
    equipped_count = 0

    for f in squad:
        # Equip weapon if not equipped
        if not f.get("weapon_uid") and w_idx < len(free_weapons):
            _, itm = free_weapons[w_idx]
            w_idx += 1
            f["weapon_uid"] = itm["uid"]
            itm["equipped_to"] = f["id"]
            equipped_count += 1

        # Equip armor if not equipped
        if not f.get("armor_uid") and a_idx < len(free_armors):
            _, itm = free_armors[a_idx]
            a_idx += 1
            f["armor_uid"] = itm["uid"]
            itm["equipped_to"] = f["id"]
            equipped_count += 1

    save_db(db)
    bot.answer_callback_query(call.id, f"✅ Авто-экипировка завершена! Выдано {equipped_count} топ-предметов.", show_alert=True)
    handle_menu_squad(call.message.chat.id, call.message.message_id, player)

def handle_custom_equip_list(chat_id, msg_id, player):
    squad = player.get("squad", [])
    txt = (
        "<b>🎒 ВЫБОРОЧНАЯ ЭКИПИРОВКА БОЙЦОВ</b>\n\n"
        "Кликните на конкретного бойца, чтобы выбрать и выдать ему оружие "
        "из Оружейного арсенала или бронежилет из Броне-ангара:"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    for f in squad:
        f_type = "Дикий" if f.get("type") == "scav" else "ЧВК"
        markup.add(types.InlineKeyboardButton(f"👤 Боец #{f['id']} [{f_type}]", callback_data=f"equip_fighter_{f['id']}"))
    markup.add(types.InlineKeyboardButton("🔙 К Отряду", callback_data="menu_squad"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_fighter_loadout_view(chat_id, msg_id, player, f_id):
    squad = player.get("squad", [])
    target = next((f for f in squad if f["id"] == f_id), None)
    if not target:
        handle_menu_squad(chat_id, msg_id, player)
        return

    stash = {itm["uid"]: itm for itm in player.get("stash", [])}
    w_name = "(Не экипировано)"
    a_name = "(Не экипировано)"
    if target.get("weapon_uid") and target["weapon_uid"] in stash:
        w_item = ITEMS_BY_ID.get(stash[target["weapon_uid"]]["item_id"], {})
        w_name = f"{w_item.get('name')} [Урон +{w_item.get('combat', 0)}]"
    if target.get("armor_uid") and target["armor_uid"] in stash:
        a_item = ITEMS_BY_ID.get(stash[target["armor_uid"]]["item_id"], {})
        a_name = f"{a_item.get('name')} [Защита +{a_item.get('armor', 0)}]"

    txt = (
        f"<b>🪖 СНАРЯЖЕНИЕ: {target.get('name')}</b>\n"
        f"Тип: <b>{'Дикий' if target.get('type') == 'scav' else 'ЧВК'}</b>\n"
        f"────────────────────────\n"
        f"🔫 Текущее оружие: <b>{w_name}</b>\n"
        f"🛡️ Текущая броня: <b>{a_name}</b>\n"
        f"────────────────────────\n"
        f"Выберите, какой слот изменить из вашего Склада:"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🔫 Выбрать Ствол из Оружейного", callback_data=f"choose_weapon_{f_id}"),
        types.InlineKeyboardButton("🛡️ Выбрать Броню из Броне-ангара", callback_data=f"choose_armor_{f_id}"),
        types.InlineKeyboardButton("❌ Снять Всё Снаряжение", callback_data=f"unequip_fighter_{f_id}"),
        types.InlineKeyboardButton("🔙 К списку бойцов", callback_data="squad_select_custom")
    )
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_choose_item_slot(chat_id, msg_id, player, f_id, category):
    stash = player.get("stash", [])
    free_items = []
    for itm in stash:
        if itm.get("equipped_to") is None:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            if info.get("category") == category:
                free_items.append((itm, info))

    cat_name = "Оружейного склада" if category == "weapons" else "Броне-ангара"
    txt = f"<b>📦 ВЫБОР ИЗ {cat_name.upper()}</b>\nДоступно свободных предметов: {len(free_items)}\n"

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not free_items:
        txt += "<i>На складе нет свободных предметов этой категории!</i>\n"
    else:
        # Show top 15 items
        for itm, info in free_items[:15]:
            val_stat = f"+{info.get('combat', 0)} ур." if category == "weapons" else f"+{info.get('armor', 0)} бр."
            btn_txt = f"{info.get('name')} [{val_stat}]"
            markup.add(types.InlineKeyboardButton(btn_txt, callback_data=f"apply_equip_{f_id}_{itm['uid']}"))

    markup.add(types.InlineKeyboardButton("🔙 Назад к бойцу", callback_data=f"equip_fighter_{f_id}"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_apply_equip(call, player, db, f_id, uid):
    target = next((f for f in player.get("squad", []) if f["id"] == f_id), None)
    stash_item = next((i for i in player.get("stash", []) if i["uid"] == uid), None)

    if not target or not stash_item:
        bot.answer_callback_query(call.id, "❌ Ошибка экипировки!", show_alert=True)
        return

    info = ITEMS_BY_ID.get(stash_item.get("item_id"), {})
    cat = info.get("category")

    # If slot already had an item, unequip previous
    if cat == "weapons":
        old_uid = target.get("weapon_uid")
        if old_uid:
            old_item = next((i for i in player.get("stash", []) if i["uid"] == old_uid), None)
            if old_item:
                old_item["equipped_to"] = None
        target["weapon_uid"] = uid
    elif cat == "armor":
        old_uid = target.get("armor_uid")
        if old_uid:
            old_item = next((i for i in player.get("stash", []) if i["uid"] == old_uid), None)
            if old_item:
                old_item["equipped_to"] = None
        target["armor_uid"] = uid

    stash_item["equipped_to"] = f_id
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Выдали: {info.get('name')}")
    handle_fighter_loadout_view(call.message.chat.id, call.message.message_id, player, f_id)

def handle_unequip_fighter(call, player, db, f_id):
    target = next((f for f in player.get("squad", []) if f["id"] == f_id), None)
    if not target:
        return

    stash = {i["uid"]: i for i in player.get("stash", [])}
    if target.get("weapon_uid") and target["weapon_uid"] in stash:
        stash[target["weapon_uid"]]["equipped_to"] = None
        target["weapon_uid"] = None
    if target.get("armor_uid") and target["armor_uid"] in stash:
        stash[target["armor_uid"]]["equipped_to"] = None
        target["armor_uid"] = None

    save_db(db)
    bot.answer_callback_query(call.id, "✅ Всё снаряжение снято и возвращено на склад.")
    handle_fighter_loadout_view(call.message.chat.id, call.message.message_id, player, f_id)

def handle_dismiss_squad(call, player, db):
    # Free all equipped items first
    for itm in player.get("stash", []):
        itm["equipped_to"] = None
    player["squad"] = []
    save_db(db)
    bot.answer_callback_query(call.id, "✅ Весь отряд распущен. Все вещи возвращены в схрон.")
    handle_menu_squad(call.message.chat.id, call.message.message_id, player)

# ----------------- SECTION 3: WAREHOUSES & PRAPOR -----------------

def handle_menu_stash(chat_id, msg_id, player):
    txt = "<b>📦 СПЕЦИАЛИЗИРОВАННЫЕ СКЛАДЫ ЧВК</b>\n\n"
    for cat_k, cat_name in WAREHOUSE_NAMES.items():
        cap = get_warehouse_capacity(player, cat_k)
        cnt = get_warehouse_count(player, cat_k)
        lvl = player.get("warehouses", {}).get(cat_k, 1)
        bar = "🟩" if cnt < cap else "🟥"
        txt += f"• <b>{cat_name}</b> (Ур. {lvl}): {bar} {cnt}/{cap} слотов\n"

    txt += (
        "\n<i>Вещи разделены по категориям. "
        "Скупка Прапора позволяет быстро продать лут за 30% стоимости (40% с ЧВК Fenrir).</i>"
    )
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("🔫 Оружейный", callback_data="view_wh_weapons"),
        types.InlineKeyboardButton("🛡️ Броне-ангар", callback_data="view_wh_armor")
    )
    markup.add(
        types.InlineKeyboardButton("🎒 Вещевой", callback_data="view_wh_gear"),
        types.InlineKeyboardButton("🔩 Компонентов", callback_data="view_wh_components")
    )
    markup.add(
        types.InlineKeyboardButton("🔼 Расширить Склады", callback_data="upgrade_warehouses_menu"),
        types.InlineKeyboardButton("💰 Скупка Прапора", callback_data="prapor_buyout_menu")
    )
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_view_warehouse(chat_id, msg_id, player, cat):
    cat_name = WAREHOUSE_NAMES.get(cat, "Склад")
    cap = get_warehouse_capacity(player, cat)
    stash = player.get("stash", [])
    items = []
    for itm in stash:
        info = ITEMS_BY_ID.get(itm.get("item_id"), {})
        if info.get("category") == cat:
            items.append((itm, info))

    rate = 0.40 if has_buff(player, "prapor_bonus") else 0.30
    pct = int(rate * 100)

    txt = (
        f"<b>📦 {cat_name.upper()} ({len(items)}/{cap} слотов)</b>\n"
        f"<i>Скупка Прапора: {pct}% от каталога. Нажмите на предмет для детального осмотра и продажи:</i>\n"
        f"────────────────────────\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    if not items:
        txt += "<i>Склад пуст.</i>\n"
    else:
        for idx, (itm, info) in enumerate(items[:15], 1):
            eq = " [🪖 НАДЕТ]" if itm.get("equipped_to") else ""
            r_badge = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(info.get("rarity"), "⬜")
            cat_p = info.get('price', 0)
            prap_p = int(cat_p * rate)
            txt += (
                f"{idx}. {r_badge} <b>{info.get('name')}</b>{eq}\n"
                f"   🏷️ Каталог: <b>{fmt_rub(cat_p)}</b> | 💰 Скупка: <b>+{fmt_rub(prap_p)}</b>\n"
            )
            if not itm.get("equipped_to"):
                markup.add(
                    types.InlineKeyboardButton(
                        f"🔍 {info.get('name')[:18]} (Сдать: +{fmt_rub(prap_p)})",
                        callback_data=f"inspect_item_{itm['uid']}"
                    )
                )

    markup.add(
        types.InlineKeyboardButton("💰 Скупка всего хлама у Прапора", callback_data="prapor_buyout_menu"),
        types.InlineKeyboardButton("🔙 К складам", callback_data="menu_stash")
    )
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_inspect_item(chat_id, msg_id, player, uid):
    item_entry = next((i for i in player.get("stash", []) if i.get("uid") == uid), None)
    if not item_entry:
        bot.edit_message_text(
            "❌ Предмет не найден в схроне.",
            chat_id, msg_id,
            reply_markup=types.InlineKeyboardMarkup().add(types.InlineKeyboardButton("🔙 К складам", callback_data="menu_stash"))
        )
        return

    info = ITEMS_BY_ID.get(item_entry.get("item_id"), {})
    rate = 0.40 if has_buff(player, "prapor_bonus") else 0.30
    pct = int(rate * 100)
    cat_price = info.get("price", 0)
    prapor_price = int(cat_price * rate)
    r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(info.get("rarity"), "⬜")

    txt = (
        f"🔍 <b>ОСМОТР ПРЕДМЕТА #{uid[-6:]}</b>\n"
        f"────────────────────────\n"
        f"{r_b} <b>{info.get('name')}</b>\n"
        f"Категория: <b>{WAREHOUSE_NAMES.get(info.get('category'), info.get('category'))}</b>\n"
        f"Редкость: <b>{info.get('rarity', 'common').upper()}</b>\n\n"
        f"<i>{info.get('desc', 'Военное снаряжение из Таркова.')}</i>\n\n"
        f"📊 <b>ФИНАНСОВЫЕ КОТИРОВКИ ПЕРЕД ПРОДАЖЕЙ:</b>\n"
        f"• 🏷️ <b>Каталожная стоимость:</b> {fmt_rub(cat_price)}\n"
        f"• 💰 <b>Скупка Прапора (перед продажей):</b> <b>+{fmt_rub(prapor_price)}</b> ({pct}% от каталога)\n"
        f"• 🛒 <b>Ориентир P2P Барахолки:</b> ~{fmt_rub(cat_price)}\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not item_entry.get("equipped_to"):
        markup.add(
            types.InlineKeyboardButton(f"💰 Продать Прапору | +{fmt_rub(prapor_price)}", callback_data=f"sell_prapor_{uid}"),
            types.InlineKeyboardButton(f"📤 Выставить на P2P | {fmt_rub(cat_price)}", callback_data=f"p2p_list_{uid}")
        )
    else:
        txt += f"\n⚠️ <i>Предмет надет на бойца #{item_entry.get('equipped_to')}. Сначала снимите его для продажи.</i>\n"

    markup.add(types.InlineKeyboardButton("🔙 Назад к складу", callback_data=f"view_wh_{info.get('category', 'gear')}"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_sell_to_prapor(call, player, db, uid):
    rate = 0.40 if has_buff(player, "prapor_bonus") else 0.30
    stash = player.get("stash", [])
    item_entry = next((i for i in stash if i.get("uid") == uid), None)
    if not item_entry:
        bot.answer_callback_query(call.id, "❌ Предмет не найден в схроне!", show_alert=True)
        return

    if item_entry.get("equipped_to"):
        bot.answer_callback_query(call.id, "❌ Предмет надет на бойца! Сначала снимите его.", show_alert=True)
        return

    info = ITEMS_BY_ID.get(item_entry.get("item_id"), {})
    cat_price = info.get("price", 0)
    payout = int(cat_price * rate)

    stash.remove(item_entry)
    player["money"] = player.get("money", 0) + payout
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"✅ Продано: {info.get('name')}!\n"
        f"🏷️ Каталог: {fmt_rub(cat_price)}\n"
        f"💰 Выплата Прапора: +{fmt_rub(payout)}\n"
        f"💵 Ваш баланс: {fmt_rub(player['money'])}",
        show_alert=True
    )
    cat = info.get("category", "gear")
    handle_view_warehouse(call.message.chat.id, call.message.message_id, player, cat)

def handle_upgrade_warehouses_menu(chat_id, msg_id, player):
    txt = (
        "<b>🔼 РАСШИРЕНИЕ ВМЕСТИМОСТИ СКЛАДОВ</b>\n\n"
        "Каждый уровень расширяет склад на дополнительные ячейки. "
        "Точная стоимость улучшения указана прямо на кнопках:"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    for cat_k, cat_name in WAREHOUSE_NAMES.items():
        cur_lvl = player.get("warehouses", {}).get(cat_k, 1)
        next_cost = get_warehouse_upgrade_cost(cur_lvl)
        if next_cost:
            btn_txt = f"🔼 {cat_name} до {cur_lvl+1} ур. | {fmt_rub(next_cost)}"
            markup.add(types.InlineKeyboardButton(btn_txt, callback_data=f"upg_wh_{cat_k}"))
        else:
            markup.add(types.InlineKeyboardButton(f"✅ {cat_name}: Макс. 10 ур.", callback_data="none"))

    markup.add(types.InlineKeyboardButton("🔙 К складам", callback_data="menu_stash"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_upgrade_warehouse_action(call, player, db, cat):
    cur_lvl = player.get("warehouses", {}).get(cat, 1)
    cost = get_warehouse_upgrade_cost(cur_lvl)
    if not cost:
        bot.answer_callback_query(call.id, "❌ Склад уже максимального уровня!", show_alert=True)
        return

    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    player["warehouses"][cat] = cur_lvl + 1
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Склад расширен до {cur_lvl + 1} уровня!")
    handle_upgrade_warehouses_menu(call.message.chat.id, call.message.message_id, player)

def handle_prapor_menu(chat_id, msg_id, player):
    rate = 0.40 if has_buff(player, "prapor_bonus") else 0.30
    pct = int(rate * 100)

    # Calculate junk value and preview list
    junk_val = 0
    cat_val = 0
    junk_count = 0
    junk_items = []

    for itm in player.get("stash", []):
        if not itm.get("equipped_to"):
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            if info.get("rarity") in ["common", "rare"] and info.get("category") in ["gear", "components"]:
                p = info.get("price", 0)
                cat_val += p
                junk_val += int(p * rate)
                junk_count += 1
                if len(junk_items) < 6:
                    junk_items.append((itm, info, p, int(p * rate)))

    txt = (
        f"<b>💰 СКУПКА ПРАПОРА ({pct}% от каталожной цены)</b>\n\n"
        f"<i>«Здорово, боец! Тащи сюда весь трофейный хлам — плачу моментально живыми рублями. "
        f"Моя ставка: {pct}% от каталожной цены.»</i>\n\n"
    )

    if junk_items:
        txt += "<b>Предметы, готовые к продаже:</b>\n"
        for _, info, cat_p, prap_p in junk_items:
            r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(info.get("rarity"), "⬜")
            txt += f"• {r_b} <b>{info.get('name')}</b>\n   🏷️ Каталог: {fmt_rub(cat_p)} ➔ 💰 Прапор: <b>+{fmt_rub(prap_p)}</b>\n"
        if junk_count > len(junk_items):
            txt += f"<i>...и еще {junk_count - len(junk_items)} предметов</i>\n"
        txt += "\n"

    txt += (
        f"📦 Готового к сдаче хлама: <b>{junk_count} шт.</b>\n"
        f"🏷️ Каталожная стоимость: <b>{fmt_rub(cat_val)}</b>\n"
        f"💰 Выплата перед продажей: <b>+{fmt_rub(junk_val)}</b>"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    if junk_count > 0:
        markup.add(types.InlineKeyboardButton(f"💸 Сдать весь хлам Прапору | +{fmt_rub(junk_val)}", callback_data="prapor_sell_all_junk"))
    markup.add(types.InlineKeyboardButton("🔙 К складам", callback_data="menu_stash"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_prapor_sell_all_junk(call, player, db):
    rate = 0.40 if has_buff(player, "prapor_bonus") else 0.30
    stash = player.get("stash", [])
    new_stash = []
    earned = 0
    total_cat = 0
    sold_count = 0

    for itm in stash:
        info = ITEMS_BY_ID.get(itm.get("item_id"), {})
        if not itm.get("equipped_to") and info.get("rarity") in ["common", "rare"] and info.get("category") in ["gear", "components"]:
            p = info.get("price", 0)
            total_cat += p
            earned += int(p * rate)
            sold_count += 1
        else:
            new_stash.append(itm)

    if sold_count == 0:
        bot.answer_callback_query(call.id, "❌ Нет подходящего хлама для продажи!", show_alert=True)
        return

    player["stash"] = new_stash
    player["money"] = player.get("money", 0) + earned
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"✅ Сдано {sold_count} предметов!\n"
        f"🏷️ Каталог: {fmt_rub(total_cat)}\n"
        f"💰 Получено от Прапора: +{fmt_rub(earned)}\n"
        f"💵 Баланс: {fmt_rub(player['money'])}",
        show_alert=True
    )
    handle_prapor_menu(call.message.chat.id, call.message.message_id, player)

# ----------------- SECTION 4: HIDEOUT & BUSINESSES -----------------

def handle_menu_hideout(chat_id, msg_id, player):
    h_lvl = player.get("hideout_lvl", 1)
    next_cost = HIDEOUT_UPGRADE_COSTS.get(h_lvl)

    # Calculate passive income
    total_rub_h = 0
    biz_bonus = 1.15 if has_buff(player, "business_income") else 1.0
    for b_key in BUSINESS_NAMES:
        lvl = player.get("businesses", {}).get(b_key, 0)
        total_rub_h += int(get_business_hourly_income(b_key, lvl) * biz_bonus)

    btc_lvl = player.get("modules", {}).get("mining_farm", 0)
    btc_bonus = 1.15 if has_buff(player, "btc_bonus") else 1.0
    btc_h = get_mining_hourly_btc(btc_lvl) * btc_bonus

    txt = (
        f"<b>🏚️ ГЛАВНОЕ УБЕЖИЩЕ (УРОВЕНЬ {h_lvl}/10)</b>\n"
        f"────────────────────────\n"
        f"Пассивный доход базы:\n"
        f"• 💰 Рубли: <b>+{fmt_rub(total_rub_h)}/час</b>\n"
        f"• 🪙 Биткоины: <b>+{btc_h:.4f} BTC/час</b>\n"
        f"────────────────────────\n"
        f"<i>Правило Синдиката: Уровень 10 Модулей и 4 Теневых Бизнесов "
        f"не может превышать текущий уровень Убежища!</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if next_cost:
        btn_txt = f"🔼 Улучшить Убежище до {h_lvl+1} ур. | {fmt_rub(next_cost)}"
        markup.add(types.InlineKeyboardButton(btn_txt, callback_data="upgrade_hideout"))
    else:
        markup.add(types.InlineKeyboardButton("✅ Убежище прокачано на максимум (10 ур.)", callback_data="none"))

    markup.add(
        types.InlineKeyboardButton("🛠️ 10 Модулей Убежища", callback_data="menu_modules"),
        types.InlineKeyboardButton("💼 4 Теневых Бизнеса", callback_data="menu_businesses"),
        types.InlineKeyboardButton("💵 Собрать Доход", callback_data="claim_income"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_upgrade_hideout(call, player, db):
    h_lvl = player.get("hideout_lvl", 1)
    cost = HIDEOUT_UPGRADE_COSTS.get(h_lvl)
    if not cost:
        bot.answer_callback_query(call.id, "❌ Убежище уже 10 уровня!", show_alert=True)
        return

    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно средств! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    player["hideout_lvl"] = h_lvl + 1
    save_db(db)

    bot.answer_callback_query(call.id, f"🎉 Убежище улучшено до {h_lvl + 1} уровня!")
    handle_menu_hideout(call.message.chat.id, call.message.message_id, player)

def handle_menu_modules(chat_id, msg_id, player):
    h_lvl = player.get("hideout_lvl", 1)
    txt = (
        f"<b>🛠️ 10 МОДУЛЕЙ УБЕЖИЩА (Лимит уровня: {h_lvl})</b>\n\n"
        f"Постройка стоит 50 000 ₽, каждый следующий уровень на 50% дороже. "
        f"Цены четко указаны на кнопках:\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    for mod_k, mod_name in MODULE_NAMES.items():
        cur_lvl = player.get("modules", {}).get(mod_k, 0)
        cost = get_module_upgrade_cost(cur_lvl)

        extra_info = ""
        if mod_k == "mining_farm":
            btc_val = get_mining_hourly_btc(cur_lvl)
            extra_info = f" ({btc_val:.2f} BTC/ч)"

        txt += f"• <b>{mod_name}</b>: Ур. {cur_lvl}/10{extra_info}\n"

        if cur_lvl >= h_lvl:
            markup.add(types.InlineKeyboardButton(f"🔒 {mod_name} (Требуется Убежище {cur_lvl+1} ур.)", callback_data="none"))
        elif cost:
            btn_txt = f"🔼 {mod_name} до {cur_lvl+1} ур. | {fmt_rub(cost)}"
            markup.add(types.InlineKeyboardButton(btn_txt, callback_data=f"upg_mod_{mod_k}"))
        else:
            markup.add(types.InlineKeyboardButton(f"✅ {mod_name} (Макс. 10 ур.)", callback_data="none"))

    markup.add(types.InlineKeyboardButton("🔙 К Убежищу", callback_data="menu_hideout"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_upgrade_module(call, player, db, mod_key):
    h_lvl = player.get("hideout_lvl", 1)
    cur_lvl = player.get("modules", {}).get(mod_key, 0)

    if cur_lvl >= h_lvl:
        bot.answer_callback_query(call.id, "❌ Уровень модуля не может превышать уровень Убежища!", show_alert=True)
        return

    cost = get_module_upgrade_cost(cur_lvl)
    if not cost:
        bot.answer_callback_query(call.id, "❌ Модуль максимального уровня!", show_alert=True)
        return

    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно средств! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    player["modules"][mod_key] = cur_lvl + 1
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Модуль улучшен до {cur_lvl + 1} ур.!")
    handle_menu_modules(call.message.chat.id, call.message.message_id, player)

def handle_menu_businesses(chat_id, msg_id, player):
    h_lvl = player.get("hideout_lvl", 1)
    biz_bonus = 1.15 if has_buff(player, "business_income") else 1.0

    txt = (
        f"<b>💼 4 ТЕНЕВЫХ БИЗНЕСА (Лимит уровня: {h_lvl})</b>\n\n"
        f"<i>Сбалансированная теневая экономика Таркова: от дешевой типографии "
        f"до масштабного трансграничного синдиката контрабанды. Приносят чистый доход в рублях каждый час:</i>\n\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    for biz_k, conf in BUSINESS_CONFIG.items():
        biz_name = conf["name"]
        tagline = conf.get("tagline", "")
        cur_lvl = player.get("businesses", {}).get(biz_k, 0)
        inc = int(get_business_hourly_income(biz_k, cur_lvl) * biz_bonus)
        cost = get_business_upgrade_cost(biz_k, cur_lvl)

        txt += f"• <b>{biz_name}</b> [Ур. {cur_lvl}/10]\n"
        txt += f"  └ <i>{tagline}</i>\n"
        txt += f"  └ Доход: <b>+{fmt_rub(inc)}/час</b>\n\n"

        if cur_lvl >= h_lvl:
            markup.add(types.InlineKeyboardButton(f"🔒 {biz_name} (Нужно Убежище {cur_lvl+1} ур.)", callback_data="none"))
        elif cost is not None:
            btn_txt = f"🔼 {biz_name} до {cur_lvl+1} ур. | {fmt_rub(cost)}"
            markup.add(types.InlineKeyboardButton(btn_txt, callback_data=f"upg_biz_{biz_k}"))
        else:
            markup.add(types.InlineKeyboardButton(f"✅ {biz_name} (Макс. 10 ур.)", callback_data="none"))

    markup.add(types.InlineKeyboardButton("🔙 К Убежищу", callback_data="menu_hideout"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_upgrade_business(call, player, db, biz_key):
    h_lvl = player.get("hideout_lvl", 1)
    cur_lvl = player.get("businesses", {}).get(biz_key, 0)

    if cur_lvl >= h_lvl:
        bot.answer_callback_query(call.id, "❌ Уровень бизнеса не может превышать уровень Убежища!", show_alert=True)
        return

    cost = get_business_upgrade_cost(biz_key, cur_lvl)
    if cost is None:
        bot.answer_callback_query(call.id, "❌ Бизнес максимального уровня!", show_alert=True)
        return

    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно средств! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    player["businesses"][biz_key] = cur_lvl + 1
    save_db(db)

    b_name = BUSINESS_NAMES.get(biz_key, "Бизнес")
    bot.answer_callback_query(call.id, f"✅ {b_name} улучшен до {cur_lvl + 1} ур.!")
    handle_menu_businesses(call.message.chat.id, call.message.message_id, player)

def handle_claim_income(call, player, db):
    now = int(time.time())
    last_claim = player.get("last_income_claim", now)
    elapsed = now - last_claim
    hours = min(48, int(elapsed // 3600))

    if hours < 1:
        minutes_left = int(60 - ((elapsed % 3600) // 60))
        bot.answer_callback_query(call.id, f"⏳ Доход начисляется раз в час! Осталось: {minutes_left} мин.", show_alert=True)
        return

    # Calculate total earned
    biz_bonus = 1.15 if has_buff(player, "business_income") else 1.0
    rub_per_h = sum(
        int(get_business_hourly_income(bk, lvl) * biz_bonus)
        for bk, lvl in player.get("businesses", {}).items()
    )

    btc_lvl = player.get("modules", {}).get("mining_farm", 0)
    btc_bonus = 1.15 if has_buff(player, "btc_bonus") else 1.0
    btc_per_h = get_mining_hourly_btc(btc_lvl) * btc_bonus

    total_rub = rub_per_h * hours
    total_btc = round(btc_per_h * hours, 4)

    player["money"] = player.get("money", 0) + total_rub
    player["btc"] = round(player.get("btc", 0.0) + total_btc, 4)
    player["last_income_claim"] = last_claim + (hours * 3600)
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"💵 Собрано за {hours} ч.: +{fmt_rub(total_rub)} и +{total_btc:.4f} BTC!",
        show_alert=True
    )
    show_main_menu(call.message.chat.id, player)

# ----------------- SECTION 5: REAL-TIME SUPPLIES -----------------

def handle_menu_supply(chat_id, msg_id, player):
    ch_lvl = player.get("supply_channel_lvl", 1)
    next_ch_cost = SUPPLY_CHANNEL_COSTS.get(ch_lvl)
    delivery = player.get("active_delivery")

    # Time reductions: -5% per level, -20% for Stalker/Revenant
    reduction = (ch_lvl - 1) * 0.05
    if has_buff(player, "supply_speed"):
        reduction += 0.20
    reduction = min(0.65, reduction)

    ground_time_sec = int(1800 * (1.0 - reduction))
    sea_time_sec = int(7200 * (1.0 - reduction))

    txt = (
        f"<b>🚚 КОНТРАБАНДНЫЕ ПОСТАВКИ (КАНАЛ УР. {ch_lvl}/10)</b>\n"
        f"Скорость доставки увеличена на: <b>{int(reduction * 100)}%</b>\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)

    if delivery:
        now = int(time.time())
        rem = delivery["end_time"] - now
        deliv_type = "Наземная" if delivery["type"] == "ground" else "Морская"
        if rem <= 0:
            txt += f"📦 <b>{deliv_type} поставка ПРИБЫЛА на таможенный склад!</b>\nНажмите кнопку ниже, чтобы забрать лут.\n"
            markup.add(types.InlineKeyboardButton("📦 ПРИНЯТЬ ПОСТАВКУ", callback_data="claim_supply"))
        else:
            m, s = divmod(rem, 60)
            txt += f"⏳ <b>{deliv_type} поставка в пути:</b> осталось <b>{m} мин. {s} сек.</b>\n"
    else:
        txt += (
            f"Выберите маршрут поставки:\n\n"
            f"1. 🚚 <b>Наземная</b>: {ground_time_sec // 60} мин. | Стоимость: 15,000 ₽\n"
            f"2. 🚢 <b>Морская (Тяжелый контейнер)</b>: {sea_time_sec // 60} мин. | Стоимость: 50,000 ₽\n\n"
            f"<i>Шанс на Legendary (или >300k ₽) лут: {1 + int((ch_lvl-1)*1.2)}% "
            f"(до 12% на 10 уровне, +10% Specter).</i>\n"
        )
        markup.add(
            types.InlineKeyboardButton(f"🚚 Заказать Наземную ({ground_time_sec // 60} мин) | 15,000 ₽", callback_data="order_supply_ground"),
            types.InlineKeyboardButton(f"🚢 Заказать Морскую ({sea_time_sec // 60} мин) | 50,000 ₽", callback_data="order_supply_sea")
        )

    if next_ch_cost:
        markup.add(types.InlineKeyboardButton(f"🔼 Прокачать Канал до {ch_lvl+1} ур. | {fmt_rub(next_ch_cost)}", callback_data="upgrade_supply_channel"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_order_supply(call, player, db, deliv_type, cost, base_time):
    if player.get("active_delivery"):
        bot.answer_callback_query(call.id, "❌ У вас уже есть активная поставка!", show_alert=True)
        return

    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно средств! Нужно {fmt_rub(cost)}", show_alert=True)
        return

    ch_lvl = player.get("supply_channel_lvl", 1)
    reduction = (ch_lvl - 1) * 0.05
    if has_buff(player, "supply_speed"):
        reduction += 0.20
    reduction = min(0.65, reduction)

    duration = int(base_time * (1.0 - reduction))
    now = int(time.time())

    player["money"] -= cost
    player["active_delivery"] = {
        "type": deliv_type,
        "start_time": now,
        "end_time": now + duration,
        "cost": cost
    }
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Контрабанда отправлена в путь! Таймер: {duration // 60} мин.")
    handle_menu_supply(call.message.chat.id, call.message.message_id, player)

def handle_claim_supply(call, player, db):
    delivery = player.get("active_delivery")
    if not delivery:
        bot.answer_callback_query(call.id, "❌ Нет активной поставки!", show_alert=True)
        return

    now = int(time.time())
    if delivery["end_time"] > now:
        rem = delivery["end_time"] - now
        bot.answer_callback_query(call.id, f"⏳ Груз еще не прибыл! Осталось: {rem // 60} мин.", show_alert=True)
        return

    ch_lvl = player.get("supply_channel_lvl", 1)
    count = 3 if delivery["type"] == "ground" else 5

    # Check warehouse space for rolled items
    rolled = [roll_supply_item(ch_lvl, player) for _ in range(count)]
    for itm in rolled:
        cat = itm.get("category", "gear")
        cap = get_warehouse_capacity(player, cat)
        cnt = get_warehouse_count(player, cat)
        if cnt >= cap:
            cat_name = WAREHOUSE_NAMES.get(cat, cat)
            bot.answer_callback_query(call.id, f"⚠️ Склад '{cat_name}' переполнен! Освободите место.", show_alert=True)
            return

    # Add items to stash
    total_val = sum(itm.get("price", 0) for itm in rolled)
    res_text = (
        "<b>📦 КОНТРАБАНДА УСПЕШНО ПРИБЫЛА!</b>\n"
        "────────────────────────\n"
        "<b>Полученные предметы со стоимостью:</b>\n"
    )
    for idx, itm in enumerate(rolled, 1):
        uid = f"sup_{now}_{idx}_{random.randint(100,999)}"
        player["stash"].append({"uid": uid, "item_id": itm["id"], "equipped_to": None})
        r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        res_text += f"{idx}. {r_b} <b>{itm['name']}</b> — <b>{fmt_rub(itm['price'])}</b>\n"

    res_text += (
        f"────────────────────────\n"
        f"💵 <b>Суммарная стоимость поставки:</b> <b>{fmt_rub(total_val)}</b>\n"
    )

    player["active_delivery"] = None
    save_db(db)

    bot.answer_callback_query(call.id, "✅ Груз принят на склады!")
    bot.send_message(call.message.chat.id, res_text)
    handle_menu_supply(call.message.chat.id, call.message.message_id, player)

def handle_upgrade_supply_channel(call, player, db):
    ch_lvl = player.get("supply_channel_lvl", 1)
    cost = SUPPLY_CHANNEL_COSTS.get(ch_lvl)
    if not cost:
        bot.answer_callback_query(call.id, "❌ Канал уже 10 уровня!", show_alert=True)
        return

    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно средств! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    player["supply_channel_lvl"] = ch_lvl + 1
    save_db(db)

    bot.answer_callback_query(call.id, f"🎉 Канал поставок улучшен до {ch_lvl + 1} уровня!")
    handle_menu_supply(call.message.chat.id, call.message.message_id, player)

# ----------------- SECTION 6: FLEA MARKET & P2P -----------------

def handle_menu_market(chat_id, msg_id, player):
    btc_rate = get_current_btc_rate()
    tax_rate = 5 if has_buff(player, "market_tax") else 10

    txt = (
        f"<b>🏪 БАРАХОЛКА ТАРКОВА & КРИПТО-ОБМЕННИК</b>\n"
        f"────────────────────────\n"
        f"🪙 Плавающий курс Bitcoin: <b>{fmt_rub(btc_rate)} / 1 BTC</b>\n"
        f"У вас в наличии: <b>{player.get('btc', 0):.4f} BTC</b>\n"
        f"Налог барахолки: <b>{tax_rate}%</b> (для Siren / Revenant: 5%)\n"
        f"────────────────────────\n"
        f"Категории товаров Барахолки:"
    )
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("🔫 Оружие", callback_data="market_cat_Оружие"),
        types.InlineKeyboardButton("🛡️ Экипировка", callback_data="market_cat_Экипировка")
    )
    markup.add(
        types.InlineKeyboardButton("💉 Медицина", callback_data="market_cat_Медицина"),
        types.InlineKeyboardButton("💎 Драгоценности", callback_data="market_cat_Драгоценности")
    )
    markup.add(types.InlineKeyboardButton("🔩 Компоненты", callback_data="market_cat_Компоненты"))

    if player.get("btc", 0) > 0.001:
        markup.add(types.InlineKeyboardButton(f"💰 Продать все BTC | +{fmt_rub(player.get('btc', 0) * btc_rate)}", callback_data="market_sell_btc"))

    markup.add(types.InlineKeyboardButton("🛒 P2P Рынок Игроков", callback_data="market_p2p"))
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_market_catalog(chat_id, msg_id, player, cat_name, page=1):
    items = [i for i in ITEMS_LIST if i.get("market_cat") == cat_name]
    per_page = 8
    total_pages = max(1, (len(items) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))

    start_idx = (page - 1) * per_page
    page_items = items[start_idx : start_idx + per_page]

    txt = (
        f"<b>🏪 БАРАХОЛКА: {cat_name.upper()} (Стр. {page}/{total_pages})</b>\n"
        f"────────────────────────\n"
    )
    for itm in page_items:
        r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        txt += f"{r_b} <b>{itm['name']}</b> — <b>{fmt_rub(itm['price'])}</b>\n<i>{itm.get('desc', '')}</i>\n\n"

    markup = types.InlineKeyboardMarkup(row_width=3)
    nav_buttons = []
    if page > 1:
        nav_buttons.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"market_page_{cat_name}_{page-1}"))
    nav_buttons.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_buttons.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"market_page_{cat_name}_{page+1}"))

    markup.row(*nav_buttons)
    markup.add(types.InlineKeyboardButton("🔙 К Барахолке", callback_data="menu_market"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_sell_btc(call, player, db):
    btc = player.get("btc", 0.0)
    if btc < 0.001:
        bot.answer_callback_query(call.id, "❌ У вас нет Биткоинов для продажи!", show_alert=True)
        return

    rate = get_current_btc_rate()
    rub = int(btc * rate)
    player["money"] = player.get("money", 0) + rub
    player["btc"] = 0.0
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"✅ Продано {btc:.4f} BTC!\n"
        f"📊 Курс: {fmt_rub(rate)} / 1 BTC\n"
        f"💰 Получено: +{fmt_rub(rub)}\n"
        f"💵 Баланс: {fmt_rub(player['money'])}",
        show_alert=True
    )
    handle_menu_market(call.message.chat.id, call.message.message_id, player)

def handle_p2p_market(chat_id, msg_id, player, db):
    lots = db.get("p2p_market", [])
    tax_pct = 0.05 if has_buff(player, "market_tax") else 0.10
    tax_rate = int(tax_pct * 100)

    txt = (
        f"<b>🛒 P2P РЫНОК ИГРОКОВ (БАРАХОЛКА)</b>\n"
        f"Комиссия на продажу: <b>{tax_rate}%</b> | Активных лотов: <b>{len(lots)}</b>\n"
        f"────────────────────────\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    if not lots:
        txt += "<i>Сейчас на P2P рынке нет выставленных предметов.</i>\n"
    else:
        for lot in lots[:10]:
            itm = lot["item"]
            r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
            cat_p = itm.get('price', 0)
            txt += (
                f"{r_b} <b>{itm['name']}</b>\n"
                f"   💰 Цена покупки: <b>{fmt_rub(lot['price'])}</b> (Каталог: {fmt_rub(cat_p)})\n"
                f"   👤 Продавец: @{lot.get('seller_name', 'Player')}\n"
            )
            if lot.get("seller_id") != player["user_id"]:
                markup.add(types.InlineKeyboardButton(f"🛒 Купить {itm['name'][:18]} | {fmt_rub(lot['price'])}", callback_data=f"buy_p2p_{lot['lot_id']}"))

    markup.add(
        types.InlineKeyboardButton("📤 Выставить предмет из схрона", callback_data="p2p_list_menu"),
        types.InlineKeyboardButton("🔙 К Барахолке", callback_data="menu_market")
    )
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_p2p_list_menu(chat_id, msg_id, player):
    stash = [i for i in player.get("stash", []) if not i.get("equipped_to")]
    tax_pct = 0.05 if has_buff(player, "market_tax") else 0.10
    tax_rate = int(tax_pct * 100)

    txt = (
        f"<b>📤 ВЫСТАВКА ПРЕДМЕТОВ НА P2P РЫНОК</b>\n"
        f"Комиссия Барахолки: <b>{tax_rate}%</b>\n\n"
        f"<i>Ниже указаны предметы вашего схрона. На кнопках отображается рыночная цена и чистая выплата после продажи:</i>\n"
        f"────────────────────────\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    if not stash:
        txt += "<i>В вашем схроне нет свободных предметов для продажи.</i>\n"
    else:
        for itm in stash[:12]:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            p = info.get("price", 10000)
            fee = int(p * tax_pct)
            net = p - fee
            r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(info.get("rarity"), "⬜")
            markup.add(
                types.InlineKeyboardButton(
                    f"{r_b} {info.get('name')[:18]} | {fmt_rub(p)} (Вам: +{fmt_rub(net)})",
                    callback_data=f"p2p_list_{itm['uid']}"
                )
            )

    markup.add(types.InlineKeyboardButton("🔙 Назад к P2P", callback_data="market_p2p"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_p2p_list_action(call, player, db, uid):
    stash = player.get("stash", [])
    item_entry = next((i for i in stash if i.get("uid") == uid), None)
    if not item_entry:
        bot.answer_callback_query(call.id, "❌ Предмет не найден!", show_alert=True)
        return

    if item_entry.get("equipped_to"):
        bot.answer_callback_query(call.id, "❌ Предмет надет на бойца!", show_alert=True)
        return

    info = ITEMS_BY_ID.get(item_entry.get("item_id"), {})
    price = info.get("price", 10000)
    tax_pct = 0.05 if has_buff(player, "market_tax") else 0.10
    fee = int(price * tax_pct)
    net = price - fee

    stash.remove(item_entry)
    db.setdefault("p2p_market", []).append({
        "lot_id": f"lot_{int(time.time())}_{random.randint(100,999)}",
        "seller_id": player["user_id"],
        "seller_name": player.get("username", "PMC"),
        "price": price,
        "item": info
    })
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"✅ Лот выставлен на P2P рынок!\n"
        f"📦 {info.get('name')}\n"
        f"🏷️ Цена лота: {fmt_rub(price)}\n"
        f"📉 Комиссия ({int(tax_pct*100)}%): -{fmt_rub(fee)}\n"
        f"💰 К получению при покупке: +{fmt_rub(net)}",
        show_alert=True
    )
    handle_p2p_market(call.message.chat.id, call.message.message_id, player, db)

def handle_buy_p2p_lot(call, player, db, lot_id):
    lots = db.get("p2p_market", [])
    lot = next((l for l in lots if l["lot_id"] == lot_id), None)
    if not lot:
        bot.answer_callback_query(call.id, "❌ Лот уже продан или снят!", show_alert=True)
        return

    price = lot["price"]
    if player.get("money", 0) < price:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Нужно {fmt_rub(price)}", show_alert=True)
        return

    # Check warehouse capacity
    item_info = lot["item"]
    cat = item_info.get("category", "gear")
    cap = get_warehouse_capacity(player, cat)
    cnt = get_warehouse_count(player, cat)
    if cnt >= cap:
        bot.answer_callback_query(call.id, "❌ Ваш склад переполнен для этого предмета!", show_alert=True)
        return

    # Process trade
    player["money"] -= price
    player["stash"].append({
        "uid": f"p2p_{int(time.time())}_{random.randint(100,999)}",
        "item_id": item_info["id"],
        "equipped_to": None
    })

    # Seller tax & credit
    seller_id_str = str(lot["seller_id"])
    if seller_id_str in db["users"]:
        seller = db["users"][seller_id_str]
        tax_pct = 0.05 if has_buff(seller, "market_tax") else 0.10
        seller_earn = int(price * (1.0 - tax_pct))
        seller["money"] = seller.get("money", 0) + seller_earn

    lots.remove(lot)
    save_db(db)

    cat_p = item_info.get("price", price)
    bot.answer_callback_query(
        call.id,
        f"✅ Куплено: {item_info['name']}!\n"
        f"💰 Списано: {fmt_rub(price)}\n"
        f"🏷️ Каталожная ценность: {fmt_rub(cat_p)}\n"
        f"💵 Остаток: {fmt_rub(player['money'])}",
        show_alert=True
    )
    handle_p2p_market(call.message.chat.id, call.message.message_id, player, db)

# ----------------- SECTION 7: RAIDS -----------------

def handle_menu_raids(chat_id, msg_id, player):
    pow_val, arm_val = calculate_squad_power(player)
    now = int(time.time())
    last_raid = player.get("last_raid_time", 0)

    cd_mult = 0.85 if has_buff(player, "cooldown_reduction") else 1.0 # Viper / Revenant

    txt = (
        f"<b>⚔️ ВЫЛАЗКИ И РЕЙДЫ В ТАРКОВ</b>\n"
        f"Мощь отряда: <b>+{pow_val}</b> | Броня: <b>+{arm_val}</b>\n"
        f"────────────────────────\n"
        f"Выберите локацию для рейда вашего отряда:\n\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    for k, loc in RAID_LOCATIONS.items():
        base_cd = int(loc["cooldown"] * cd_mult)
        rem_cd = max(0, (last_raid + base_cd) - now)

        fee = loc["scav_fee"]
        if fee > 0 and has_buff(player, "scav_discount"): # Nomad
            fee = int(fee * 0.80)

        fee_txt = f" | Плата: {fmt_rub(fee)}" if fee > 0 else " | Бесплатно"
        txt += f"• <b>{loc['name']}</b>{fee_txt}\n<i>{loc['desc']}</i>\n\n"

        if rem_cd > 0:
            markup.add(types.InlineKeyboardButton(f"⏳ {loc['name']} (Кулдаун: {rem_cd} сек)", callback_data="none"))
        else:
            markup.add(types.InlineKeyboardButton(f"🔫 Идти в рейд: {loc['name']}", callback_data=f"start_raid_{k}"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_start_raid(call, player, db, loc_key):
    loc = RAID_LOCATIONS.get(loc_key, RAID_LOCATIONS["factory"])
    now = int(time.time())
    last_raid = player.get("last_raid_time", 0)
    cd_mult = 0.85 if has_buff(player, "cooldown_reduction") else 1.0
    rem_cd = max(0, (last_raid + int(loc["cooldown"] * cd_mult)) - now)

    if rem_cd > 0:
        bot.answer_callback_query(call.id, f"⏳ Отряд отдыхает! Подождите {rem_cd} сек.", show_alert=True)
        return

    fee = loc["scav_fee"]
    if fee > 0 and has_buff(player, "scav_discount"):
        fee = int(fee * 0.80)

    if player.get("money", 0) < fee:
        bot.answer_callback_query(call.id, f"❌ Недостаточно средств на пропуск! Нужно {fmt_rub(fee)}", show_alert=True)
        return

    if not player.get("squad", []):
        bot.answer_callback_query(call.id, "❌ В отряде нет бойцов! Наймите их в меню Отряда.", show_alert=True)
        return

    player["money"] -= fee
    player["last_raid_time"] = now

    pow_val, arm_val = calculate_squad_power(player)
    result = simulate_raid(loc_key, player, pow_val, arm_val)

    # Outcome
    if result["success"]:
        player["stats"]["raids_count"] = player["stats"].get("raids_count", 0) + 1
        player["money"] += result["rubles"]

        total_loot_val = sum(itm.get("price", 0) for itm in result["items"])
        res_txt = (
            f"🎉 <b>УСПЕШНЫЙ ВЫХОД ИЗ РЕЙДА!</b>\n"
            f"Локация: <b>{result['location']}</b>\n"
            f"Шанс выживания был: <b>{result['win_chance']}%</b>\n"
            f"Добыто денег: <b>+{fmt_rub(result['rubles'])}</b>\n\n"
            f"<b>Вынесенные предметы со стоимостью:</b>\n"
        )
        for idx, itm in enumerate(result["items"], 1):
            r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
            if can_store_item(player, itm["id"]):
                player["stash"].append({"uid": f"raid_{now}_{idx}", "item_id": itm["id"], "equipped_to": None})
                res_txt += f"• {r_b} <b>{itm['name']}</b> — <b>{fmt_rub(itm['price'])}</b>\n"
            else:
                res_txt += f"• ⚠️ {itm['name']} ({fmt_rub(itm['price'])}) — брошен (склад полон!)\n"

        res_txt += (
            f"\n💵 <b>Суммарная ценность хабара:</b> <b>{fmt_rub(total_loot_val)}</b>\n"
            f"💰 <b>Общая прибыль рейда:</b> <b>+{fmt_rub(result['rubles'] + total_loot_val)}</b>\n"
        )
    else:
        # Failure: Squad dies and loses equipped gear!
        lost_items_names = []
        stash = {i["uid"]: i for i in player.get("stash", [])}
        for f in player.get("squad", []):
            if f.get("weapon_uid") and f["weapon_uid"] in stash:
                w_info = ITEMS_BY_ID.get(stash[f["weapon_uid"]]["item_id"], {})
                lost_items_names.append(w_info.get("name", "Оружие"))
                player["stash"].remove(stash[f["weapon_uid"]])
            if f.get("armor_uid") and f["armor_uid"] in stash:
                a_info = ITEMS_BY_ID.get(stash[f["armor_uid"]]["item_id"], {})
                lost_items_names.append(a_info.get("name", "Броня"))
                player["stash"].remove(stash[f["armor_uid"]])

        player["squad"] = [] # Squad lost!
        res_txt = (
            f"💀 <b>ОТРЯД ПОГИБ В РЕЙДЕ! MIA / K.I.A.</b>\n"
            f"Локация: <b>{result['location']}</b>\n"
            f"Вражеские снайперы и ЧВК уничтожили бойцов.\n\n"
            f"⚠️ Все нанятые бойцы погибли!\n"
            f"⚠️ Утрачено снаряжение: {', '.join(lost_items_names) if lost_items_names else 'Ничего'}"
        )

    save_db(db)
    bot.answer_callback_query(call.id)
    bot.send_message(call.message.chat.id, res_txt)
    handle_menu_raids(call.message.chat.id, call.message.message_id, player)

# ----------------- SECTION 8: DARKZONE (PVP IN CHATS) -----------------

def handle_menu_darkzone(chat_id, msg_id, player, db):
    pow_val, arm_val = calculate_squad_power(player)
    duels = db.get("active_duels", {})

    txt = (
        f"<b>💀 ДАРКЗОН (PVP СТАВКИ В БЕСЕДАХ)</b>\n"
        f"Ваша боевая мощь: <b>+{pow_val}</b> | Броня: <b>+{arm_val}</b>\n"
        f"Бойцов в строю: <b>{len(player.get('squad', []))}/5</b>\n"
        f"────────────────────────\n"
        f"<i>Правила Даркзона:\n"
        f"1. Победитель забирает банк (95% от ставок).\n"
        f"2. Проигравший ТЕРЯЕТ СТАВКУ, ВСЕХ БОЙЦОВ ОТРЯДА и ВСЕ ЭКИПИРОВАННЫЕ ПРЕДМЕТЫ навсегда!\n"
        f"3. ЧВК Ronin и Revenant получают +15% к шансу победы.</i>\n\n"
        f"Активные вызовы в Зоне:"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    if not duels:
        txt += "\n<i>Сейчас нет активных дуэлей. Создайте свой вызов!</i>"
    else:
        for d_id, d in list(duels.items())[:6]:
            if d.get("creator_id") != player["user_id"]:
                markup.add(types.InlineKeyboardButton(
                    f"⚔️ Принять вызов @{d.get('creator_name')} | {fmt_rub(d['bet'])}",
                    callback_data=f"accept_duel_{d_id}"
                ))

    markup.add(
        types.InlineKeyboardButton("⚔️ Бросить вызов на 10,000 ₽", callback_data="create_duel_10000"),
        types.InlineKeyboardButton("⚔️ Бросить вызов на 50,000 ₽", callback_data="create_duel_50000"),
        types.InlineKeyboardButton("⚔️ Бросить вызов на 100,000 ₽", callback_data="create_duel_100000"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_create_duel(call, player, db, bet):
    if player.get("money", 0) < bet:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей для ставки {fmt_rub(bet)}!", show_alert=True)
        return

    if not player.get("squad", []):
        bot.answer_callback_query(call.id, "❌ У вас нет бойцов для участия в дуэли!", show_alert=True)
        return

    duel_id = f"duel_{int(time.time())}_{player['user_id']}"
    db.setdefault("active_duels", {})[duel_id] = {
        "duel_id": duel_id,
        "chat_id": call.message.chat.id,
        "creator_id": player["user_id"],
        "creator_name": player.get("username", "PMC"),
        "bet": bet,
        "created_at": int(time.time())
    }
    save_db(db)

    bot.answer_callback_query(call.id, f"⚔️ Вызов на {fmt_rub(bet)} выставлен в Даркзоне!")
    pow_val, arm_val = calculate_squad_power(player)
    bot.send_message(
        call.message.chat.id,
        f"<b>⚔️ ВЫЗОВ В ДАРКЗОН!</b>\n"
        f"ЧВК <b>@{player.get('username')}</b> бросает вызов в секторе!\n"
        f"Ставка: <b>{fmt_rub(bet)}</b> | Бойцов: <b>{len(player.get('squad', []))}</b>\n"
        f"Огневая мощь: <b>{pow_val}</b> | Броня: <b>{arm_val}</b>\n\n"
        f"Кто готов принять бой? Нажмите кнопку ниже!",
        reply_markup=types.InlineKeyboardMarkup().add(
            types.InlineKeyboardButton(f"⚔️ Принять бой ({fmt_rub(bet)})", callback_data=f"accept_duel_{duel_id}")
        )
    )

def handle_accept_duel(call, player, db, duel_id):
    duels = db.get("active_duels", {})
    duel = duels.get(duel_id)
    if not duel:
        bot.answer_callback_query(call.id, "❌ Дуэль уже завершена или отменена!", show_alert=True)
        return

    creator_id = str(duel["creator_id"])
    if creator_id == str(player["user_id"]):
        bot.answer_callback_query(call.id, "❌ Нельзя принять свой собственный вызов!", show_alert=True)
        return

    creator = db["users"].get(creator_id)
    if not creator:
        duels.pop(duel_id, None)
        save_db(db)
        bot.answer_callback_query(call.id, "❌ Создатель дуэли недоступен!", show_alert=True)
        return

    bet = duel["bet"]
    if player.get("money", 0) < bet or creator.get("money", 0) < bet:
        bot.answer_callback_query(call.id, "❌ У одного из участников недостаточно средств!", show_alert=True)
        return

    if not player.get("squad", []) or not creator.get("squad", []):
        bot.answer_callback_query(call.id, "❌ У одного из участников пустой отряд!", show_alert=True)
        return

    # Combat calculation
    pow1, arm1 = calculate_squad_power(creator)
    pow2, arm2 = calculate_squad_power(player)

    score1 = (pow1 * 1.3 + arm1 * 0.9 + len(creator.get("squad", [])) * 15) * random.uniform(0.85, 1.15)
    score2 = (pow2 * 1.3 + arm2 * 0.9 + len(player.get("squad", [])) * 15) * random.uniform(0.85, 1.15)

    if has_buff(creator, "pvp_bonus"):
        score1 *= 1.15
    if has_buff(player, "pvp_bonus"):
        score2 *= 1.15

    # Determine winner
    bank = int(bet * 2 * 0.95) # 5% zone rake
    if score1 >= score2:
        winner = creator
        loser = player
    else:
        winner = player
        loser = creator

    winner["money"] = winner.get("money", 0) + int(bet * 0.95)
    loser["money"] = loser.get("money", 0) - bet

    winner["stats"]["pvp_wins"] = winner["stats"].get("pvp_wins", 0) + 1
    loser["stats"]["pvp_losses"] = loser["stats"].get("pvp_losses", 0) + 1

    # Loser loses equipped gear & squad
    loser_stash = {i["uid"]: i for i in loser.get("stash", [])}
    for f in loser.get("squad", []):
        if f.get("weapon_uid") and f["weapon_uid"] in loser_stash:
            loser["stash"].remove(loser_stash[f["weapon_uid"]])
        if f.get("armor_uid") and f["armor_uid"] in loser_stash:
            loser["stash"].remove(loser_stash[f["armor_uid"]])
    loser["squad"] = []

    duels.pop(duel_id, None)
    save_db(db)

    bot.answer_callback_query(call.id, "⚔️ БОЙ ЗАВЕРШЕН!")
    bot.send_message(
        call.message.chat.id,
        f"<b>💀 СМЕРТЕЛЬНАЯ БИТВА В ДАРКЗОНЕ ОКОНЧЕНА!</b>\n\n"
        f"🏆 Победитель: <b>@{winner.get('username')}</b>\n"
        f"💰 Выигрыш: <b>+{fmt_rub(bank)}</b>\n\n"
        f"☠️ Проигравший: <b>@{loser.get('username')}</b>\n"
        f"⚠️ Потерял ставку: <b>-{fmt_rub(bet)}</b>\n"
        f"⚠️ Весь отряд уничтожен, всё надетое снаряжение сгорело!"
    )

# ----------------- SECTION 8.5: MILITARY CONTAINERS & CRATES -----------------

def handle_menu_containers(chat_id, msg_id, player):
    txt = (
        "<b>🧰 ВОЕННЫЕ КЕЙСЫ И СХРОНЫ СНАБЖЕНИЯ</b>\n"
        "────────────────────────\n"
        "<i>⚠️ ВНИМАНИЕ: Окупаемость контейнеров НЕ гарантирована!\n"
        "По законам Зоны Таркова большинство контейнеров приносят меньше своей стоимости "
        "(вероятность неокупа ~48-50%), но дают реальный шанс сорвать окуп или легендарный джекпот.</i>\n\n"
        "<b>Доступные контейнеры снабжения:</b>\n\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    for cid, cfg in CONTAINER_DEFINITIONS.items():
        loss_pct = int(cfg["probabilities"][0] * 100)
        item_c = f"{cfg['item_count'][0]}-{cfg['item_count'][1]}"
        txt += (
            f"<b>{cfg['badge']} {cfg['name']}</b>\n"
            f"💰 Стоимость: <b>{fmt_rub(cfg['price'])}</b> | Содержимое: <b>{item_c} предм.</b>\n"
            f"<i>{cfg['desc']}</i>\n"
            f"📊 Экономический риск: вероятность неокупа <b>~{loss_pct}%</b>\n\n"
        )
        markup.add(
            types.InlineKeyboardButton(
                f"{cfg['badge']} Открыть {cfg['name']} | {fmt_rub(cfg['price'])}",
                callback_data=f"open_cnt_{cid}"
            )
        )

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_open_container(call, player, db, container_id):
    cfg = CONTAINER_DEFINITIONS.get(container_id)
    if not cfg:
        bot.answer_callback_query(call.id, "❌ Неизвестный контейнер!", show_alert=True)
        return

    price = cfg["price"]
    if player.get("money", 0) < price:
        bot.answer_callback_query(call.id, f"❌ Недостаточно средств! Нужно {fmt_rub(price)}", show_alert=True)
        return

    loot_res = generate_container_loot(container_id, player)
    items = loot_res["items"]

    # Check capacity per category
    for itm in items:
        cat = itm.get("category", "gear")
        cap = get_warehouse_capacity(player, cat)
        cnt = get_warehouse_count(player, cat)
        if cnt >= cap:
            cat_name = WAREHOUSE_NAMES.get(cat, cat)
            bot.answer_callback_query(call.id, f"⚠️ Склад '{cat_name}' переполнен! Освободите место.", show_alert=True)
            return

    # Deduct price
    player["money"] -= price
    now = int(time.time())

    # Add items to stash
    for idx, itm in enumerate(items, 1):
        uid = f"cnt_{now}_{idx}_{random.randint(100,999)}"
        player["stash"].append({"uid": uid, "item_id": itm["id"], "equipped_to": None})

    player.setdefault("stats", {})["containers_opened"] = player.get("stats", {}).get("containers_opened", 0) + 1
    save_db(db)

    # Format result message
    delta = loot_res["delta"]
    total_val = loot_res["total_value"]
    if loot_res["outcome"] == "jackpot":
        status_txt = f"🔥 <b>СУПЕР-ДЖЕКПОТ! (+{fmt_rub(delta)})</b>"
    elif delta > 0:
        status_txt = f"📈 <b>🟢 ОКУП (+{fmt_rub(delta)})</b>"
    elif abs(delta) <= 50000:
        status_txt = f"⚖️ <b>🟡 ОКОЛО НУЛЯ ({fmt_rub(delta)})</b>"
    else:
        status_txt = f"📉 <b>🔴 НЕОКУП ({fmt_rub(delta)})</b>"

    res_txt = (
        f"{cfg['badge']} <b>ОТКРЫТИЕ: {cfg['name'].upper()}</b>\n"
        f"💰 Затрачено на контейнер: <b>{fmt_rub(price)}</b>\n"
        f"────────────────────────\n"
        f"<b>Выпавшие предметы со стоимостью:</b>\n"
    )

    for idx, itm in enumerate(items, 1):
        r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        res_txt += f"{idx}. {r_b} <b>{itm['name']}</b> — <b>{fmt_rub(itm['price'])}</b>\n"

    res_txt += (
        f"────────────────────────\n"
        f"💵 <b>Суммарная ценность лута:</b> <b>{fmt_rub(total_val)}</b>\n"
        f"📊 <b>Результат:</b> {status_txt}\n"
        f"💳 <b>Ваш остаток рублей:</b> {fmt_rub(player['money'])}\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(f"🔄 Открыть еще один ({fmt_rub(price)})", callback_data=f"open_cnt_{container_id}"),
        types.InlineKeyboardButton("🧰 К выбору кейсов", callback_data="menu_containers"),
        types.InlineKeyboardButton("📦 Открыть Склады", callback_data="menu_stash")
    )

    bot.answer_callback_query(call.id, f"📦 Кейс открыт! Добыто на {fmt_rub(total_val)}")
    bot.edit_message_text(res_txt, call.message.chat.id, call.message.message_id, reply_markup=markup)

# ----------------- SECTION 9: DYNAMIC AIRDROP -----------------

def handle_menu_airdrop(chat_id, msg_id, player, db):
    ad = db.setdefault("airdrop", {"active": False, "last_spawn": 0})
    now = int(time.time())
    cooldown = 5400 # 90 minutes
    rem = max(0, (ad.get("last_spawn", 0) + cooldown) - now)

    txt = (
        f"<b>✈️ ЭИРДРОП СНАБЖЕНИЯ ЧВК (СБРОС РАЗ В 90 МИН)</b>\n"
        f"────────────────────────\n"
        f"Военный самолет периодически сбрасывает массивный ящик гуманитарной помощи. "
        f"Внутри может оказаться всё: от дефицитных патронов Игольник до Видеокарт, Биткоинов "
        f"и <b>эксклюзивных реликвий Боссов</b> ('Кувалда Тагиллы', 'Маска Киллы').\n\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    if ad.get("active"):
        txt += "🚨 <b>ЯЩИК ЭИРДРОПА ПРЯМО СЕЙЧАС ЛЕЖИТ В ЗОНЕ!</b>\nНажмите кнопку быстрее всех!"
        markup.add(types.InlineKeyboardButton("📦 ОБЫСКАТЬ ЯЩИК", callback_data="loot_airdrop_box"))
    else:
        m, s = divmod(rem, 60)
        txt += f"⏳ Следующий пролет самолета через: <b>{m} мин. {s} сек.</b>"
        if is_admin(player["user_id"], player.get("username")):
            markup.add(types.InlineKeyboardButton("🚨 Принудительно сбросить Эирдроп [ADMIN]", callback_data="admin_action_airdrop"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_loot_airdrop(call, player, db):
    ad = db.get("airdrop", {})
    if not ad.get("active"):
        bot.answer_callback_query(call.id, "❌ Ящик уже кто-то забрал!", show_alert=True)
        return

    ad["active"] = False
    ad["last_spawn"] = int(time.time())

    loot = generate_airdrop_loot()
    player["money"] = player.get("money", 0) + loot["rubles"]
    player["btc"] = round(player.get("btc", 0.0) + loot["btc"], 4)
    player["stats"]["airdrop_looted"] = player["stats"].get("airdrop_looted", 0) + 1

    now = int(time.time())
    res_txt = (
        f"🎉 <b>ВЫ ПЕРВЫМ ОБЫСКАЛИ ВОЕННЫЙ ЭИРДРОП!</b>\n"
        f"Счастливчик: <b>@{player.get('username')}</b>\n"
        f"────────────────────────\n"
        f"💰 Деньги: <b>+{fmt_rub(loot['rubles'])}</b>\n"
        f"🪙 Криптовалюта: <b>+{loot['btc']} BTC</b>\n\n"
        f"<b>Найденные предметы в контейнере:</b>\n"
    )
    total_loot_val = sum(itm.get("price", 0) for itm in loot["items"])
    for idx, itm in enumerate(loot["items"], 1):
        r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        if can_store_item(player, itm["id"]):
            player["stash"].append({"uid": f"drop_{now}_{idx}", "item_id": itm["id"], "equipped_to": None})
            res_txt += f"• {r_b} <b>{itm['name']}</b> — <b>{fmt_rub(itm['price'])}</b>\n"
        else:
            res_txt += f"• ⚠️ {itm['name']} ({fmt_rub(itm['price'])}) — Склад переполнен!\n"

    res_txt += (
        f"\n────────────────────────\n"
        f"💵 <b>Суммарная ценность лута:</b> <b>{fmt_rub(total_loot_val)}</b>\n"
        f"💰 <b>Общая ценность эирдропа:</b> <b>+{fmt_rub(loot['rubles'] + total_loot_val)}</b>\n"
    )

    save_db(db)
    bot.answer_callback_query(call.id, "🎉 ЭИРДРОП ЗАЛУТАН!")
    bot.send_message(call.message.chat.id, res_txt)

# ----------------- SECTION 10: ADMIN PANEL (@revenuts) -----------------

def handle_menu_admin(chat_id, msg_id, player):
    txt = (
        f"<b>👑 ПАНЕЛЬ АДМИНИСТРАТОРА: @revenuts</b>\n"
        f"Статус: <b>💀 [ADMIN] 💰 REVENANT GD 💰 💀</b>\n"
        f"Все 10 баффов ЧВК активны одновременно!\n\n"
        f"Быстрые действия разработчика:"
    )
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("💰 +10,000,000 ₽", callback_data="admin_action_money"),
        types.InlineKeyboardButton("🪙 +10.0 BTC", callback_data="admin_action_btc")
    )
    markup.add(
        types.InlineKeyboardButton("🟨 Выдать Топ Лут", callback_data="admin_action_toploot"),
        types.InlineKeyboardButton("✈️ Спавн Эирдропа", callback_data="admin_action_airdrop")
    )
    markup.add(
        types.InlineKeyboardButton("⚡ Макс. Убежище", callback_data="admin_action_maxhideout"),
        types.InlineKeyboardButton("🔄 Сброс Профиля", callback_data="admin_action_reset")
    )
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_admin_action(call, player, db, act):
    if not is_admin(player["user_id"], player.get("username")):
        bot.answer_callback_query(call.id, "❌ Отказано в доступе!", show_alert=True)
        return

    now = int(time.time())
    if act == "money":
        player["money"] = player.get("money", 0) + 10000000
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Начислено 10,000,000 ₽!")
    elif act == "btc":
        player["btc"] = round(player.get("btc", 0.0) + 10.0, 4)
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Начислено 10.0 BTC!")
    elif act == "toploot":
        top_items = [
            "slick_armor_legendary", "killa_helmet_legendary",
            "tagilla_sledgehammer_legendary", "mk18_mjolnir_legendary"
        ]
        for idx, tid in enumerate(top_items):
            player["stash"].append({"uid": f"adm_{now}_{idx}", "item_id": tid, "equipped_to": None})
        save_db(db)
        bot.answer_callback_query(call.id, "✅ В схрон добавлены Slick, Маска Киллы, Кувалда Тагиллы и Mk-18 Mjölnir!")
    elif act == "airdrop":
        db.setdefault("airdrop", {})["active"] = True
        db["airdrop"]["last_spawn"] = now
        save_db(db)
        bot.answer_callback_query(call.id, "🚨 Эирдроп активирован в зоне!")
        bot.send_message(
            call.message.chat.id,
            "✈️ <b>ВНИМАНИЕ! ИЛ-76 СБРОСИЛ ВОЕННЫЙ ЭИРДРОП!</b>\n"
            "Контейнер опустился на парашюте! Кто первый нажмет кнопку — заберет лут!",
            reply_markup=types.InlineKeyboardMarkup().add(
                types.InlineKeyboardButton("📦 ОБЫСКАТЬ ЯЩИК", callback_data="loot_airdrop_box")
            )
        )
    elif act == "maxhideout":
        player["hideout_lvl"] = 10
        for m in player.get("modules", {}):
            player["modules"][m] = 10
        for b in player.get("businesses", {}):
            player["businesses"][b] = 10
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Убежище и все модули прокачаны на 10 уровень!")
    elif act == "reset":
        db["users"][str(player["user_id"])] = create_new_player(player["user_id"], player.get("username"), "Revenant")
        save_db(db)
        bot.answer_callback_query(call.id, "🔄 Профиль сброшен к начальному состоянию!")

    handle_menu_admin(call.message.chat.id, call.message.message_id, db["users"][str(player["user_id"])])

# Admin Text Commands
@bot.message_handler(commands=['airdrop'])
def cmd_airdrop(message):
    if not is_admin(message.from_user.id, message.from_user.username):
        return
    db = load_db()
    db.setdefault("airdrop", {})["active"] = True
    db["airdrop"]["last_spawn"] = int(time.time())
    save_db(db)
    bot.send_message(
        message.chat.id,
        "✈️ <b>ВОЕННЫЙ ЭИРДРОП СБРОШЕН В СЕКТОРЕ!</b>\n"
        "Нажмите кнопку, чтобы забрать армейский лут!",
        reply_markup=types.InlineKeyboardMarkup().add(
            types.InlineKeyboardButton("📦 ОБЫСКАТЬ ЯЩИК", callback_data="loot_airdrop_box")
        )
    )

@bot.message_handler(commands=['give_money', 'give_item', 'set_module', 'set_level', 'reset_player'])
def cmd_admin_commands(message):
    if not is_admin(message.from_user.id, message.from_user.username):
        return

    parts = message.text.split()
    cmd = parts[0].lower()
    db = load_db()

    try:
        if cmd == "/give_money" and len(parts) >= 3:
            target_id = parts[1].lstrip("@")
            amount = int(parts[2])
            u = db["users"].get(target_id)
            if u:
                u["money"] = u.get("money", 0) + amount
                save_db(db)
                bot.reply_to(message, f"✅ Выдано {fmt_rub(amount)} игроку {target_id}")

        elif cmd == "/give_item" and len(parts) >= 3:
            target_id = parts[1].lstrip("@")
            item_id = parts[2]
            u = db["users"].get(target_id)
            if u and item_id in ITEMS_BY_ID:
                u["stash"].append({"uid": f"cmd_{int(time.time())}", "item_id": item_id, "equipped_to": None})
                save_db(db)
                bot.reply_to(message, f"✅ Предмет {item_id} добавлен в схрон {target_id}")

        elif cmd == "/set_level" and len(parts) >= 3:
            target_id = parts[1].lstrip("@")
            lvl = int(parts[2])
            u = db["users"].get(target_id)
            if u:
                u["hideout_lvl"] = max(1, min(10, lvl))
                save_db(db)
                bot.reply_to(message, f"✅ Уровень Убежища игрока {target_id} установлен на {lvl}")

        elif cmd == "/reset_player" and len(parts) >= 2:
            target_id = parts[1].lstrip("@")
            if target_id in db["users"]:
                uname = db["users"][target_id].get("username")
                db["users"][target_id] = create_new_player(int(target_id), uname, "Viper")
                save_db(db)
                bot.reply_to(message, f"✅ Профиль игрока {target_id} сброшен!")
    except Exception as e:
        bot.reply_to(message, f"❌ Ошибка выполнения команды: {e}")

# ----------------- ENTRYPOINT -----------------

if __name__ == "__main__":
    print("=" * 60)
    print("ESCAPE FROM TARKOV MMO ECONOMIC TELEGRAM BOT")
    print("Items loaded:", len(ITEMS_LIST))
    print("=" * 60)

    if not BOT_TOKEN or BOT_TOKEN == "DUMMY_TOKEN_PLEASE_SET_BOT_TOKEN":
        print("\n[CONFIGURATION REQUIRED]")
        print("1. Open Settings -> Secrets in AI Studio (or set BOT_TOKEN in .env).")
        print("2. Add key: BOT_TOKEN, value: your Telegram Bot token from @BotFather.")
        print("3. Run: python3 bot.py")
        print("=" * 60)
        sys.exit(0)

    print("[SUCCESS] Bot is starting polling...")
    bot.infinity_polling(skip_pending=True)
