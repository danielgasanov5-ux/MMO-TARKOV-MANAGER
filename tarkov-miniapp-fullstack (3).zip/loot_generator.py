# -*- coding: utf-8 -*-
"""
Loot Generator & Raid System for Escape from Tarkov
Real-time deliveries, airdrops with boss items, and raid engine.
"""

import random
from tarkov_engine import ITEMS_LIST, ITEMS_BY_ID, has_buff

# Filter item pools by rarity
POOL_LEGENDARY = [i for i in ITEMS_LIST if i.get("rarity") == "legendary" or i.get("price", 0) >= 300000]
POOL_EPIC = [i for i in ITEMS_LIST if i.get("rarity") == "epic" and i not in POOL_LEGENDARY]
POOL_RARE = [i for i in ITEMS_LIST if i.get("rarity") == "rare"]
POOL_COMMON = [i for i in ITEMS_LIST if i.get("rarity") == "common"]

# Special Airdrop Boss items
BOSS_RELICS = [
    "tagilla_sledgehammer_legendary",
    "killa_helmet_legendary",
    "golden_tt_reshala_legendary",
    "glukhar_cap_legendary"
]

def pick_item_by_rarity(rarity):
    if rarity == "legendary" and POOL_LEGENDARY:
        return random.choice(POOL_LEGENDARY)
    if rarity == "epic" and POOL_EPIC:
        return random.choice(POOL_EPIC)
    if rarity == "rare" and POOL_RARE:
        return random.choice(POOL_RARE)
    if POOL_COMMON:
        return random.choice(POOL_COMMON)
    return random.choice(ITEMS_LIST)

def roll_supply_item(supply_lvl, user):
    # Rule 3:
    # Base chance for Legendary / >300k: Lvl 1 = 1%, Lvl 5 = 5%, Lvl 10 = 12%
    # Epic: Lvl 1 = 9%, Lvl 10 = 35%
    lvl = max(1, min(10, supply_lvl))
    leg_chance = 0.01 + (lvl - 1) * (0.11 / 9.0) # 1% to 12%
    epic_chance = 0.09 + (lvl - 1) * (0.26 / 9.0) # 9% to 35%

    if has_buff(user, "loot_bonus"):
        leg_chance += 0.10
        epic_chance += 0.10

    roll = random.random()
    if roll < leg_chance:
        return pick_item_by_rarity("legendary")
    elif roll < (leg_chance + epic_chance):
        return pick_item_by_rarity("epic")
    elif roll < (leg_chance + epic_chance + 0.35):
        return pick_item_by_rarity("rare")
    else:
        return pick_item_by_rarity("common")

def generate_airdrop_loot():
    """Balanced airdrop reward pool with ammo, meds, gear, modest rubles and BTC."""
    loot = {
        "items": [],
        "rubles": random.randint(35000, 85000),
        "btc": round(random.uniform(0.05, 0.25), 3)
    }

    # 15% chance for a Boss exclusive relic
    if random.random() < 0.15:
        relic_id = random.choice(BOSS_RELICS)
        if relic_id in ITEMS_BY_ID:
            loot["items"].append(ITEMS_BY_ID[relic_id])

    # 1 High-tier weapon or armor (15% Legendary, 40% Epic, 45% Rare)
    roll_tier = random.random()
    if roll_tier < 0.15:
        loot["items"].append(pick_item_by_rarity("legendary"))
    elif roll_tier < 0.55:
        loot["items"].append(pick_item_by_rarity("epic"))
    else:
        loot["items"].append(pick_item_by_rarity("rare"))

    # 1 Med / Barter / Component item
    if random.random() < 0.30:
        loot["items"].append(pick_item_by_rarity("epic"))
    else:
        loot["items"].append(pick_item_by_rarity("rare"))

    # 1-2 Common items / ammo
    for _ in range(random.randint(1, 2)):
        loot["items"].append(pick_item_by_rarity("common"))

    return loot

# Container & Case Definitions with Mathematical Risk vs Reward Balance
CONTAINER_DEFINITIONS = {
    "scav_box_150k": {
        "id": "scav_box_150k",
        "name": "🧰 Контрабандный Ящик Диких",
        "price": 150000,
        "badge": "🧰",
        "desc": "Сбитый из досок ящик с кустарной контрабандой Диких. Высокий риск неокупа.",
        "item_count": (2, 3),
        "loss_range": (45000, 105000),       # ~50%
        "even_range": (125000, 175000),      # ~35%
        "profit_range": (195000, 320000),    # ~15%
        "probabilities": [0.50, 0.35, 0.15]
    },
    "army_container_750k": {
        "id": "army_container_750k",
        "name": "📦 Армейский Спецконтейнер",
        "price": 750000,
        "badge": "📦",
        "desc": "Герметичный военный контейнер ВС РФ / UNTAR. Лут может не окупить затраты!",
        "item_count": (3, 4),
        "loss_range": (220000, 490000),      # ~48% НЕОКУП (минус 260к - 530к ₽)
        "even_range": (620000, 820000),      # ~34% ОКОЛО НУЛЯ
        "profit_range": (880000, 1250000),   # ~14% ОКУП
        "jackpot_range": (1350000, 2000000), # ~4% ДЖЕКПОТ
        "probabilities": [0.48, 0.34, 0.14, 0.04]
    },
    "terragroup_case_2500k": {
        "id": "terragroup_case_2500k",
        "name": "💼 Секретный Кейс TerraGroup",
        "price": 2500000,
        "badge": "💼",
        "desc": "Титановый сейф-кейс лаборатории. Дорогостоящий риск ради ключ-карт и прототипов.",
        "item_count": (3, 5),
        "loss_range": (1100000, 1850000),    # ~50% НЕОКУП (минус до 1.4 млн ₽)
        "even_range": (2200000, 2750000),    # ~32% ОКОЛО НУЛЯ
        "profit_range": (3100000, 4200000),  # ~15% ОКУП
        "jackpot_range": (5000000, 7500000), # ~3% ДЖЕКПОТ
        "probabilities": [0.50, 0.32, 0.15, 0.03]
    }
}

def generate_container_loot(container_id, user=None):
    """
    Generates balanced container loot where total items value may not pay off.
    Strictly balances the 750k container and others against guaranteed millions.
    """
    cfg = CONTAINER_DEFINITIONS.get(container_id, CONTAINER_DEFINITIONS["army_container_750k"])
    price = cfg["price"]
    probs = list(cfg["probabilities"])

    # If player has loot bonus buff (Pharaoh/Revenant), slight +5% bump to profit
    if user and has_buff(user, "loot_bonus"):
        if len(probs) == 4:
            probs[0] = max(0.35, probs[0] - 0.05)
            probs[2] += 0.05
        else:
            probs[0] = max(0.35, probs[0] - 0.05)
            probs[2] += 0.05

    roll = random.random()
    if len(probs) == 4:
        if roll < probs[0]:
            outcome = "loss"
            target = random.randint(*cfg["loss_range"])
        elif roll < probs[0] + probs[1]:
            outcome = "even"
            target = random.randint(*cfg["even_range"])
        elif roll < probs[0] + probs[1] + probs[2]:
            outcome = "profit"
            target = random.randint(*cfg["profit_range"])
        else:
            outcome = "jackpot"
            target = random.randint(*cfg["jackpot_range"])
    else:
        if roll < probs[0]:
            outcome = "loss"
            target = random.randint(*cfg["loss_range"])
        elif roll < probs[0] + probs[1]:
            outcome = "even"
            target = random.randint(*cfg["even_range"])
        else:
            outcome = "profit"
            target = random.randint(*cfg["profit_range"])

    min_cnt, max_cnt = cfg["item_count"]
    count = random.randint(min_cnt, max_cnt)

    chosen = []
    current_sum = 0
    remaining_target = target
    for i in range(count - 1):
        budget = max(5000, remaining_target // (count - i))
        min_p = max(5000, int(budget * 0.35))
        max_p = int(budget * 1.65)
        candidates = [it for it in ITEMS_LIST if min_p <= it.get("price", 0) <= max_p]
        if not candidates:
            candidates = [it for it in ITEMS_LIST if it.get("price", 0) <= max_p * 1.5]
        if not candidates:
            candidates = ITEMS_LIST
        it = random.choice(candidates)
        chosen.append(it)
        current_sum += it.get("price", 0)
        remaining_target = max(5000, target - current_sum)

    last_cands = [it for it in ITEMS_LIST if abs(it.get("price", 0) - remaining_target) < remaining_target * 0.5]
    if not last_cands:
        last_cands = [it for it in ITEMS_LIST if it.get("price", 0) <= remaining_target * 1.5]
    if not last_cands:
        last_cands = ITEMS_LIST
    last_it = min(last_cands, key=lambda it: abs(it.get("price", 0) - remaining_target))
    chosen.append(last_it)

    total_val = sum(it.get("price", 0) for it in chosen)
    delta = total_val - price

    return {
        "container_id": cfg["id"],
        "name": cfg["name"],
        "price": price,
        "items": chosen,
        "total_value": total_val,
        "delta": delta,
        "outcome": outcome
    }

# Raid Locations
RAID_LOCATIONS = {
    "factory": {
        "name": "🏭 Завод (Factory)",
        "desc": "Жестокий ближний бой, легкие Дикие и шанс встретить Тагиллу.",
        "difficulty": 35,
        "cooldown": 180, # 3 minutes
        "scav_fee": 0,
        "loot_count": (1, 2)
    },
    "customs": {
        "name": "🌲 Таможня (Customs)",
        "desc": "Общаги, стройка, заправка. Охрана босса Решалы.",
        "difficulty": 65,
        "cooldown": 300, # 5 minutes
        "scav_fee": 5000,
        "loot_count": (2, 3)
    },
    "woods": {
        "name": "🏕️ Лес (Woods)",
        "desc": "Снайперские дуэли, лесопилка, снайпер Штурман с СВД.",
        "difficulty": 90,
        "cooldown": 420,
        "scav_fee": 10000,
        "loot_count": (2, 4)
    },
    "reserve": {
        "name": "🏢 Военная база 'Резерв'",
        "desc": "Бункеры, бронепоезд, элитная свита Глухаря и военный лут.",
        "difficulty": 130,
        "cooldown": 600,
        "scav_fee": 20000,
        "loot_count": (3, 5)
    },
    "labs": {
        "name": "🧪 Лаборатория TerraGroup",
        "desc": "Рейдеры ЧВК, тяжелая броня, электронные ключ-карты и LEDX.",
        "difficulty": 180,
        "cooldown": 900,
        "scav_fee": 50000,
        "loot_count": (4, 6)
    }
}

def simulate_raid(location_key, user, squad_power, squad_armor):
    loc = RAID_LOCATIONS.get(location_key, RAID_LOCATIONS["factory"])
    diff = loc["difficulty"]

    # Success chance based on power + armor
    combined_stat = (squad_power * 1.2) + (squad_armor * 0.8)
    ratio = combined_stat / max(1, diff)

    # Win probability curve
    win_chance = min(0.95, max(0.15, ratio / (ratio + 1.0) * 1.3))
    if has_buff(user, "pvp_bonus"): # Ronin/Revenant
        win_chance = min(0.98, win_chance + 0.10)

    roll = random.random()
    success = roll < win_chance

    min_l, max_l = loc["loot_count"]
    found_items = []
    earned_rubles = 0

    if success:
        loot_count = random.randint(min_l, max_l)
        for _ in range(loot_count):
            r = random.random()
            if r < 0.10 or has_buff(user, "loot_bonus"):
                found_items.append(pick_item_by_rarity("epic"))
            elif r < 0.45:
                found_items.append(pick_item_by_rarity("rare"))
            else:
                found_items.append(pick_item_by_rarity("common"))
        earned_rubles = random.randint(15000, 35000) * (loc["difficulty"] // 30)
        if has_buff(user, "prapor_bonus"):
            earned_rubles = int(earned_rubles * 1.1)

    return {
        "success": success,
        "location": loc["name"],
        "items": found_items,
        "rubles": earned_rubles,
        "win_chance": round(win_chance * 100, 1)
    }
