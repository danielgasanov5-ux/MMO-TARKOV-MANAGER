export type ItemCategory = 'weapons' | 'ammo' | 'armor' | 'meds' | 'barter' | 'keys' | 'food' | 'secureContainer';

export type ItemRarity = 'common' | 'rare' | 'epic' | 'classified' | 'legendary';

export interface TarkovItem {
  id: string;
  name: string;
  shortName: string;
  category: ItemCategory;
  subcategory?: string;
  description: string;
  price: number; // in Roubles ₽
  rarity: ItemRarity;
  slots: number; // 1 or 2 cells
  weight: number; // kg
  caliber?: string;
  armorClass?: number;
  durability?: { current: number; max: number };
  quantity?: number;
  iconName: string;
  inRaid?: boolean;
  find_only?: boolean;
}

export interface StashCell {
  index: number; // 0 to 99 (100 cells total)
  item: TarkovItem | null;
}

export interface TraderItem {
  id: string;
  item: TarkovItem;
  stock: number;
  loyaltyRequired: number; // 1 to 4
  price: number;
  barterOnly?: boolean;
}

export interface QuestObjective {
  id: string;
  text: string;
  current: number;
  target: number;
  completed: boolean;
}

export interface Quest {
  id: string;
  title: string;
  traderName: string;
  traderAvatar: string;
  location: string;
  introText: string;
  briefText: string;
  objectives: QuestObjective[];
  rewards: {
    exp: number;
    rubles: number;
    rep: number;
    itemRewards?: string[];
  };
  status: 'available' | 'in_progress' | 'completed';
}

export type RaidTacticId = 'stealth' | 'assault' | 'sniper' | 'scavenge';

export interface RaidTactic {
  id: RaidTacticId;
  name: string;
  title: string;
  badge: string;
  description: string;
  risk: 'Низкий' | 'Высокий' | 'Экстремальный' | 'Умеренный';
  lootPotential: string;
  survivalBonus: number; // % modifier
  killChance: number;
  color: string;
}

export interface RaidLocation {
  id: string;
  name: string;
  codeName: string;
  difficulty: 'Легкая' | 'Средняя' | 'Высокая' | 'Смертельная';
  estTime: string;
  description: string;
  dangerNotes: string;
  hotZones: string[];
  scavBoss: string | null;
  minLevel: number;
}

export interface PMCProfile {
  name: string;
  callsign: string;
  level: number;
  faction: 'BEAR' | 'USEC';
  exp: number;
  nextLevelExp: number;
  rubles: number;
  dollars: number;
  euros: number;
  health: {
    head: number;
    maxHead: number;
    thorax: number;
    maxThorax: number;
    stomach: number;
    maxStomach: number;
    arms: number;
    maxArms: number;
    legs: number;
    maxLegs: number;
  };
  praporRep: number;
  praporSpent: number;
  raidsCount: number;
  survivedCount: number;
  killsCount: number;
}

export interface RaidExecutionResult {
  location: RaidLocation;
  tactic: RaidTactic;
  status: 'survived' | 'kia' | 'mia';
  expEarned: number;
  rublesFound: number;
  kills: number;
  lootFound: TarkovItem[];
  damageTaken: number;
  questUpdates: string[];
  logs: string[];
}
