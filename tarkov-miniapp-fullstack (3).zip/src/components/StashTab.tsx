import React, { useState, useMemo } from 'react';
import { 
  Package, 
  ArrowUpDown, 
  Search, 
  Crosshair, 
  Shield, 
  Headphones,
  ArrowRightLeft,
  Sparkles,
  Check
} from 'lucide-react';
import { StashCell, TarkovItem, ItemCategory } from '../types';
import { ItemIcon } from './ItemIcon';
import { soundManager } from '../utils/audio';
import { equipStashItemBackend } from '../api/client';

interface StashTabProps {
  stash: StashCell[];
  onUpdateStash: (newStash: StashCell[]) => void;
  onSelectItem: (item: TarkovItem, cellIndex: number) => void;
  equippedWeapon: TarkovItem | null;
  equippedArmor: TarkovItem | null;
  equippedHelmet: TarkovItem | null;
  equippedHeadset?: TarkovItem | null;
  equippedRig: TarkovItem | null;
  onEquipItem: (item: TarkovItem, cellIndex?: number) => void;
  onUnequipItem: (slot: 'weapon' | 'armor' | 'helmet' | 'headset' | 'rig') => void;
}

export const StashTab: React.FC<StashTabProps> = ({
  stash,
  onUpdateStash,
  onSelectItem,
  equippedWeapon,
  equippedArmor,
  equippedHelmet,
  equippedHeadset,
  equippedRig,
  onEquipItem,
  onUnequipItem,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCellSource, setActiveCellSource] = useState<number | null>(null);
  const [quickEquipNotice, setQuickEquipNotice] = useState<string | null>(null);

  // Count occupied cells
  const occupiedCount = useMemo(() => {
    return stash.filter(cell => cell.item !== null).length;
  }, [stash]);

  // Total stash value in Roubles
  const totalStashValue = useMemo(() => {
    return stash.reduce((sum, cell) => sum + (cell.item ? cell.item.price : 0), 0);
  }, [stash]);

  // Total stash weight in kg
  const totalWeight = useMemo(() => {
    return stash.reduce((sum, cell) => sum + (cell.item ? cell.item.weight : 0), 0);
  }, [stash]);

  // Check if item matches category filter
  const matchesCategory = (item: TarkovItem | null, cat: string) => {
    if (!item) return false;
    if (cat === 'all') return true;
    if (cat === 'weapons') return item.category === 'weapons';
    if (cat === 'armor_helmets') {
      return item.category === 'armor' && (item.subcategory === 'body_armor' || item.subcategory === 'helmet' || item.name.includes('Броня') || item.name.includes('Шлем') || item.name.includes('Каска') || item.name.includes('PACA') || item.name.includes('Алтын') || item.name.includes('Корунд') || item.name.includes('Slick') || item.name.includes('6Б'));
    }
    if (cat === 'headset') {
      return item.category === 'armor' && (item.subcategory === 'headset' || item.name.toLowerCase().includes('наушник') || item.name.includes('ГСШ') || item.name.includes('ComTac') || item.name.includes('Sordin') || item.name.includes('Razor'));
    }
    if (cat === 'rigs') {
      return item.category === 'armor' && item.subcategory === 'rig';
    }
    return item.category === cat;
  };

  // Filtered cells for highlight
  const isHighlighted = (item: TarkovItem | null) => {
    if (!item) return false;
    if (!matchesCategory(item, selectedCategory)) return false;
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      return (
        item.name.toLowerCase().includes(q) ||
        item.shortName.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q)
      );
    }
    return true;
  };

  // Items for quick-equip panel when armor/helmets or headset tab is selected
  const quickCategoryItems = useMemo(() => {
    if (selectedCategory !== 'armor_helmets' && selectedCategory !== 'headset' && selectedCategory !== 'weapons') {
      return [];
    }
    return stash
      .filter(c => c.item && matchesCategory(c.item, selectedCategory))
      .map(c => ({ item: c.item!, cellIndex: c.index }));
  }, [stash, selectedCategory]);

  const handleQuickEquip = async (item: TarkovItem, cellIndex: number) => {
    soundManager.playItemMove();
    let slotType = 'armor';
    if (item.category === 'weapons') {
      slotType = 'weapon';
    } else if (item.subcategory === 'headset' || item.name.toLowerCase().includes('наушник') || item.name.includes('ГСШ') || item.name.includes('ComTac') || item.name.includes('Sordin')) {
      slotType = 'headset';
    } else if (item.subcategory === 'helmet' || item.name.includes('Шлем') || item.name.includes('Каска') || item.name.includes('Колпак') || item.name.includes('Алтын')) {
      slotType = 'helmet';
    } else if (item.subcategory === 'rig') {
      slotType = 'rig';
    }

    // Call client prop
    onEquipItem(item, cellIndex);

    // Sync with backend API
    try {
      await equipStashItemBackend(cellIndex, slotType);
    } catch {
      // client-side handles state
    }

    setQuickEquipNotice(`Экипировано: ${item.shortName}`);
    setTimeout(() => setQuickEquipNotice(null), 2500);
  };

  // Move or swap items between cells
  const handleCellClick = (index: number) => {
    const targetCell = stash[index];

    if (activeCellSource !== null) {
      if (activeCellSource === index) {
        setActiveCellSource(null);
        soundManager.playClick();
        return;
      }

      soundManager.playItemMove();
      const newStash = [...stash];
      const sourceItem = newStash[activeCellSource].item;
      const targetItem = newStash[index].item;

      newStash[activeCellSource].item = targetItem;
      newStash[index].item = sourceItem;

      onUpdateStash(newStash);
      setActiveCellSource(null);
      return;
    }

    if (targetCell.item) {
      soundManager.playClick();
      onSelectItem(targetCell.item, index);
    }
  };

  const handleStartMove = (index: number, e: React.MouseEvent) => {
    e.stopPropagation();
    soundManager.playClick();
    setActiveCellSource(activeCellSource === index ? null : index);
  };

  // Auto-sort items in the 100-cell stash
  const handleAutoSort = () => {
    soundManager.playItemMove();
    const items = stash
      .map(c => c.item)
      .filter((it): it is TarkovItem => it !== null);

    const categoryOrder: Record<ItemCategory, number> = {
      weapons: 1,
      armor: 2,
      ammo: 3,
      meds: 4,
      barter: 5,
      keys: 6,
      food: 7,
      secureContainer: 8,
    };

    items.sort((a, b) => {
      const catDiff = (categoryOrder[a.category] || 99) - (categoryOrder[b.category] || 99);
      if (catDiff !== 0) return catDiff;
      return b.price - a.price;
    });

    const newStash: StashCell[] = Array.from({ length: 100 }, (_, idx) => ({
      index: idx,
      item: items[idx] || null,
    }));

    onUpdateStash(newStash);
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* Top Loadout & Stash Controls */}
      <div className="bg-[#0f0f0f] border border-[#2a2a2a] rounded-sm overflow-hidden shadow-xl">
        <div className="p-3.5 border-b border-[#2a2a2a] flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#151515]">
          <div>
            <div className="flex items-center gap-2">
              <Package className="w-4 h-4 text-[#9a8866]" />
              <h2 className="text-xs uppercase tracking-[0.2em] font-bold text-[#9a8866]">
                STASH (10x10 СЕТКА • 100 ЯЧЕЕК)
              </h2>
            </div>
            <p className="text-[10px] text-[#666] font-mono mt-0.5 tracking-wide">
              ХРАНИЛИЩЕ ОПЕРАТИВНИКА • ПОЛНЫЙ НАБОР СНАРЯЖЕНИЯ И ТРОФЕЕВ
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleAutoSort}
              className="px-3 py-1.5 bg-[#1a1a1a] hover:bg-[#222] text-[#888] hover:text-[#d1d1d1] border border-[#333] rounded-sm text-[10px] font-mono uppercase tracking-wider flex items-center gap-1.5 transition-colors"
              title="Упорядочить предметы по категориям и ценности"
            >
              <ArrowUpDown className="w-3.5 h-3.5 text-[#9a8866]" />
              Автосортировка
            </button>
          </div>
        </div>

        {/* Capacity & Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3.5 bg-[#0f0f0f] text-xs font-mono">
          <div className="p-2.5 bg-[#121212] rounded-sm border border-[#222]">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">ВМЕСТИМОСТЬ СХРОНА</div>
            <div className="flex items-baseline gap-1 mt-1">
              <span className={`text-sm font-bold font-mono ${occupiedCount >= 100 ? 'text-red-400' : 'text-[#d1d1d1]'}`}>
                {occupiedCount}
              </span>
              <span className="text-[#555] text-[10px]">/ 100 ячеек</span>
            </div>
            <div className="w-full h-1 bg-[#1a1a1a] rounded-none mt-2 overflow-hidden">
              <div 
                className={`h-full transition-all ${occupiedCount > 90 ? 'bg-red-500' : 'bg-[#9a8866]'}`}
                style={{ width: `${(occupiedCount / 100) * 100}%` }}
              />
            </div>
          </div>

          <div className="p-2.5 bg-[#121212] rounded-sm border border-[#222]">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">СТОИМОСТЬ ИМУЩЕСТВА</div>
            <div className="text-sm font-bold font-mono text-[#9a8866] mt-1">
              {totalStashValue.toLocaleString('ru-RU')} ₽
            </div>
            <div className="text-[9px] text-[#555] mt-1 uppercase">Оценка по Барахолке</div>
          </div>

          <div className="p-2.5 bg-[#121212] rounded-sm border border-[#222]">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">МАССА СНАРЯЖЕНИЯ</div>
            <div className="text-sm font-bold font-mono text-[#d1d1d1] mt-1">
              {totalWeight.toFixed(1)} кг
            </div>
            <div className="text-[9px] text-[#555] mt-1 uppercase">Лимит без перегруза</div>
          </div>

          <div className="p-2.5 bg-[#121212] rounded-sm border border-[#222]">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">СВОБОДНЫЕ СЛОТЫ</div>
            <div className="text-sm font-bold font-mono text-[#888] mt-1">
              {100 - occupiedCount} яч.
            </div>
            <div className="text-[9px] text-[#555] mt-1 uppercase">
              {occupiedCount >= 100 ? 'Схрон забит!' : 'Доступно под хабар'}
            </div>
          </div>
        </div>
      </div>

      {/* Active PMC Loadout Strip (5 Slots: Weapon, Armor, Helmet, Headset, Rig) */}
      <div className="bg-[#0f0f0f] border border-[#2a2a2a] rounded-sm p-3.5 shadow">
        <div className="text-[10px] uppercase font-bold tracking-[0.15em] text-[#888] font-mono mb-2.5 flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-[#9a8866]">
            <Shield className="w-3.5 h-3.5 text-[#9a8866]" />
            АКТИВНЫЙ БОЕКОМПЛЕКТ В РЕЙД
          </span>
          <span className="text-[#666] font-normal lowercase">
            (кликните слот для снятия в схрон)
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-mono">
          {/* Weapon Slot */}
          <div 
            onClick={() => equippedWeapon && onUnequipItem('weapon')}
            className={`p-2 rounded-sm border cursor-pointer transition-all flex items-center gap-2.5 ${
              equippedWeapon 
                ? 'bg-[#151515] border-l-2 border-l-[#9a8866] border-[#2e2e2e] hover:border-[#444]' 
                : 'bg-[#111] border-dashed border-[#222] opacity-70'
            }`}
          >
            <div className="w-8 h-8 bg-[#1a1a1a] rounded-sm flex items-center justify-center border border-[#2a2a2a] shrink-0">
              <Crosshair className="w-4 h-4 text-[#9a8866]" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[9px] uppercase text-[#666] tracking-wider">ОРУЖИЕ</div>
              <div className="font-bold text-[#d1d1d1] truncate text-xs">
                {equippedWeapon ? equippedWeapon.shortName : 'Пусто'}
              </div>
            </div>
          </div>

          {/* Armor Slot */}
          <div 
            onClick={() => equippedArmor && onUnequipItem('armor')}
            className={`p-2 rounded-sm border cursor-pointer transition-all flex items-center gap-2.5 ${
              equippedArmor 
                ? 'bg-[#151515] border-l-2 border-l-[#9a8866] border-[#2e2e2e] hover:border-[#444]' 
                : 'bg-[#111] border-dashed border-[#222] opacity-70'
            }`}
          >
            <div className="w-8 h-8 bg-[#1a1a1a] rounded-sm flex items-center justify-center border border-[#2a2a2a] shrink-0">
              <Shield className="w-4 h-4 text-blue-400" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[9px] uppercase text-[#666] tracking-wider">БРОНЕЖИЛЕТ</div>
              <div className="font-bold text-[#d1d1d1] truncate text-xs">
                {equippedArmor ? equippedArmor.shortName : 'Пусто'}
              </div>
            </div>
          </div>

          {/* Helmet Slot */}
          <div 
            onClick={() => equippedHelmet && onUnequipItem('helmet')}
            className={`p-2 rounded-sm border cursor-pointer transition-all flex items-center gap-2.5 ${
              equippedHelmet 
                ? 'bg-[#151515] border-l-2 border-l-[#9a8866] border-[#2e2e2e] hover:border-[#444]' 
                : 'bg-[#111] border-dashed border-[#222] opacity-70'
            }`}
          >
            <div className="w-8 h-8 bg-[#1a1a1a] rounded-sm flex items-center justify-center border border-[#2a2a2a] shrink-0">
              <Shield className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[9px] uppercase text-[#666] tracking-wider">ШЛЕМ</div>
              <div className="font-bold text-[#d1d1d1] truncate text-xs">
                {equippedHelmet ? equippedHelmet.shortName : 'Пусто'}
              </div>
            </div>
          </div>

          {/* Headset Slot (Active Tactical Headset) */}
          <div 
            onClick={() => equippedHeadset && onUnequipItem('headset')}
            className={`p-2 rounded-sm border cursor-pointer transition-all flex items-center gap-2.5 ${
              equippedHeadset 
                ? 'bg-[#151515] border-l-2 border-l-[#9a8866] border-[#2e2e2e] hover:border-[#444]' 
                : 'bg-[#111] border-dashed border-[#222] opacity-70'
            }`}
          >
            <div className="w-8 h-8 bg-[#1a1a1a] rounded-sm flex items-center justify-center border border-[#2a2a2a] shrink-0">
              <Headphones className="w-4 h-4 text-amber-400" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[9px] uppercase text-[#666] tracking-wider">НАУШНИКИ</div>
              <div className="font-bold text-[#d1d1d1] truncate text-xs">
                {equippedHeadset ? equippedHeadset.shortName : 'Пусто'}
              </div>
            </div>
          </div>

          {/* Rig Slot */}
          <div 
            onClick={() => equippedRig && onUnequipItem('rig')}
            className={`p-2 rounded-sm border cursor-pointer transition-all flex items-center gap-2.5 ${
              equippedRig 
                ? 'bg-[#151515] border-l-2 border-l-[#9a8866] border-[#2e2e2e] hover:border-[#444]' 
                : 'bg-[#111] border-dashed border-[#222] opacity-70'
            }`}
          >
            <div className="w-8 h-8 bg-[#1a1a1a] rounded-sm flex items-center justify-center border border-[#2a2a2a] shrink-0">
              <Package className="w-4 h-4 text-[#9a8866]" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[9px] uppercase text-[#666] tracking-wider">РАЗГРУЗКА</div>
              <div className="font-bold text-[#d1d1d1] truncate text-xs">
                {equippedRig ? equippedRig.shortName : 'Пусто'}
              </div>
            </div>
          </div>
        </div>

        {equippedHeadset && (
          <div className="mt-2.5 px-2.5 py-1.5 bg-[#121612] border border-emerald-800/40 rounded-sm text-[10px] font-mono text-emerald-300 flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Бонус активной гарнитуры: раскрытие засад за 50 м и -25% входящего урона при внезапном огневом контакте!</span>
          </div>
        )}
      </div>

      {/* Quick Equip Flash Notice */}
      {quickEquipNotice && (
        <div className="p-2.5 bg-[#182618] border border-emerald-500 rounded-sm text-xs font-mono text-emerald-300 flex items-center gap-2 animate-fadeIn">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{quickEquipNotice}</span>
        </div>
      )}

      {/* Category Tabs (Fixed Armor & Helmets + Active Headsets buttons) */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {[
            { id: 'all', label: 'Все' },
            { id: 'weapons', label: '🔫 Оружие' },
            { id: 'armor_helmets', label: '🛡️ Броня и Шлемы' },
            { id: 'headset', label: '🎧 Активные наушники' },
            { id: 'rigs', label: '🎒 Разгрузки' },
            { id: 'meds', label: '💊 Медицина' },
            { id: 'ammo', label: '📦 Патроны' },
            { id: 'barter', label: '💎 Ценности' },
            { id: 'keys', label: '🔑 Ключи' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                soundManager.playClick();
                setSelectedCategory(tab.id);
              }}
              className={`px-3 py-1.5 rounded-sm text-[10px] font-mono uppercase tracking-wider whitespace-nowrap transition-colors border ${
                selectedCategory === tab.id
                  ? 'bg-[#9a8866] text-black font-bold border-[#9a8866]'
                  : 'bg-[#151515] text-[#666] border-[#2a2a2a] hover:text-[#d1d1d1] hover:bg-[#1f1f1f]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative min-w-[200px]">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#666]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Поиск по схрону..."
            className="w-full pl-8 pr-3 py-1.5 bg-[#121212] border border-[#2a2a2a] rounded-sm text-xs font-mono text-[#d1d1d1] placeholder:text-[#555] focus:outline-none focus:border-[#9a8866]"
          />
        </div>
      </div>

      {/* Quick-Equip Drawer for Armor/Helmets and Headsets */}
      {(selectedCategory === 'armor_helmets' || selectedCategory === 'headset') && (
        <div className="p-3 bg-[#131313] border border-[#2a2a2a] rounded-sm space-y-2">
          <div className="flex items-center justify-between text-[10px] font-mono text-[#9a8866] uppercase tracking-wider">
            <span>
              {selectedCategory === 'armor_helmets' ? '🛡️ БРОНЯ И ШЛЕМЫ В СХРОНЕ' : '🎧 АКТИВНЫЕ НАУШНИКИ В СХРОНЕ'} ({quickCategoryItems.length} ШТ.)
            </span>
            <span className="text-[#666]">Кликните по предмету для мгновенного надевания</span>
          </div>

          {quickCategoryItems.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {quickCategoryItems.map(({ item, cellIndex }) => (
                <div
                  key={item.id}
                  onClick={() => handleQuickEquip(item, cellIndex)}
                  className="p-2 bg-[#1a1a1a] hover:bg-[#242424] border border-[#333] hover:border-[#9a8866] rounded-sm flex items-center justify-between gap-2 cursor-pointer transition-all"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <ItemIcon
                      iconName={item.iconName}
                      category={item.category}
                      rarity={item.rarity}
                      className="w-4 h-4 shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-[#d1d1d1] truncate font-tarkov">
                        {item.shortName}
                      </div>
                      <div className="text-[9px] text-[#777] font-mono truncate">
                        {item.armorClass ? `Класс ${item.armorClass} • ` : ''} {item.weight} кг
                      </div>
                    </div>
                  </div>

                  <button
                    className="px-2 py-1 bg-[#2a2a2a] hover:bg-[#9a8866] text-[#888] hover:text-black font-bold rounded-sm text-[9px] font-mono uppercase tracking-wider transition-colors shrink-0"
                  >
                    Надеть
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-[11px] text-[#666] font-mono py-2 text-center">
              В вашем схроне нет предметов этой категории. Найдите их в рейдах или приобретите у Прапора!
            </div>
          )}
        </div>
      )}

      {activeCellSource !== null && (
        <div className="p-3 bg-[#1e1c18] border border-[#9a8866]/50 rounded-sm flex items-center justify-between text-xs font-mono text-[#9a8866]">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 animate-spin text-[#9a8866]" />
            <span>
              Выбрана ячейка #{activeCellSource + 1}. Кликните по любой ячейке для перемещения или обмена.
            </span>
          </div>
          <button
            onClick={() => setActiveCellSource(null)}
            className="px-2.5 py-0.5 bg-[#2a2a2a] hover:bg-[#333] text-[#d1d1d1] rounded-sm text-[10px] uppercase font-bold"
          >
            Отмена
          </button>
        </div>
      )}

      {/* The 100-Cell Tarkov Tactical Grid (Strict 10x10 CSS Grid) */}
      <div className="bg-[#080808] border border-[#222] rounded-sm p-3.5 shadow-2xl">
        <div className="flex items-center justify-between text-[10px] font-mono text-[#666] uppercase tracking-wider mb-2.5 px-1">
          <span className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-[#9a8866]" />
            СЕТКА СХРОНА: 100 ЯЧЕЕК (10x10)
          </span>
          <span className="text-[#444] hidden sm:inline">
            10 РЯДОВ ПО 10 СЛОТОВ • КЛИК ДЛЯ ОСМОТРА ИЛИ НАДЕВАНИЯ
          </span>
        </div>

        {/* 100 Grid Cells Container (Strict 10-column layout) */}
        <div className="grid grid-cols-5 sm:grid-cols-10 gap-1 sm:gap-1.5 bg-[#050505] p-1.5 border border-[#1a1a1a]">
          {stash.map((cell) => {
            const item = cell.item;
            const highlighted = isHighlighted(item);
            const isSelected = activeCellSource === cell.index;

            return (
              <div
                key={cell.index}
                onClick={() => handleCellClick(cell.index)}
                className={`group relative aspect-square rounded-none border transition-all cursor-pointer flex flex-col items-center justify-center p-1 select-none overflow-hidden ${
                  isSelected
                    ? 'border-[#9a8866] ring-1 ring-[#9a8866] bg-[#221f19]'
                    : item
                    ? highlighted
                      ? 'border-[#2a2a2a] hover:border-[#9a8866] bg-[#141414] hover:bg-[#1a1a1a]'
                      : 'border-[#1a1a1a] opacity-30 bg-[#0d0d0d]'
                    : 'border-[#161616] hover:border-[#2a2a2a] bg-[#0c0c0c]'
                }`}
                title={item ? `${item.name} (${item.price.toLocaleString('ru-RU')} ₽)` : `Ячейка #${cell.index + 1}`}
              >
                {/* Cell Number Badge */}
                <span className="absolute top-0.5 left-1 text-[7px] font-mono text-[#444] pointer-events-none group-hover:text-[#666]">
                  {cell.index + 1 < 10 ? `0${cell.index + 1}` : cell.index + 1}
                </span>

                {item ? (
                  <>
                    {/* Item Category / Rarity Indicator */}
                    <ItemIcon
                      iconName={item.iconName}
                      category={item.category}
                      rarity={item.rarity}
                      className="w-5 h-5 sm:w-6 sm:h-6"
                    />

                    {/* Short item label */}
                    <span className="text-[9px] sm:text-[10px] font-bold text-[#d1d1d1] font-tarkov text-center leading-tight truncate w-full px-0.5 mt-0.5">
                      {item.shortName}
                    </span>

                    {/* Quantity or Durability Indicator */}
                    {item.quantity && (
                      <span className="absolute bottom-0.5 right-1 text-[8px] font-mono font-bold text-[#9a8866] bg-black/80 px-0.5 rounded-none">
                        {item.quantity}
                      </span>
                    )}

                    {item.durability && (
                      <span className="absolute bottom-0.5 right-1 text-[7px] font-mono text-emerald-400 bg-black/80 px-0.5 rounded-none">
                        {item.durability.current}
                      </span>
                    )}

                    {/* Find Only Badge */}
                    {item.find_only && (
                      <span className="absolute top-0.5 right-1 text-[6px] font-mono text-amber-400 bg-black/80 px-0.5 rounded-none">
                        FIR
                      </span>
                    )}

                    {/* Move Handle on hover */}
                    <button
                      onClick={(e) => handleStartMove(cell.index, e)}
                      className="absolute top-0.5 right-0.5 p-0.5 bg-black/80 text-[#888] hover:text-[#d1d1d1] opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Переместить ячейку"
                    >
                      <ArrowRightLeft className="w-2.5 h-2.5" />
                    </button>
                  </>
                ) : (
                  <div className="w-1 h-1 bg-[#222] group-hover:bg-[#444]" />
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
