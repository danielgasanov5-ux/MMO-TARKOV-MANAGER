import React from 'react';
import { 
  User, 
  Shield, 
  Award, 
  Crosshair, 
  Heart, 
  TrendingUp, 
  RotateCcw,
  Zap,
  Activity
} from 'lucide-react';
import { PMCProfile, TarkovItem } from '../types';
import { soundManager } from '../utils/audio';

interface ProfileTabProps {
  profile: PMCProfile;
  onUpdateProfile: (updater: (prev: PMCProfile) => PMCProfile) => void;
  equippedWeapon: TarkovItem | null;
  equippedArmor: TarkovItem | null;
  equippedHelmet: TarkovItem | null;
  equippedHeadset?: TarkovItem | null;
  equippedRig: TarkovItem | null;
  onResetStash: () => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  profile,
  onUpdateProfile,
  equippedWeapon,
  equippedArmor,
  equippedHelmet,
  equippedHeadset,
  equippedRig,
  onResetStash,
}) => {
  const survivalRate = profile.raidsCount > 0 
    ? Math.round((profile.survivedCount / profile.raidsCount) * 100) 
    : 100;

  const kdRatio = profile.raidsCount - profile.survivedCount > 0 
    ? (profile.killsCount / (profile.raidsCount - profile.survivedCount)).toFixed(2)
    : profile.killsCount.toFixed(2);

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* PMC Dossier Card */}
      <div className="bg-[#0f0f0f] border border-[#2a2a2a] rounded-sm p-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-[#242424]">
          <div className="flex items-center gap-3.5">
            <div className={`w-12 h-12 rounded-sm flex items-center justify-center font-bold text-sm border font-mono tracking-wider ${
              profile.faction === 'BEAR'
                ? 'bg-[#1e1515] border-red-900/60 text-red-400'
                : 'bg-[#151c24] border-sky-900/60 text-sky-400'
            }`}>
              {profile.faction}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-[#d1d1d1] font-tarkov uppercase tracking-wide">
                  {profile.callsign}
                </h2>
                <span className="px-2 py-0.5 bg-[#181818] text-[#9a8866] border border-[#333] rounded-sm text-[10px] font-mono font-bold uppercase tracking-wider">
                  LEVEL {profile.level}
                </span>
              </div>
              <p className="text-[10px] text-[#666] font-mono mt-0.5 tracking-wide">
                OPERATIVE: {profile.faction === 'BEAR' ? 'Battle Enhanced Air Recon (BEAR)' : 'United Security (USEC)'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                soundManager.playClick();
                onUpdateProfile(prev => ({
                  ...prev,
                  faction: prev.faction === 'BEAR' ? 'USEC' : 'BEAR'
                }));
              }}
              className="px-3 py-1.5 bg-[#1e1e1e] hover:bg-[#282828] text-[#aaa] hover:text-[#d1d1d1] border border-[#333] rounded-sm text-[10px] font-mono uppercase tracking-wider transition-colors"
            >
              Сменить фракцию
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                if (confirm('Сбросить схрон к исходному набору из 20 предметов?')) {
                  onResetStash();
                }
              }}
              className="px-3 py-1.5 bg-[#1f1515] hover:bg-[#2d1b1b] text-red-400 border border-red-900/60 rounded-sm text-[10px] font-mono uppercase tracking-wider flex items-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              Сброс схрона
            </button>
          </div>
        </div>

        {/* Combat Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 text-xs font-mono">
          <div className="p-3 bg-[#151515] border border-[#242424] rounded-sm">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">ВЫХОДОВ В РЕЙД</div>
            <div className="text-sm font-bold text-[#d1d1d1] mt-1">
              {profile.raidsCount} рейдов
            </div>
            <div className="text-[9px] text-[#666] mt-0.5">
              Выжил: <span className="text-emerald-400 font-semibold">{profile.survivedCount}</span>
            </div>
          </div>

          <div className="p-3 bg-[#151515] border border-[#242424] rounded-sm">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">ПРОЦЕНТ ВЫЖИВАНИЯ</div>
            <div className="text-sm font-bold text-emerald-400 mt-1">
              {survivalRate}%
            </div>
            <div className="text-[9px] text-[#666] mt-0.5">Боевая статистика</div>
          </div>

          <div className="p-3 bg-[#151515] border border-[#242424] rounded-sm">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">ЛИКВИДИРОВАНО ЦЕЛЕЙ</div>
            <div className="text-sm font-bold text-red-400 mt-1">
              {profile.killsCount} врагов
            </div>
            <div className="text-[9px] text-[#666] mt-0.5">K/D: {kdRatio}</div>
          </div>

          <div className="p-3 bg-[#151515] border border-[#242424] rounded-sm">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">РЕПУТАЦИЯ ПРАПОРА</div>
            <div className="text-sm font-bold text-[#9a8866] mt-1">
              +{profile.praporRep.toFixed(2)}
            </div>
            <div className="text-[9px] text-[#666] mt-0.5">
              Оборот: {profile.praporSpent.toLocaleString('ru-RU')} ₽
            </div>
          </div>
        </div>
      </div>

      {/* Equipped Gear Dossier */}
      <div className="bg-[#0f0f0f] border border-[#2a2a2a] rounded-sm p-4 shadow-xl">
        <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-[#9a8866] font-mono mb-3 flex items-center gap-2">
          <Shield className="w-3.5 h-3.5 text-[#9a8866]" />
          ТЕКУЩИЙ БОЕКОМПЛЕКТ БОЙЦА
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
          <div className="p-3 bg-[#151515] border border-[#242424] rounded-sm">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">ОСНОВНОЙ СТВОЛ</div>
            <div className="font-bold text-[#d1d1d1] mt-1">
              {equippedWeapon ? equippedWeapon.name : 'Не экипировано'}
            </div>
            {equippedWeapon && (
              <div className="text-[10px] text-[#777] mt-0.5">
                Калибр: {equippedWeapon.caliber} • Масса: {equippedWeapon.weight} кг
              </div>
            )}
          </div>

          <div className="p-3 bg-[#151515] border border-[#242424] rounded-sm">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">БРОНЕЖИЛЕТ</div>
            <div className="font-bold text-[#d1d1d1] mt-1">
              {equippedArmor ? equippedArmor.name : 'Не экипировано'}
            </div>
            {equippedArmor && (
              <div className="text-[10px] text-[#777] mt-0.5">
                Класс: {equippedArmor.armorClass} • Прочность: {equippedArmor.durability?.current} HP
              </div>
            )}
          </div>

          <div className="p-3 bg-[#151515] border border-[#242424] rounded-sm">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">ШЛЕМ</div>
            <div className="font-bold text-[#d1d1d1] mt-1">
              {equippedHelmet ? equippedHelmet.name : 'Не экипировано'}
            </div>
          </div>

          <div className="p-3 bg-[#151515] border border-[#242424] rounded-sm">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">ТАКТИЧЕСКАЯ РАЗГРУЗКА</div>
            <div className="font-bold text-[#d1d1d1] mt-1">
              {equippedRig ? equippedRig.name : 'Не экипировано'}
            </div>
          </div>

          <div className="p-3 bg-[#151515] border border-[#242424] rounded-sm">
            <div className="text-[#666] text-[9px] uppercase tracking-wider">АКТИВНЫЕ НАУШНИКИ (ГАРНИТУРА)</div>
            <div className="font-bold text-[#d1d1d1] mt-1">
              {equippedHeadset ? equippedHeadset.name : 'Не экипировано (Шанс внезапной засады)'}
            </div>
            {equippedHeadset && (
              <div className="text-[10px] text-amber-400 mt-0.5">
                Бонус: +25% к защите от засад в рейдах
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
