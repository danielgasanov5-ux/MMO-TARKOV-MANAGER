import React from 'react';
import { X, Shield, Weight, CircleDollarSign, Zap, Crosshair } from 'lucide-react';
import { TarkovItem } from '../types';
import { ItemIcon } from './ItemIcon';
import { soundManager } from '../utils/audio';

interface ItemModalProps {
  item: TarkovItem | null;
  onClose: () => void;
  onSell?: (item: TarkovItem) => void;
  onEquip?: (item: TarkovItem) => void;
  onDiscard?: (item: TarkovItem) => void;
  onUseMed?: (item: TarkovItem) => void;
}

export const ItemModal: React.FC<ItemModalProps> = ({
  item,
  onClose,
  onSell,
  onEquip,
  onDiscard,
  onUseMed,
}) => {
  if (!item) return null;

  const getRarityBadge = (rarity: string) => {
    switch (rarity) {
      case 'classified':
        return { label: 'СЕКРЕТНО / РЕДКОЕ', class: 'border-amber-500/50 text-amber-400 bg-amber-500/10' };
      case 'epic':
        return { label: 'ВОЕННОГО НАЗНАЧЕНИЯ', class: 'border-purple-500/50 text-purple-400 bg-purple-500/10' };
      case 'rare':
        return { label: 'СПЕЦОБОРУДОВАНИЕ', class: 'border-blue-500/50 text-blue-400 bg-blue-500/10' };
      default:
        return { label: 'СТАНДАРТНОЕ', class: 'border-zinc-700 text-zinc-400 bg-zinc-800/40' };
    }
  };

  const badge = getRarityBadge(item.rarity);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#0f0f0f] border border-[#2a2a2a] rounded-sm shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#151515] border-b border-[#242424]">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#9a8866]" />
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-[#888]">
              ОСМОТР ПРЕДМЕТА #{item.id.toUpperCase().slice(-6)}
            </span>
          </div>
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="p-1 text-[#666] hover:text-[#d1d1d1] rounded-sm transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          <div className="flex gap-4 items-start">
            <div className="w-20 h-20 bg-[#181818] border border-[#2e2e2e] rounded-sm flex flex-col items-center justify-center relative p-2 shrink-0">
              <ItemIcon iconName={item.iconName} category={item.category} rarity={item.rarity} className="w-10 h-10" />
              {item.inRaid && (
                <span className="absolute top-1 left-1 px-1 text-[8px] font-mono font-bold bg-[#9a8866] text-black rounded-none uppercase">
                  В РЕЙДЕ
                </span>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="inline-block px-1.5 py-0.5 rounded-sm text-[9px] font-mono font-semibold mb-1 border border-[#333] bg-[#1a1a1a] text-[#9a8866]">
                {item.category.toUpperCase()}
              </div>
              <h3 className="text-sm font-bold text-[#d1d1d1] font-tarkov leading-snug">
                {item.name}
              </h3>
              <p className="text-[10px] text-[#666] mt-0.5 font-mono uppercase">
                СЕТКА: {item.slots} ЯЧЕЙКИ • ВЕС: {item.weight} КГ
              </p>
            </div>
          </div>

          {/* Description */}
          <div className="p-3 bg-[#121212] border-l-2 border-[#9a8866] border border-[#222] rounded-none text-xs text-[#888] leading-relaxed font-mono">
            {item.description}
          </div>

          {/* Tactical specs grid */}
          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <div className="flex flex-col justify-between p-2 bg-[#151515] rounded-sm border border-[#242424] col-span-2 sm:col-span-1">
              <div className="flex items-center justify-between text-[10px] uppercase text-[#666] mb-1">
                <span className="flex items-center gap-1.5">
                  <CircleDollarSign className="w-3.5 h-3.5 text-[#9a8866]" />
                  Каталог:
                </span>
                <span className="font-bold text-[#888]">
                  {item.price.toLocaleString('ru-RU')} ₽
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#9a8866] font-semibold">
                  Перед продажей:
                </span>
                <span className="font-bold text-emerald-400 font-mono">
                  +{item.category === 'junk' || item.category === 'barter' ? Math.round(item.price / 2.3).toLocaleString('ru-RU') : Math.round(item.price * 0.6).toLocaleString('ru-RU')} ₽
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between p-2 bg-[#151515] rounded-sm border border-[#242424]">
              <span className="text-[#666] flex items-center gap-1.5 text-[10px] uppercase">
                <Weight className="w-3.5 h-3.5 text-[#666]" />
                Масса:
              </span>
              <span className="font-bold text-[#aaa]">
                {item.weight} кг
              </span>
            </div>

            {item.caliber && (
              <div className="flex items-center justify-between p-2 bg-[#151515] rounded-sm border border-[#242424]">
                <span className="text-[#666] flex items-center gap-1.5 text-[10px] uppercase">
                  <Crosshair className="w-3.5 h-3.5 text-[#888]" />
                  Калибр:
                </span>
                <span className="font-bold text-[#bbb]">
                  {item.caliber}
                </span>
              </div>
            )}

            {item.armorClass && (
              <div className="flex items-center justify-between p-2 bg-[#151515] rounded-sm border border-[#242424]">
                <span className="text-[#666] flex items-center gap-1.5 text-[10px] uppercase">
                  <Shield className="w-3.5 h-3.5 text-[#888]" />
                  Класс брони:
                </span>
                <span className="font-bold text-[#9a8866]">
                  {item.armorClass} класс
                </span>
              </div>
            )}

            {item.durability && (
              <div className="flex items-center justify-between p-2 bg-[#151515] rounded-sm border border-[#242424] col-span-2">
                <span className="text-[#666] flex items-center gap-1.5 text-[10px] uppercase">
                  <Zap className="w-3.5 h-3.5 text-emerald-400" />
                  Ресурс / Прочность:
                </span>
                <span className="font-bold text-emerald-400">
                  {item.durability.current} / {item.durability.max}
                </span>
              </div>
            )}

            {item.quantity && (
              <div className="flex items-center justify-between p-2 bg-[#151515] rounded-sm border border-[#242424] col-span-2">
                <span className="text-[#666] text-[10px] uppercase">Количество в пачке:</span>
                <span className="font-bold text-[#9a8866]">{item.quantity} шт.</span>
              </div>
            )}
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-col gap-2 font-mono">
            {item.category === 'meds' && onUseMed && (
              <button
                onClick={() => {
                  soundManager.playSuccess();
                  onUseMed(item);
                  onClose();
                }}
                className="w-full py-2.5 px-3 bg-[#1e2a22] hover:bg-[#25362b] border border-emerald-800 text-emerald-300 font-bold rounded-sm text-[10px] uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5"
              >
                Использовать медкомплект
              </button>
            )}

            {(item.category === 'weapons' || item.category === 'armor') && onEquip && (
              <button
                onClick={() => {
                  soundManager.playEquipWeapon();
                  onEquip(item);
                  onClose();
                }}
                className="w-full py-2.5 px-3 bg-[#2a2a2a] hover:bg-[#333] border border-[#3a3a3a] text-[#d1d1d1] font-bold rounded-sm text-[10px] uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5"
              >
                Экипировать в активный слот
              </button>
            )}

            {onSell && (
              <button
                onClick={() => {
                  soundManager.playCash();
                  onSell(item);
                  onClose();
                }}
                className="w-full py-2.5 px-3 bg-[#9a8866] hover:bg-[#a89572] text-black font-bold rounded-sm text-[10px] uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 shadow"
              >
                💰 Сдать Прапору (+{(item.category === 'junk' || item.category === 'barter' ? Math.round(item.price / 2.3) : Math.round(item.price * 0.6)).toLocaleString('ru-RU')} ₽)
              </button>
            )}

            {onDiscard && (
              <button
                onClick={() => {
                  soundManager.playClick();
                  onDiscard(item);
                  onClose();
                }}
                className="w-full py-1.5 px-3 text-[#666] hover:text-red-400 text-[10px] uppercase tracking-wider transition-colors text-center"
              >
                Сбросить на пол (Уничтожить)
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
