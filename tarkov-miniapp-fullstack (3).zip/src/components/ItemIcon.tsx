import React from 'react';
import { 
  Crosshair, 
  Shield, 
  ShieldAlert, 
  HeartPulse, 
  Bandage, 
  Syringe, 
  Layers, 
  Cpu, 
  Coins, 
  Watch, 
  Wrench, 
  Key, 
  Bomb, 
  Package, 
  Box
} from 'lucide-react';
import { ItemCategory, ItemRarity } from '../types';

interface ItemIconProps {
  iconName: string;
  category: ItemCategory;
  rarity?: ItemRarity;
  className?: string;
}

export const ItemIcon: React.FC<ItemIconProps> = ({ iconName, category, rarity = 'common', className = 'w-5 h-5' }) => {
  const getIcon = () => {
    switch (iconName) {
      case 'Crosshair': return <Crosshair className={className} />;
      case 'Shield': return <Shield className={className} />;
      case 'ShieldAlert': return <ShieldAlert className={className} />;
      case 'HeartPulse': return <HeartPulse className={className} />;
      case 'Bandage': return <Bandage className={className} />;
      case 'Syringe': return <Syringe className={className} />;
      case 'Layers': return <Layers className={className} />;
      case 'Cpu': return <Cpu className={className} />;
      case 'Coins': return <Coins className={className} />;
      case 'Watch': return <Watch className={className} />;
      case 'Wrench': return <Wrench className={className} />;
      case 'Key': return <Key className={className} />;
      case 'Bomb': return <Bomb className={className} />;
      case 'Package': return <Package className={className} />;
      default:
        switch (category) {
          case 'weapons': return <Crosshair className={className} />;
          case 'ammo': return <Layers className={className} />;
          case 'armor': return <Shield className={className} />;
          case 'meds': return <HeartPulse className={className} />;
          case 'keys': return <Key className={className} />;
          default: return <Box className={className} />;
        }
    }
  };

  const getRarityColor = () => {
    switch (rarity) {
      case 'classified': return 'text-amber-400';
      case 'epic': return 'text-purple-400';
      case 'rare': return 'text-blue-400';
      default: return 'text-zinc-400';
    }
  };

  return (
    <div className={`inline-flex items-center justify-center ${getRarityColor()}`}>
      {getIcon()}
    </div>
  );
};
