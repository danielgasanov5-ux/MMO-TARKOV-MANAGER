import React, { useState } from 'react';
import { 
  X, 
  Download, 
  FileArchive, 
  Server, 
  Terminal, 
  ShieldCheck, 
  Check, 
  Layers, 
  ExternalLink,
  Code
} from 'lucide-react';
import { soundManager } from '../utils/audio';

interface ZipDownloadModalProps {
  onClose: () => void;
}

export const ZipDownloadModal: React.FC<ZipDownloadModalProps> = ({ onClose }) => {
  const [copied, setCopied] = useState(false);

  const handleDownload = () => {
    soundManager.playClick();
    const link = document.createElement('a');
    link.href = '/tarkov-miniapp-fullstack.zip';
    link.download = 'tarkov-miniapp-fullstack.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyCmd = () => {
    soundManager.playClick();
    navigator.clipboard.writeText('cd backend && pip install -r requirements.txt && uvicorn main:app --reload');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
      <div 
        className="w-full max-w-xl bg-[#0f0f0f] border border-[#2a2a2a] rounded-sm shadow-2xl overflow-hidden font-mono flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#151515] border-b border-[#242424]">
          <div className="flex items-center gap-2.5">
            <FileArchive className="w-4 h-4 text-[#9a8866]" />
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#d1d1d1]">
              ПОЛНЫЙ ПРОЕКТ ПОД КЛЮЧ (.ZIP)
            </span>
          </div>
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="p-1 text-[#666] hover:text-[#d1d1d1] rounded-sm transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 overflow-y-auto space-y-4 text-xs">
          {/* Main Download Hero Card */}
          <div className="p-4 bg-[#141414] border border-[#262626] rounded-sm flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <div className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2 justify-center sm:justify-start">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                tarkov-miniapp-fullstack.zip
              </div>
              <p className="text-[11px] text-[#888]">
                Включает Frontend (React 19/TS) + Backend (Python FastAPI + SQLite) + Telegram Auth
              </p>
            </div>

            <button
              onClick={handleDownload}
              className="w-full sm:w-auto px-5 py-2.5 bg-[#9a8866] hover:bg-[#a89572] text-black font-bold uppercase text-[11px] tracking-wider rounded-sm transition-colors flex items-center justify-center gap-2 shadow shrink-0"
            >
              <Download className="w-4 h-4" />
              СКАЧАТЬ АРХИВ (.ZIP)
            </button>
          </div>

          {/* Architecture Breakdown */}
          <div className="space-y-2">
            <div className="text-[10px] text-[#666] uppercase tracking-[0.2em] font-bold">
              СОДЕРЖИМОЕ АРХИВА:
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div className="p-3 bg-[#121212] border border-[#222] rounded-sm space-y-1.5">
                <div className="flex items-center gap-2 text-white font-bold text-[11px]">
                  <Server className="w-3.5 h-3.5 text-[#9a8866]" />
                  Python FastAPI Backend
                </div>
                <ul className="text-[10px] text-[#777] space-y-1 list-disc list-inside">
                  <li><span className="text-[#aaa]">main.py</span> — эндпоинты API схрона и рынка</li>
                  <li><span className="text-[#aaa]">telegram_auth.py</span> — HMAC-SHA256 initData</li>
                  <li><span className="text-[#aaa]">raid_engine.py</span> — 15 стадий, POI, подсумок</li>
                  <li><span className="text-[#aaa]">database.py</span> — SQLAlchemy + SQLite</li>
                  <li><span className="text-[#aaa]">requirements.txt, Dockerfile, run.sh</span></li>
                </ul>
              </div>

              <div className="p-3 bg-[#121212] border border-[#222] rounded-sm space-y-1.5">
                <div className="flex items-center gap-2 text-white font-bold text-[11px]">
                  <Layers className="w-3.5 h-3.5 text-sky-400" />
                  React 19 Frontend
                </div>
                <ul className="text-[10px] text-[#777] space-y-1 list-disc list-inside">
                  <li>Схрон на 100 ячеек (10×10) и слоты экипировки</li>
                  <li>Барахолка Прапора с пагинацией и пакетами</li>
                  <li>Кнопка быстрой продажи хлама Прапору</li>
                  <li>15-этапный интерактивный рейд с подсумком</li>
                  <li>Звуковой движок и симуляция Telegram WebApp</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Endpoints Synchronized */}
          <div className="p-3 bg-[#121212] border border-[#222] rounded-sm space-y-2">
            <div className="text-[10px] text-[#666] uppercase tracking-wider font-bold">
              СИНХРОНИЗИРОВАННЫЕ API ЭНДПОИНТЫ:
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[10px]">
              <div className="flex items-center gap-1.5 bg-[#171717] px-2 py-1 rounded-sm border border-[#262626]">
                <span className="text-emerald-400 font-bold">GET</span>
                <span className="text-[#ccc]">/api/stash</span>
                <span className="text-[#666] text-[9px] ml-auto">100 ячеек</span>
              </div>
              <div className="flex items-center gap-1.5 bg-[#171717] px-2 py-1 rounded-sm border border-[#262626]">
                <span className="text-emerald-400 font-bold">GET</span>
                <span className="text-[#ccc]">/api/market</span>
                <span className="text-[#666] text-[9px] ml-auto">Пагинация</span>
              </div>
              <div className="flex items-center gap-1.5 bg-[#171717] px-2 py-1 rounded-sm border border-[#262626]">
                <span className="text-amber-400 font-bold">POST</span>
                <span className="text-[#ccc]">/api/sell_all</span>
                <span className="text-[#666] text-[9px] ml-auto">1 кнопка</span>
              </div>
              <div className="flex items-center gap-1.5 bg-[#171717] px-2 py-1 rounded-sm border border-[#262626]">
                <span className="text-amber-400 font-bold">POST</span>
                <span className="text-[#ccc]">/api/raid/start</span>
                <span className="text-[#666] text-[9px] ml-auto">15 этапов</span>
              </div>
              <div className="flex items-center gap-1.5 bg-[#171717] px-2 py-1 rounded-sm border border-[#262626] col-span-1 sm:col-span-2">
                <span className="text-amber-400 font-bold">POST</span>
                <span className="text-[#ccc]">/api/raid/action</span>
                <span className="text-[#666] text-[9px] ml-auto">POI, шмот друга 'Гюрзы', подсумок</span>
              </div>
            </div>
          </div>

          {/* Quick Start Command */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-[#666] uppercase tracking-wider font-bold">
                КОМАНДА ЗАПУСКА BACKEND:
              </span>
              <button
                onClick={handleCopyCmd}
                className="text-[10px] text-[#9a8866] hover:text-white flex items-center gap-1"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Terminal className="w-3 h-3" />}
                {copied ? 'Скопировано!' : 'Копировать'}
              </button>
            </div>
            <div className="p-2.5 bg-[#0a0a0a] border border-[#222] rounded-sm text-[10px] text-emerald-400 overflow-x-auto">
              cd backend && pip install -r requirements.txt && uvicorn main:app --reload
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#151515] border-t border-[#242424] flex items-center justify-between text-[10px] text-[#666]">
          <span>Разработано для Telegram Mini Apps</span>
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="px-3 py-1.5 bg-[#222] hover:bg-[#2a2a2a] text-[#aaa] hover:text-white rounded-sm transition-colors uppercase"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
};
