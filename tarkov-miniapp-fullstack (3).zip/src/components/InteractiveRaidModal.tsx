import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Crosshair, 
  MapPin, 
  Lock, 
  AlertTriangle, 
  Award, 
  Heart, 
  Coins, 
  Zap, 
  Check, 
  X, 
  ChevronRight, 
  Clock, 
  Skull, 
  Radio, 
  Package, 
  Eye, 
  Footprints,
  Compass,
  LogOut,
  Handshake,
  Headphones
} from 'lucide-react';
import { RaidLocation, RaidTactic, PMCProfile, TarkovItem, RaidExecutionResult } from '../types';
import { soundManager } from '../utils/audio';
import { start15StageRaid, sendRaidAction, returnFriendGearBackend } from '../api/client';

interface InteractiveRaidModalProps {
  location: RaidLocation;
  tactic: RaidTactic;
  profile: PMCProfile;
  equippedHeadset?: TarkovItem | null;
  onFinish: (result: RaidExecutionResult) => void;
  onClose: () => void;
}

interface TacticalChoice {
  id: string;
  title: string;
  description: string;
  actionType: string;
  riskLevel: string;
  lootBonus: number;
  survivalModifier: number;
}

export const InteractiveRaidModal: React.FC<InteractiveRaidModalProps> = ({
  location,
  tactic,
  profile,
  equippedHeadset,
  onFinish,
  onClose,
}) => {
  const [raidId, setRaidId] = useState<string>('');
  const [stage, setStage] = useState<number>(1);
  const [stageTitle, setStageTitle] = useState<string>('Высадка в секторе (Инфильтрация)');
  const [situationText, setSituationText] = useState<string>(
    'Вы проникли за внешний периметр. В воздухе запах гари и сырой земли. Радиосканер фиксирует переговоры местных Диких на частоте 433.100 МГц.'
  );
  const [poiName, setPoiName] = useState<string>('Точка десантирования "Север-1"');
  const [health, setHealth] = useState<number>(440);
  const [kills, setKills] = useState<number>(0);
  const [expEarned, setExpEarned] = useState<number>(100);
  const [rublesFound, setRublesFound] = useState<number>(0);
  const [friendGearFound, setFriendGearFound] = useState<boolean>(false);
  const [friendGearSecured, setFriendGearSecured] = useState<boolean>(false);
  const [friendGearReturned, setFriendGearReturned] = useState<boolean>(false);
  const [standardLoot, setStandardLoot] = useState<TarkovItem[]>([]);
  const [secureLoot, setSecureLoot] = useState<TarkovItem[]>([]);
  const [logs, setLogs] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const [isSurvived, setIsSurvived] = useState<boolean>(false);
  const [friendReturnFeedback, setFriendReturnFeedback] = useState<string | null>(null);

  // Helper to check if item is high-value for secure container (Alpha 2x2: up to 4 slots)
  const isHighValue = (item: TarkovItem): boolean => {
    if (item.category === 'keys') return true;
    if (item.rarity === 'legendary' || item.rarity === 'epic') return true;
    if (item.price >= 50000) return true;
    const n = item.name.toLowerCase();
    return (
      n.includes('биткоин') ||
      n.includes('ledx') ||
      n.includes('видеокарта') ||
      n.includes('череп') ||
      n.includes('жетон') ||
      n.includes('тетриз') ||
      n.includes('дефибриллятор')
    );
  };

  // Re-sort items so that high-value items always take priority in the 4 secure container slots
  const autoSortSecurePouch = (currentStd: TarkovItem[], currentSec: TarkovItem[]) => {
    const allLoot = [...currentSec, ...currentStd];
    const newSec: TarkovItem[] = [];
    const newStd: TarkovItem[] = [];

    // Sort by value descending
    allLoot.sort((a, b) => {
      const aPrio = isHighValue(a) ? 1000000 + a.price : a.price;
      const bPrio = isHighValue(b) ? 1000000 + b.price : b.price;
      return bPrio - aPrio;
    });

    for (const item of allLoot) {
      if (newSec.length < 4 && isHighValue(item)) {
        newSec.push(item);
      } else {
        newStd.push(item);
      }
    }

    return { newStd, newSec };
  };

  // Available tactical choices for current stage
  const [choices, setChoices] = useState<TacticalChoice[]>([
    {
      id: 'c1_stealth',
      title: 'Скрытное движение по низине',
      description: 'Обойти открытые участки вдоль оврага, минимизируя шум шагов.',
      actionType: 'flank',
      riskLevel: 'Низкий',
      lootBonus: 1.0,
      survivalModifier: 15,
    },
    {
      id: 'c1_scout_kpp',
      title: 'Быстрый обыск сторожки КПП',
      description: 'Проверить ящики у заставы в надежде найти быстрый хабар до прихода патруля.',
      actionType: 'loot_poi',
      riskLevel: 'Умеренный',
      lootBonus: 1.3,
      survivalModifier: 0,
    }
  ]);

  // Start 15-stage raid on mount
  useEffect(() => {
    soundManager.playRaidStart();
    const initRaid = async () => {
      setIsLoading(true);
      const res = await start15StageRaid(location.id, tactic.id);
      if (res) {
        setRaidId(res.raidId);
        setStage(res.currentStage);
        setStageTitle(res.stageTitle);
        setSituationText(res.situationText);
        setPoiName(res.poiName);
        setChoices(res.availableChoices || []);
        setLogs(res.logs || []);
      } else {
        // Local engine start
        const generatedId = `raid-local-${Date.now()}`;
        setRaidId(generatedId);
        const headsetNote = equippedHeadset 
          ? ` [🎧 Гарнитура ${equippedHeadset.shortName} активна: засады обнаруживаются за 50 м!]`
          : '';
        setLogs([
          `[00:00] ВЫСАДКА: ЧВК ${profile.callsign} проник на локацию ${location.name.toUpperCase()}.${headsetNote}`,
          `[00:05] ДОКТРИНА: Выбрана тактика "${tactic.name.toUpperCase()}". Впереди 15 тактических этапов.`
        ]);
      }
      setIsLoading(false);
    };

    initRaid();
  }, [location, tactic, profile, equippedHeadset]);

  // Handle early exfiltration on ANY stage
  const handleEarlyExfil = () => {
    if (isFinished) return;
    soundManager.playSuccess();
    setIsFinished(true);
    setIsSurvived(true);
    setLogs(prev => [
      ...prev,
      `[ЭВАКУАЦИЯ НА ЭТАПЕ ${stage}/15] Оперативник принял тактическое решение досрочно покинуть зону!`,
      `[УСПЕХ] Резервный выход активирован. Накопленный хабар и снаряжение доставлены в схрон.`
    ]);
  };

  const handleChoice = async (choice: TacticalChoice) => {
    if (isLoading || isFinished) return;
    setIsLoading(true);

    if (choice.actionType === 'combat') {
      soundManager.playShoot();
    } else if (choice.actionType === 'rescue_friend') {
      soundManager.playEquip();
    } else if (choice.actionType === 'secure_pouch') {
      soundManager.playSuccess();
    } else {
      soundManager.playClick();
    }

    const res = await sendRaidAction(raidId, choice.id);

    if (res && res.stage) {
      const s = res.stage;
      setStage(s.currentStage);
      setStageTitle(s.stageTitle);
      setSituationText(s.situationText);
      setPoiName(s.poiName);
      setHealth(s.health);
      setKills(s.kills);
      setExpEarned(s.expEarned);
      setRublesFound(s.rublesFound);
      setFriendGearFound(s.friendGearFound);
      setFriendGearSecured(s.friendGearSecured);

      const { newStd, newSec } = autoSortSecurePouch(s.standardLoot || [], s.secureContainerLoot || []);
      setStandardLoot(newStd);
      setSecureLoot(newSec);

      setChoices(s.availableChoices || []);
      setLogs(s.logs || []);

      if (s.isFinished) {
        setIsFinished(true);
        setIsSurvived(s.isSurvived);
        if (s.isSurvived) soundManager.playSuccess();
      }
    } else {
      // Local fallback simulation for 15 stages
      const nextStage = stage + 1;
      let damage = choice.riskLevel === 'Высокий' ? 40 : choice.riskLevel === 'Экстремальный' ? 65 : 15;
      if (equippedHeadset) {
        damage = Math.round(damage * 0.75); // -25% damage reduction from headset
      }
      let newHealth = Math.max(0, health - damage);
      let newKills = kills + (choice.actionType === 'combat' ? 2 : 0);
      let newExp = expEarned + 200;
      let newRubles = rublesFound + 15000;
      let newFoundFriend = friendGearFound;
      let newSecured = friendGearSecured;
      let newStdLoot = [...standardLoot];
      let newSecLoot = [...secureLoot];

      let newLog = `[Этап ${stage}/15] Выполнено: ${choice.title}.`;

      // Special Stage 10: Friend's Gear Discovery
      if (stage === 10 || choice.actionType === 'rescue_friend') {
        newFoundFriend = true;
        const friendM4: TarkovItem = {
          id: `loot-friend-m4-${Date.now()}`,
          name: "Тюнингованный Colt M4A1 (Оружие Гюрзы)",
          shortName: "M4A1 Гюрзы",
          category: "weapons",
          description: "Именной карабин погибшего напарника. Полный тактический обвес.",
          price: 175000,
          rarity: "epic",
          slots: 2,
          weight: 3.8,
          caliber: "5.56x45 мм",
          iconName: "Crosshair",
          inRaid: true
        };
        const friendDogtag: TarkovItem = {
          id: `loot-friend-dogtag-${Date.now()}`,
          name: "Золотой жетон ЧВК (Гюрза, ур. 42)",
          shortName: "Жетон Гюрзы",
          category: "barter",
          description: "Армейский жетон товарища для передачи Прапору.",
          price: 120000,
          rarity: "epic",
          slots: 1,
          weight: 0.05,
          iconName: "Award",
          inRaid: true
        };
        newStdLoot.push(friendM4, friendDogtag);
        newLog += " ОБНАРУЖЕН ШМОТ НАПАРНИКА 'ГЮРЗЫ': Карабин M4A1 и золотой жетон спасены!";
        newExp += 600;
      }

      // Special Stage 12: Secure Container Auto-Transfer
      if (stage === 12 || choice.actionType === 'secure_pouch') {
        newSecured = true;
      }

      // Auto-sort high value into secure container (Alpha 2x2)
      const sorted = autoSortSecurePouch(newStdLoot, newSecLoot);
      newStdLoot = sorted.newStd;
      newSecLoot = sorted.newSec;

      if (newHealth <= 0) {
        setIsFinished(true);
        setIsSurvived(false);
        soundManager.playKilled();
        setLogs(prev => [...prev, newLog, `[00:44] КРИТИЧЕСКОЕ РАНЕНИЕ: ЧВК ${profile.callsign} погиб в бою. Весь хабар в рюкзаке утерян, но подсумок 'Альфа' сохранен!`]);
      } else if (nextStage > 15) {
        setIsFinished(true);
        setIsSurvived(true);
        soundManager.playSuccess();
        setLogs(prev => [...prev, newLog, `[00:45] ЭВАКУАЦИЯ: Все 15 этапов завершены! Вертолет доставил оперативника в безопасную зону.`]);
      } else {
        setStage(nextStage);
        setStageTitle(getStageTitleLocal(nextStage));
        setPoiName(getPoiLocal(nextStage));
        setSituationText(getSituationLocal(nextStage));
        setChoices(getChoicesLocal(nextStage));
        setHealth(newHealth);
        setKills(newKills);
        setExpEarned(newExp);
        setRublesFound(newRubles);
        setFriendGearFound(newFoundFriend);
        setFriendGearSecured(newSecured);
        setStandardLoot(newStdLoot);
        setSecureLoot(newSecLoot);
        setLogs(prev => [...prev, newLog]);
      }
    }

    setIsLoading(false);
  };

  // Return friend's gear handler
  const handleReturnFriendGear = async () => {
    if (friendGearReturned) return;
    soundManager.playCash();

    try {
      await returnFriendGearBackend('@Gurza_PMC');
    } catch {
      // client fallback
    }

    setFriendGearReturned(true);
    setRublesFound(prev => prev + 75000);
    setFriendReturnFeedback("🤝 Снаряжение напарника успешно возвращено бойцу @Gurza_PMC! Прапор передал вам благодарность: +75,000 ₽ и +0.05 репутации!");
  };

  const handleFinalExit = () => {
    soundManager.playClick();
    const finalLoot = isSurvived ? [...standardLoot, ...secureLoot] : [...secureLoot];
    const finalResult: RaidExecutionResult = {
      location,
      tactic,
      status: isSurvived ? 'survived' : 'kia',
      expEarned: isSurvived ? expEarned : Math.round(expEarned * 0.4),
      rublesFound: isSurvived ? rublesFound : 0,
      kills,
      lootFound: finalLoot,
      damageTaken: 440 - health,
      questUpdates: friendGearFound 
        ? ["Квест 'Память о товарище': Оружие и жетон Гюрзы спасены (+75,000 ₽ / уважение Прапора)!"] 
        : [],
      logs,
    };
    onFinish(finalResult);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-3xl bg-[#0e0e0e] border border-[#2a2a2a] rounded-sm shadow-2xl overflow-hidden font-mono flex flex-col max-h-[95vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Tactical HUD Header */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-[#141414] border-b border-[#242424]">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#9a8866]">
                ТАКТИЧЕСКИЙ РЕЙД // {location.codeName}
              </span>
              <span className="text-[10px] text-[#666] ml-2">
                Тактика: {tactic.name}
              </span>
              {equippedHeadset && (
                <span className="ml-2 text-[9px] text-amber-400 bg-amber-950/40 px-1.5 py-0.5 rounded-sm border border-amber-800/50">
                  🎧 {equippedHeadset.shortName}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5 text-red-400">
              <Heart className="w-3.5 h-3.5 fill-current" />
              <span className="font-bold">{health}/440 HP</span>
            </div>
            <div className="flex items-center gap-1.5 text-[#9a8866]">
              <Coins className="w-3.5 h-3.5" />
              <span>💰 {rublesFound.toLocaleString('ru-RU')} ₽</span>
            </div>
            <button
              onClick={onClose}
              className="p-1 text-[#666] hover:text-white rounded-sm"
              title="Прервать рейд"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stage Progress Bar (1 to 15) with Exfil button */}
        <div className="px-4 py-2 bg-[#111] border-b border-[#222]">
          <div className="flex items-center justify-between text-[10px] text-[#888] mb-1.5 font-bold uppercase tracking-wider">
            <span className="text-[#9a8866] flex items-center gap-1">
              <Compass className="w-3 h-3" />
              ЭТАП {stage} ИЗ 15
            </span>
            <span>{poiName}</span>
            <span>Устранено: {kills} ЧВК</span>
          </div>

          <div className="w-full h-1.5 bg-[#1e1e1e] rounded-none overflow-hidden flex gap-0.5">
            {Array.from({ length: 15 }).map((_, i) => (
              <div 
                key={i}
                className={`h-full flex-1 transition-all ${
                  i + 1 < stage 
                    ? 'bg-[#9a8866]' 
                    : i + 1 === stage 
                    ? 'bg-amber-400 animate-pulse' 
                    : 'bg-[#222]'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1 text-xs">
          {/* Situation Card */}
          <div className="p-3.5 bg-[#141414] border border-[#262626] rounded-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#9a8866]">
                ОБСТАНОВКА НА ЭТАПЕ {stage}
              </span>
              <span className="text-[9px] px-1.5 py-0.5 bg-[#222] text-[#888] rounded-sm uppercase">
                {stageTitle}
              </span>
            </div>
            <p className="text-[#ccc] leading-relaxed text-xs">
              {situationText}
            </p>
          </div>

          {/* Friend's Gear Discovery Banner (Stage 10+ Event) */}
          {friendGearFound && (
            <div className="p-3 bg-amber-950/20 border border-amber-600/40 rounded-sm flex items-start gap-3 text-xs animate-fadeIn">
              <Award className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="font-bold text-amber-300 uppercase tracking-wider">
                  СПАСЕНО СНАРЯЖЕНИЕ И ЖЕТОН НАПАРНИКА ('ГЮРЗА')
                </div>
                <div className="text-[#aaa] text-[11px] mt-0.5">
                  Тюнингованный карабин M4A1 и золотой жетон боевого товарища спасены. После эвакуации вы сможете вернуть их напарнику через кнопку в итогах рейда!
                </div>
              </div>
            </div>
          )}

          {/* Secure Container (ПОДСУМОК 2X2) Auto-Sort Visual Tray */}
          <div className="p-3 bg-[#121212] border border-[#262626] rounded-sm space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#9a8866] font-bold text-[11px] uppercase tracking-wider">
                <Lock className="w-3.5 h-3.5 text-[#9a8866]" />
                ЗАЩИЩЕННЫЙ ПОДСУМОК 'АЛЬФА' (2X2) • АВТО-СОРТИРОВКА
              </div>
              <span className="text-[9px] text-[#666] uppercase">
                Ценности защищены даже в случае K.I.A.
              </span>
            </div>

            <div className="grid grid-cols-4 gap-2">
              {Array.from({ length: 4 }).map((_, idx) => {
                const item = secureLoot[idx];
                return (
                  <div 
                    key={idx}
                    className={`h-16 rounded-sm border flex flex-col items-center justify-center p-1 text-center transition-all ${
                      item 
                        ? 'bg-amber-950/20 border-amber-600/50 text-amber-200' 
                        : 'bg-[#161616] border-[#222] text-[#444]'
                    }`}
                  >
                    {item ? (
                      <>
                        <Lock className="w-3 h-3 text-[#9a8866] mb-1" />
                        <span className="text-[9px] font-bold leading-tight line-clamp-1">{item.shortName}</span>
                        <span className="text-[8px] text-[#888]">💰 {item.price.toLocaleString('ru-RU')} ₽</span>
                      </>
                    ) : (
                      <span className="text-[9px] font-mono text-[#333]">[ПУСТОЙ СЛОТ]</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Tactical Action Choices & PERMANENT EARLY EXFIL BUTTON */}
          {!isFinished ? (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#666]">
                  ВЫБОР ТАКТИЧЕСКОГО ДЕЙСТВИЯ:
                </div>

                {/* The Early Exfiltration Button (AVAILABLE ON ALL STAGES) */}
                <button
                  onClick={handleEarlyExfil}
                  className="px-3 py-1.5 bg-[#261d15] hover:bg-[#382a1e] border border-[#9a8866]/60 hover:border-[#9a8866] text-[#9a8866] font-bold rounded-sm text-[10px] uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-sm"
                  title="Досрочно эвакуироваться с текущим хабаром и выжить"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>🏃‍♂️ Пойти на выход</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {choices.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => handleChoice(c)}
                    disabled={isLoading}
                    className="p-3 bg-[#161616] hover:bg-[#1c1c1c] border border-[#2b2b2b] hover:border-[#9a8866] rounded-sm text-left transition-all flex flex-col justify-between group disabled:opacity-50"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-white group-hover:text-[#9a8866] text-xs">
                          {c.title}
                        </span>
                        <span className={`text-[8px] px-1 py-0.5 rounded-sm uppercase font-semibold border ${
                          c.riskLevel === 'Низкий' ? 'bg-[#18241b] text-emerald-400 border-emerald-900/40' :
                          c.riskLevel === 'Умеренный' ? 'bg-[#262016] text-[#9a8866] border-[#9a8866]/30' :
                          'bg-[#281616] text-red-400 border-red-900/40'
                        }`}>
                          {c.riskLevel} риск
                        </span>
                      </div>
                      <p className="text-[10px] text-[#888] leading-relaxed">
                        {c.description}
                      </p>
                    </div>

                    <div className="mt-2.5 pt-1.5 border-t border-[#222] flex items-center justify-between text-[9px] text-[#666]">
                      <span>Лут: x{c.lootBonus.toFixed(1)}</span>
                      <span className="text-[#9a8866] font-bold flex items-center gap-0.5">
                        Выбрать действие <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            /* Raid Result Screen (KIA or Survived) */
            <div className={`p-4 rounded-sm border text-center space-y-3 ${
              isSurvived 
                ? 'bg-[#142018] border-emerald-600/50 text-emerald-200' 
                : 'bg-[#201414] border-red-800 text-red-300'
            }`}>
              <div className="text-base font-bold uppercase tracking-widest flex items-center justify-center gap-2">
                {isSurvived ? (
                  <>
                    <Check className="w-5 h-5 text-emerald-400" />
                    РЕЙД ЗАВЕРШЕН: УСПЕШНАЯ ЭВАКУАЦИЯ ИЗ ТАРКОВА!
                  </>
                ) : (
                  <>
                    <Skull className="w-5 h-5 text-red-500" />
                    ОПЕРАТИВНИК ПОГИБ В БОЮ (M.I.A / K.I.A)
                  </>
                )}
              </div>

              <p className="text-xs text-[#aaa]">
                {isSurvived
                  ? 'Эвакуация прошла успешно! Все найденные трофеи, рубли и снаряжение в безопасности переносятся в схрон.'
                  : 'Снаряжение в рюкзаке утеряно. Все предметы из защищенного подсумка сохранены и доставлены в схрон!'}
              </p>

              {/* Friend's Gear Rescue Reward Action Button */}
              {friendGearFound && (
                <div className="p-3 bg-[#1e1c18] border border-amber-600/50 rounded-sm text-center space-y-2">
                  <div className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center justify-center gap-1.5">
                    <Handshake className="w-4 h-4 text-amber-400" />
                    СПАСЕННОЕ СНАРЯЖЕНИЕ БОЙЦА @Gurza_PMC
                  </div>

                  {!friendGearReturned ? (
                    <button
                      onClick={handleReturnFriendGear}
                      className="px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-black font-bold uppercase text-[10px] font-mono tracking-wider rounded-sm transition-all shadow flex items-center justify-center gap-2 mx-auto"
                    >
                      <Handshake className="w-3.5 h-3.5" />
                      <span>🤝 Вернуть спасенное снаряжение @Gurza_PMC (+75,000 ₽)</span>
                    </button>
                  ) : (
                    <div className="text-xs text-emerald-400 font-mono font-bold">
                      {friendReturnFeedback}
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-3 gap-2 max-w-sm mx-auto text-xs py-2">
                <div className="p-2 bg-black/40 rounded-sm">
                  <span className="text-[9px] text-[#888] block">ОПЫТ</span>
                  <span className="font-bold text-white">+{expEarned} XP</span>
                </div>
                <div className="p-2 bg-black/40 rounded-sm">
                  <span className="text-[9px] text-[#888] block">РУБЛИ</span>
                  <span className="font-bold text-[#9a8866]">💰 +{rublesFound.toLocaleString('ru-RU')} ₽</span>
                </div>
                <div className="p-2 bg-black/40 rounded-sm">
                  <span className="text-[9px] text-[#888] block">УСТРАНЕНО</span>
                  <span className="font-bold text-red-400">{kills} ЧВК</span>
                </div>
              </div>

              <button
                onClick={handleFinalExit}
                className="px-6 py-2.5 bg-[#9a8866] hover:bg-[#a89572] text-black font-bold uppercase text-xs tracking-wider rounded-sm transition-colors shadow"
              >
                ПЕРЕЙТИ В СХРОН И ЗАБРАТЬ ЛУТ
              </button>
            </div>
          )}

          {/* Combat & Event Logs */}
          <div className="p-2.5 bg-[#0a0a0a] border border-[#222] rounded-sm space-y-1 max-h-32 overflow-y-auto font-mono text-[10px] text-[#777]">
            <div className="text-[#555] uppercase text-[9px] font-bold sticky top-0 bg-[#0a0a0a]">ЖУРНАЛ БОЕВЫХ ДЕЙСТВИЙ:</div>
            {logs.map((log, idx) => (
              <div key={idx} className="leading-snug text-[#999]">
                {log}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper local fallback data
function getStageTitleLocal(stage: number): string {
  const titles = [
    '', 'Высадка в секторе', 'Внешний периметр', 'Промзона и товарняк',
    'Сигнал бедствия S.O.S', 'Подступы к Главному Корпусу', 'Дуэль со снайпером',
    'Лабораторный блок', 'Оружейная комната', 'Коридорная засада',
    'МЕСТО ГИБЕЛИ НАПАРНИКА', 'Прорыв с хабаром', 'Тактический подсумок',
    'Свита Босса локации', 'Подступы к эвакуации', 'ФИНАЛЬНАЯ ЭВАКУАЦИЯ'
  ];
  return titles[stage] || `Этап ${stage}`;
}

function getPoiLocal(stage: number): string {
  const pois = [
    '', 'Точка "Север-1"', 'Пролом в заборе', 'Товарные вагоны',
    'Радиопередатчик S.O.S', 'Фасад Администрации', 'Снайперский кран',
    'Гермодверь лаборатории', 'Арсенал комендатуры', 'Узкий коридор',
    'Тело напарника "Гюрзы"', 'Транспортный шлюз', 'Схрон в расщелине',
    'Блокпост охраны Босса', 'Берег у лодки', 'Катер эвакуации'
  ];
  return pois[stage] || 'Сектор';
}

function getSituationLocal(stage: number): string {
  if (stage === 10) {
    return 'В углу машинного зала вы обнаружили тело напарника "Гюрзы". Рядом лежит его именной карабин M4A1 и золотой жетон бойца. Вы можете эвакуировать его снаряжение для передачи Прапору!';
  }
  if (stage === 12) {
    return 'Короткая передышка. Защищенный подсумок "Альфа" автоматически блокирует самые ценные трофеи (LEDX, Биткоины, жетоны), гарантируя их сохранение даже при гибели!';
  }
  if (stage === 15) {
    return 'ТАЙМЕР ЭВАКУАЦИИ 00:00! Катер отходит от причала. Зеленый сигнальный огонь догорает. Подтвердите выход в схрон!';
  }
  return `Тактический этап ${stage} из 15. Радиосканер фиксирует перемещения противника. Выберите следующее действие.`;
}

function getChoicesLocal(stage: number): TacticalChoice[] {
  if (stage === 10) {
    return [
      {
        id: 'c10_rescue_gear',
        title: 'ЭВАКУИРОВАТЬ ШМОТ И ЖЕТОН НАПАРНИКА',
        description: 'Забрать именной карабин M4A1 и золотой жетон Гюрзы для Прапора (+150,000 ₽ бонус!).',
        actionType: 'rescue_friend',
        riskLevel: 'Умеренный',
        lootBonus: 2.5,
        survivalModifier: 0
      },
      {
        id: 'c10_honor_dogtag',
        title: 'Забрать только жетон на память',
        description: 'Снять жетон товарища и продолжить движение налегке.',
        actionType: 'rescue_friend',
        riskLevel: 'Низкий',
        lootBonus: 1.5,
        survivalModifier: 15
      }
    ];
  }
  if (stage === 12) {
    return [
      {
        id: 'c12_secure_valuables',
        title: 'СПРЯТАТЬ ЖЕТОН И LEDX В ПОДСУМОК',
        description: 'Гарантировать сохранность самых ценных трофеев даже при гибели бойца!',
        actionType: 'secure_pouch',
        riskLevel: 'Низкий',
        lootBonus: 1.8,
        survivalModifier: 25
      },
      {
        id: 'c12_prep_meds',
        title: 'Перевязать раны полевым бинтом',
        description: 'Восполнить запас здоровья перед выходом.',
        actionType: 'flank',
        riskLevel: 'Низкий',
        lootBonus: 1.0,
        survivalModifier: 20
      }
    ];
  }
  if (stage === 15) {
    return [
      {
        id: 'c15_complete_exfil',
        title: 'ПОДТВЕРДИТЬ ЭВАКУАЦИЮ В СХРОН',
        description: 'Завершить рейд, зафиксировать опыт и перенести весь хабар в схрон.',
        actionType: 'extract',
        riskLevel: 'Низкий',
        lootBonus: 1.0,
        survivalModifier: 100
      }
    ];
  }

  return [
    {
      id: `c_${stage}_tactical`,
      title: 'Тактический штурм позиции',
      description: 'Устранить угрозу прицельным огнем и забрать хабар.',
      actionType: 'combat',
      riskLevel: 'Умеренный',
      lootBonus: 1.4,
      survivalModifier: 5
    },
    {
      id: `c_${stage}_flank`,
      title: 'Фланговый обход по укрытиям',
      description: 'Миновать простреливаемую зону и проверить скрытый тайник.',
      actionType: 'flank',
      riskLevel: 'Низкий',
      lootBonus: 1.1,
      survivalModifier: 20
    }
  ];
}
