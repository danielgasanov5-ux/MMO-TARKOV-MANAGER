import React, { useState } from 'react';
import { 
  Shield, 
  Volume2, 
  VolumeX, 
  Heart, 
  Coins, 
  MoreVertical, 
  Maximize2, 
  Minimize2,
  Activity,
  Crosshair,
  UserCheck,
  FileArchive,
  Download
} from 'lucide-react';
import { PMCProfile } from '../types';
import { soundManager } from '../utils/audio';
import { ZipDownloadModal } from './ZipDownloadModal';

interface HeaderProps {
  profile: PMCProfile;
  onUpdateProfile: (updater: (prev: PMCProfile) => PMCProfile) => void;
  isSimulatedMobile: boolean;
  onToggleMobileView: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  profile,
  onUpdateProfile,
  isSimulatedMobile,
  onToggleMobileView,
}) => {
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [showHealthModal, setShowHealthModal] = useState(false);
  const [showZipModal, setShowZipModal] = useState(false);

  const toggleSound = () => {
    soundManager.enabled = !audioEnabled;
    setAudioEnabled(!audioEnabled);
    if (!audioEnabled) soundManager.playClick();
  };

  const totalCurrentHp = 
    profile.health.head + 
    profile.health.thorax + 
    profile.health.stomach + 
    profile.health.arms + 
    profile.health.legs;

  const totalMaxHp = 
    profile.health.maxHead + 
    profile.health.maxThorax + 
    profile.health.maxStomach + 
    profile.health.maxArms + 
    profile.health.maxLegs;

  const hpPercent = Math.round((totalCurrentHp / totalMaxHp) * 100);

  const toggleFaction = () => {
    soundManager.playClick();
    onUpdateProfile(prev => ({
      ...prev,
      faction: prev.faction === 'BEAR' ? 'USEC' : 'BEAR'
    }));
  };

  const healFull = () => {
    soundManager.playSuccess();
    onUpdateProfile(prev => ({
      ...prev,
      health: {
        ...prev.health,
        head: prev.health.maxHead,
        thorax: prev.health.maxThorax,
        stomach: prev.health.maxStomach,
        arms: prev.health.maxArms,
        legs: prev.health.maxLegs,
      }
    }));
  };

  return (
    <header className="w-full bg-[#121212] border-b border-[#2a2a2a] sticky top-0 z-40 select-none shadow-xl">
      {/* Telegram Mini App Top Bar */}
      <div className="flex items-center justify-between px-4 py-1.5 bg-[#0a0a0a] border-b border-[#1e1e1e] text-[10px] font-mono-military text-[#666]">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-[#9a8866] animate-pulse" />
          <span className="text-[#888] font-semibold tracking-widest uppercase">
            TARKOV.TG // OPERATIONAL LINK
          </span>
          <span className="hidden sm:inline text-[#444]">0.13.5.0.25832</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Download Full-Stack Turn-Key ZIP Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              setShowZipModal(true);
            }}
            className="flex items-center gap-1.5 px-2.5 py-0.5 bg-[#9a8866]/15 hover:bg-[#9a8866]/25 border border-[#9a8866]/40 hover:border-[#9a8866] text-[#d1d1d1] hover:text-white rounded-sm text-[10px] font-mono font-bold tracking-wider transition-all shadow-sm"
            title="Скачать весь проект под ключ (React Frontend + Python FastAPI Backend + SQLite)"
          >
            <Download className="w-3 h-3 text-[#9a8866]" />
            <span className="text-[#9a8866]">СКАЧАТЬ .ZIP</span>
            <span className="hidden sm:inline text-[8px] px-1 bg-[#9a8866] text-black font-extrabold rounded-none">FastAPI</span>
          </button>

          <div className="text-[#333]">|</div>

          <button
            onClick={toggleSound}
            className="p-1 text-[#666] hover:text-[#d1d1d1] rounded-sm hover:bg-[#1a1a1a] transition-colors"
            title={audioEnabled ? 'Выключить звук' : 'Включить звук'}
          >
            {audioEnabled ? <Volume2 className="w-3.5 h-3.5 text-[#9a8866]" /> : <VolumeX className="w-3.5 h-3.5 text-[#444]" />}
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              onToggleMobileView();
            }}
            className="p-1 text-[#666] hover:text-[#d1d1d1] rounded-sm hover:bg-[#1a1a1a] transition-colors"
            title={isSimulatedMobile ? 'Полный экран' : 'Вид Telegram Mini App'}
          >
            {isSimulatedMobile ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
          </button>

          <div className="text-[#333]">|</div>
          <button 
            onClick={() => {
              soundManager.playClick();
              alert('Escape from Tarkov Telegram Mini App: Схрон на 100 ячеек, Барахолка Прапора с пагинацией и Рейды с квестами и выбором тактики.');
            }}
            className="p-1 text-[#666] hover:text-[#d1d1d1] rounded-sm hover:bg-[#1a1a1a]"
          >
            <MoreVertical className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main PMC Operator Dashboard Bar */}
      <div className="px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-4">
        {/* Profile & Level */}
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 bg-[#9a8866] flex flex-col items-center justify-center text-black font-bold rounded-sm shadow shrink-0">
            <span className="text-[9px] font-mono leading-none tracking-tight">LVL</span>
            <span className="text-sm font-black font-mono leading-tight">{profile.level}</span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase tracking-widest text-[#666]">
                OPERATOR [{profile.faction}]
              </span>
              <button
                onClick={toggleFaction}
                className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded-sm bg-[#1a1a1a] border border-[#2a2a2a] text-[#888] hover:text-[#d1d1d1] hover:border-[#444] transition-colors"
                title="Переключить фракцию (BEAR / USEC)"
              >
                СМЕНИТЬ
              </button>
            </div>
            <p className="text-sm font-bold tracking-tight text-[#d1d1d1] font-tarkov">
              {profile.callsign}
            </p>
            <div className="flex items-center gap-2 mt-0.5">
              <div className="w-24 sm:w-32 h-1 bg-[#1a1a1a] rounded-none overflow-hidden">
                <div 
                  className="h-full bg-[#9a8866] transition-all" 
                  style={{ width: `${Math.min(100, (profile.exp / profile.nextLevelExp) * 100)}%` }} 
                />
              </div>
              <span className="text-[9px] font-mono text-[#555]">
                {profile.exp}/{profile.nextLevelExp} XP
              </span>
            </div>
          </div>
        </div>

        {/* Health Tracker */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              soundManager.playClick();
              setShowHealthModal(!showHealthModal);
            }}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-sm border text-xs font-mono transition-colors ${
              hpPercent > 70
                ? 'bg-[#151515] border-[#2a2a2a] text-[#d1d1d1] hover:border-[#444]'
                : hpPercent > 30
                ? 'bg-amber-950/20 border-amber-800/40 text-amber-300 hover:border-amber-700'
                : 'bg-red-950/40 border-red-800 text-red-400 animate-pulse'
            }`}
            title="Диагностика частей тела"
          >
            <Heart className="w-3.5 h-3.5 fill-current text-red-500/80" />
            <span className="font-semibold">{totalCurrentHp}/{totalMaxHp} HP</span>
          </button>
        </div>

        {/* Tactical Wallets */}
        <div className="flex items-center gap-4 sm:gap-7 text-right">
          <div>
            <span className="text-[10px] uppercase text-[#666] block tracking-wider">Roubles</span>
            <span className="text-[#9a8866] font-mono text-sm font-semibold">
              {profile.rubles.toLocaleString('ru-RU')} ₽
            </span>
          </div>

          <div className="hidden sm:block">
            <span className="text-[10px] uppercase text-[#666] block tracking-wider">Dollars</span>
            <span className="text-blue-400 font-mono text-sm font-semibold">
              {profile.dollars.toLocaleString('en-US')} $
            </span>
          </div>

          <div className="hidden sm:block">
            <span className="text-[10px] uppercase text-[#666] block tracking-wider">Euros</span>
            <span className="text-green-500 font-mono text-sm font-semibold">
              {profile.euros.toLocaleString('de-DE')} €
            </span>
          </div>
        </div>
      </div>

      {/* Diagnostics / Body Health Modal */}
      {showHealthModal && (
        <div className="p-4 bg-[#0f0f0f] border-t border-[#2a2a2a] text-xs font-mono text-[#aaa] animate-fadeIn">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 text-[#d1d1d1] font-bold font-tarkov text-xs tracking-wider uppercase">
              <Activity className="w-4 h-4 text-[#9a8866]" />
              СОСТОЯНИЕ ЗДОРОВЬЯ ОПЕРАТИВНИКА
            </div>
            {totalCurrentHp < totalMaxHp && (
              <button
                onClick={healFull}
                className="px-3 py-1 bg-[#222] hover:bg-[#2a2a2a] text-[#9a8866] border border-[#333] rounded-sm font-bold uppercase text-[10px] tracking-wider transition-colors"
              >
                Полечить всё (Салва / Бинт)
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            <div className="p-2.5 bg-[#151515] border border-[#222] rounded-sm">
              <div className="text-[#666] text-[9px] uppercase tracking-wider">ГОЛОВА</div>
              <div className="font-bold text-[#d1d1d1] mt-1">{profile.health.head} / {profile.health.maxHead}</div>
              <div className="w-full h-1 bg-[#1a1a1a] mt-1.5">
                <div className="h-full bg-[#9a8866]" style={{ width: `${(profile.health.head / profile.health.maxHead) * 100}%` }} />
              </div>
            </div>

            <div className="p-2.5 bg-[#151515] border border-[#222] rounded-sm">
              <div className="text-[#666] text-[9px] uppercase tracking-wider">ГРУДНАЯ КЛЕТКА</div>
              <div className="font-bold text-[#d1d1d1] mt-1">{profile.health.thorax} / {profile.health.maxThorax}</div>
              <div className="w-full h-1 bg-[#1a1a1a] mt-1.5">
                <div className="h-full bg-[#9a8866]" style={{ width: `${(profile.health.thorax / profile.health.maxThorax) * 100}%` }} />
              </div>
            </div>

            <div className="p-2.5 bg-[#151515] border border-[#222] rounded-sm">
              <div className="text-[#666] text-[9px] uppercase tracking-wider">ЖИВОТ</div>
              <div className="font-bold text-[#d1d1d1] mt-1">{profile.health.stomach} / {profile.health.maxStomach}</div>
              <div className="w-full h-1 bg-[#1a1a1a] mt-1.5">
                <div className="h-full bg-[#9a8866]" style={{ width: `${(profile.health.stomach / profile.health.maxStomach) * 100}%` }} />
              </div>
            </div>

            <div className="p-2.5 bg-[#151515] border border-[#222] rounded-sm">
              <div className="text-[#666] text-[9px] uppercase tracking-wider">РУКИ</div>
              <div className="font-bold text-[#d1d1d1] mt-1">{profile.health.arms} / {profile.health.maxArms}</div>
              <div className="w-full h-1 bg-[#1a1a1a] mt-1.5">
                <div className="h-full bg-[#9a8866]" style={{ width: `${(profile.health.arms / profile.health.maxArms) * 100}%` }} />
              </div>
            </div>

            <div className="p-2.5 bg-[#151515] border border-[#222] rounded-sm col-span-2 sm:col-span-1">
              <div className="text-[#666] text-[9px] uppercase tracking-wider">НОГИ</div>
              <div className="font-bold text-[#d1d1d1] mt-1">{profile.health.legs} / {profile.health.maxLegs}</div>
              <div className="w-full h-1 bg-[#1a1a1a] mt-1.5">
                <div className="h-full bg-[#9a8866]" style={{ width: `${(profile.health.legs / profile.health.maxLegs) * 100}%` }} />
              </div>
            </div>
          </div>
        </div>
      )}

      {showZipModal && (
        <ZipDownloadModal onClose={() => setShowZipModal(false)} />
      )}
    </header>
  );
};
