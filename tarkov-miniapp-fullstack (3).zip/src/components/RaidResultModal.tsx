import React, { useState } from 'react';
import { 
  Award, 
  Coins, 
  Crosshair, 
  Heart, 
  Package, 
  X, 
  CheckCircle2, 
  AlertOctagon,
  Handshake
} from 'lucide-react';
import { RaidExecutionResult, TarkovItem } from '../types';
import { ItemIcon } from './ItemIcon';
import { soundManager } from '../utils/audio';
import { returnFriendGearBackend } from '../api/client';

interface RaidResultModalProps {
  result: RaidExecutionResult | null;
  onClose: () => void;
}

export const RaidResultModal: React.FC<RaidResultModalProps> = ({ result, onClose }) => {
  if (!result) return null;

  const isSurvived = result.status === 'survived';
  const hasFriendGear = result.questUpdates.some(q => q.includes('Гюрз') || q.includes('напарник')) ||
                        result.lootFound.some(it => it.name.includes('Гюрз') || it.name.includes('Жетон'));
  
  const [friendReturned, setFriendReturned] = useState<boolean>(false);
  const [returnFeedback, setReturnFeedback] = useState<string | null>(null);

  const handleReturnFriendGear = async () => {
    if (friendReturned) return;
    soundManager.playCash();

    try {
      await returnFriendGearBackend('@Gurza_PMC');
    } catch {
      // client fallback
    }

    setFriendReturned(true);
    setReturnFeedback("🤝 Снаряжение напарника успешно возвращено бойцу @Gurza_PMC! Прапор начислил +75,000 ₽ и уважение (+0.05)!");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-lg bg-[#0f0f0f] border border-[#2a2a2a] rounded-sm shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Banner */}
        <div className={`p-4 text-center border-b ${
          isSurvived 
            ? 'bg-[#131d16] border-b border-emerald-900/60 text-emerald-400' 
            : 'bg-[#1c1212] border-b border-red-900/60 text-red-400'
        }`}>
          <div className="flex items-center justify-center gap-2 text-xl sm:text-2xl font-black font-tarkov tracking-wider uppercase">
            {isSurvived ? (
              <>
                <CheckCircle2 className="w-6 h-6" />
                ВЫЖИЛ В РЕЙДЕ
              </>
            ) : (
              <>
                <AlertOctagon className="w-6 h-6" />
                УБИТ В БОЮ (M.I.A)
              </>
            )}
          </div>
          <p className="text-[10px] font-mono text-[#777] uppercase tracking-wider mt-1">
            Локация: {result.location.name} • Тактика: {result.tactic.name}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="p-4 space-y-4 font-mono text-xs">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="p-2.5 bg-[#151515] border border-[#242424] rounded-sm">
              <div className="text-[#666] text-[9px] uppercase tracking-wider">ОПЫТ (EXP)</div>
              <div className="text-xs font-bold text-[#d1d1d1] mt-0.5 flex items-center gap-1">
                <Award className="w-3 h-3 text-[#9a8866]" />
                +{result.expEarned} XP
              </div>
            </div>

            <div className="p-2.5 bg-[#151515] border border-[#242424] rounded-sm">
              <div className="text-[#666] text-[9px] uppercase tracking-wider">РУБЛИ</div>
              <div className="text-xs font-bold text-[#9a8866] mt-0.5 flex items-center gap-1">
                <Coins className="w-3 h-3" />
                💰 +{result.rublesFound.toLocaleString('ru-RU')} ₽
              </div>
            </div>

            <div className="p-2.5 bg-[#151515] border border-[#242424] rounded-sm">
              <div className="text-[#666] text-[9px] uppercase tracking-wider">ЦЕЛИ</div>
              <div className="text-xs font-bold text-red-400 mt-0.5 flex items-center gap-1">
                <Crosshair className="w-3 h-3" />
                {result.kills} тел
              </div>
            </div>

            <div className="p-2.5 bg-[#151515] border border-[#242424] rounded-sm">
              <div className="text-[#666] text-[9px] uppercase tracking-wider">УРОН</div>
              <div className="text-xs font-bold text-[#888] mt-0.5 flex items-center gap-1">
                <Heart className="w-3 h-3 text-red-400" />
                -{result.damageTaken} HP
              </div>
            </div>
          </div>

          {/* Friend Gear Rescue Box */}
          {hasFriendGear && (
            <div className="p-3 bg-[#1e1c18] border border-amber-600/50 rounded-sm text-center space-y-2">
              <div className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center justify-center gap-1.5">
                <Handshake className="w-4 h-4 text-amber-400" />
                СПАСЕННОЕ СНАРЯЖЕНИЕ БОЙЦА @Gurza_PMC
              </div>
              {!friendReturned ? (
                <button
                  onClick={handleReturnFriendGear}
                  className="px-4 py-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-black font-bold uppercase text-[10px] font-mono tracking-wider rounded-sm transition-all shadow flex items-center justify-center gap-2 mx-auto"
                >
                  <Handshake className="w-3.5 h-3.5" />
                  <span>🤝 Вернуть спасенное снаряжение @Gurza_PMC (+75,000 ₽)</span>
                </button>
              ) : (
                <div className="text-xs text-emerald-400 font-mono font-bold">
                  {returnFeedback}
                </div>
              )}
            </div>
          )}

          {/* Loot Retrieved and sent to 100-cell stash */}
          {result.lootFound.length > 0 && (
            <div>
              <div className="text-[10px] font-bold text-[#888] uppercase mb-2 flex items-center gap-1.5 tracking-wider">
                <Package className="w-3.5 h-3.5 text-[#9a8866]" />
                ЭВАКУИРОВАННЫЙ ХАБАР (ОТПРАВЛЕН В СХРОН):
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {result.lootFound.map((item) => (
                  <div
                    key={item.id}
                    className="p-2 bg-[#151515] border-l-2 border-l-[#9a8866] border border-[#242424] rounded-sm flex items-center gap-2"
                  >
                    <div className="w-7 h-7 bg-[#1c1c1c] border border-[#2e2e2e] rounded-sm flex items-center justify-center shrink-0">
                      <ItemIcon
                        iconName={item.iconName}
                        category={item.category}
                        rarity={item.rarity}
                        className="w-3.5 h-3.5"
                      />
                    </div>
                    <div className="min-w-0">
                      <div className="font-bold text-[#d1d1d1] text-[10px] truncate font-tarkov">
                        {item.shortName}
                      </div>
                      <div className="text-[9px] text-[#9a8866]">
                        💰 +{item.price.toLocaleString('ru-RU')} ₽ • ⚖️ {item.weight} кг
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Quest Progress Updates */}
          {result.questUpdates.length > 0 && (
            <div className="p-2.5 bg-[#131d16] border border-emerald-900/50 rounded-sm">
              <div className="text-[9px] font-bold text-emerald-400/80 uppercase mb-1">
                ОБНОВЛЕНИЕ КВЕСТОВ:
              </div>
              {result.questUpdates.map((update, idx) => (
                <div key={idx} className="text-emerald-400 text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-3 h-3 shrink-0" />
                  {update}
                </div>
              ))}
            </div>
          )}

          {/* Combat Log Extracts */}
          <div className="p-2.5 bg-[#0a0a0a] border border-[#222] rounded-sm space-y-1 text-[10px] text-[#666] max-h-28 overflow-y-auto">
            {result.logs.map((log, index) => (
              <div key={index}>{log}</div>
            ))}
          </div>

          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="w-full py-2.5 px-4 bg-[#2a2a2a] hover:bg-[#333] border border-[#3a3a3a] hover:border-[#9a8866] text-[#d1d1d1] font-bold uppercase rounded-sm font-mono tracking-widest text-xs transition-colors shadow"
          >
            Вернуться в схрон
          </button>
        </div>
      </div>
    </div>
  );
};
