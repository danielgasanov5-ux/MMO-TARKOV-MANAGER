import React, { useState, useMemo } from 'react';
import { 
  ShoppingBag, 
  ChevronLeft, 
  ChevronRight, 
  Search, 
  Lock, 
  CircleDollarSign, 
  ArrowDownToLine, 
  ArrowUpFromLine,
  Check,
  AlertCircle
} from 'lucide-react';
import { TraderItem, TarkovItem, StashCell, PMCProfile } from '../types';
import { PRAPOR_INFO, PRAPOR_GOODS } from '../data/praporGoods';
import { ItemIcon } from './ItemIcon';
import { soundManager } from '../utils/audio';
import { sellAllJunkToBackend } from '../api/client';

interface PraporTabProps {
  profile: PMCProfile;
  stash: StashCell[];
  onBuyItem: (traderItem: TraderItem) => boolean;
  onSellItem: (item: TarkovItem, cellIndex: number) => void;
  onSellAllBarter: () => void;
  onSelectItem: (item: TarkovItem, cellIndex: number) => void;
  onBulkSell?: (itemsSold: number, rublesGained: number) => void;
}

export const PraporTab: React.FC<PraporTabProps> = ({
  profile,
  stash,
  onBuyItem,
  onSellItem,
  onSellAllBarter,
  onSelectItem,
  onBulkSell,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'buy' | 'sell'>('buy');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [sellNotice, setSellNotice] = useState<string | null>(null);
  const [isSellingAll, setIsSellingAll] = useState<boolean>(false);

  // 4 items per page so the 9 default starter items can be easily paginated
  const itemsPerPage = 4;

  // Calculate free slots in the 100-cell stash
  const freeSlots = useMemo(() => {
    return stash.filter(cell => cell.item === null).length;
  }, [stash]);

  // Determine current Prapor Loyalty Level
  const currentLL = useMemo(() => {
    if (profile.praporSpent >= 2800000 && profile.praporRep >= 0.60) return 4;
    if (profile.praporSpent >= 1600000 && profile.praporRep >= 0.35) return 3;
    if (profile.praporSpent >= 750000 && profile.praporRep >= 0.20) return 2;
    return 1;
  }, [profile.praporSpent, profile.praporRep]);

  // Filter goods
  const filteredGoods = useMemo(() => {
    return PRAPOR_GOODS.filter(good => {
      if (selectedCategory !== 'all' && good.item.category !== selectedCategory) {
        return false;
      }
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        return (
          good.item.name.toLowerCase().includes(q) ||
          good.item.shortName.toLowerCase().includes(q) ||
          good.item.category.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [selectedCategory, searchQuery]);

  // Pagination calculation
  const totalPages = Math.max(1, Math.ceil(filteredGoods.length / itemsPerPage));
  const displayedGoods = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredGoods.slice(start, start + itemsPerPage);
  }, [filteredGoods, currentPage, itemsPerPage]);

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      soundManager.playClick();
      setCurrentPage(newPage);
    }
  };

  // Identify junk and barter items in stash for bulk sell (reduced by 2.3x fair trader price)
  const isJunkItem = (item: TarkovItem | null): boolean => {
    if (!item) return false;
    if (item.category === 'barter') return true;
    if (item.find_only) return true;
    const n = item.name.toLowerCase();
    return (
      n.includes('болт') ||
      n.includes('гайк') ||
      n.includes('свеч') ||
      n.includes('плат') ||
      n.includes('реле') ||
      n.includes('провод') ||
      n.includes('дрель') ||
      n.includes('шланг') ||
      n.includes('батарейка')
    );
  };

  const junkCells = useMemo(() => {
    return stash.filter(c => isJunkItem(c.item));
  }, [stash]);

  // Fair trader price is base price / 2.3
  const totalJunkValue = useMemo(() => {
    return junkCells.reduce((acc, c) => {
      if (!c.item) return acc;
      return acc + Math.round(c.item.price / 2.3);
    }, 0);
  }, [junkCells]);

  const handleSellAllJunk = async () => {
    if (junkCells.length === 0 || isSellingAll) return;
    setIsSellingAll(true);
    soundManager.playCash();

    const count = junkCells.length;
    const gained = totalJunkValue;

    // Try backend call
    try {
      await sellAllJunkToBackend();
    } catch {
      // client-side fallback
    }

    if (onBulkSell) {
      onBulkSell(count, gained);
    } else {
      onSellAllBarter();
    }

    setSellNotice(`Сдано ${count} позиций хлама за ${gained.toLocaleString('ru-RU')} ₽ (по курсу скупки 1:2.3)!`);
    setTimeout(() => setSellNotice(null), 4000);
    setIsSellingAll(false);
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* Prapor Trader Identity Banner */}
      <div className="bg-[#0f0f0f] border border-[#2a2a2a] rounded-sm p-4 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            {/* Prapor Avatar */}
            <div className="w-12 h-12 bg-[#222] border border-[#333] rounded-sm flex items-center justify-center grayscale relative overflow-hidden shrink-0">
              <span className="select-none text-2xl">👮‍♂️</span>
              <span className="absolute bottom-0 inset-x-0 bg-[#0a0a0a]/90 text-[8px] font-mono text-center text-[#9a8866] font-bold py-0.5 border-t border-[#333]">
                LL{currentLL}
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-[#aaa] font-tarkov uppercase tracking-wide">
                  {PRAPOR_INFO.name}
                </h2>
                <span className="px-2 py-0.5 bg-[#1a1a1a] text-[#9a8866] border border-[#333] rounded-sm font-mono text-[10px] font-bold uppercase tracking-wider">
                  {PRAPOR_INFO.callsign}
                </span>
              </div>
              <p className="text-[10px] text-[#555] font-mono mt-0.5 tracking-wide">
                Loyalty Level {currentLL} • Репутация {profile.praporRep.toFixed(2)} • Оборот {profile.praporSpent.toLocaleString('ru-RU')} ₽
              </p>
            </div>
          </div>

          {/* Stash Space Warning Badge & Quick Sell All Button */}
          <div className="flex items-center gap-3 self-stretch md:self-auto justify-between md:justify-end">
            <button
              onClick={handleSellAllJunk}
              disabled={junkCells.length === 0 || isSellingAll}
              className={`px-3 py-2 rounded-sm text-[10px] font-mono uppercase font-bold tracking-wider flex items-center gap-1.5 transition-all border ${
                junkCells.length > 0 
                  ? 'bg-[#9a8866] hover:bg-[#a89572] text-black border-[#9a8866] shadow' 
                  : 'bg-[#181818] text-[#555] border-[#222] cursor-not-allowed'
              }`}
              title="Продать весь хлам, электронику и бартер из схрона по курсу Прапора (/2.3)"
            >
              <CircleDollarSign className="w-3.5 h-3.5" />
              <span>💰 Продать весь хлам {junkCells.length > 0 ? `(${junkCells.length} шт / +${totalJunkValue.toLocaleString('ru-RU')} ₽)` : ''}</span>
            </button>

            <div className="p-2 bg-[#121212] border border-[#222] rounded-sm text-right">
              <div className="text-[9px] uppercase tracking-wider text-[#666] font-mono">МЕСТО В СХРОНЕ</div>
              <div className="text-xs font-mono font-bold mt-0.5">
                {freeSlots > 0 ? (
                  <span className="text-[#888]">Свободно {freeSlots} / 100 яч.</span>
                ) : (
                  <span className="text-red-400">СХРОН ПЕРЕПОЛНЕН!</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Prapor Quote */}
        <div className="mt-3 p-2.5 bg-[#151515] border-l-2 border-[#9a8866] text-xs text-[#888] font-mono italic">
          «{PRAPOR_INFO.greeting}»
        </div>
      </div>

      {/* Sell Notice Flash */}
      {sellNotice && (
        <div className="p-3 bg-[#182618] border border-emerald-500 rounded-sm text-xs font-mono text-emerald-300 flex items-center gap-2 animate-fadeIn">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{sellNotice}</span>
        </div>
      )}

      {/* Subtabs: Buy vs Sell */}
      <div className="flex bg-[#1a1a1a] border-b border-[#2a2a2a] rounded-sm overflow-hidden">
        <button
          onClick={() => {
            soundManager.playClick();
            setActiveSubTab('buy');
          }}
          className={`px-6 py-3 text-xs font-bold uppercase tracking-widest transition-colors ${
            activeSubTab === 'buy'
              ? 'text-[#9a8866] border-b-2 border-[#9a8866] bg-[#151515]'
              : 'text-[#555] hover:text-[#888]'
          }`}
        >
          <span className="flex items-center gap-2">
            <ArrowDownToLine className="w-3.5 h-3.5" />
            Барахолка Прапора (Дефолтный запас)
          </span>
        </button>

        <button
          onClick={() => {
            soundManager.playClick();
            setActiveSubTab('sell');
          }}
          className={`px-6 py-3 text-xs font-bold uppercase tracking-widest transition-colors ${
            activeSubTab === 'sell'
              ? 'text-[#9a8866] border-b-2 border-[#9a8866] bg-[#151515]'
              : 'text-[#555] hover:text-[#888]'
          }`}
        >
          <span className="flex items-center gap-2">
            <ArrowUpFromLine className="w-3.5 h-3.5" />
            Скупка хабара ({junkCells.length} позиций хлама)
          </span>
        </button>
      </div>

      {/* BUY TAB: Goods Catalogue with Russian pagination buttons */}
      {activeSubTab === 'buy' && (
        <div className="space-y-3">
          {/* Filter Bar & Search */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
              {[
                { id: 'all', label: 'Все товары (9)' },
                { id: 'weapons', label: 'Оружие' },
                { id: 'ammo', label: 'Боеприпасы' },
                { id: 'armor', label: 'Броня и шлемы' },
                { id: 'meds', label: 'Медицина' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    soundManager.playClick();
                    setSelectedCategory(tab.id);
                    setCurrentPage(1);
                  }}
                  className={`px-3 py-1.5 rounded-sm text-[10px] font-mono uppercase tracking-wider whitespace-nowrap transition-colors border ${
                    selectedCategory === tab.id
                      ? 'bg-[#9a8866] text-black font-bold border-[#9a8866]'
                      : 'bg-[#151515] text-[#666] border-[#2a2a2a] hover:text-[#d1d1d1]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="relative min-w-[220px]">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-[#666]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                placeholder="Поиск по стартовому каталогу..."
                className="w-full pl-8 pr-3 py-1.5 bg-[#121212] border border-[#2a2a2a] rounded-sm text-xs font-mono text-[#d1d1d1] placeholder:text-[#555] focus:outline-none focus:border-[#9a8866]"
              />
            </div>
          </div>

          {/* Pagination Controls Bar (Explicit [⬅️ Назад] [Страница X/Y] [Вперед ➡️]) */}
          <div className="flex items-center justify-between bg-[#151515] border border-[#2a2a2a] rounded-sm px-4 py-2.5 text-xs font-mono">
            <div className="text-[10px] uppercase text-[#666] tracking-wider">
              ТОВАРЫ: {displayedGoods.length} ИЗ {filteredGoods.length} •{' '}
              <span className="text-[#9a8866] font-bold">СТРАНИЦА {currentPage} ИЗ {totalPages}</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage <= 1}
                className="px-3 py-1.5 bg-[#222] text-[#888] hover:text-[#d1d1d1] hover:bg-[#2e2e2e] border border-[#333] rounded-sm disabled:opacity-30 disabled:cursor-not-allowed transition-colors text-[10px] uppercase font-bold flex items-center gap-1"
                title="Предыдущая страница товаров"
              >
                <span>⬅️ Назад</span>
              </button>

              <div className="px-3 py-1.5 text-[10px] font-mono text-[#9a8866] font-bold border border-[#333] bg-[#1a1a1a] rounded-sm uppercase tracking-wider">
                Страница {currentPage} / {totalPages}
              </div>

              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage >= totalPages}
                className="px-3 py-1.5 bg-[#222] text-[#888] hover:text-[#d1d1d1] hover:bg-[#2e2e2e] border border-[#333] rounded-sm disabled:opacity-30 disabled:cursor-not-allowed transition-colors text-[10px] uppercase font-bold flex items-center gap-1"
                title="Следующая страница товаров"
              >
                <span>Вперед ➡️</span>
              </button>
            </div>
          </div>

          {/* Product Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-3">
            {displayedGoods.map((entry) => {
              const item = entry.item;
              const isLocked = entry.loyaltyRequired > currentLL;
              const canAfford = profile.rubles >= entry.price;
              const hasSpace = freeSlots >= item.slots;

              return (
                <div
                  key={entry.id}
                  className={`p-3.5 rounded-sm border transition-all flex flex-col justify-between ${
                    isLocked
                      ? 'bg-[#101010] border-[#222] opacity-50'
                      : 'bg-[#151515] border-l-2 border-l-[#9a8866] border-[#262626] hover:border-[#3a3a3a] shadow-sm'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#2a2a2a] border border-[#333] rounded-sm flex items-center justify-center shrink-0">
                          <ItemIcon
                            iconName={item.iconName}
                            category={item.category}
                            rarity={item.rarity}
                            className="w-5 h-5"
                          />
                        </div>
                        <div>
                          <div className="text-[9px] font-mono uppercase tracking-wider text-[#666]">
                            {item.category} • {item.slots} ЯЧ.
                          </div>
                          <h4 className="text-xs font-bold text-[#d1d1d1] font-tarkov leading-snug">
                            {item.name}
                          </h4>
                        </div>
                      </div>

                      {entry.loyaltyRequired > 1 && (
                        <span className={`px-1.5 py-0.5 rounded-sm text-[9px] font-mono font-bold border shrink-0 ${
                          isLocked 
                            ? 'bg-red-950/40 border-red-800 text-red-400' 
                            : 'bg-[#222] border-[#333] text-[#9a8866]'
                        }`}>
                          LL{entry.loyaltyRequired}
                        </span>
                      )}
                    </div>

                    <p className="text-[10px] text-[#777] font-mono mt-2 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>

                    <div className="flex items-center gap-2 mt-2 text-[9px] font-mono text-[#666] uppercase">
                      <span>На складе: <strong className="text-[#aaa]">{entry.stock} шт.</strong></span>
                      {item.caliber && <span>• {item.caliber}</span>}
                      {item.armorClass && <span>• КЛАСС {item.armorClass}</span>}
                      {item.quantity && <span>• {item.quantity} ШТ</span>}
                    </div>
                  </div>

                  {/* Price & Buy Button */}
                  <div className="mt-3 pt-2.5 border-t border-[#242424] flex items-center justify-between gap-2">
                    <div>
                      <div className="text-[9px] uppercase tracking-wider text-[#666] font-mono">ЦЕНА</div>
                      <div className="text-sm font-bold text-[#9a8866] font-mono">
                        💰 {entry.price.toLocaleString('ru-RU')} ₽
                      </div>
                    </div>

                    {isLocked ? (
                      <div className="flex items-center gap-1 text-[10px] font-mono text-red-400">
                        <Lock className="w-3.5 h-3.5" />
                        <span>LL{entry.loyaltyRequired}</span>
                      </div>
                    ) : (
                      <button
                        onClick={() => {
                          const success = onBuyItem(entry);
                          if (success) {
                            soundManager.playCash();
                          }
                        }}
                        disabled={!canAfford || !hasSpace}
                        className={`px-4 py-2 rounded-sm text-[10px] uppercase font-bold tracking-wider transition-all border ${
                          !canAfford
                            ? 'bg-[#1e1e1e] text-[#555] border-[#2a2a2a] cursor-not-allowed'
                            : !hasSpace
                            ? 'bg-[#1e1e1e] text-red-400 border-[#2a2a2a] cursor-not-allowed'
                            : 'bg-[#9a8866] hover:bg-[#a89572] text-black border-[#9a8866] shadow'
                        }`}
                      >
                        {!hasSpace ? 'Нет места' : !canAfford ? 'Не хватает ₽' : 'Купить'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Pagination Controls Bar (BOTTOM) */}
          <div className="flex items-center justify-center gap-3 pt-2 border-t border-[#222]">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage <= 1}
              className="px-4 py-2 bg-[#1a1a1a] hover:bg-[#242424] text-[#888] hover:text-[#d1d1d1] text-[10px] font-mono uppercase tracking-wider border border-[#333] rounded-sm disabled:opacity-20 flex items-center gap-1"
            >
              ⬅️ Назад
            </button>

            <span className="text-[10px] font-mono uppercase text-[#9a8866] font-bold tracking-wider px-3">
              Страница {currentPage} из {totalPages}
            </span>

            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage >= totalPages}
              className="px-4 py-2 bg-[#1a1a1a] hover:bg-[#242424] text-[#888] hover:text-[#d1d1d1] text-[10px] font-mono uppercase tracking-wider border border-[#333] rounded-sm disabled:opacity-20 flex items-center gap-1"
            >
              Вперед ➡️
            </button>
          </div>
        </div>
      )}

      {/* SELL TAB: Sell items directly from your 100-cell stash */}
      {activeSubTab === 'sell' && (
        <div className="space-y-3">
          <div className="p-3.5 bg-[#0f0f0f] border border-[#2a2a2a] rounded-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-[#9a8866] font-mono">
                СДАТЬ ТРОФЕИ И ХАБАР ПРАПОРУ
              </h3>
              <p className="text-[10px] text-[#666] font-mono mt-0.5 tracking-wide">
                Прапор скупает хлам и найденные ценности со сниженной ставкой, освобождая место под боевые вылазки.
              </p>
            </div>

            {junkCells.length > 0 && (
              <button
                onClick={handleSellAllJunk}
                disabled={isSellingAll}
                className="px-4 py-2 bg-[#9a8866] hover:bg-[#a89572] text-black font-bold text-[10px] font-mono uppercase tracking-wider rounded-sm flex items-center gap-1.5 transition-colors shadow shrink-0"
              >
                <CircleDollarSign className="w-3.5 h-3.5" />
                💰 Продать весь хлам ({junkCells.length} шт / +{totalJunkValue.toLocaleString('ru-RU')} ₽)
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
            {stash
              .filter(cell => cell.item !== null)
              .map((cell) => {
                const item = cell.item!;
                const isJunk = isJunkItem(item);
                const sellPrice = isJunk ? Math.round(item.price / 2.3) : Math.round(item.price * 0.6);

                return (
                  <div
                    key={cell.index}
                    className={`p-3 bg-[#151515] border border-[#262626] hover:border-[#3a3a3a] rounded-sm flex items-center justify-between gap-2.5 transition-colors ${
                      isJunk ? 'border-l-2 border-l-[#9a8866]' : ''
                    }`}
                  >
                    <div 
                      className="flex items-center gap-2.5 min-w-0 cursor-pointer"
                      onClick={() => onSelectItem(item, cell.index)}
                    >
                      <div className="w-9 h-9 bg-[#222] border border-[#333] rounded-sm flex items-center justify-center shrink-0">
                        <ItemIcon
                          iconName={item.iconName}
                          category={item.category}
                          rarity={item.rarity}
                          className="w-4 h-4"
                        />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-[#d1d1d1] truncate font-tarkov">
                          {item.shortName}
                        </div>
                        <div className="text-[10px] font-mono space-y-0.5">
                          <div className="text-[#777]">
                            Каталог: <span className="text-[#999]">{item.price.toLocaleString('ru-RU')} ₽</span>
                          </div>
                          <div className="text-emerald-400 font-bold">
                            Перед продажей: +{sellPrice.toLocaleString('ru-RU')} ₽ {isJunk ? '(хлам)' : ''}
                          </div>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        soundManager.playCash();
                        setSellNotice(`Продано Прапору: ${item.shortName} за +${sellPrice.toLocaleString('ru-RU')} ₽! (Каталог: ${item.price.toLocaleString('ru-RU')} ₽)`);
                        onSellItem(item, cell.index);
                      }}
                      className="px-3 py-1.5 bg-[#2a2a2a] hover:bg-[#333] hover:border-[#9a8866] text-[#d1d1d1] border border-[#3a3a3a] rounded-sm text-[10px] font-mono uppercase tracking-wider font-bold transition-colors shrink-0 flex flex-col items-end"
                    >
                      <span>Сдать</span>
                      <span className="text-[9px] text-emerald-400">+{sellPrice.toLocaleString('ru-RU')} ₽</span>
                    </button>
                  </div>
                );
              })}
          </div>

          {stash.filter(c => c.item !== null).length === 0 && (
            <div className="p-8 text-center bg-[#111] border border-[#222] rounded-sm text-[#555] text-xs font-mono uppercase tracking-wider">
              В вашем схроне нет предметов для продажи. Совершите рейд или купите снаряжение!
            </div>
          )}
        </div>
      )}
    </div>
  );
};
