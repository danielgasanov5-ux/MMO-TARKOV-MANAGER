import React, { useState } from 'react';
import { 
  Crosshair, 
  MapPin, 
  ShieldAlert, 
  BookOpen, 
  CheckSquare, 
  Gift, 
  Zap, 
  Play, 
  Radio, 
  Skull, 
  Clock, 
  Compass,
  AlertTriangle,
  Award,
  Footprints,
  Eye,
  Crosshair as SniperIcon,
  PackageCheck
} from 'lucide-react';
import { 
  RaidLocation, 
  RaidTactic, 
  RaidTacticId, 
  Quest, 
  PMCProfile, 
  TarkovItem, 
  StashCell,
  RaidExecutionResult 
} from '../types';
import { RAID_LOCATIONS } from '../data/locations';
import { RAID_TACTICS } from '../data/tactics';
import { INITIAL_QUESTS } from '../data/quests';
import { LOOT_POOL } from '../data/items';
import { soundManager } from '../utils/audio';
import { InteractiveRaidModal } from './InteractiveRaidModal';

interface RaidsTabProps {
  profile: PMCProfile;
  stash: StashCell[];
  onExecuteRaid: (result: RaidExecutionResult) => void;
  equippedWeapon: TarkovItem | null;
  equippedArmor: TarkovItem | null;
  equippedHeadset?: TarkovItem | null;
}

export const RaidsTab: React.FC<RaidsTabProps> = ({
  profile,
  stash,
  onExecuteRaid,
  equippedWeapon,
  equippedArmor,
  equippedHeadset,
}) => {
  const [selectedLocation, setSelectedLocation] = useState<RaidLocation>(RAID_LOCATIONS[1]); // Default: Customs (Таможня)
  const [selectedTacticId, setSelectedTacticId] = useState<RaidTacticId>('stealth');
  const [selectedQuestId, setSelectedQuestId] = useState<string>('quest-debut');
  const [questsList, setQuestsList] = useState<Quest[]>(INITIAL_QUESTS);
  const [isRaiding, setIsRaiding] = useState(false);
  const [showInteractiveRaid, setShowInteractiveRaid] = useState(false);
  const [raidLogs, setRaidLogs] = useState<string[]>([]);
  const [raidProgress, setRaidProgress] = useState<number>(0);

  const selectedTactic = RAID_TACTICS.find(t => t.id === selectedTacticId)!;
  const currentQuest = questsList.find(q => q.id === selectedQuestId) || questsList[0];

  const handleSelectTactic = (id: RaidTacticId) => {
    soundManager.playClick();
    setSelectedTacticId(id);
  };

  const handleSelectLocation = (loc: RaidLocation) => {
    soundManager.playClick();
    setSelectedLocation(loc);
  };

  const handleSelectQuest = (id: string) => {
    soundManager.playClick();
    setSelectedQuestId(id);
  };

  // Run the raid simulation with chosen tactic & location
  const handleDeploy = () => {
    if (isRaiding) return;

    soundManager.playRaidStart();
    setIsRaiding(true);
    setRaidProgress(10);
    setRaidLogs([
      `[00:00] ВЫСАДКА: ЧВК ${profile.callsign} (${profile.faction}) десантировался на локации ${selectedLocation.name.toUpperCase()}.`,
      `[00:05] ДОКТРИНА: Активирована тактика "${selectedTactic.name.toUpperCase()}". Готовность оружия 100%.`
    ]);

    // Simulated phase 1: Infiltration
    setTimeout(() => {
      setRaidProgress(40);
      const isBossArea = Math.random() > 0.65 && selectedLocation.scavBoss !== null;
      let phaseLog = `[00:15] ПЕРЕДВИЖЕНИЕ: Разведка зоны ${selectedLocation.hotZones[0]}. Звуки далекой перестрелки.`;
      
      if (selectedTactic.id === 'stealth') {
        phaseLog = `[00:15] СКРЫТНОСТЬ: Обход патруля Диких по кустам. Замечен схрон в тайнике.`;
      } else if (selectedTactic.id === 'assault') {
        phaseLog = `[00:15] ШТУРМ: Атакован опорный пункт Диких! Очередь на подавление.`;
      } else if (selectedTactic.id === 'sniper') {
        phaseLog = `[00:15] ЗАСАДА: Занята позиция на возвышенности с обзором на 200 метров.`;
      } else if (selectedTactic.id === 'scavenge') {
        phaseLog = `[00:15] МАРОДЕРСТВО: Вскрыт оружейный ящик и картотека в караулке.`;
      }

      setRaidLogs(prev => [...prev, phaseLog]);
    }, 900);

    // Simulated phase 2: Encounter / Quest Check
    setTimeout(() => {
      setRaidProgress(75);
      const killsCount = selectedTactic.id === 'assault' 
        ? Math.floor(Math.random() * 3) + 2 
        : selectedTactic.id === 'sniper' 
        ? Math.floor(Math.random() * 2) + 1 
        : Math.floor(Math.random() * 2);

      let encounterLog = `[00:28] СТОЛКНОВЕНИЕ: Ликвидировано целей: ${killsCount} (Дикие).`;
      if (killsCount === 0 && selectedTactic.id === 'stealth') {
        encounterLog = `[00:28] СКРЫТНОСТЬ: Ни одного выстрела не произведено. Патрули обойдены без шума.`;
      }

      setRaidLogs(prev => [...prev, encounterLog]);
    }, 1800);

    // Simulated phase 3: Extraction and Outcome resolution
    setTimeout(() => {
      setRaidProgress(100);

      // Base survival chance calculation
      let survivalChance = 65; // base 65%
      survivalChance += selectedTactic.survivalBonus;
      if (equippedWeapon) survivalChance += 10;
      if (equippedArmor) survivalChance += 15;
      if (selectedLocation.difficulty === 'Высокая') survivalChance -= 15;
      if (selectedLocation.difficulty === 'Смертельная') survivalChance -= 25;

      const roll = Math.random() * 100;
      const survived = roll < Math.min(95, Math.max(20, survivalChance));

      const kills = survived ? (selectedTactic.id === 'assault' ? 3 : selectedTactic.id === 'sniper' ? 2 : 1) : 0;
      const expEarned = survived ? (selectedLocation.id === 'reserve' ? 2400 : 1200) + kills * 300 : 250;
      const rublesFound = survived ? Math.floor(Math.random() * 45000) + 25000 : 0;
      const damageTaken = survived ? Math.floor(Math.random() * 110) + 20 : 380;

      // Pick loot items if survived
      const lootFound: TarkovItem[] = [];
      if (survived) {
        const lootCount = selectedTactic.id === 'scavenge' ? 3 : 2;
        for (let i = 0; i < lootCount; i++) {
          const randomLoot = LOOT_POOL[Math.floor(Math.random() * LOOT_POOL.length)];
          // clone with fresh id
          lootFound.push({
            ...randomLoot,
            id: `loot-${Date.now()}-${i}`,
            inRaid: true,
          });
        }
      }

      // Update quests objectives progress
      const questUpdates: string[] = [];
      if (survived && kills > 0) {
        setQuestsList(prev => prev.map(q => {
          if (q.id === 'quest-debut') {
            const updatedObjs = q.objectives.map(obj => {
              if (obj.id === 'obj-1') {
                const newCur = Math.min(obj.target, obj.current + kills);
                return { ...obj, current: newCur, completed: newCur >= obj.target };
              }
              return obj;
            });
            return { ...q, objectives: updatedObjs };
          }
          return q;
        }));
        questUpdates.push(`Прогресс квеста "Дебют": +${kills} Диких ликвидировано`);
      }

      const finalStatus: 'survived' | 'kia' = survived ? 'survived' : 'kia';

      const finalResult: RaidExecutionResult = {
        location: selectedLocation,
        tactic: selectedTactic,
        status: finalStatus,
        expEarned,
        rublesFound,
        kills,
        lootFound,
        damageTaken,
        questUpdates,
        logs: [
          ...raidLogs,
          survived 
            ? `[00:35] ЭВАКУАЦИЯ: ЧВК успешно вышел через точку выхода! Статус: ВЫЖИЛ (SURVIVED)` 
            : `[00:33] КРИТИЧЕСКИЙ УРОН: Попадание в грудь. ЧВК погиб в бою. Статус: УБИТ В БОЮ (KIA)`
        ]
      };

      if (survived) {
        soundManager.playSuccess();
      } else {
        soundManager.playClick();
      }

      setIsRaiding(false);
      onExecuteRaid(finalResult);
    }, 2700);
  };

  const getTacticIcon = (id: RaidTacticId) => {
    switch (id) {
      case 'stealth': return <Eye className="w-4 h-4 text-emerald-400" />;
      case 'assault': return <Crosshair className="w-4 h-4 text-red-400" />;
      case 'sniper': return <SniperIcon className="w-4 h-4 text-sky-400" />;
      case 'scavenge': return <PackageCheck className="w-4 h-4 text-amber-400" />;
    }
  };

  return (
    <div className="space-y-4 animate-fadeIn">
      {/* Location Selector Carousel */}
      <div className="bg-[#121212] border border-[#2a2a2a] rounded-sm p-4 shadow-xl">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#242424]">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#9a8866]" />
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-[#9a8866] font-mono">
              ВЫБОР ЛОКАЦИИ ДЛЯ ВЫСАДКИ
            </h2>
          </div>
          <span className="text-[10px] font-mono text-[#666] uppercase tracking-wider">
            Норвинская область // Тарков
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          {RAID_LOCATIONS.map((loc) => {
            const isSelected = selectedLocation.id === loc.id;
            return (
              <button
                key={loc.id}
                onClick={() => handleSelectLocation(loc)}
                className={`p-3 rounded-sm border text-left transition-all flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#181818] border-l-2 border-l-[#9a8866] border-[#3a3a3a] shadow'
                    : 'bg-[#141414] border-[#222] hover:bg-[#1a1a1a] hover:border-[#333]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-mono font-bold text-[#666] uppercase">
                      {loc.codeName}
                    </span>
                    <span className={`text-[8px] font-mono px-1 py-0.5 rounded-sm uppercase tracking-wider font-semibold border ${
                      loc.difficulty === 'Легкая' ? 'bg-[#18241b] text-emerald-400 border-emerald-900/50' :
                      loc.difficulty === 'Средняя' ? 'bg-[#262016] text-[#9a8866] border-[#9a8866]/30' :
                      'bg-[#281616] text-red-400 border-red-900/50'
                    }`}>
                      {loc.difficulty}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-[#d1d1d1] font-tarkov mt-1.5 leading-snug">
                    {loc.name.split(' (')[0]}
                  </h4>
                </div>

                <div className="mt-2.5 pt-1.5 border-t border-[#222] text-[9px] font-mono text-[#666] flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-[#555]" />
                    {loc.estTime}
                  </span>
                  {loc.scavBoss && (
                    <span className="text-[#9a8866] font-bold">
                      {loc.scavBoss}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Location Brief */}
        <div className="mt-3 p-3 bg-[#151515] border border-[#242424] rounded-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs font-mono">
          <div className="text-[#888]">
            <strong className="text-[#d1d1d1] font-tarkov uppercase">{selectedLocation.name}:</strong>{' '}
            <span className="text-[#777]">{selectedLocation.description}</span>
          </div>
          <div className="text-[#9a8866] shrink-0 font-bold flex items-center gap-1 text-[11px]">
            <AlertTriangle className="w-3.5 h-3.5" />
            {selectedLocation.dangerNotes}
          </div>
        </div>
      </div>

      {/* TACTICAL CHOICE BUTTONS ("Кнопки выбора тактики") */}
      <div className="bg-[#121212] border border-[#2a2a2a] rounded-sm p-4 shadow-xl">
        <div className="flex items-center justify-between mb-2 pb-2 border-b border-[#242424]">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-[#9a8866]" />
            <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-[#9a8866] font-mono">
              ТАКТИЧЕСКАЯ ДОКТРИНА РЕЙДА (ВЫБОР ТАКТИКИ)
            </h3>
          </div>
          <span className="text-[10px] font-mono text-[#9a8866] font-bold uppercase tracking-wider">
            ВЫБРАНО: {selectedTactic.name}
          </span>
        </div>

        <p className="text-[11px] text-[#666] font-mono mb-3">
          Выберите тактику ведения боя перед выходом. Тактика напрямую определяет вероятность встреч с ЧВК, выживаемость и тип добываемого хабара.
        </p>

        {/* The 4 Tactical Choice Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {RAID_TACTICS.map((tactic) => {
            const isSelected = selectedTacticId === tactic.id;
            return (
              <button
                key={tactic.id}
                onClick={() => handleSelectTactic(tactic.id)}
                className={`p-3.5 rounded-sm border text-left transition-all flex flex-col justify-between relative overflow-hidden group ${
                  isSelected
                    ? 'bg-[#181818] border-l-2 border-l-[#9a8866] border-[#383838] shadow'
                    : 'bg-[#141414] border-[#222] hover:bg-[#1a1a1a] hover:border-[#333]'
                }`}
              >
                {/* Top badge */}
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    {getTacticIcon(tactic.id)}
                    <span className="text-xs font-bold text-[#d1d1d1] font-tarkov">
                      {tactic.name}
                    </span>
                  </div>
                  <span
                    className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded-sm border uppercase tracking-wider"
                    style={{ borderColor: tactic.color, color: tactic.color }}
                  >
                    {tactic.badge}
                  </span>
                </div>

                {/* Description */}
                <p className="text-[10px] text-[#777] font-mono mt-2 leading-relaxed">
                  {tactic.description}
                </p>

                {/* Modifiers Footer */}
                <div className="mt-3 pt-2 border-t border-[#242424] grid grid-cols-2 gap-1 text-[9px] font-mono">
                  <div>
                    <span className="text-[#555]">Выживание:</span>{' '}
                    <strong className={tactic.survivalBonus >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                      {tactic.survivalBonus > 0 ? `+${tactic.survivalBonus}%` : `${tactic.survivalBonus}%`}
                    </strong>
                  </div>
                  <div>
                    <span className="text-[#555]">Опасность:</span>{' '}
                    <strong className="text-[#888]">{tactic.risk}</strong>
                  </div>
                  <div className="col-span-2 text-[#777] truncate mt-0.5">
                    Лут: <span className="text-[#9a8866] font-semibold">{tactic.lootPotential}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* QUESTS TEXT OUTPUT ("Вывод текста квестов") */}
      <div className="bg-[#121212] border border-[#2a2a2a] rounded-sm p-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-3 pb-2 border-b border-[#242424]">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-[#9a8866] animate-pulse" />
            <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-[#9a8866] font-mono">
              РАДИОПЕРЕХВАТ ТОРГОВЦЕВ // ТЕКСТ КВЕСТОВ И ЗАДАНИЙ
            </h3>
          </div>
          <span className="text-[10px] font-mono text-[#666] uppercase tracking-wider">
            Контракты торговцев Таркова
          </span>
        </div>

        {/* Quest Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
          {questsList.map((quest) => (
            <button
              key={quest.id}
              onClick={() => handleSelectQuest(quest.id)}
              className={`px-3 py-1.5 rounded-sm text-[10px] font-mono uppercase tracking-wider whitespace-nowrap transition-colors border flex items-center gap-1.5 ${
                selectedQuestId === quest.id
                  ? 'bg-[#9a8866] text-black font-bold border-[#9a8866]'
                  : 'bg-[#151515] text-[#777] border-[#262626] hover:text-[#d1d1d1]'
              }`}
            >
              <span>{quest.traderAvatar}</span>
              <span>{quest.title}</span>
              <span className={`text-[8px] px-1 py-0.2 rounded-sm ${
                quest.status === 'in_progress' ? 'bg-[#222] text-[#9a8866]' : 'bg-[#1a1a1a] text-[#555]'
              }`}>
                {quest.status === 'in_progress' ? 'В процессе' : 'Доступен'}
              </span>
            </button>
          ))}
        </div>

        {/* Quest Terminal Body */}
        <div className="p-3.5 sm:p-4 bg-[#151515] border border-[#262626] rounded-sm space-y-3 font-mono">
          {/* Header */}
          <div className="flex items-start justify-between gap-2 pb-2 border-b border-[#262626]">
            <div>
              <div className="text-[9px] text-[#666] uppercase tracking-widest">
                ЗАКАЗЧИК: {currentQuest.traderName} • ЛОКАЦИЯ: {currentQuest.location}
              </div>
              <h4 className="text-sm font-bold text-[#d1d1d1] font-tarkov mt-0.5">
                {currentQuest.title}
              </h4>
            </div>
            <div className="px-2 py-0.5 bg-[#1f1f1f] text-[#9a8866] border border-[#333] rounded-sm text-[10px] font-bold">
              +{currentQuest.rewards.exp} XP
            </div>
          </div>

          {/* Authentic Monologue Dialogue Text */}
          <div className="p-3 bg-[#121212] border-l-2 border-[#9a8866] rounded-none text-xs text-[#888] leading-relaxed italic">
            «{currentQuest.introText}»
          </div>

          {/* Objectives Checklist with Counters */}
          <div>
            <div className="text-[10px] font-bold text-[#aaa] uppercase mb-1.5 flex items-center gap-1.5 tracking-wider">
              <CheckSquare className="w-3.5 h-3.5 text-emerald-400" />
              ОПЕРАТИВНЫЕ ЦЕЛИ КОНТРАКТА:
            </div>
            <div className="space-y-1.5">
              {currentQuest.objectives.map((obj) => (
                <div
                  key={obj.id}
                  className="flex items-center justify-between p-2 bg-[#181818] border border-[#282828] rounded-sm text-xs"
                >
                  <span className={obj.completed ? 'text-emerald-400 line-through' : 'text-[#bbb]'}>
                    • {obj.text}
                  </span>
                  <span className={`font-bold font-mono text-[11px] ${obj.completed ? 'text-emerald-400' : 'text-[#9a8866]'}`}>
                    [{obj.current} / {obj.target}]
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Rewards Panel */}
          <div className="pt-2.5 border-t border-[#262626] flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-3 text-[#888]">
              <span className="flex items-center gap-1 text-[#9a8866] font-bold">
                <Gift className="w-3.5 h-3.5" />
                Награда: {currentQuest.rewards.rubles.toLocaleString('ru-RU')} ₽
              </span>
              <span>• Репутация Прапора: +{currentQuest.rewards.rep}</span>
            </div>

            {currentQuest.rewards.itemRewards && (
              <div className="text-[#666] text-[10px] uppercase">
                Снаряжение: {currentQuest.rewards.itemRewards.join(', ')}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* RAID DEPLOYMENT LAUNCH BUTTON & ACTIVE CONSOLE */}
      <div className="bg-[#0f0f0f] border border-[#2a2a2a] rounded-sm p-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="text-[10px] font-mono text-[#666] uppercase tracking-wider">
              ГОТОВНОСТЬ К РЕЙДУ // ПРОВЕРКА ЭКИПИРОВКИ
            </div>
            <div className="text-xs font-bold text-[#d1d1d1] font-tarkov mt-0.5">
              {equippedWeapon ? `Оружие: ${equippedWeapon.shortName}` : 'Оружие: Не экипировано'} •{' '}
              {equippedArmor ? `Броня: ${equippedArmor.shortName}` : 'Броня: Отсутствует'} •{' '}
              {equippedHeadset ? `🎧 Наушники: ${equippedHeadset.shortName} (+25% к защите)` : 'Наушники: Нет (риск засады)'}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full sm:w-auto">
            {/* Primary 15-Stage Interactive Raid Engine Button */}
            <button
              onClick={() => {
                soundManager.playClick();
                setShowInteractiveRaid(true);
              }}
              disabled={isRaiding}
              className="px-6 py-3 rounded-sm font-mono font-bold text-xs tracking-wider uppercase transition-all shadow-lg flex items-center justify-center gap-2 border bg-[#9a8866] hover:bg-[#a89572] text-black border-[#9a8866]"
            >
              <Zap className="w-3.5 h-3.5 fill-current text-black" />
              15-ЭТАПНЫЙ РЕЙД (СЮЖЕТ & ПОДСУМОК)
            </button>

            {/* Quick Simulation Deploy Button */}
            <button
              onClick={handleDeploy}
              disabled={isRaiding}
              className={`px-5 py-3 rounded-sm font-mono font-bold text-xs tracking-wider uppercase transition-all shadow-lg flex items-center justify-center gap-2 border ${
                isRaiding
                  ? 'bg-[#181818] text-[#555] border-[#2a2a2a] cursor-not-allowed'
                  : 'bg-[#1a1a1a] hover:bg-[#252525] text-[#bbb] hover:text-white border-[#333] hover:border-[#555]'
              }`}
            >
              <Play className={`w-3.5 h-3.5 fill-current text-[#9a8866] ${isRaiding ? 'animate-spin' : ''}`} />
              {isRaiding ? 'БОЙ...' : 'БЫСТРЫЙ РЕЙД'}
            </button>
          </div>
        </div>

        {/* Live Simulation Progress Log */}
        {isRaiding && (
          <div className="mt-4 pt-3 border-t border-[#242424] space-y-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-[#666] uppercase tracking-wider">
              <span>СИМУЛЯЦИЯ БОЯ НА ЛОКАЦИИ...</span>
              <span className="text-[#9a8866] font-bold">{raidProgress}%</span>
            </div>
            <div className="w-full h-1.5 bg-[#1c1c1c] rounded-none overflow-hidden">
              <div
                className="h-full bg-[#9a8866] transition-all duration-300"
                style={{ width: `${raidProgress}%` }}
              />
            </div>

            <div className="p-3 bg-[#0a0a0a] border border-[#222] rounded-sm font-mono text-xs space-y-1 max-h-32 overflow-y-auto">
              {raidLogs.map((log, index) => (
                <div key={index} className="text-[#888]">
                  {log}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Interactive 15-Stage Raid Engine Modal */}
      {showInteractiveRaid && (
        <InteractiveRaidModal
          location={selectedLocation}
          tactic={selectedTactic}
          profile={profile}
          equippedHeadset={equippedHeadset}
          onFinish={(result) => {
            setShowInteractiveRaid(false);
            onExecuteRaid(result);
          }}
          onClose={() => setShowInteractiveRaid(false)}
        />
      )}
    </div>
  );
};
