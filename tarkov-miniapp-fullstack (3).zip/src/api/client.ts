/**
 * Tarkov Mini App API Client
 * Synchronized with Python FastAPI Backend (/backend/main.py)
 */

export const API_BASE_URL = 
  (typeof import.meta !== 'undefined' && (import.meta as unknown as { env?: { VITE_API_URL?: string } }).env?.VITE_API_URL) || 
  'http://localhost:8000';

export async function fetchStashFromBackend(initData?: string) {
  try {
    const res = await fetch(`${API_BASE_URL}/api/stash`, {
      headers: {
        'X-Telegram-Init-Data': initData || 'dev',
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[API] Backend unreachable, using client state:', err);
    return null;
  }
}

export async function fetchMarketFromBackend(page: number, limit: number, category?: string, search?: string) {
  try {
    const params = new URLSearchParams({
      page: String(page),
      limit: String(limit),
      ...(category ? { category } : {}),
      ...(search ? { search } : {}),
    });
    const res = await fetch(`${API_BASE_URL}/api/market?${params.toString()}`, {
      headers: { 'X-Telegram-Init-Data': 'dev' },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[API] Market backend offline:', err);
    return null;
  }
}

export async function sellAllJunkToBackend() {
  try {
    const res = await fetch(`${API_BASE_URL}/api/sell_all`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Telegram-Init-Data': 'dev',
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[API] Sell All backend offline:', err);
    return null;
  }
}

export async function start15StageRaid(locationId: string, tacticId: string) {
  try {
    const res = await fetch(`${API_BASE_URL}/api/raid/start`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Telegram-Init-Data': 'dev',
      },
      body: JSON.stringify({ locationId, tacticId }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[API] Raid start backend offline, falling back to local 15-stage engine:', err);
    return null;
  }
}

export async function sendRaidAction(raidId: string, choiceId: string) {
  try {
    const res = await fetch(`${API_BASE_URL}/api/raid/action`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Telegram-Init-Data': 'dev',
      },
      body: JSON.stringify({ raidId, choiceId }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[API] Raid action backend offline, falling back to local resolution:', err);
    return null;
  }
}

export async function equipStashItemBackend(cellIndex: number, slotType: string) {
  try {
    const res = await fetch(`${API_BASE_URL}/api/stash/equip`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Telegram-Init-Data': 'dev',
      },
      body: JSON.stringify({ cellIndex, slotType }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[API] Equip stash item backend offline:', err);
    return null;
  }
}

export async function returnFriendGearBackend(friendUsername: string = '@Gurza_PMC') {
  try {
    const res = await fetch(`${API_BASE_URL}/api/raid/return_friend_gear`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Telegram-Init-Data': 'dev',
      },
      body: JSON.stringify({ friendUsername }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.warn('[API] Return friend gear backend offline:', err);
    return null;
  }
}
