import React, { useState, useEffect } from 'react';
import { 
  Package, 
  ShoppingBag, 
  Crosshair, 
  User, 
  Smartphone,
  ShieldAlert
} from 'lucide-react';
import { 
  StashCell, 
  PMCProfile, 
  TarkovItem, 
  TraderItem, 
  RaidExecutionResult 
} from './types';
import { INITIAL_ITEMS } from './data/items';
import { Header } from './components/Header';
import { StashTab } from './components/StashTab';
import { PraporTab } from './components/PraporTab';
import { RaidsTab } from './components/RaidsTab';
import { ProfileTab } from './components/ProfileTab';
import { ItemModal } from './components/ItemModal';
import { RaidResultModal } from './components/RaidResultModal';
import { soundManager } from './utils/audio';

// Default 100-cell stash generator (10x10)
const generateInitialStash = (): StashCell[] => {
  return Array.from({ length: 100 }, (_, index) => ({
    index,
    item: INITIAL_ITEMS[index] ? { ...INITIAL_ITEMS[index] } : null,
  }));
};

const DEFAULT_PROFILE: PMCProfile = {
  name: 'Оперативник',
  callsign: 'TARK_GHOST',
  level: 8,
  faction: 'BEAR',
  exp: 14200,
  nextLevelExp: 22000,
  rubles: 485000,
  dollars: 1250,
  euros: 800,
  health: {
    head: 35,
    maxHead: 35,
    thorax: 85,
    maxThorax: 85,
    stomach: 70,
    maxStomach: 70,
    arms: 120,
    maxArms: 120,
    legs: 130,
    maxLegs: 130,
  },
  praporRep: 0.28,
  praporSpent: 920000,
  raidsCount: 14,
  survivedCount: 9,
  killsCount: 22,
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'stash' | 'prapor' | 'raids' | 'profile'>('stash');
  const [stash, setStash] = useState<StashCell[]>(() => {
    const saved = localStorage.getItem('tarkov_stash_100');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return generateInitialStash();
  });

  const [profile, setProfile] = useState<PMCProfile>(() => {
    const saved = localStorage.getItem('tarkov_pmc_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    return DEFAULT_PROFILE;
  });

  const [equippedWeapon, setEquippedWeapon] = useState<TarkovItem | null>(INITIAL_ITEMS[0]); // AK-74M
  const [equippedArmor, setEquippedArmor] = useState<TarkovItem | null>(INITIAL_ITEMS[8]); // 6B13
  const [equippedHelmet, setEquippedHelmet] = useState<TarkovItem | null>(INITIAL_ITEMS[9]); // Sfera-S
  const [equippedHeadset, setEquippedHeadset] = useState<TarkovItem | null>({
    id: 'starter-headset-gssh',
    name: 'Активные наушники ГСШ-01 6М2',
    shortName: 'ГСШ-01',
    category: 'armor',
    subcategory: 'headset',
    description: 'Отечественные активные наушники. Усиливают тихие звуки шагов и гасят громкие взрывы.',
    price: 18500,
    rarity: 'common',
    slots: 1,
    weight: 0.38,
    iconName: 'Headphones',
    inRaid: false,
  });
  const [equippedRig, setEquippedRig] = useState<TarkovItem | null>(INITIAL_ITEMS[10]); // Rig

  const [inspectItem, setInspectItem] = useState<{ item: TarkovItem; cellIndex: number } | null>(null);
  const [lastRaidResult, setLastRaidResult] = useState<RaidExecutionResult | null>(null);
  const [isSimulatedMobile, setIsSimulatedMobile] = useState<boolean>(false);

  // Save to local storage for persistence
  useEffect(() => {
    localStorage.setItem('tarkov_stash_100', JSON.stringify(stash));
  }, [stash]);

  useEffect(() => {
    localStorage.setItem('tarkov_pmc_profile', JSON.stringify(profile));
  }, [profile]);

  // Handle Tab Switch
  const handleTabSwitch = (tab: 'stash' | 'prapor' | 'raids' | 'profile') => {
    soundManager.playClick();
    setActiveTab(tab);
  };

  // Buy item from Prapor: place in first available slot of the 100-cell stash
  const handleBuyItem = (traderItem: TraderItem): boolean => {
    if (profile.rubles < traderItem.price) {
      alert('Недостаточно рублей!');
      return false;
    }

    const firstEmptyIndex = stash.findIndex(cell => cell.item === null);
    if (firstEmptyIndex === -1) {
      alert('В схроне нет места! Схрон на 100 ячеек полностью забит.');
      return false;
    }

    // Deduct money and update Prapor stats
    setProfile(prev => ({
      ...prev,
      rubles: prev.rubles - traderItem.price,
      praporSpent: prev.praporSpent + traderItem.price,
      praporRep: Number((prev.praporRep + 0.01).toFixed(2)),
    }));

    // Add item to 100-cell stash
    const newStash = [...stash];
    const newItem: TarkovItem = {
      ...traderItem.item,
      id: `bought-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      inRaid: false,
    };
    newStash[firstEmptyIndex].item = newItem;
    setStash(newStash);

    return true;
  };

  // Sell item from 100-cell stash to Prapor
  const handleSellItem = (item: TarkovItem, cellIndex: number) => {
    // Add money to wallet
    setProfile(prev => ({
      ...prev,
      rubles: prev.rubles + item.price,
      praporSpent: prev.praporSpent + item.price,
      praporRep: Number((prev.praporRep + 0.005).toFixed(2)),
    }));

    // Remove from stash cell
    const newStash = [...stash];
    newStash[cellIndex].item = null;
    setStash(newStash);

    if (inspectItem?.cellIndex === cellIndex) {
      setInspectItem(null);
    }
  };

  // Sell all barter items and junk at once
  const handleBulkSell = (itemsSold: number, rublesGained: number) => {
    const isJunk = (item: TarkovItem | null): boolean => {
      if (!item) return false;
      if (item.category === 'barter') return true;
      if (item.find_only) return true;
      const n = item.name.toLowerCase();
      return (
        n.includes('болт') ||
        n.includes('гайк') ||
        n.includes('свеч') ||
        n.includes('плат') ||
        n.includes('реле') ||
        n.includes('провод') ||
        n.includes('дрель') ||
        n.includes('шланг') ||
        n.includes('батарейка')
      );
    };

    const newStash = stash.map(cell => {
      if (isJunk(cell.item)) {
        return { ...cell, item: null };
      }
      return cell;
    });

    setProfile(prev => ({
      ...prev,
      rubles: prev.rubles + rublesGained,
      praporSpent: prev.praporSpent + rublesGained,
      praporRep: Number((prev.praporRep + (itemsSold * 0.005)).toFixed(2)),
    }));
    setStash(newStash);
  };

  const handleSellAllBarter = () => {
    let gainedRubles = 0;
    let soldCount = 0;
    const newStash = stash.map(cell => {
      if (cell.item && cell.item.category === 'barter') {
        gainedRubles += Math.round(cell.item.price / 2.3);
        soldCount++;
        return { ...cell, item: null };
      }
      return cell;
    });

    if (gainedRubles > 0) {
      setProfile(prev => ({
        ...prev,
        rubles: prev.rubles + gainedRubles,
        praporSpent: prev.praporSpent + gainedRubles,
        praporRep: Number((prev.praporRep + (soldCount * 0.005)).toFixed(2)),
      }));
      setStash(newStash);
    }
  };

  // Discard item
  const handleDiscardItem = (item: TarkovItem) => {
    if (inspectItem) {
      const newStash = [...stash];
      newStash[inspectItem.cellIndex].item = null;
      setStash(newStash);
      setInspectItem(null);
    }
  };

  // Equip item to loadout
  const handleEquipItem = (item: TarkovItem, cellIndex?: number) => {
    soundManager.playItemMove();
    let prevItem: TarkovItem | null = null;

    if (item.category === 'weapons') {
      prevItem = equippedWeapon;
      setEquippedWeapon(item);
    } else if (item.category === 'armor') {
      if (item.subcategory === 'headset' || item.name.toLowerCase().includes('наушник') || item.name.includes('ГСШ') || item.name.includes('ComTac') || item.name.includes('Sordin') || item.name.includes('Razor')) {
        prevItem = equippedHeadset;
        setEquippedHeadset(item);
      } else if (item.subcategory === 'helmet' || item.name.includes('Шлем') || item.name.includes('Каска') || item.name.includes('Сфера') || item.name.includes('Алтын') || item.name.includes('Колпак')) {
        prevItem = equippedHelmet;
        setEquippedHelmet(item);
      } else if (item.subcategory === 'rig') {
        prevItem = equippedRig;
        setEquippedRig(item);
      } else {
        prevItem = equippedArmor;
        setEquippedArmor(item);
      }
    }

    if (cellIndex !== undefined) {
      const newStash = [...stash];
      newStash[cellIndex].item = prevItem;
      setStash(newStash);
    }
  };

  // Unequip item to stash
  const handleUnequipItem = (slot: 'weapon' | 'armor' | 'helmet' | 'headset' | 'rig') => {
    soundManager.playItemMove();
    const firstEmptyIndex = stash.findIndex(c => c.item === null);

    let itemToUnequip: TarkovItem | null = null;
    if (slot === 'weapon') {
      itemToUnequip = equippedWeapon;
      setEquippedWeapon(null);
    } else if (slot === 'armor') {
      itemToUnequip = equippedArmor;
      setEquippedArmor(null);
    } else if (slot === 'helmet') {
      itemToUnequip = equippedHelmet;
      setEquippedHelmet(null);
    } else if (slot === 'headset') {
      itemToUnequip = equippedHeadset;
      setEquippedHeadset(null);
    } else if (slot === 'rig') {
      itemToUnequip = equippedRig;
      setEquippedRig(null);
    }

    if (itemToUnequip && firstEmptyIndex !== -1) {
      const newStash = [...stash];
      newStash[firstEmptyIndex].item = itemToUnequip;
      setStash(newStash);
    }
  };

  // Use medical item
  const handleUseMed = (item: TarkovItem) => {
    setProfile(prev => ({
      ...prev,
      health: {
        ...prev.health,
        head: prev.health.maxHead,
        thorax: prev.health.maxThorax,
        stomach: prev.health.maxStomach,
        arms: prev.health.maxArms,
        legs: prev.health.maxLegs,
      }
    }));

    if (inspectItem) {
      const newStash = [...stash];
      newStash[inspectItem.cellIndex].item = null;
      setStash(newStash);
      setInspectItem(null);
    }
  };

  // Execute Raid outcome
  const handleExecuteRaid = (result: RaidExecutionResult) => {
    setLastRaidResult(result);

    setProfile(prev => {
      const newExp = prev.exp + result.expEarned;
      const leveledUp = newExp >= prev.nextLevelExp;
      const newLevel = leveledUp ? prev.level + 1 : prev.level;
      const nextLevelExp = leveledUp ? prev.nextLevelExp + 10000 : prev.nextLevelExp;

      // Distribute damage to limbs
      const remainingDamage = result.damageTaken;
      const newHead = Math.max(10, prev.health.head - Math.floor(remainingDamage * 0.15));
      const newThorax = Math.max(15, prev.health.thorax - Math.floor(remainingDamage * 0.35));
      const newStomach = Math.max(10, prev.health.stomach - Math.floor(remainingDamage * 0.2));
      const newArms = Math.max(20, prev.health.arms - Math.floor(remainingDamage * 0.15));
      const newLegs = Math.max(20, prev.health.legs - Math.floor(remainingDamage * 0.15));

      return {
        ...prev,
        level: newLevel,
        exp: newExp,
        nextLevelExp,
        rubles: prev.rubles + result.rublesFound,
        raidsCount: prev.raidsCount + 1,
        survivedCount: result.status === 'survived' ? prev.survivedCount + 1 : prev.survivedCount,
        killsCount: prev.killsCount + result.kills,
        health: {
          ...prev.health,
          head: newHead,
          thorax: newThorax,
          stomach: newStomach,
          arms: newArms,
          legs: newLegs,
        }
      };
    });

    // Add retrieved loot to 100-cell stash
    if (result.lootFound.length > 0) {
      setStash(prev => {
        const newStash = [...prev];
        result.lootFound.forEach(item => {
          const emptySlotIndex = newStash.findIndex(cell => cell.item === null);
          if (emptySlotIndex !== -1) {
            newStash[emptySlotIndex].item = item;
          }
        });
        return newStash;
      });
    }
  };

  const handleResetStash = () => {
    setStash(generateInitialStash());
    setProfile(DEFAULT_PROFILE);
  };

  return (
    <div className={`min-h-screen bg-[#0a0a0a] text-[#d1d1d1] flex flex-col items-center tarkov-grid-bg transition-all ${
      isSimulatedMobile ? 'py-4 px-2' : ''
    }`}>
      {/* Simulation Wrapper (allows responsive full width or mobile Telegram container) */}
      <div className={`w-full bg-[#0a0a0a] border-x border-[#1a1a1a] flex flex-col min-h-screen transition-all shadow-2xl ${
        isSimulatedMobile ? 'max-w-[440px] rounded-sm overflow-hidden min-h-[820px] border border-[#2a2a2a]' : 'max-w-7xl'
      }`}>
        {/* Global PMC Header */}
        <Header
          profile={profile}
          onUpdateProfile={setProfile}
          isSimulatedMobile={isSimulatedMobile}
          onToggleMobileView={() => setIsSimulatedMobile(!isSimulatedMobile)}
        />

        {/* Main Content Area */}
        <main className="flex-1 p-3 sm:p-5 overflow-y-auto pb-24">
          {activeTab === 'stash' && (
            <StashTab
              stash={stash}
              onUpdateStash={setStash}
              onSelectItem={(item, cellIndex) => setInspectItem({ item, cellIndex })}
              equippedWeapon={equippedWeapon}
              equippedArmor={equippedArmor}
              equippedHelmet={equippedHelmet}
              equippedHeadset={equippedHeadset}
              equippedRig={equippedRig}
              onEquipItem={handleEquipItem}
              onUnequipItem={handleUnequipItem}
            />
          )}

          {activeTab === 'prapor' && (
            <PraporTab
              profile={profile}
              stash={stash}
              onBuyItem={handleBuyItem}
              onSellItem={handleSellItem}
              onSellAllBarter={handleSellAllBarter}
              onBulkSell={handleBulkSell}
              onSelectItem={(item, cellIndex) => setInspectItem({ item, cellIndex })}
            />
          )}

          {activeTab === 'raids' && (
            <RaidsTab
              profile={profile}
              stash={stash}
              onExecuteRaid={handleExecuteRaid}
              equippedWeapon={equippedWeapon}
              equippedArmor={equippedArmor}
              equippedHeadset={equippedHeadset}
            />
          )}

          {activeTab === 'profile' && (
            <ProfileTab
              profile={profile}
              onUpdateProfile={setProfile}
              equippedWeapon={equippedWeapon}
              equippedArmor={equippedArmor}
              equippedHelmet={equippedHelmet}
              equippedHeadset={equippedHeadset}
              equippedRig={equippedRig}
              onResetStash={handleResetStash}
            />
          )}
        </main>

        {/* Bottom Telegram Mini App Tactical Navigation Bar */}
        <nav className="fixed bottom-0 inset-x-0 z-40 bg-[#0d0d0d]/95 backdrop-blur-md border-t border-[#222222] py-2 px-3 flex items-center justify-around max-w-7xl mx-auto font-mono">
          <button
            onClick={() => handleTabSwitch('stash')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-sm transition-all ${
              activeTab === 'stash'
                ? 'text-[#9a8866] font-bold'
                : 'text-[#555] hover:text-[#888]'
            }`}
          >
            <div className={`p-1 rounded-sm ${activeTab === 'stash' ? 'bg-[#9a8866]/10' : ''}`}>
              <Package className="w-4 h-4" />
            </div>
            <span className="text-[10px] uppercase tracking-wider">СХРОН (100)</span>
          </button>

          <button
            onClick={() => handleTabSwitch('prapor')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-sm transition-all ${
              activeTab === 'prapor'
                ? 'text-[#9a8866] font-bold'
                : 'text-[#555] hover:text-[#888]'
            }`}
          >
            <div className={`p-1 rounded-sm ${activeTab === 'prapor' ? 'bg-[#9a8866]/10' : ''}`}>
              <ShoppingBag className="w-4 h-4" />
            </div>
            <span className="text-[10px] uppercase tracking-wider">ПРАПОР</span>
          </button>

          <button
            onClick={() => handleTabSwitch('raids')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-sm transition-all relative ${
              activeTab === 'raids'
                ? 'text-[#9a8866] font-bold'
                : 'text-[#555] hover:text-[#888]'
            }`}
          >
            <div className={`p-1 rounded-sm ${activeTab === 'raids' ? 'bg-[#9a8866]/10' : ''}`}>
              <Crosshair className="w-4 h-4 text-[#9a8866]" />
            </div>
            <span className="text-[10px] uppercase tracking-wider">РЕЙДЫ</span>
          </button>

          <button
            onClick={() => handleTabSwitch('profile')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-sm transition-all ${
              activeTab === 'profile'
                ? 'text-[#9a8866] font-bold'
                : 'text-[#555] hover:text-[#888]'
            }`}
          >
            <div className={`p-1 rounded-sm ${activeTab === 'profile' ? 'bg-[#9a8866]/10' : ''}`}>
              <User className="w-4 h-4" />
            </div>
            <span className="text-[10px] uppercase tracking-wider">ДОСЬЕ ЧВК</span>
          </button>
        </nav>
      </div>

      {/* Inspect Item Modal */}
      {inspectItem && (
        <ItemModal
          item={inspectItem.item}
          onClose={() => setInspectItem(null)}
          onSell={(item) => handleSellItem(item, inspectItem.cellIndex)}
          onEquip={handleEquipItem}
          onDiscard={handleDiscardItem}
          onUseMed={handleUseMed}
        />
      )}

      {/* Raid Result Extraction Modal */}
      {lastRaidResult && (
        <RaidResultModal
          result={lastRaidResult}
          onClose={() => setLastRaidResult(null)}
        />
      )}
    </div>
  );
}
