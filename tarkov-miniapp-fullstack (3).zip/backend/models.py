from sqlalchemy import Column, Integer, String, Float, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship
from database import Base

class Player(Base):
    __tablename__ = "players"

    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(Integer, unique=True, index=True, nullable=False)
    username = Column(String(64), default="PMC_Operator")
    callsign = Column(String(64), default="Гроза")
    faction = Column(String(16), default="BEAR")
    level = Column(Integer, default=1)
    exp = Column(Integer, default=0)
    next_level_exp = Column(Integer, default=1000)
    rubles = Column(Integer, default=350000)
    dollars = Column(Integer, default=500)
    euros = Column(Integer, default=250)
    
    # Prapor progression
    prapor_rep = Column(Float, default=0.20)
    prapor_spent = Column(Integer, default=120000)
    
    # Combat stats
    raids_count = Column(Integer, default=0)
    survived_count = Column(Integer, default=0)
    kills_count = Column(Integer, default=0)

    # Relationships
    stash_cells = relationship("StashCellModel", back_populates="player", cascade="all, delete-orphan")
    equipped_gear = relationship("EquippedGearModel", back_populates="player", uselist=False, cascade="all, delete-orphan")
    raid_sessions = relationship("RaidSessionModel", back_populates="player", cascade="all, delete-orphan")


class StashCellModel(Base):
    __tablename__ = "stash_cells"

    id = Column(Integer, primary_key=True, index=True)
    player_id = Column(Integer, ForeignKey("players.id"), nullable=False, index=True)
    cell_index = Column(Integer, nullable=False)  # 0 to 99
    item_json = Column(Text, nullable=True)        # JSON representation of TarkovItem

    player = relationship("Player", back_populates="stash_cells")


class EquippedGearModel(Base):
    __tablename__ = "equipped_gear"

    id = Column(Integer, primary_key=True, index=True)
    player_id = Column(Integer, ForeignKey("players.id"), unique=True, nullable=False)
    
    weapon_json = Column(Text, nullable=True)
    armor_json = Column(Text, nullable=True)
    helmet_json = Column(Text, nullable=True)
    headset_json = Column(Text, nullable=True)
    rig_json = Column(Text, nullable=True)
    secure_container_json = Column(Text, nullable=True) # 2x2 secure pouch (Alpha/Gamma)

    player = relationship("Player", back_populates="equipped_gear")


class RaidSessionModel(Base):
    __tablename__ = "raid_sessions"

    id = Column(String(64), primary_key=True, index=True)
    player_id = Column(Integer, ForeignKey("players.id"), nullable=False)
    location_id = Column(String(32), nullable=False)
    tactic_id = Column(String(32), default="stealth")
    
    current_stage = Column(Integer, default=1)  # 1 to 15
    max_stages = Column(Integer, default=15)
    
    health = Column(Integer, default=440)
    max_health = Column(Integer, default=440)
    is_finished = Column(Boolean, default=False)
    is_survived = Column(Boolean, default=False)
    
    kills = Column(Integer, default=0)
    exp_earned = Column(Integer, default=0)
    rubles_found = Column(Integer, default=0)
    damage_taken = Column(Integer, default=0)
    
    # Fallen friend's gear rescue quest status
    friend_gear_found = Column(Boolean, default=False)
    friend_gear_secured = Column(Boolean, default=False)
    
    # Dynamic injuries and buddy status
    injuries_json = Column(Text, default="[]")
    buddy_status = Column(String(32), default="healthy")
    
    # Loot stored in backpack vs Secure Container (Alpha/Gamma Container)
    standard_loot_json = Column(Text, default="[]")
    secure_container_loot_json = Column(Text, default="[]")
    logs_json = Column(Text, default="[]")
    
    created_at = Column(String(32))

    player = relationship("Player", back_populates="raid_sessions")
