import os
import logging
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo

router = Router(name="raid_router")
logger = logging.getLogger(__name__)

# URL of the Tarkov Telegram Mini App WebApp
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://tarkov-mini-app.local")

# Group chat handler: Command("raid", ignore_mention=True)
# Allows triggering /raid in group chats without needing to tag the bot explicitly (@botname)
@router.message(Command("raid", ignore_mention=True))
async def handle_group_raid_command(message: Message):
    """
    Handles /raid command in both private and group chats.
    With ignore_mention=True, members can just type '/raid' directly.
    """
    user_name = message.from_user.first_name or "Оперативник"
    chat_type = message.chat.type

    logger.info(f"User {user_name} ({message.from_user.id}) launched /raid in {chat_type}")

    text = (
        f"🚨 <b>ВНИМАНИЕ, ЧВК {user_name.upper()}! ОБЪЯВЛЕН БОЕВОЙ РЕЙД!</b>\n\n"
        f"📍 <b>Сектор операции:</b> Таможня / Завод / Лес\n"
        f"⏱ <b>Длительность:</b> 15 тактических этапов с точками интереса (POI)\n"
        f"💼 <b>Защищенный подсумок:</b> Автоматическая защита Биткоинов и LEDX\n"
        f"🤝 <b>Командная взаимовыручка:</b> Спасение экипировки павшего напарника\n\n"
        f"<i>Нажмите кнопку ниже, чтобы войти в рейд через Telegram Mini App:</i>"
    )

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="⚔️ Войти в рейд (Escape from Tarkov)",
                    web_app=WebAppInfo(url=WEBAPP_URL)
                )
            ],
            [
                InlineKeyboardButton(
                    text="📦 Мой Схрон (100 ячеек)",
                    web_app=WebAppInfo(url=f"{WEBAPP_URL}?tab=stash")
                ),
                InlineKeyboardButton(
                    text="💰 Барахолка Прапора",
                    web_app=WebAppInfo(url=f"{WEBAPP_URL}?tab=prapor")
                )
            ]
        ]
    )

    await message.reply(text=text, reply_markup=keyboard, parse_mode="HTML")
