import os
import hmac
import hashlib
import json
import urllib.parse
from typing import Optional, Dict, Any
from fastapi import Header, HTTPException, status
from pydantic import BaseModel

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")

class TelegramUser(BaseModel):
    id: int
    first_name: str
    last_name: Optional[str] = ""
    username: Optional[str] = "PMC_Operator"
    language_code: Optional[str] = "ru"

def validate_telegram_init_data(init_data: str, bot_token: str) -> Optional[Dict[str, Any]]:
    """
    Validates Telegram WebApp initData according to Telegram guidelines:
    1. Parse query string
    2. Extract 'hash'
    3. Sort remaining keys alphabetically
    4. Construct data_check_string: 'key=value\n'
    5. secret_key = HMAC_SHA256('WebAppData', bot_token)
    6. computed_hash = HMAC_SHA256(secret_key, data_check_string)
    """
    if not init_data or not bot_token:
        return None
        
    try:
        parsed_data = dict(urllib.parse.parse_qsl(init_data, keep_blank_values=True))
        if "hash" not in parsed_data:
            return None
            
        received_hash = parsed_data.pop("hash")
        
        # Sort keys
        sorted_keys = sorted(parsed_data.keys())
        data_check_string = "\n".join([f"{k}={parsed_data[k]}" for k in sorted_keys])
        
        # Calculate HMAC
        secret_key = hmac.new(b"WebAppData", bot_token.encode("utf-8"), hashlib.sha256).digest()
        calculated_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()
        
        if hmac.compare_digest(calculated_hash, received_hash):
            if "user" in parsed_data:
                parsed_data["user"] = json.loads(parsed_data["user"])
            return parsed_data
    except Exception as e:
        print(f"Error validating initData: {e}")
        return None
        
    return None

def get_current_user(
    x_telegram_init_data: Optional[str] = Header(None, alias="X-Telegram-Init-Data")
) -> TelegramUser:
    """
    FastAPI dependency for authenticating Telegram WebApp requests.
    In development mode or when BOT_TOKEN is empty, falls back to a default PMC operator profile.
    """
    bot_token = os.getenv("BOT_TOKEN", BOT_TOKEN)
    
    # Development bypass if no token or mock header passed
    if not bot_token or ENVIRONMENT == "development" or x_telegram_init_data in [None, "", "mock", "dev"]:
        return TelegramUser(
            id=7770001,
            first_name="BEAR",
            last_name="Operator",
            username="TarkovSurvivor",
            language_code="ru"
        )
        
    data = validate_telegram_init_data(x_telegram_init_data, bot_token)
    if not data or "user" not in data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired Telegram WebApp authentication data"
        )
        
    u = data["user"]
    return TelegramUser(
        id=u.get("id", 0),
        first_name=u.get("first_name", "PMC"),
        last_name=u.get("last_name", ""),
        username=u.get("username", "PMC_Operator"),
        language_code=u.get("language_code", "ru")
    )
