import random
import uuid
from typing import Dict, Any, List, Tuple, Optional
from schemas import TarkovItemSchema, TacticalChoiceSchema, RaidStageStateSchema
from data_seed import ALL_ITEMS_CATALOG
from raid_events_pool import RAID_EVENTS_POOL, get_events_by_location

# Helper lookup functions for POI Loot
def get_items_by_filter(cat_list=None, min_price=0, max_price=9999999, subcat=None):
    res = []
    for it in ALL_ITEMS_CATALOG:
        if cat_list and it.get("category") not in cat_list:
            continue
        if subcat and it.get("subcategory") != subcat:
            continue
        p = it.get("price", 0)
        if min_price <= p <= max_price:
            res.append(it)
    return res if res else ALL_ITEMS_CATALOG


def get_event_for_stage(location_id: str, stage_idx: int) -> Dict[str, Any]:
    """
    Selects a unique story-branching event from the 80+ events pool
    matched to location and stage.
    """
    loc_events = get_events_by_location(location_id)
    if not loc_events:
        loc_events = RAID_EVENTS_POOL
    # Stable yet diverse progression based on stage index
    ev_idx = (stage_idx - 1) % len(loc_events)
    return loc_events[ev_idx]


def generate_stage_state(
    raid_id: str,
    stage_idx: int,
    health: int,
    kills: int,
    exp_earned: int,
    rubles_found: int,
    damage_taken: int,
    friend_gear_found: bool,
    friend_gear_secured: bool,
    standard_loot: List[Dict[str, Any]],
    secure_loot: List[Dict[str, Any]],
    logs: List[str],
    location_id: str = "customs",
    is_finished: bool = False,
    is_survived: bool = False,
    injuries: Optional[List[str]] = None,
    buddy_status: str = "healthy"
) -> RaidStageStateSchema:
    injuries = injuries or []
    event = get_event_for_stage(location_id, stage_idx)

    choices: List[TacticalChoiceSchema] = []

    # If buddy is unconscious, prioritize rescue choices
    if buddy_status == "unconscious" and not is_finished:
        choices.append(TacticalChoiceSchema(
            id="c_buddy_morphine",
            title="🩹 [Морфий]: Экстренная реанимация напарника",
            description="Вколоть шприц Морфия/Пропитала прямо через разгрузку, чтобы вернуть бойца в строй (+120 HP).",
            actionType="rescue_friend",
            riskLevel="Умеренный",
            lootBonus=1.0,
            survivalModifier=30
        ))
        choices.append(TacticalChoiceSchema(
            id="c_buddy_carry",
            title="🏋️‍♂️ [Эвакуация]: Тащить раненого напарника на плечах",
            description="Взвалить товарища на себя. Скорость и скрытность снижены на 50%, но его жизнь и снаряжение спасены.",
            actionType="flank",
            riskLevel="Высокий",
            lootBonus=1.2,
            survivalModifier=10
        ))
        choices.append(TacticalChoiceSchema(
            id="c_early_exfil",
            title="🏃‍♂️ Пойти на выход ради спасения жизни напарника",
            description="Прервать рейд немедленно! Вынести напарника к полевому госпиталю санитаров со всем хабаром.",
            actionType="exfil",
            riskLevel="Безопасно",
            lootBonus=1.5,
            survivalModifier=100
        ))
    else:
        # Standard Branching: [🔫 Штурм] vs [🥷 Обход]
        has_broken_leg = "fracture" in injuries

        choices.append(TacticalChoiceSchema(
            id=f"c_{stage_idx}_assault",
            title=event["assault"]["action"],
            description="Лобовой бой на подавление. Высокий урон врагам, шанс сорвать куш, но риск получить ранение.",
            actionType="combat",
            riskLevel="Высокий" if event["category"] in ["boss", "combat"] else "Умеренный",
            lootBonus=event["assault"]["lootBonus"],
            survivalModifier=0
        ))

        stealth_title = event["stealth"]["action"]
        stealth_desc = "Скрытный обход по укрытиям, засадам и вентиляции. Минимальный риск шума."
        if has_broken_leg:
            stealth_title += " ⚠️ (ШТРАФ: ПЕРЕЛОМ НОГИ)"
            stealth_desc = "Перелом ноги! Шаги отдаются хрустом кости, скрытность снижена, риск обнаружения повышен."

        choices.append(TacticalChoiceSchema(
            id=f"c_{stage_idx}_stealth",
            title=stealth_title,
            description=stealth_desc,
            actionType="flank",
            riskLevel="Умеренный" if has_broken_leg else "Низкий",
            lootBonus=event["stealth"]["lootBonus"],
            survivalModifier=15 if not has_broken_leg else -10
        ))

        # Medical self-treatment option if heavy bleeding or fracture
        if "heavy_bleeding" in injuries:
            choices.append(TacticalChoiceSchema(
                id="c_med_tourniquet",
                title="🩸 [Жгут Эсмарха]: Остановить тяжелое кровотечение",
                description="Наложить жгут на бедро и затянуть закрутку, чтобы остановить потерю 15 HP за шаг.",
                actionType="med",
                riskLevel="Низкий",
                lootBonus=1.0,
                survivalModifier=20
            ))
        elif "fracture" in injuries:
            choices.append(TacticalChoiceSchema(
                id="c_med_splint",
                title="🦴 [Шина]: Зафиксировать перелом ноги",
                description="Наложить иммобилизационную шину, вернув возможность бесшумного перемещения.",
                actionType="med",
                riskLevel="Низкий",
                lootBonus=1.0,
                survivalModifier=20
            ))

        # Special Stage 10: Friend Gear Rescue
        if stage_idx == 10 and not friend_gear_found:
            choices.insert(0, TacticalChoiceSchema(
                id="c10_rescue_gear",
                title="🤝 [Эвакуация]: Спасти карабин M4A1 и жетон напарника @Gurza_PMC",
                description="Забрать именное оружие и золотой жетон товарища для передачи Прапору (+75,000 ₽ / уважение).",
                actionType="rescue_friend",
                riskLevel="Умеренный",
                lootBonus=2.5,
                survivalModifier=5
            ))

        # Always ensure early exit option is present
        if not is_finished and stage_idx < 15:
            choices.append(TacticalChoiceSchema(
                id="c_early_exfil",
                title="🏃‍♂️ Пойти на выход (Досрочная эвакуация)",
                description="Покинуть сектор сейчас через запасной путь, сохранив жизнь и весь найденный хабар.",
                actionType="exfil",
                riskLevel="Безопасно",
                lootBonus=1.0,
                survivalModifier=100
            ))

    return RaidStageStateSchema(
        raidId=raid_id,
        currentStage=stage_idx,
        maxStages=15,
        stageTitle=event["title"],
        situationText=event["situation"],
        poiName=event["poi"],
        hotZoneAlert="ОПАСНАЯ ЗОНА (HOT ZONE)" if event["category"] in ["boss", "hazard"] else None,
        health=health,
        maxHealth=440,
        kills=kills,
        expEarned=exp_earned,
        rublesFound=rubles_found,
        damageTaken=damage_taken,
        friendGearFound=friend_gear_found,
        friendGearSecured=friend_gear_secured,
        availableChoices=choices,
        standardLoot=[TarkovItemSchema(**it) for it in standard_loot],
        secureContainerLoot=[TarkovItemSchema(**it) for it in secure_loot],
        logs=logs,
        isFinished=is_finished,
        isSurvived=is_survived
    )


def roll_poi_loot(stage_idx: int, poi_name: str, choice_id: str) -> List[Dict[str, Any]]:
    """
    Rolls dynamic loot tailored to the current stage and action.
    """
    found = []
    
    # Dorms / High Value (e.g. stage 5, 10, 12)
    if stage_idx in [5, 10, 12]:
        high_pool = get_items_by_filter(min_price=80000)
        item = random.choice(high_pool).copy()
        item["id"] = f"{item['id']}-{uuid.uuid4().hex[:6]}"
        found.append(item)
    elif "combat" in choice_id or "assault" in choice_id:
        combat_pool = get_items_by_filter(cat_list=["weapons", "armor", "ammo"], min_price=25000)
        item = random.choice(combat_pool).copy()
        item["id"] = f"{item['id']}-{uuid.uuid4().hex[:6]}"
        found.append(item)
    else:
        junk_pool = get_items_by_filter(cat_list=["barter", "meds", "ammo", "food"], max_price=60000)
        item = random.choice(junk_pool).copy()
        item["id"] = f"{item['id']}-{uuid.uuid4().hex[:6]}"
        found.append(item)

    return found


def resolve_raid_choice(
    current_stage: int,
    choice_id: str,
    health: int,
    tactic_id: str,
    friend_gear_found: bool,
    friend_gear_secured: bool,
    standard_loot: List[Dict[str, Any]],
    secure_loot: List[Dict[str, Any]],
    has_headset: bool = False,
    armor_class: int = 2,
    armor_durability: float = 50.0,
    weapon_tier: int = 2,
    injuries: Optional[List[str]] = None,
    buddy_status: str = "healthy",
    location_id: str = "customs"
) -> Tuple[int, int, int, int, int, bool, bool, List[Dict[str, Any]], List[Dict[str, Any]], str, List[Dict[str, Any]], List[str], str, float]:
    """
    Resolves action choice at stage with story branching, realistic ballistics,
    armor durability degradation, dynamic injuries, and unconscious buddy recovery.
    """
    injuries = list(injuries or [])
    outcome_text = ""
    damage = 0
    kills_gain = 0
    exp_gain = 120
    rubles_gain = random.randint(10000, 25000)
    newly_found = []
    updated_durability = armor_durability

    event = get_event_for_stage(location_id, current_stage)

    # 1. EARLY EXFILTRATION HANDLER
    if choice_id in ["c_early_exfil", "c15_complete_exfil"] or "early_exfil" in choice_id:
        outcome_text = "🏃‍♂️ ДОСРОЧНАЯ ЭВАКУАЦИЯ: Оперативник запросил эвакуацию через резервный коридор! Весь добытый хабар и спасенный шмот доставлены в схрон."
        return (
            health, 0, 0, 350, 0,
            friend_gear_found, friend_gear_secured,
            standard_loot, secure_loot, outcome_text, [],
            injuries, buddy_status, updated_durability
        )

    # 2. MEDICAL HEALING ACTIONS
    if choice_id == "c_med_tourniquet":
        if "heavy_bleeding" in injuries:
            injuries.remove("heavy_bleeding")
        outcome_text = "🩹 Наложен жгут Эсмарха: артериальное кровотечение успешно остановлено! Потеря крови прекратилась."
        return (
            health, 0, 0, 80, 0,
            friend_gear_found, friend_gear_secured,
            standard_loot, secure_loot, outcome_text, [],
            injuries, buddy_status, updated_durability
        )
    elif choice_id == "c_med_splint":
        if "fracture" in injuries:
            injuries.remove("fracture")
        outcome_text = "🦴 Наложена иммобилизационная шина: кость зафиксирована, возможность скрытного бесшумного шага восстановлена."
        return (
            health, 0, 0, 80, 0,
            friend_gear_found, friend_gear_secured,
            standard_loot, secure_loot, outcome_text, [],
            injuries, buddy_status, updated_durability
        )
    elif choice_id == "c_buddy_morphine":
        buddy_status = "healthy"
        outcome_text = "💉 Введен шприц Морфия: напарник пришел в сознание, поднялся на ноги и прикрывает тыл короткими очередями!"
        return (
            health, 0, 1, 200, 0,
            friend_gear_found, friend_gear_secured,
            standard_loot, secure_loot, outcome_text, [],
            injuries, buddy_status, updated_durability
        )
    elif choice_id == "c_buddy_carry":
        buddy_status = "carried"
        outcome_text = "🏋️‍♂️ Вы взвалили раненого напарника на плечи. Движение замедлено, но бросить своего нельзя!"
        return (
            health, 10, 0, 150, 0,
            friend_gear_found, friend_gear_secured,
            standard_loot, secure_loot, outcome_text, [],
            injuries, buddy_status, updated_durability
        )

    # 3. BLEEDING DEGEN CHECK
    if "heavy_bleeding" in injuries:
        bleed_dmg = 15
        health = max(1, health - bleed_dmg)
        logs_bleed = " [🩸 Тяжелое кровотечение отнимает -15 HP!]"
    else:
        logs_bleed = ""

    # 4. HEADSET BONUS (Unless concussed)
    has_active_headset = has_headset and ("concussion" not in injuries)
    headset_note = " [🎧 Тактические наушники заранее засекли шорохи]" if has_active_headset else ""

    # 5. FRIEND GEAR RESCUE (STAGE 10)
    if current_stage == 10 or choice_id == "c10_rescue_gear":
        friend_gear_found = True
        m4_friend = next((x for x in ALL_ITEMS_CATALOG if x["id"] == "item-m4a1-cqbr"), ALL_ITEMS_CATALOG[0]).copy()
        m4_friend["id"] = f"friend-m4-{uuid.uuid4().hex[:6]}"
        m4_friend["name"] = "Тюнингованный Colt M4A1 (Оружие Гюрзы)"
        m4_friend["shortName"] = "M4A1 Гюрзы"

        dogtag_friend = next((x for x in ALL_ITEMS_CATALOG if x["id"] == "item-dogtag-pmc"), ALL_ITEMS_CATALOG[1]).copy()
        dogtag_friend["id"] = f"friend-dogtag-{uuid.uuid4().hex[:6]}"
        dogtag_friend["name"] = "Золотой жетон ЧВК (Гюрза, ур. 42)"
        dogtag_friend["shortName"] = "Жетон Гюрзы"

        newly_found.extend([m4_friend, dogtag_friend])
        exp_gain += 600
        outcome_text = f"🤝 ОБНАРУЖЕНО СНАРЯЖЕНИЕ ГЮРЗЫ: Вы бережно уложили именной карабин M4A1 и золотой жетон напарника для Прапора!{headset_note}"

    # 6. TACTICAL ASSAULT [🔫 Штурм]
    elif "assault" in choice_id or "combat" in choice_id:
        branch = event["assault"]
        raw_damage = branch["damageBase"]
        kills_gain = branch["kills"]
        exp_gain += branch["exp"]

        # High-tier weapons mow down Scavs
        if weapon_tier >= 4:
            kills_gain += 1
            raw_damage = max(5, int(raw_damage * 0.7))

        # BALLISTICS & ARMOR PROTECTION
        # High class armor (class 5-6) absorbs 70% to 90% of incoming Scav damage while durability > 0
        if updated_durability > 0 and armor_class >= 1:
            protection_factor = min(0.90, 0.20 + (armor_class * 0.12))
            absorbed = int(raw_damage * protection_factor)
            effective_damage = max(5, raw_damage - absorbed)
            # Degrade armor durability
            dur_loss = max(2.0, absorbed * 0.2)
            updated_durability = max(0.0, round(updated_durability - dur_loss, 1))
            armor_note = f" (Броня {armor_class} класса поглотила {absorbed} ед. урона! Прочность: {updated_durability})"
        else:
            effective_damage = raw_damage
            armor_note = " (Броня пробита или отсутствует! Чистый урон по телу)"

        damage = effective_damage
        health = max(0, health - damage)

        # Dynamic injury roll on high damage
        if damage >= 30 and random.random() < 0.50:
            if "heavy_bleeding" not in injuries:
                injuries.append("heavy_bleeding")
                armor_note += " ⚠️ ПОЛУЧЕНО ТЯЖЕЛОЕ КРОВОТЕЧЕНИЕ!"
            elif "fracture" not in injuries:
                injuries.append("fracture")
                armor_note += " ⚠️ ПЕРЕЛОМ НОГИ!"

        outcome_text = f"{branch['outcome']}{armor_note}{logs_bleed}"

        # Roll loot from defeated enemies
        loot_rolled = roll_poi_loot(current_stage, event["poi"], choice_id)
        if loot_rolled:
            newly_found.extend(loot_rolled)
            outcome_text += f" В бою отбит ценный трофей: {loot_rolled[0]['name']} (💰 {loot_rolled[0]['price']:,} ₽)!"

    # 7. TACTICAL STEALTH [🥷 Обход]
    else:
        branch = event["stealth"]
        raw_damage = branch["damageBase"]
        exp_gain += branch["exp"]

        # Fracture penalty for stealth
        if "fracture" in injuries:
            raw_damage += 25
            fracture_note = " ⚠️ Из-за перелома ноги вы оступились с громким стоном, привлекая огонь!"
        else:
            fracture_note = ""

        # Headset stealth bonus
        if has_active_headset:
            raw_damage = max(0, int(raw_damage * 0.65))

        if updated_durability > 0 and raw_damage > 0:
            absorbed = int(raw_damage * (0.2 + armor_class * 0.1))
            damage = max(0, raw_damage - absorbed)
            updated_durability = max(0.0, round(updated_durability - 1.0, 1))
        else:
            damage = raw_damage

        health = max(0, health - damage)
        outcome_text = f"{branch['outcome']}{fracture_note}{headset_note}{logs_bleed}"

        # Safe POI loot check
        if random.random() < 0.65:
            loot_rolled = roll_poi_loot(current_stage, event["poi"], choice_id)
            if loot_rolled:
                newly_found.extend(loot_rolled)
                outcome_text += f" В тайнике обнаружен предмет: {loot_rolled[0]['name']}!"

    # 8. BUDDY CRITICAL CHECK (INSTEAD OF INSTANT DEATH LOOP)
    if health <= 0:
        if buddy_status == "healthy":
            buddy_status = "unconscious"
            health = 1 # Keep PMC barely conscious to make the rescue choice!
            outcome_text += " 🚨 НАПАРНИК ПОЛУЧИЛ ТЯЖЕЛОЕ РАНЕНИЕ И ПОТЕРЯЛ СОЗНАНИЕ! Требуется экстренное решение: применить Морфий, тащить на себе или отступить к эвакуации!"
        else:
            health = 0 # True KIA if already downed twice

    # 9. AUTO-SORT TO SECURE CONTAINER (Alpha 2x2: up to 4 slots)
    for item in newly_found:
        is_elite = (
            item.get("price", 0) >= 90000 or
            item.get("subcategory") == "valuable" or
            item.get("category") == "keys" or
            "Биткоин" in item.get("name", "") or
            "LEDX" in item.get("name", "") or
            "Видеокарта" in item.get("name", "") or
            "Жетон" in item.get("name", "") or
            "Алтын" in item.get("name", "")
        )
        if is_elite and len(secure_loot) < 4:
            secure_loot.append(item)
        else:
            standard_loot.append(item)

    return (
        health, damage, kills_gain, exp_gain, rubles_gain,
        friend_gear_found, friend_gear_secured,
        standard_loot, secure_loot, outcome_text, newly_found,
        injuries, buddy_status, updated_durability
    )
