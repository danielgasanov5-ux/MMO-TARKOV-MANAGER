import os
import json
import uuid
from typing import Optional, List
from fastapi import FastAPI, Depends, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from database import engine, Base, get_db
from models import Player, StashCellModel, EquippedGearModel, RaidSessionModel
from schemas import (
    StashResponse, StashCellSchema, EquippedGearSchema,
    MarketResponse, MarketItemSchema, BuyItemRequest, BuyItemResponse,
    SellItemRequest, SellItemResponse, SellAllResponse,
    RaidStartRequest, RaidActionRequest, RaidStageStateSchema, RaidActionResultSchema,
    PlayerProfileResponse, TarkovItemSchema, ReturnFriendGearRequest, ReturnFriendGearResponse
)
from telegram_auth import get_current_user, TelegramUser
from data_seed import STARTER_EQUIPMENT, STARTER_STASH_ITEMS, PRAPOR_MARKET_CATALOG
from raid_engine import generate_stage_state, resolve_raid_choice

# Initialize database schema tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Tarkov Mini App - Fullstack Backend",
    description="Python FastAPI backend for Escape from Tarkov Telegram Mini App",
    version="1.0.0"
)

# CORS configuration
origins = os.getenv("CORS_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins if origins != ["*"] else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_or_create_player(db: Session, tg_user: TelegramUser) -> Player:
    player = db.query(Player).filter(Player.telegram_id == tg_user.id).first()
    if not player:
        player = Player(
            telegram_id=tg_user.id,
            username=tg_user.username or f"PMC_{tg_user.id}",
            callsign="Гроза",
            faction="BEAR",
            level=1,
            exp=0,
            next_level_exp=1000,
            rubles=350000,
            prapor_rep=0.20,
            prapor_spent=120000
        )
        db.add(player)
        db.commit()
        db.refresh(player)

        # Create 100 stash cells
        stash_map = {item["index"]: item["item"] for item in STARTER_STASH_ITEMS}
        for i in range(100):
            item_data = stash_map.get(i, None)
            cell = StashCellModel(
                player_id=player.id,
                cell_index=i,
                item_json=json.dumps(item_data) if item_data else None
            )
            db.add(cell)

        # Create starter equipment
        equip = EquippedGearModel(
            player_id=player.id,
            weapon_json=json.dumps(STARTER_EQUIPMENT.get("weapon")),
            armor_json=json.dumps(STARTER_EQUIPMENT.get("armor")),
            helmet_json=json.dumps(STARTER_EQUIPMENT.get("helmet")),
            headset_json=json.dumps(STARTER_EQUIPMENT.get("headset")),
            rig_json=json.dumps(STARTER_EQUIPMENT.get("rig")),
            secure_container_json=json.dumps(STARTER_EQUIPMENT.get("secureContainer"))
        )
        db.add(equip)
        db.commit()
        db.refresh(player)

    return player

@app.get("/api/health")
def health_check():
    return {"status": "ok", "service": "tarkov-miniapp-backend", "engine": "FastAPI+SQLite"}

@app.get("/api/profile", response_model=PlayerProfileResponse)
def get_profile(
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    return PlayerProfileResponse(
        id=player.id,
        telegramId=player.telegram_id,
        username=player.username,
        callsign=player.callsign,
        faction=player.faction,
        level=player.level,
        exp=player.exp,
        nextLevelExp=player.next_level_exp,
        rubles=player.rubles,
        dollars=player.dollars,
        euros=player.euros,
        praporRep=player.prapor_rep,
        praporSpent=player.prapor_spent,
        raidsCount=player.raids_count,
        survivedCount=player.survived_count,
        killsCount=player.kills_count
    )

# 1. Stash: 10x10 Grid & Equipped Gear
@app.get("/api/stash", response_model=StashResponse)
def get_stash(
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    cells_db = db.query(StashCellModel).filter(StashCellModel.player_id == player.id).order_by(StashCellModel.cell_index).all()
    
    cell_schemas = []
    total_value = 0
    free_slots = 0
    
    for c in cells_db:
        item_obj = json.loads(c.item_json) if c.item_json else None
        if item_obj:
            total_value += item_obj.get("price", 0)
            cell_schemas.append(StashCellSchema(index=c.cell_index, item=TarkovItemSchema(**item_obj)))
        else:
            free_slots += 1
            cell_schemas.append(StashCellSchema(index=c.cell_index, item=None))

    equip_db = db.query(EquippedGearModel).filter(EquippedGearModel.player_id == player.id).first()
    equipped_schema = EquippedGearSchema(
        weapon=TarkovItemSchema(**json.loads(equip_db.weapon_json)) if equip_db and equip_db.weapon_json else None,
        armor=TarkovItemSchema(**json.loads(equip_db.armor_json)) if equip_db and equip_db.armor_json else None,
        helmet=TarkovItemSchema(**json.loads(equip_db.helmet_json)) if equip_db and equip_db.helmet_json else None,
        headset=TarkovItemSchema(**json.loads(equip_db.headset_json)) if equip_db and equip_db.headset_json else None,
        rig=TarkovItemSchema(**json.loads(equip_db.rig_json)) if equip_db and equip_db.rig_json else None,
        secureContainer=TarkovItemSchema(**json.loads(equip_db.secure_container_json)) if equip_db and equip_db.secure_container_json else None
    )

    return StashResponse(
        cells=cell_schemas,
        equipped=equipped_schema,
        freeSlots=free_slots,
        totalSlots=100,
        stashValue=total_value,
        rubles=player.rubles
    )

# 2. Market with Prapor bundles & Pagination
@app.get("/api/market", response_model=MarketResponse)
def get_market(
    page: int = Query(1, ge=1),
    limit: int = Query(6, ge=1, le=20),
    category: Optional[str] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    
    items = PRAPOR_MARKET_CATALOG
    if category and category != "all":
        items = [x for x in items if x["item"]["category"] == category]
    if search:
        s = search.lower()
        items = [x for x in items if s in x["item"]["name"].lower() or s in x["item"]["shortName"].lower()]
        
    total = len(items)
    total_pages = max(1, (total + limit - 1) // limit)
    start_idx = (page - 1) * limit
    paged = items[start_idx : start_idx + limit]
    
    # Calculate loyalty level: LL1 default, LL2 >= 750k & 0.20 rep, LL3 >= 1.6M & 0.35, LL4 >= 2.8M & 0.60
    current_ll = 1
    if player.prapor_spent >= 2800000 and player.prapor_rep >= 0.60:
        current_ll = 4
    elif player.prapor_spent >= 1600000 and player.prapor_rep >= 0.35:
        current_ll = 3
    elif player.prapor_spent >= 750000 and player.prapor_rep >= 0.20:
        current_ll = 2
        
    return MarketResponse(
        items=[MarketItemSchema(**x) for x in paged],
        page=page,
        limit=limit,
        total=total,
        totalPages=total_pages,
        praporRep=player.prapor_rep,
        praporSpent=player.prapor_spent,
        playerRubles=player.rubles,
        currentLoyaltyLevel=current_ll
    )

@app.post("/api/market/buy", response_model=BuyItemResponse)
def buy_market_item(
    req: BuyItemRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    catalog_item = next((x for x in PRAPOR_MARKET_CATALOG if x["id"] == req.marketItemId), None)
    if not catalog_item:
        raise HTTPException(status_code=404, detail="Товар не найден на Барахолке Прапора")
        
    price = catalog_item["price"] * req.quantity
    if player.rubles < price:
        raise HTTPException(status_code=400, detail="Недостаточно рублей у бойца")
        
    # Find free stash cell
    empty_cell = db.query(StashCellModel).filter(
        StashCellModel.player_id == player.id,
        StashCellModel.item_json == None
    ).order_by(StashCellModel.cell_index).first()
    
    if not empty_cell:
        raise HTTPException(status_code=400, detail="Схрон заполнен (0 свободных ячеек из 100)")
        
    # Deduct rubles and update Prapor stats
    player.rubles -= price
    player.prapor_spent += price
    player.prapor_rep = round(player.prapor_rep + 0.02, 2)
    
    bought_item = catalog_item["item"].copy()
    bought_item["id"] = f"{bought_item['id']}-{uuid.uuid4().hex[:6]}"
    empty_cell.item_json = json.dumps(bought_item)
    
    db.commit()
    db.refresh(player)
    
    return BuyItemResponse(
        success=True,
        message=f"Приобретено: {bought_item['name']} за {price:,} ₽",
        boughtItem=TarkovItemSchema(**bought_item),
        newRubles=player.rubles,
        praporRep=player.prapor_rep,
        praporSpent=player.prapor_spent,
        placedIndex=empty_cell.cell_index
    )

# 3. Sell All: One-button sell of all junk/barter/find-only loot from stash to Prapor (at ~2.3x lower trader price)
@app.post("/api/sell_all", response_model=SellAllResponse)
def sell_all_junk(
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    cells = db.query(StashCellModel).filter(
        StashCellModel.player_id == player.id,
        StashCellModel.item_json != None
    ).all()
    
    total_rubles = 0
    sold_count = 0
    
    for c in cells:
        item = json.loads(c.item_json)
        # Sell barter, keys, electronics and found-in-raid items that are not weapons/equipped
        cat = item.get("category")
        is_valuable_junk = (
            cat in ["barter", "keys", "food"] or 
            item.get("subcategory") == "valuable" or
            (item.get("find_only") and cat not in ["weapons", "armor"]) or
            "Хабар" in item.get("description", "") or
            item.get("id", "").startswith("item-fo-")
        )
        if is_valuable_junk:
            # Prapor buys junk at ~2.3x lower rate (fair trader purchase rate)
            raw_price = item.get("price", 0)
            # Dynamic durability price drop for worn armor
            dur = item.get("durability")
            dur_ratio = 1.0
            if dur and isinstance(dur, dict) and dur.get("max", 0) > 0:
                dur_ratio = max(0.15, dur.get("current", 0) / dur.get("max", 1))
            trader_buy_price = max(500, int((raw_price / 2.3) * dur_ratio))
            total_rubles += trader_buy_price
            sold_count += 1
            c.item_json = None
            
    if sold_count == 0:
        return SellAllResponse(
            success=False,
            itemsSold=0,
            rublesEarned=0,
            newRubles=player.rubles,
            praporRep=player.prapor_rep,
            praporSpent=player.prapor_spent,
            message="В схроне нет бартерного хлама или рейдового хабара для срочной продажи Прапору."
        )
        
    player.rubles += total_rubles
    player.prapor_spent += total_rubles
    player.prapor_rep = round(player.prapor_rep + (0.01 * min(10, sold_count)), 2)
    
    db.commit()
    db.refresh(player)
    
    return SellAllResponse(
        success=True,
        itemsSold=sold_count,
        rublesEarned=total_rubles,
        newRubles=player.rubles,
        praporRep=player.prapor_rep,
        praporSpent=player.prapor_spent,
        message=f"Прапор выкупил {sold_count} предметов со скидкой хлама на сумму {total_rubles:,} ₽!"
    )

# Equip item from stash into character slot (weapon, armor, helmet, headset, rig)
@app.post("/api/stash/equip", response_model=StashResponse)
def equip_item_from_stash(
    req: EquipItemRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    cell = db.query(StashCellModel).filter(
        StashCellModel.player_id == player.id,
        StashCellModel.cell_index == req.cellIndex
    ).first()
    
    if not cell or not cell.item_json:
        raise HTTPException(status_code=400, detail="Ячейка схрона пуста")
        
    item_to_equip = json.loads(cell.item_json)
    equip_db = db.query(EquippedGearModel).filter(EquippedGearModel.player_id == player.id).first()
    if not equip_db:
        raise HTTPException(status_code=500, detail="Модель экипировки не найдена")

    target_slot = req.slotType
    prev_equipped_json = None

    if target_slot == "weapon":
        prev_equipped_json = equip_db.weapon_json
        equip_db.weapon_json = json.dumps(item_to_equip)
    elif target_slot == "armor":
        prev_equipped_json = equip_db.armor_json
        equip_db.armor_json = json.dumps(item_to_equip)
    elif target_slot == "helmet":
        prev_equipped_json = equip_db.helmet_json
        equip_db.helmet_json = json.dumps(item_to_equip)
    elif target_slot == "headset":
        prev_equipped_json = equip_db.headset_json
        equip_db.headset_json = json.dumps(item_to_equip)
    elif target_slot == "rig":
        prev_equipped_json = equip_db.rig_json
        equip_db.rig_json = json.dumps(item_to_equip)
    else:
        raise HTTPException(status_code=400, detail=f"Недопустимый слот экипировки: {target_slot}")

    # Swap: put previously equipped item back in this cell
    cell.item_json = prev_equipped_json
    db.commit()
    db.refresh(player)

    return get_stash(db=db, user=user)

# 4. 15-Stage Raid Engine: Start & Action
@app.post("/api/raid/start", response_model=RaidStageStateSchema)
def start_raid(
    req: RaidStartRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    player.raids_count += 1
    
    raid_id = f"raid-{uuid.uuid4().hex[:8]}"
    initial_log = [
        f"Оперативник {player.callsign} проник на локацию '{req.locationId.upper()}'.",
        "Выбрана тактическая доктрина рейда. Начат этап 1 из 15."
    ]
    
    session = RaidSessionModel(
        id=raid_id,
        player_id=player.id,
        location_id=req.locationId,
        tactic_id=req.tacticId,
        current_stage=1,
        max_stages=15,
        health=440,
        max_health=440,
        kills=0,
        exp_earned=100,
        rubles_found=0,
        damage_taken=0,
        friend_gear_found=False,
        friend_gear_secured=False,
        standard_loot_json="[]",
        secure_container_loot_json="[]",
        logs_json=json.dumps(initial_log)
    )
    db.add(session)
    db.commit()
    
    return generate_stage_state(
        raid_id=raid_id,
        stage_idx=1,
        health=440,
        kills=0,
        exp_earned=100,
        rubles_found=0,
        damage_taken=0,
        friend_gear_found=False,
        friend_gear_secured=False,
        standard_loot=[],
        secure_loot=[],
        logs=initial_log,
        location_id=req.locationId,
        injuries=[],
        buddy_status="healthy"
    )

@app.post("/api/raid/action", response_model=RaidActionResultSchema)
def raid_action(
    req: RaidActionRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    session = db.query(RaidSessionModel).filter(RaidSessionModel.id == req.raidId).first()
    if not session:
        raise HTTPException(status_code=404, detail="Активная сессия рейда не найдена")
    if session.is_finished:
        raise HTTPException(status_code=400, detail="Этот рейд уже завершен")
        
    player = session.player
    standard_loot = json.loads(session.standard_loot_json)
    secure_loot = json.loads(session.secure_container_loot_json)
    logs = json.loads(session.logs_json)
    
    equip_db = db.query(EquippedGearModel).filter(EquippedGearModel.player_id == player.id).first()
    has_headset = equip_db is not None and equip_db.headset_json is not None

    armor_class = 2
    armor_durability = 50.0
    if equip_db and equip_db.armor_json:
        try:
            arm_data = json.loads(equip_db.armor_json)
            armor_class = arm_data.get("armorClass", 2)
            dur = arm_data.get("durability", {})
            armor_durability = float(dur.get("current", 50.0))
        except Exception:
            pass

    weapon_tier = 2
    if equip_db and equip_db.weapon_json:
        try:
            wep_data = json.loads(equip_db.weapon_json)
            if "ВСС" in wep_data.get("name", "") or "M4A1" in wep_data.get("name", "") or "DVL" in wep_data.get("name", ""):
                weapon_tier = 5
            elif "АК-74М" in wep_data.get("name", ""):
                weapon_tier = 4
        except Exception:
            pass

    injuries = json.loads(session.injuries_json or "[]")
    buddy_status = session.buddy_status or "healthy"

    (
        new_health, damage, kills_gain, exp_gain, rubles_gain,
        friend_gear_found, friend_gear_secured,
        standard_loot, secure_loot, outcome_text, newly_found,
        updated_injuries, updated_buddy, updated_dur
    ) = resolve_raid_choice(
        current_stage=session.current_stage,
        choice_id=req.choiceId,
        health=session.health,
        tactic_id=session.tactic_id,
        friend_gear_found=session.friend_gear_found,
        friend_gear_secured=session.friend_gear_secured,
        standard_loot=standard_loot,
        secure_loot=secure_loot,
        has_headset=has_headset,
        armor_class=armor_class,
        armor_durability=armor_durability,
        weapon_tier=weapon_tier,
        injuries=injuries,
        buddy_status=buddy_status,
        location_id=session.location_id
    )

    # Update armor durability in equipped gear if changed
    if equip_db and equip_db.armor_json:
        try:
            arm_data = json.loads(equip_db.armor_json)
            if "durability" in arm_data:
                arm_data["durability"]["current"] = int(updated_dur)
                equip_db.armor_json = json.dumps(arm_data)
        except Exception:
            pass
    
    session.health = new_health
    session.damage_taken += damage
    session.kills += kills_gain
    session.exp_earned += exp_gain
    session.rubles_found += rubles_gain
    session.friend_gear_found = friend_gear_found
    session.friend_gear_secured = friend_gear_secured
    session.injuries_json = json.dumps(updated_injuries)
    session.buddy_status = updated_buddy
    session.standard_loot_json = json.dumps(standard_loot)
    session.secure_container_loot_json = json.dumps(secure_loot)
    
    logs.append(f"[Этап {session.current_stage}/15] {outcome_text}")
    
    status_state = "continue"
    is_survived = False
    
    # Check KIA
    if session.health <= 0:
        session.is_finished = True
        session.is_survived = False
        status_state = "kia"
        logs.append("КРИТИЧЕСКИЙ УРОН: Оперативник погиб в бою (M.I.A).")
        
        # Transfer secure container items to stash!
        for sec_item in secure_loot:
            empty_cell = db.query(StashCellModel).filter(
                StashCellModel.player_id == player.id,
                StashCellModel.item_json == None
            ).first()
            if empty_cell:
                empty_cell.item_json = json.dumps(sec_item)
                
        player.exp += session.exp_earned // 2
        
    # Advance to next stage or finish at Stage 15 or early exfil
    elif session.current_stage >= 15 or req.choiceId in ["c15_complete_exfil", "c_early_exfil"] or "early_exfil" in req.choiceId:
        session.is_finished = True
        session.is_survived = True
        is_survived = True
        status_state = "survived"
        player.survived_count += 1
        
        # Add bonus for friend's gear rescue!
        friend_bonus = 150000 if session.friend_gear_found else 0
        if session.friend_gear_secured:
            friend_bonus += 50000
            
        player.rubles += session.rubles_found + friend_bonus
        player.exp += session.exp_earned + (1000 if session.friend_gear_found else 0)
        player.kills_count += session.kills
        
        # Level up check
        if player.exp >= player.next_level_exp:
            player.level += 1
            player.next_level_exp = int(player.next_level_exp * 1.5)
            
        # Place all retrieved loot (standard + secure) into stash
        all_loot = standard_loot + secure_loot
        for loot_item in all_loot:
            empty_cell = db.query(StashCellModel).filter(
                StashCellModel.player_id == player.id,
                StashCellModel.item_json == None
            ).first()
            if empty_cell:
                empty_cell.item_json = json.dumps(loot_item)
                
        logs.append("УСПЕШНАЯ ЭВАКУАЦИЯ: Весь вынесенный хабар и спасенный шмот напарника доставлены в схрон!")
    else:
        session.current_stage += 1
        
    session.logs_json = json.dumps(logs)
    db.commit()
    db.refresh(session)
    db.refresh(player)
    
    stage_state = generate_stage_state(
        raid_id=session.id,
        stage_idx=session.current_stage,
        health=session.health,
        kills=session.kills,
        exp_earned=session.exp_earned,
        rubles_found=session.rubles_found,
        damage_taken=session.damage_taken,
        friend_gear_found=session.friend_gear_found,
        friend_gear_secured=session.friend_gear_secured,
        standard_loot=standard_loot,
        secure_loot=secure_loot,
        logs=logs,
        location_id=session.location_id,
        is_finished=session.is_finished,
        is_survived=session.is_survived,
        injuries=updated_injuries,
        buddy_status=updated_buddy
    )
    
    return RaidActionResultSchema(
        stage=stage_state,
        outcomeText=outcome_text,
        damageTakenThisTurn=damage,
        newItemsFound=[TarkovItemSchema(**x) for x in newly_found],
        status=status_state
    )

# 5. Return rescued friend gear after raid
@app.post("/api/raid/return_friend_gear", response_model=ReturnFriendGearResponse)
def return_friend_gear(
    req: ReturnFriendGearRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    reward_rubles = 75000
    rep_bonus = 0.05

    player.rubles += reward_rubles
    player.prapor_rep = round(player.prapor_rep + rep_bonus, 2)
    player.prapor_spent += reward_rubles

    db.commit()
    db.refresh(player)

    return ReturnFriendGearResponse(
        success=True,
        rublesReward=reward_rubles,
        praporRepBonus=rep_bonus,
        message=f"Прапор: 'Молодец, боец! Ты спас снаряжение нашего товарища {req.friendUsername}. Вот твоя награда: +75,000 ₽ и уважение (+{rep_bonus} репутации)!'",
        newRubles=player.rubles,
        newPraporRep=player.prapor_rep
    )

# 6. ZIP download endpoint
@app.get("/api/download-zip")
def download_project_zip():
    zip_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "public", "tarkov-miniapp-fullstack.zip")
    if not os.path.exists(zip_path):
        raise HTTPException(status_code=404, detail="ZIP архив еще не собран")
    return FileResponse(
        path=zip_path,
        filename="tarkov-miniapp-fullstack.zip",
        media_type="application/zip"
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", 8000)), reload=True)
