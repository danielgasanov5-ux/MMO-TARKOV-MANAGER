# -*- coding: utf-8 -*-
"""
ESCAPE FROM TARKOV MMO ECONOMIC MANAGER TELEGRAM BOT
Built with pyTelegramBotAPI (telebot).
Complete text-based Telegram Bot with:
- 720 Items Database
- Dynamic Economic Crises (+/-30-50% per category daily)
- Balanced Flea Market (6 Categories, P2P with 10% tax and cancel lot, Prapor 30% buyout, Deficit components)
- 6-Player Cooperative Raids (5 difficulties, Legendary Keycards on Hard+, 2-hour penalty on failure)
- 4 Equipment Slots (Weapon, Body Armor, Helmet, Headset) with Auto-equip and Selective Equip
- 4 Specialized Warehouses (up to 10 tiers with exact upgrade costs on buttons)
- Full Admin Panel and Text Commands for @revenuts with Rank 💀 [ADMIN] 💰 REVENANT GD 💰 💀
"""

import os
import sys
import time
import random
import json
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import telebot
from telebot import types

from tarkov_engine import (
    load_db, save_db, create_new_player, generate_scav_gear,
    PMC_AVATARS, get_pmc_avatar,
    PMC_DEFINITIONS, HIDEOUT_UPGRADE_COSTS, MODULE_NAMES, MODULE_EFFECTS, BUSINESS_NAMES, BUSINESS_CONFIG,
    WAREHOUSE_NAMES, BASE_WAREHOUSE_CAPS, MARKET_CATEGORIES,
    get_warehouse_upgrade_cost, get_module_upgrade_cost, get_business_upgrade_cost, SUPPLY_CHANNEL_COSTS,
    get_current_btc_rate, get_business_hourly_income, get_mining_hourly_btc,
    has_buff, get_warehouse_capacity, get_warehouse_count, can_store_item,
    calculate_squad_power, check_and_update_economic_crisis, get_crisis_price,
    ITEMS_BY_ID, ITEMS_LIST, is_admin,
    get_player_level, add_player_exp, get_fighter_hire_cost, add_player_rubles,
    BASE_GUARD_CONTRACTS, get_guard_status, evaluate_base_security, buy_guard_contract,
    recover_base_assault, recover_base_fence,
    SPECIAL_BUSINESSES, get_special_businesses_income,
    DB_LOCK
)

from loot_generator import (
    roll_supply_item, generate_supply_drop, generate_airdrop_loot, simulate_raid, RAID_LOCATIONS,
    CONTAINER_DEFINITIONS, generate_container_loot, roll_strict_tarkov_loot,
    COOP_DIFFICULTIES, calculate_raid_win_chance,
    BOSS_AMBUSH_DEFINITIONS, roll_boss_ambush, simulate_boss_combat, simulate_boss_retreat
)

from coop_system import (
    handle_menu_coop, handle_coop_difficulty_view, handle_create_coop_lobby,
    handle_join_coop_lobby, handle_leave_coop_lobby, handle_start_coop_lobby,
    render_lobby_ui, get_leader_keycard
)

from clothes_system import (
    CLOTHES_CATEGORIES, CLOTHES_BY_ID, CLOTHES_BY_CATEGORY,
    get_player_clothes_stash, get_player_equipped_clothes,
    get_equipped_item_in_slot, buy_clothing_item,
    equip_clothing_item, unequip_clothing_item, discard_clothing_item,
    is_clothing_item, is_clothing_uid, player_owns_clothing,
    admin_grant_clothing, admin_set_player_title, admin_clear_player_title,
    normalize_clothing_slot
)
from relics_system import (
    BOSS_SETS, ALL_30_RELICS, RELICS_BY_ID,
    get_player_relics, get_player_boss_sets, has_boss_set_bonus, get_active_boss_bonuses_list
)
from mythic_system import (
    MYTHIC_ITEMS, GOONS_GEAR, ZRYACHIY_GEAR, has_mythic_item, get_player_mythics, get_squad_mythic_perks,
    add_mythic_item_to_player,
    can_launch_black_division, execute_black_division_raid,
    can_claim_goons_supply, claim_goons_gear_supply,
    can_launch_goons_raid, execute_goons_raid, COOLDOWN_24H,
    check_zryachiy_daily_supply, get_zryachiy_supply_status, claim_zryachiy_gear_supply,
    can_claim_reserve_armor, claim_reserve_armor_supply,
    can_send_reserve_contraband_truck, send_reserve_contraband_truck, MYTHIC_ARMORS
)
from boss_summon_system import (
    is_boss_summon_triggered, get_random_summoned_boss, render_boss_summon_screen,
    handle_recruit_summoned_boss, handle_fight_summoned_boss, SUMMONED_BOSSES
)
from signature_raid_system import (
    handle_menu_signature_raid, handle_start_signature_raid, can_launch_signature_raid
)
from gd_military_system import (
    has_gd_business, get_gd_bp_state, add_gd_bp_exp, roll_gd_raid_weapon,
    get_bp_stages_summary, get_unclaimed_rewards_count, claim_all_unclaimed_rewards,
    render_bp_main_menu, render_bp_stage_view, render_bp_levels_page, render_bp_weapons_page,
    GD_BATTLEPASS_LEVELS, GD_WEAPONS_CATALOG, STAGES_CONFIG, _apply_level_reward
)
from titles_system import (
    sync_player_titles, get_equipped_title, equip_title, unequip_title,
    render_titles_menu, render_all_titles_catalog, TITLES_REGISTRY,
    get_title_id, resolve_title_from_id
)
from passives_system import (
    get_all_player_passives, render_passives_menu
)
from prestige import (
    render_prestige_menu, render_prestige_confirm, execute_prestige_reset,
    get_player_prestige, get_prestige_badge, PRESTIGE_TIERS, has_player_dsp_sensor,
    render_prestige_mastery_menu, render_prestige_black_raid_menu,
    allocate_prestige_skill, reset_prestige_skills, execute_prestige_black_raid
)
from bot_stats import render_bot_stats
from gd_military_system import BP_WEAPONS_LEVEL_MAP

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
if not BOT_TOKEN:
    print("[WARNING] BOT_TOKEN is not set in environment or Secrets!")
    print("Please set BOT_TOKEN in your environment or Secrets before starting the bot.")

bot = telebot.TeleBot(BOT_TOKEN if BOT_TOKEN else "DUMMY_TOKEN_PLEASE_SET_BOT_TOKEN", parse_mode="HTML")

import html
import re

# Universal safe edit message text wrapper: handles photo messages, deleted messages, HTML errors, and message length limits
_orig_edit_message_text = bot.edit_message_text

def _safe_universal_edit_message_text(text, chat_id=None, message_id=None, inline_message_id=None, parse_mode="HTML", **kwargs):
    if not text:
        return None
    if len(text) > 4000:
        text = text[:3950] + "\n\n[Содержимое сокращено]"
    
    reply_markup = kwargs.get("reply_markup")
    
    if message_id and chat_id:
        try:
            return _orig_edit_message_text(
                text,
                chat_id=chat_id,
                message_id=message_id,
                inline_message_id=inline_message_id,
                parse_mode=parse_mode,
                **kwargs
            )
        except Exception as e:
            err_str = str(e).lower()
            if "message is not modified" in err_str:
                return None
            if "can't parse entities" in err_str or "entity" in err_str or "parse" in err_str:
                clean_txt = re.sub(r"<[^>]+>", "", text)
                try:
                    kw = dict(kwargs)
                    kw.pop("parse_mode", None)
                    return _orig_edit_message_text(
                        clean_txt,
                        chat_id=chat_id,
                        message_id=message_id,
                        inline_message_id=inline_message_id,
                        parse_mode=None,
                        **kw
                    )
                except Exception as e_clean:
                    err_clean = str(e_clean).lower()
                    if "message is not modified" in err_clean:
                        return None
            # Message is either a photo, deleted, or cannot be edited directly:
            # Delete old message and send new text message
            try:
                bot.delete_message(chat_id, message_id)
            except Exception:
                pass
            try:
                return bot.send_message(
                    chat_id,
                    text,
                    reply_markup=reply_markup,
                    parse_mode=parse_mode
                )
            except Exception as e2:
                err2 = str(e2).lower()
                if "can't parse entities" in err2 or "entity" in err2 or "parse" in err2:
                    clean_txt = re.sub(r"<[^>]+>", "", text)
                    try:
                        return bot.send_message(
                            chat_id,
                            clean_txt,
                            reply_markup=reply_markup,
                            parse_mode=None
                        )
                    except Exception:
                        pass
                logging.error("universal_edit fallback send_message error: %s", e2)
                return None
    if chat_id:
        try:
            return bot.send_message(chat_id, text, reply_markup=reply_markup, parse_mode=parse_mode)
        except Exception as e:
            err2 = str(e).lower()
            if "can't parse entities" in err2 or "entity" in err2 or "parse" in err2:
                clean_txt = re.sub(r"<[^>]+>", "", text)
                try:
                    return bot.send_message(chat_id, clean_txt, reply_markup=reply_markup, parse_mode=None)
                except Exception:
                    pass
            logging.error("universal_edit send_message error: %s", e)
            return None
    return None

bot.edit_message_text = _safe_universal_edit_message_text

import html
import re

MKT_CAT_TO_CODE = {
    "Оружие": "w",
    "Экипировка": "e",
    "Шлемы": "h",
    "Наушники": "hp",
    "Медицина": "m",
    "Драгоценности": "v",
    "Компоненты": "c"
}
MKT_CODE_TO_CAT = {v: k for k, v in MKT_CAT_TO_CODE.items()}

def _safe_edit_or_send(txt, chat_id, msg_id, markup):
    if not txt:
        return None
    if len(txt) > 4000:
        txt = txt[:3950] + "\n\n[Содержимое сокращено]"
    if msg_id:
        res = bot.edit_message_text(txt, chat_id=chat_id, message_id=msg_id, reply_markup=markup, parse_mode="HTML")
        if res is not None:
            return res
    try:
        return bot.send_message(chat_id, txt, reply_markup=markup, parse_mode="HTML")
    except Exception as e:
        err_str = str(e).lower()
        if "can't parse entities" in err_str or "entity" in err_str or "parse" in err_str:
            clean_txt = re.sub(r"<[^>]+>", "", txt)
            try:
                return bot.send_message(chat_id, clean_txt, reply_markup=markup, parse_mode=None)
            except Exception:
                pass
        logging.error("safe edit/send error: %s", e)
        return None


DEFAULT_RAIDS_MENU_PHOTO = "https://i.postimg.cc/mDkvL4Vq/tarkov-raids-banner.jpg"

DEFAULT_LOCATION_PHOTOS = {
    "factory": "https://i.postimg.cc/85bY4j0q/factory-tarkov.jpg",
    "customs": "https://i.postimg.cc/y8rK1b8x/customs-tarkov.jpg",
    "woods": "https://i.postimg.cc/XvL4Q8F5/woods-tarkov.jpg",
    "reserve": "https://i.postimg.cc/q7SjJ3fL/reserve-tarkov.jpg",
    "labs": "https://i.postimg.cc/3J8Rk1m7/labs-tarkov.jpg"
}

LOC_NAMES_MAP = {
    "factory": "Завод",
    "customs": "Таможня",
    "woods": "Лес",
    "reserve": "Резерв",
    "labs": "Лаборатория TerraGroup"
}

def get_raids_menu_photo(db=None):
    if db:
        custom = db.get("raids_menu_photo") or db.get("menu_photos", {}).get("raids")
        if custom:
            return custom
    return DEFAULT_RAIDS_MENU_PHOTO

def get_location_photo(loc_key, db=None):
    if db:
        custom = db.get("location_photos", {}).get(loc_key)
        if custom:
            return custom
    return DEFAULT_LOCATION_PHOTOS.get(loc_key, DEFAULT_RAIDS_MENU_PHOTO)

DEFAULT_MENU_PHOTOS = {
    "supply": "https://i.postimg.cc/q7SjJ3fL/reserve-tarkov.jpg",
    "containers": "https://i.postimg.cc/85bY4j0q/factory-tarkov.jpg",
    "stash": "https://i.postimg.cc/Y9SZD0XJ/IMG-20260914-183339-584.jpg",
    "market": "https://i.postimg.cc/y8rK1b8x/customs-tarkov.jpg",
    "ashot": "https://i.postimg.cc/mDkvL4Vq/tarkov-raids-banner.jpg",
    "the_goons": "https://i.postimg.cc/XvL4Q8F5/woods-tarkov.jpg",
    "reserve_vault": "https://i.postimg.cc/q7SjJ3fL/reserve-tarkov.jpg",
    "black_division": "https://i.postimg.cc/3J8Rk1m7/labs-tarkov.jpg",
    "zryachiy": "https://i.postimg.cc/XvL4Q8F5/woods-tarkov.jpg",
    "darkzone": "https://i.postimg.cc/85bY4j0q/factory-tarkov.jpg",
    "base_guard": "https://i.postimg.cc/q7SjJ3fL/reserve-tarkov.jpg",
    "signature_raid": "https://i.postimg.cc/Y9SZD0XJ/IMG-20260914-183339-584.jpg",
}

MENU_NAMES_MAP = {
    "supply": "Контрабанда и снабжение",
    "containers": "Военные кейсы и контейнеры",
    "stash": "Склады и схрон оператора",
    "market": "Барахолка & P2P",
    "ashot": "Магазин одежды «Шота у Ашота»",
    "the_goons": "Штаб банды Отступников (The Goons)",
    "black_division": "Спецоперация Black Division",
    "zryachiy": "Дозор Зрячего (Маяк)",
    "darkzone": "Даркзон (PVP)",
    "base_guard": "Охрана базы ЧВК",
    "signature_raid": "Спецоперация Сигнатурного ЧВК",
}

MENU_ALIASES = {
    "supply": "supply", "контрабанда": "supply", "снабжение": "supply", "поставки": "supply",
    "containers": "containers", "кейсы": "containers", "контейнеры": "containers", "ящики": "containers", "cases": "containers",
    "stash": "stash", "схрон": "stash", "склад": "stash", "инвентарь": "stash",
    "market": "market", "барахолка": "market", "рынок": "market", "торговля": "market", "флимаркет": "market",
    "ashot": "ashot", "ашот": "ashot", "шота": "ashot", "одежда": "ashot", "гардероб": "ashot", "шмот": "ashot",
    "the_goons": "the_goons", "goons": "the_goons", "гуны": "the_goons", "отступники": "the_goons", "гунов": "the_goons",
    "black_division": "black_division", "bd": "black_division", "бд": "black_division", "блэк": "black_division", "блэк дивижн": "black_division",
    "zryachiy": "zryachiy", "зрячий": "zryachiy", "маяк": "zryachiy", "дозор": "zryachiy",
    "darkzone": "darkzone", "даркзон": "darkzone", "тёмная зона": "darkzone", "темная зона": "darkzone",
    "base_guard": "base_guard", "guard": "base_guard", "охрана": "base_guard", "база": "base_guard", "секьюрити": "base_guard",
    "signature_raid": "signature_raid", "signature": "signature_raid", "сигнатурный": "signature_raid", "сигнатурный рейд": "signature_raid", "спецоперация": "signature_raid"
}

def get_menu_photo(menu_key, db=None):
    if db:
        custom = db.get("menu_photos", {}).get(menu_key)
        if custom:
            return custom
    return DEFAULT_MENU_PHOTOS.get(menu_key, DEFAULT_RAIDS_MENU_PHOTO)


def _safe_send_photo(photo, caption, chat_id, msg_id, markup):
    if not photo:
        return _safe_edit_or_send(caption, chat_id, msg_id, markup)

    safe_caption = caption or ""
    overflow_text = None
    if len(safe_caption) > 1020:
        cutoff = safe_caption.rfind("\n", 0, 1000)
        if cutoff == -1:
            cutoff = 980
        overflow_text = safe_caption[cutoff:].strip()
        safe_caption = safe_caption[:cutoff] + "\n..."

    if msg_id:
        try:
            bot.delete_message(chat_id, msg_id)
        except Exception:
            pass

    sent_photo = None
    try:
        if isinstance(photo, str) and os.path.exists(photo):
            with open(photo, "rb") as f:
                sent_photo = bot.send_photo(chat_id, photo=f, caption=safe_caption, reply_markup=markup if not overflow_text else None, parse_mode="HTML")
        else:
            sent_photo = bot.send_photo(chat_id, photo=photo, caption=safe_caption, reply_markup=markup if not overflow_text else None, parse_mode="HTML")
        
        if overflow_text:
            bot.send_message(chat_id, overflow_text, reply_markup=markup, parse_mode="HTML")
        return sent_photo
    except Exception as e:
        err_str = str(e).lower()
        if "can't parse entities" in err_str or "entity" in err_str or "parse" in err_str:
            clean_caption = re.sub(r"<[^>]+>", "", safe_caption)
            try:
                if isinstance(photo, str) and os.path.exists(photo):
                    with open(photo, "rb") as f:
                        sent_photo = bot.send_photo(chat_id, photo=f, caption=clean_caption, reply_markup=markup if not overflow_text else None, parse_mode=None)
                else:
                    sent_photo = bot.send_photo(chat_id, photo=photo, caption=clean_caption, reply_markup=markup if not overflow_text else None, parse_mode=None)
                if overflow_text:
                    clean_overflow = re.sub(r"<[^>]+>", "", overflow_text)
                    bot.send_message(chat_id, clean_overflow, reply_markup=markup, parse_mode=None)
                return sent_photo
            except Exception:
                pass
        logging.warning("_safe_send_photo failed (%s), falling back to text", e)
        return _safe_edit_or_send(caption, chat_id, None, markup)


# Format rubles helper
def fmt_rub(val):
    return f"{int(val):,} ₽".replace(",", " ")

def check_npc_p2p_auto_buyout(player, db):
    """
    Simulates wealthy NPC buyout of 1 active P2P lot for owners of 'fence_protection'
    once every 3 hours (10,800 seconds).
    Pays full price of the lot to player (0% commission) and deletes the item from the market.
    """
    if not player or not db:
        return None
    spec = player.get("special_businesses", {})
    if not spec.get("fence_protection"):
        return None

    now = int(time.time())
    BUYOUT_COOLDOWN = 3 * 3600  # 3 hours (10,800 sec)
    last_b = player.get("last_npc_p2p_buyout", 0)

    # Initialize timestamp upon first check if unset
    if last_b == 0:
        player["last_npc_p2p_buyout"] = now
        return None

    if now - last_b < BUYOUT_COOLDOWN:
        return None

    lots = db.get("p2p_market", [])
    user_id = player.get("user_id")
    player_lots = [l for l in lots if l.get("seller_id") == user_id]
    if not player_lots:
        return None

    chosen_lot = random.choice(player_lots)
    item_info = chosen_lot.get("item", {})
    price = chosen_lot.get("price", 0)

    # Full payment to seller (100% price, 0% commission)
    add_player_rubles(player, price)
    player.setdefault("stats", {})["total_earned_rubles"] = (
        player.get("stats", {}).get("total_earned_rubles", 0) + price
    )

    if chosen_lot in lots:
        lots.remove(chosen_lot)

    player["last_npc_p2p_buyout"] = now
    notif = (
        f"🎩 <b>АВТОВЫКУП СКУПЩИКА (Крышевание Барахолки):</b>\n"
        f"Богатый теневой NPC выкупил ваш лот <b>{item_info.get('name', 'Товар')}</b> с P2P-барахолки!\n"
        f"💰 Полная выплата: <b>+{fmt_rub(price)}</b> зачислена вам на баланс!"
    )
    player.setdefault("notifications", []).append(notif)
    return notif

def get_player(user_id, username=None, telegram_username=None):
    db = load_db()
    uid = str(user_id)
    if uid in db["users"]:
        u = db["users"][uid]
        changed = False
        if username and u.get("username") != username:
            u["username"] = username
            changed = True
        if telegram_username is not None and u.get("telegram_username") != telegram_username:
            u["telegram_username"] = telegram_username
            changed = True
        incidents = evaluate_base_security(u)
        if incidents:
            changed = True
        npc_notif = check_npc_p2p_auto_buyout(u, db)
        if npc_notif:
            changed = True
        if changed:
            save_db(db)
        return u, db
    return None, db

# ----------------- MAIN KEYBOARDS -----------------
def get_main_menu_markup(user):
    markup = types.InlineKeyboardMarkup(row_width=2)
    b_profile = types.InlineKeyboardButton("👤 Профиль ЧВК", callback_data="menu_profile")
    b_squad = types.InlineKeyboardButton("🪖 Мой Отряд", callback_data="menu_squad")
    b_stash = types.InlineKeyboardButton("📦 Склады и Схрон", callback_data="menu_stash")
    b_market = types.InlineKeyboardButton("🏪 Барахолка и P2P", callback_data="menu_market")
    b_hideout = types.InlineKeyboardButton("🏚️ Убежище и Бизнес", callback_data="menu_hideout")
    b_supply = types.InlineKeyboardButton("🚚 Контрабанда", callback_data="menu_supply")
    b_raids = types.InlineKeyboardButton("⚔️ Рейды в Тарков", callback_data="menu_raids")
    b_darkzone = types.InlineKeyboardButton("💀 Даркзон (PvP)", callback_data="menu_darkzone")
    b_income = types.InlineKeyboardButton("🎁 Собрать Доход", callback_data="claim_income")
    b_containers = types.InlineKeyboardButton("🧰 Военные Кейсы", callback_data="menu_containers")
    b_airdrop = types.InlineKeyboardButton("📦 Эирдроп Зоны", callback_data="menu_airdrop")
    b_bp = types.InlineKeyboardButton("🎖️ Боевой Пропуск GD", callback_data="menu_gd_battlepass")
    b_passives = types.InlineKeyboardButton("🔮 Пассивки", callback_data="menu_passives")
    b_titles = types.InlineKeyboardButton("🏷️ Титулы", callback_data="menu_titles_collection")
    b_stats = types.InlineKeyboardButton("📊 Статистика", callback_data="menu_bot_stats")
    b_prestige = types.InlineKeyboardButton("🎖️ Престиж", callback_data="menu_prestige")

    markup.add(b_profile, b_squad)
    markup.add(b_stash, b_market)
    markup.add(b_hideout, b_supply)
    markup.add(b_raids, b_darkzone)
    markup.add(b_income, b_containers)
    markup.add(b_airdrop, b_bp)
    markup.add(b_passives, b_titles)
    markup.add(b_stats, b_prestige)

    if is_admin(user["user_id"], user.get("telegram_username")):
        markup.add(types.InlineKeyboardButton("💀 Admin-панель (@revenuts)", callback_data="menu_admin"))

    return markup

# ----------------- START & PMC SELECTION -----------------
@bot.message_handler(commands=['start', 'help'])
def cmd_start(message):
    user_id = message.from_user.id
    telegram_username = getattr(message.from_user, "username", None)
    display_name = message.from_user.username or message.from_user.first_name or f"PMC_{user_id}"
    player, db = get_player(user_id, display_name, telegram_username)

    if not player or not player.get("pmc_signature"):
        txt = (
            "<b>⚔️ ДОБРО ПОЖАЛОВАТЬ В ТАРКОВ: МЕНЕДЖЕР ЧВК</b>\n\n"
            "Норвинская область охвачена войной. Прежде чем выйти в рейд и развернуть Убежище, "
            "<b>вы обязаны навсегда выбрать своего Сигнатурного ЧВК</b>.\n\n"
            "Каждый ЧВК дает нерушимый пассивный бафф вашей военной корпорации:\n\n"
        )
        for key, p in PMC_DEFINITIONS.items():
            if key == "Revenant":
                continue
            txt += f"{p['icon']} <b>{p['name']}</b>: {p['desc']}\n"

        markup = types.InlineKeyboardMarkup(row_width=2)
        buttons = []
        for key, p in PMC_DEFINITIONS.items():
            if key == "Revenant":
                continue
            buttons.append(types.InlineKeyboardButton(f"{p['icon']} {p['name']}", callback_data=f"select_pmc_{key}"))

        for i in range(0, len(buttons), 2):
            markup.row(*buttons[i:i+2])

        if is_admin(user_id, telegram_username):
            markup.add(types.InlineKeyboardButton("💀 REVENANT [ADMIN EXCLUSIVE]", callback_data="select_pmc_Revenant"))

        bot.send_message(message.chat.id, txt, reply_markup=markup)
        return

    show_main_menu(message.chat.id, player)

def show_main_menu(chat_id, user, message_id=None):
    db = load_db()
    check_and_update_economic_crisis(db)
    try:
        check_zryachiy_daily_supply(user)
    except Exception:
        pass
    save_db(db)

    pow_val, arm_val = calculate_squad_power(user)
    pmc = user.get("pmc_signature", "Viper")
    pmc_display = user.get("custom_pmc_callsign") or pmc
    pmc_icon = PMC_DEFINITIONS.get(pmc, {}).get("icon", "🎖️")

    rank_title = "Рядовой ЧВК"
    if is_admin(user["user_id"], user.get("telegram_username")) or pmc == "Revenant":
        rank_title = "💀 [ADMIN] 💰 REVENANT GD 💰 💀"
    elif user.get("hideout_lvl", 1) >= 8:
        rank_title = "Генерал Норвинского Сектора"
    elif user.get("hideout_lvl", 1) >= 5:
        rank_title = "Командир Синдиката"
    elif user.get("hideout_lvl", 1) >= 3:
        rank_title = "Опытный Наемник"

    crisis = db.get("economic_crisis", {})
    crisis_banner = ""
    if crisis and crisis.get("expires_at", 0) > time.time():
        sign = "+" if crisis.get("direction") == "surge" else "-"
        crisis_banner = f"🚨 <b>КРИЗИС РЫНКА:</b> {crisis.get('category')} ({sign}{crisis.get('shift_pct')}%)\n"

    coop_cooldown_banner = ""
    if user.get("coop_cooldown_until", 0) > time.time():
        rem = int((user["coop_cooldown_until"] - time.time()) // 60)
        coop_cooldown_banner = f"🚑 <b>ТРАВМА ОТРЯДА:</b> Медблок {rem} мин. (Бафф ЧВК отключен!)\n"

    unread_notifs = user.pop("notifications", [])
    notif_banner = ""
    if unread_notifs:
        notif_banner = "\n\n".join(unread_notifs) + "\n────────────────────────\n"
        save_db(db)

    max_squad = 6 if has_boss_set_bonus(user, "glukhar") else 5
    custom_title = user.get("custom_title")
    custom_title_line = f"🏷️ Титул: <b>{custom_title}</b>\n" if custom_title else ""
    txt = (
        f"{notif_banner}"
        f"<b>🏢 ШТАБ-КВАРТИРА ЧВК: {user.get('username', 'Оператор')}</b>\n"
        f"{custom_title_line}"
        f"Статус: <b>{rank_title}</b>\n"
        f"Сигнатурный ЧВК: {pmc_icon} <b>{pmc_display}</b>\n"
        f"────────────────────────\n"
        f"{crisis_banner}{coop_cooldown_banner}"
        f"💰 Баланс: <b>{fmt_rub(user.get('money', 0))}</b> | 🪙 BTC: <b>{user.get('btc', 0):.4f}</b>\n"
        f"🪖 Отряд: <b>{len(user.get('squad', []))}/{max_squad} бойцов</b>\n"
        f"⚔️ Огневая мощь: <b>{pow_val}</b> | 🛡️ Броня: <b>{arm_val}</b>\n"
        f"🏚️ Убежище: <b>Уровень {user.get('hideout_lvl', 1)}/10</b>\n"
        f"────────────────────────\n"
        f"<i>Выберите действие в меню ниже:</i>"
    )

    markup = get_main_menu_markup(user)
    if message_id:
        try:
            bot.edit_message_text(txt, chat_id, message_id, reply_markup=markup)
            return
        except Exception:
            pass
    bot.send_message(chat_id, txt, reply_markup=markup)

# ----------------- CALLBACK QUERY DISPATCHER -----------------
def _handle_callback_query_inner(call):
    user_id = call.from_user.id
    telegram_username = getattr(call.from_user, "username", None)
    display_name = call.from_user.username or call.from_user.first_name or f"PMC_{user_id}"
    username = display_name
    data = call.data
    chat_id = call.message.chat.id
    msg_id = call.message.message_id

    # 1. PMC Selection
    if data.startswith("select_pmc_"):
        pmc_key = data.replace("select_pmc_", "")
        if pmc_key == "Revenant" and not is_admin(user_id, telegram_username):
            bot.answer_callback_query(call.id, "❌ ЧВК Revenant доступен только @revenuts!", show_alert=True)
            return
        db = load_db()
        player = create_new_player(user_id, telegram_username or display_name, pmc_key)
        player["username"] = display_name
        player["telegram_username"] = telegram_username
        db["users"][str(user_id)] = player
        save_db(db)
        p_info = PMC_DEFINITIONS.get(pmc_key, {})
        bot.answer_callback_query(call.id, f"✅ Вы выбрали ЧВК {pmc_key}!")
        bot.send_message(
            chat_id,
            f"🎉 <b>Добро пожаловать на службу, ЧВК {pmc_key}!</b>\n\n"
            f"{p_info.get('icon', '🎖️')} <b>Ваш бонус:</b> {p_info.get('desc')}\n\n"
            f"Вам выдано стартовое снаряжение со стоимостью:\n"
            f"• 💰 <b>500 000 ₽</b> наличными\n"
            f"• 🪖 <b>1 Нанятый боец</b> (Дикий #1)\n"
            f"• 🔫 <b>АК-74М</b> — {fmt_rub(38000)}\n"
            f"• 🔫 <b>ТОЗ-106</b> — {fmt_rub(9500)}\n"
            f"• 🎧 <b>Активные наушники ГСШ-01</b> — {fmt_rub(18000)}\n"
            f"• 🪖 <b>Шлем Колпак-1С</b> — {fmt_rub(12000)}\n"
            f"• 💊 <b>Аптечка АИ-2 (2 шт)</b> — {fmt_rub(24000)}\n"
            f"• 🩹 <b>Бинт и медицинская шина</b> — {fmt_rub(14000)}\n"
            f"• 📦 <b>Патроны 5.45x39 БТ (120 шт)</b> — {fmt_rub(48000)}\n"
            f"• 🏢 <b>4 специализированных склада</b> 1-го уровня"
        )
        show_main_menu(chat_id, player)
        return

    player, db = get_player(user_id, display_name, telegram_username)
    if not player and not ((data.startswith("set_pmc_art_") or data.startswith("set_menu_art_") or data.startswith("set_loc_art_") or data == "set_raid_art_menu" or data == "delete_current_msg") and is_admin(user_id, telegram_username)):
        bot.answer_callback_query(call.id, "⚠️ Начните игру через /start", show_alert=True)
        return

    # Navigation
    if data == "main_menu":
        bot.answer_callback_query(call.id)
        show_main_menu(chat_id, player, msg_id)
        return

    # Profile
    elif data == "menu_profile":
        bot.answer_callback_query(call.id)
        handle_menu_profile(chat_id, msg_id, player)
        return
    elif data == "show_pmc_avatar":
        bot.answer_callback_query(call.id, "🖼️ Загружаю арт в HD качестве...")
        handle_show_pmc_avatar(chat_id, player, db)
        return
    elif data.startswith("set_pmc_art_"):
        target_pmc = data.replace("set_pmc_art_", "")
        telegram_username = getattr(call.from_user, "username", None)
        if not is_admin(call.from_user.id, telegram_username):
            bot.answer_callback_query(call.id, "⛔ Только для администратора!", show_alert=True)
            return
        file_id = PENDING_ADMIN_PHOTOS.get(call.from_user.id)
        if not file_id:
            bot.answer_callback_query(call.id, "❌ Фото не найдено в буфере. Отправьте его заново.", show_alert=True)
            return
        db.setdefault("pmc_custom_avatars", {})[target_pmc] = file_id
        save_db(db)
        bot.answer_callback_query(call.id, f"✅ Аватар для {target_pmc} привязан!", show_alert=True)
        try:
            bot.edit_message_text(
                f"✅ <b>Аватар для класса {target_pmc} успешно привязан!</b>\n\n"
                f"🔑 <b>Telegram file_id:</b>\n<code>{file_id}</code>\n\n"
                f"<i>Все игроки класса {target_pmc} теперь видят это фото в 100% качестве без сжатия хостингами.</i>",
                chat_id,
                msg_id,
                parse_mode="HTML"
            )
        except Exception:
            pass
        return
    elif data == "set_raid_art_menu":
        file_id = PENDING_ADMIN_PHOTOS.get(call.from_user.id)
        if file_id:
            db["raids_menu_photo"] = file_id
            save_db(db)
            bot.answer_callback_query(call.id, "✅ Фото меню рейдов привязано!", show_alert=True)
            try:
                bot.edit_message_text("✅ <b>Фото для меню «Рейды в Тарков» успешно привязано!</b>\n\n<i>Отображается над списком локаций.</i>", chat_id, msg_id, parse_mode="HTML")
            except Exception:
                pass
        return
    elif data.startswith("set_loc_art_"):
        loc_code = data.replace("set_loc_art_", "")
        file_id = PENDING_ADMIN_PHOTOS.get(call.from_user.id)
        if file_id:
            db.setdefault("location_photos", {})[loc_code] = file_id
            save_db(db)
            loc_title = LOC_NAMES_MAP.get(loc_code, loc_code)
            bot.answer_callback_query(call.id, f"✅ Фото для {loc_title} привязано!", show_alert=True)
            try:
                bot.edit_message_text(f"✅ <b>Фото для локации «{loc_title}» успешно привязано!</b>\n\n<i>Отображается над результатами рейда.</i>", chat_id, msg_id, parse_mode="HTML")
            except Exception:
                pass
        return
    elif data.startswith("set_menu_art_"):
        m_key = data.replace("set_menu_art_", "")
        file_id = PENDING_ADMIN_PHOTOS.get(call.from_user.id)
        if file_id:
            db.setdefault("menu_photos", {})[m_key] = file_id
            save_db(db)
            m_name = MENU_NAMES_MAP.get(m_key, m_key)
            bot.answer_callback_query(call.id, f"✅ Фото для {m_name} привязано!", show_alert=True)
            try:
                bot.edit_message_text(f"✅ <b>Фото для меню «{m_name}» успешно привязано!</b>\n\n<i>Отображается в шапке раздела.</i>", chat_id, msg_id, parse_mode="HTML")
            except Exception:
                pass
        return
    elif data == "delete_current_msg":
        try:
            bot.delete_message(chat_id, msg_id)
        except Exception:
            pass
        bot.answer_callback_query(call.id)
        return

    # Squad & Recruitment
    elif data == "menu_squad":
        bot.answer_callback_query(call.id)
        handle_menu_squad(chat_id, msg_id, player)
        return
    elif data == "hire_scav":
        handle_hire_fighter(call, player, db, "scav")
        return
    elif data == "hire_pmc":
        handle_hire_fighter(call, player, db, "pmc")
        return
    elif data == "prapor_bankruptcy_aid":
        handle_prapor_bankruptcy_aid(call, player, db)
        return
    elif data.startswith("disband_fighter_"):
        f_id = int(data.replace("disband_fighter_", ""))
        handle_disband_fighter(call, player, db, f_id)
        return
    elif data == "auto_equip":
        handle_auto_equip(call, player, db)
        return
    elif data == "none":
        bot.answer_callback_query(call.id)
        return
    elif data.startswith("view_fighter_"):
        bot.answer_callback_query(call.id)
        f_id = int(data.replace("view_fighter_", ""))
        handle_view_fighter(chat_id, msg_id, player, f_id)
        return
    elif data.startswith("slot_choose_"):
        bot.answer_callback_query(call.id)
        parts = data.split("_")
        f_id = int(parts[2])
        slot_type = parts[3]
        page = int(parts[4]) if len(parts) > 4 else 1
        handle_slot_choose(chat_id, msg_id, player, f_id, slot_type, page)
        return
    elif data.startswith("slot_equip_"):
        parts = data.split("_", 4)
        f_id = int(parts[2])
        slot_type = parts[3]
        uid = parts[4]
        handle_slot_equip(call, player, db, f_id, slot_type, uid)
        return
    elif data.startswith("slot_unequip_"):
        parts = data.split("_")
        f_id = int(parts[2])
        slot_type = parts[3]
        handle_slot_unequip(call, player, db, f_id, slot_type)
        return
    elif data == "view_relics_collection":
        bot.answer_callback_query(call.id)
        handle_view_relics_collection(chat_id, msg_id, player)
        return
    elif data == "view_mythics_info":
        bot.answer_callback_query(call.id)
        handle_view_mythics_info(chat_id, msg_id, player)
        return
    elif data == "menu_black_division":
        bot.answer_callback_query(call.id)
        handle_menu_black_division(chat_id, msg_id, player, db)
        return
    elif data.startswith("bd_target_"):
        boss_key = data.replace("bd_target_", "")
        handle_bd_target_boss(call, player, db, boss_key)
        return
    elif data == "menu_the_goons":
        bot.answer_callback_query(call.id)
        handle_menu_the_goons(chat_id, msg_id, player, db)
        return
    elif data == "goons_claim_supply":
        handle_goons_claim_supply(call, player, db)
        return
    elif data == "goons_start_raid":
        handle_goons_start_raid(call, player, db)
        return
    elif data == "menu_zryachiy":
        bot.answer_callback_query(call.id)
        handle_menu_zryachiy(chat_id, msg_id, player, db)
        return
    elif data == "zryachiy_claim_supply":
        handle_zryachiy_claim_supply(call, player, db)
        return
    elif data == "menu_reserve_vault":
        bot.answer_callback_query(call.id)
        handle_menu_reserve_vault(chat_id, msg_id, player, db)
        return
    elif data == "claim_reserve_armor":
        handle_claim_reserve_armor(call, player, db)
        return
    elif data == "send_reserve_truck":
        handle_send_reserve_truck(call, player, db)
        return
    elif data == "view_reserve_armors":
        bot.answer_callback_query(call.id)
        handle_view_reserve_armors(chat_id, msg_id, player, db)
        return
    elif data == "container_sell_all":
        handle_container_sell_all(call, player, db)
        return

    # Stash & Warehouses
    elif data == "menu_stash":
        bot.answer_callback_query(call.id)
        handle_menu_stash(chat_id, msg_id, player)
        return
    elif data.startswith("stash_cat_"):
        bot.answer_callback_query(call.id)
        parts = data.split("_")
        cat = parts[2]
        page = int(parts[3]) if len(parts) > 3 else 1
        handle_stash_category(chat_id, msg_id, player, cat, page)
        return
    elif data.startswith("prapor_sell_all_"):
        rarity = data.replace("prapor_sell_all_", "")
        handle_prapor_sell_rarity(call, player, db, None, rarity)
        return
    elif data.startswith("prapor_sell_cat_"):
        rest = data[len("prapor_sell_cat_"):]
        parts = rest.rsplit("_", 1)
        cat = parts[0]
        rarity = parts[1]
        handle_prapor_sell_rarity(call, player, db, cat, rarity)
        return
    elif data.startswith("prapor_sell_"):
        uid = data.replace("prapor_sell_", "")
        handle_prapor_sell(call, player, db, uid)
        return
    elif data.startswith("upgrade_wh_"):
        cat = data.replace("upgrade_wh_", "")
        handle_upgrade_warehouse(call, player, db, cat)
        return

    # Flea Market & P2P
    elif data == "menu_market":
        bot.answer_callback_query(call.id)
        handle_menu_market(chat_id, msg_id, player, db)
        return
    elif data.startswith("market_cat_"):
        bot.answer_callback_query(call.id)
        cat_name = data.replace("market_cat_", "")
        handle_market_catalog(chat_id, msg_id, player, db, cat_name, 1)
        return
    elif data.startswith("market_page_"):
        bot.answer_callback_query(call.id)
        rest = data[len("market_page_"):]
        if "_" in rest:
            cat_name, page_str = rest.rsplit("_", 1)
            page = int(page_str)
        else:
            cat_name = rest
            page = 1
        handle_market_catalog(chat_id, msg_id, player, db, cat_name, page)
        return
    # --- SHOP: "Шота у Ашота", Profile Clothes & Market Buy Fix ---
    elif data in ["ashot_shop_main", "ashot_shop"]:
        bot.answer_callback_query(call.id)
        handle_ashot_shop(chat_id, msg_id, player)
        return
    elif data.startswith("ashot_cat_"):
        bot.answer_callback_query(call.id)
        parts = data.split("_")
        cat_key = parts[2]
        page = int(parts[3]) if len(parts) > 3 else 1
        handle_ashot_category(chat_id, msg_id, player, db, cat_key, page)
        return
    elif data.startswith("ashot_buy:") or data.startswith("ashot_buy_"):
        try:
            if data.startswith("ashot_buy:"):
                parts = data.split(":")
                cat_key = parts[1]
                item_id = parts[2]
                page = int(parts[3])
            else:
                rest = data[len("ashot_buy_"):]
                parts = rest.rsplit("_", 2)
                cat_key = parts[0]
                item_id = parts[1]
                page = int(parts[2])
            handle_ashot_buy_action(call, player, db, cat_key, item_id, page)
        except Exception as e:
            logging.error(f"Error ashot buy callback: {e}")
            bot.answer_callback_query(call.id, "❌ Ошибка при покупке у Ашота!", show_alert=True)
        return
    elif data == "stash_clothes_menu":
        bot.answer_callback_query(call.id)
        handle_stash_clothes_menu(chat_id, msg_id, player)
        return
    elif data.startswith("prof_cloth_"):
        bot.answer_callback_query(call.id)
        parts = data.split("_")
        slot = parts[2]
        page = int(parts[3]) if len(parts) > 3 else 1
        handle_profile_clothes_category(chat_id, msg_id, player, db, slot, page)
        return
    elif data.startswith("cloth_equip:") or data.startswith("cloth_equip_"):
        try:
            if data.startswith("cloth_equip:"):
                parts = data.split(":")
                slot = parts[1]
                uid = parts[2]
                page = int(parts[3])
            else:
                parts = data.split("_", 3)
                slot = parts[2]
                rest = parts[3].rsplit("_", 1)
                uid = rest[0]
                page = int(rest[1])
            handle_cloth_equip(call, player, db, slot, uid, page)
        except Exception as e:
            logging.error(f"Error cloth equip: {e}")
            bot.answer_callback_query(call.id, "❌ Ошибка экипировки!", show_alert=True)
        return
    elif data.startswith("cloth_unequip:") or data.startswith("cloth_unequip_"):
        try:
            if data.startswith("cloth_unequip:"):
                parts = data.split(":")
                slot = parts[1]
                uid = parts[2]
                page = int(parts[3])
            else:
                parts = data.split("_", 3)
                slot = parts[2]
                rest = parts[3].rsplit("_", 1)
                uid = rest[0]
                page = int(rest[1])
            handle_cloth_unequip(call, player, db, slot, uid, page)
        except Exception as e:
            logging.error(f"Error cloth unequip: {e}")
            bot.answer_callback_query(call.id, "❌ Ошибка снятия!", show_alert=True)
        return
    elif data.startswith("cloth_discard:") or data.startswith("cloth_discard_"):
        try:
            if data.startswith("cloth_discard:"):
                parts = data.split(":")
                slot = parts[1]
                uid = parts[2]
                page = int(parts[3])
            else:
                parts = data.split("_", 3)
                slot = parts[2]
                rest = parts[3].rsplit("_", 1)
                uid = rest[0]
                page = int(rest[1])
            handle_cloth_discard(call, player, db, slot, uid, page)
        except Exception as e:
            logging.error(f"Error cloth discard: {e}")
            bot.answer_callback_query(call.id, "❌ Ошибка удаления!", show_alert=True)
        return
    elif data.startswith("market_buy_") or data.startswith("mktbuy:"):
        try:
            if data.startswith("mktbuy:"):
                parts = data.split(":")
                item_id = parts[1]
                raw_cat = parts[2]
                cat_name = MKT_CODE_TO_CAT.get(raw_cat, raw_cat)
                page = int(parts[3])
            else:
                rest = data[len("market_buy_"):]
                parts = rest.rsplit("_", 2)
                item_id = parts[0]
                cat_name = parts[1]
                page = int(parts[2])
            handle_market_buy_action(call, player, db, item_id, cat_name, page)
        except Exception as e:
            logging.error(f"Error handling market buy: {e}")
            bot.answer_callback_query(call.id, "❌ Ошибка при покупке на барахолке!", show_alert=True)
        return
    elif data == "market_sell_btc":
        handle_sell_btc(call, player, db)
        return
    elif data == "market_p2p":
        bot.answer_callback_query(call.id)
        handle_p2p_market(chat_id, msg_id, player, db, page=1)
        return
    elif data.startswith("p2p_market_page_"):
        bot.answer_callback_query(call.id)
        p = int(data.replace("p2p_market_page_", ""))
        handle_p2p_market(chat_id, msg_id, player, db, page=p)
        return
    elif data == "p2p_list_menu":
        bot.answer_callback_query(call.id)
        handle_p2p_list_menu(chat_id, msg_id, player, db, page=1)
        return
    elif data.startswith("p2p_list_page_"):
        bot.answer_callback_query(call.id)
        p = int(data.replace("p2p_list_page_", ""))
        handle_p2p_list_menu(chat_id, msg_id, player, db, page=p)
        return
    elif data.startswith("p2p_list_"):
        uid = data.replace("p2p_list_", "")
        handle_p2p_list_action(call, player, db, uid)
        return
    elif data.startswith("buy_p2p_"):
        lot_id = data.replace("buy_p2p_", "")
        handle_buy_p2p_lot(call, player, db, lot_id)
        return
    elif data.startswith("cancel_p2p_"):
        lot_id = data.replace("cancel_p2p_", "")
        handle_cancel_p2p_lot(call, player, db, lot_id)
        return

    # Hideout & Businesses
    elif data == "menu_hideout":
        bot.answer_callback_query(call.id)
        handle_menu_hideout(chat_id, msg_id, player)
        return
    elif data == "menu_special_businesses":
        bot.answer_callback_query(call.id)
        handle_menu_special_businesses(chat_id, msg_id, player, db)
        return
    elif data == "buy_spec_smugglers_fleet":
        handle_buy_special_business(call, player, db, "smugglers_fleet")
        return
    elif data == "buy_spec_fence_protection":
        handle_buy_special_business(call, player, db, "fence_protection")
        return
    elif data == "buy_spec_gd_shadow_agent":
        handle_buy_special_business(call, player, db, "gd_shadow_agent")
        return
    elif data == "buy_spec_d2_underground_btc_mine":
        handle_buy_special_business(call, player, db, "d2_underground_btc_mine")
        return
    elif data == "menu_gd_battlepass":
        bot.answer_callback_query(call.id)
        handle_menu_gd_battlepass(chat_id, msg_id, player, db)
        return
    elif data.startswith("gd_bp_stages_view_"):
        bot.answer_callback_query(call.id)
        stage_num = int(data.replace("gd_bp_stages_view_", ""))
        handle_gd_bp_stage_view(chat_id, msg_id, player, db, stage_num)
        return
    elif data.startswith("gd_bp_levels_page_"):
        bot.answer_callback_query(call.id)
        page = int(data.replace("gd_bp_levels_page_", ""))
        handle_gd_bp_levels_page(chat_id, msg_id, player, db, page)
        return
    elif data.startswith("gd_bp_weapons_page_"):
        bot.answer_callback_query(call.id)
        page = int(data.replace("gd_bp_weapons_page_", ""))
        handle_gd_bp_weapons_page(chat_id, msg_id, player, db, page)
        return
    elif data == "gd_bp_claim_all":
        handle_gd_bp_claim_all(call, player, db)
        return
    # Passives & Perks Menu
    elif data == "menu_passives" or data == "menu_passives_summary":
        bot.answer_callback_query(call.id)
        handle_menu_passives(chat_id, msg_id, player, db, tab="summary")
        return
    elif data == "menu_passives_mythics":
        bot.answer_callback_query(call.id)
        handle_menu_passives(chat_id, msg_id, player, db, tab="mythics")
        return
    elif data == "menu_passives_biz":
        bot.answer_callback_query(call.id)
        handle_menu_passives(chat_id, msg_id, player, db, tab="businesses")
        return
    elif data.startswith("menu_passives_bp_"):
        bot.answer_callback_query(call.id)
        p_page = int(data.replace("menu_passives_bp_", ""))
        handle_menu_passives(chat_id, msg_id, player, db, tab="bp", page=p_page)
        return
    # Titles Menu & Equipment
    elif data == "menu_titles_collection":
        bot.answer_callback_query(call.id)
        handle_menu_titles(chat_id, msg_id, player, page=1)
        return
    elif data.startswith("menu_titles_all_"):
        bot.answer_callback_query(call.id)
        t_page = int(data.replace("menu_titles_all_", ""))
        handle_menu_all_titles(chat_id, msg_id, player, page=t_page)
        return
    elif data.startswith("menu_titles_"):
        bot.answer_callback_query(call.id)
        t_page = int(data.replace("menu_titles_", ""))
        handle_menu_titles(chat_id, msg_id, player, page=t_page)
        return
    elif data.startswith("title_select_"):
        t_raw = data.replace("title_select_", "")
        t_name = resolve_title_from_id(player, t_raw) or t_raw
        handle_select_title(call, player, db, t_name)
        return
    elif data == "title_unselect":
        handle_unselect_title(call, player, db)
        return
    # Statistics Dashboard
    elif data == "menu_bot_stats":
        bot.answer_callback_query(call.id)
        handle_menu_bot_stats(chat_id, msg_id, player, db)
        return
    # Prestige System Handlers
    elif data == "menu_prestige":
        bot.answer_callback_query(call.id)
        handle_menu_prestige(chat_id, msg_id, player)
        return
    elif data.startswith("prestige_view_"):
        bot.answer_callback_query(call.id)
        try:
            v_tier = int(data.replace("prestige_view_", ""))
        except Exception:
            v_tier = 1
        handle_menu_prestige(chat_id, msg_id, player, view_tier=v_tier)
        return
    elif data.startswith("prestige_confirm_"):
        bot.answer_callback_query(call.id)
        try:
            t_tier = int(data.replace("prestige_confirm_", ""))
        except Exception:
            t_tier = 1
        handle_prestige_confirm(chat_id, msg_id, player, target_tier=t_tier)
        return
    elif data.startswith("prestige_execute_"):
        try:
            t_tier = int(data.replace("prestige_execute_", ""))
        except Exception:
            t_tier = 1
        handle_prestige_execute(call, player, db, target_tier=t_tier)
        return
    elif data == "menu_prestige_mastery":
        bot.answer_callback_query(call.id)
        handle_menu_prestige_mastery(chat_id, msg_id, player)
        return
    elif data.startswith("prestige_alloc_"):
        skill_id = data.replace("prestige_alloc_", "")
        handle_prestige_alloc(call, player, db, skill_id)
        return
    elif data == "prestige_reset_mastery":
        handle_prestige_reset_mastery(call, player, db)
        return
    elif data in ("prestige_max_info", "prestige_max_disabled"):
        bot.answer_callback_query(call.id, "👑 Вы достигли высшего ранга Престиж V (Абсолют)! Вам открыт Черный Рейд Смотрителя и Древо Мастерства.", show_alert=True)
        return
    elif data == "sell_relic_duplicates":
        from relics_system import sell_duplicate_relics
        sold_cnt, earned_rub, sold_items = sell_duplicate_relics(player)
        if sold_cnt > 0:
            save_db(db)
            bot.answer_callback_query(call.id, f"💰 Продано {sold_cnt} дубликатов реликвий на сумму +{fmt_rub(earned_rub)}! Все уникальные реликвии сохранены.", show_alert=True)
        else:
            bot.answer_callback_query(call.id, "ℹ️ В вашем схроне нет дубликатов реликвий!", show_alert=True)
        handle_view_relics_collection(chat_id, msg_id, player)
        return
    elif data == "sell_relic_duplicates_empty":
        bot.answer_callback_query(call.id, "💎 В вашем схроне нет дубликатов. Все имеющиеся реликвии уникальны!", show_alert=True)
        return
    elif data == "menu_pmc_skills" or data.startswith("sig_tree_") or data.startswith("sig_branch_"):
        bot.answer_callback_query(call.id)
        from signature_skills_system import render_signature_skills_menu
        pmc_k = player.get("pmc_signature", "Viper")
        view_b = None
        if data.startswith("sig_branch_"):
            parts = data.split("_")
            if len(parts) >= 4:
                pmc_k = parts[2]
                view_b = "_".join(parts[3:])
        elif data.startswith("sig_tree_"):
            pmc_k = data.replace("sig_tree_", "")
        txt, markup = render_signature_skills_menu(player, pmc_key=pmc_k, view_branch=view_b)
        _safe_edit_or_send(txt, chat_id, msg_id, markup)
        return
    elif data.startswith("sig_alloc_"):
        parts = data.split("_")
        from signature_skills_system import allocate_signature_skill, render_signature_skills_menu
        if len(parts) >= 5:
            pmc_k = parts[2]
            branch_k = parts[3]
            skill_k = "_".join(parts[4:])
            ok, msg = allocate_signature_skill(player, pmc_k, branch_k, skill_k)
            if ok:
                save_db(db)
                bot.answer_callback_query(call.id, f"✅ {msg}", show_alert=False)
            else:
                bot.answer_callback_query(call.id, f"❌ {msg}", show_alert=True)
            txt, markup = render_signature_skills_menu(player, pmc_key=pmc_k, view_branch=branch_k)
            _safe_edit_or_send(txt, chat_id, msg_id, markup)
        return
    elif data.startswith("sig_reset_"):
        pmc_k = data.replace("sig_reset_", "")
        from signature_skills_system import reset_signature_skills, render_signature_skills_menu
        ok, msg = reset_signature_skills(player, pmc_k)
        save_db(db)
        bot.answer_callback_query(call.id, f"🔄 {msg}", show_alert=True)
        txt, markup = render_signature_skills_menu(player, pmc_key=pmc_k)
        _safe_edit_or_send(txt, chat_id, msg_id, markup)
        return
    elif data == "menu_prestige_black_raid":
        bot.answer_callback_query(call.id)
        handle_menu_prestige_black_raid(chat_id, msg_id, player)
        return
    elif data == "prestige_launch_black_raid":
        handle_prestige_launch_black_raid(call, player, db)
        return
    elif data == "upgrade_hideout":
        handle_upgrade_hideout(call, player, db)
        return
    elif data.startswith("upgrade_module_"):
        mod_key = data.replace("upgrade_module_", "")
        handle_upgrade_module(call, player, db, mod_key)
        return
    elif data.startswith("upgrade_biz_"):
        biz_key = data.replace("upgrade_biz_", "")
        handle_upgrade_business(call, player, db, biz_key)
        return
    elif data == "claim_income":
        handle_claim_income(call, player, db)
        return
    elif data == "menu_base_guard":
        bot.answer_callback_query(call.id)
        handle_menu_base_guard(chat_id, msg_id, player, db)
        return
    elif data.startswith("buy_guard_"):
        contract_id = data.replace("buy_guard_", "")
        handle_buy_guard_contract(call, player, db, contract_id)
        return
    elif data == "base_assault":
        handle_base_assault(call, player, db)
        return
    elif data == "base_fence_buyout":
        handle_base_fence_buyout(call, player, db)
        return

    # Supplies
    elif data == "menu_supply":
        bot.answer_callback_query(call.id)
        handle_menu_supply(chat_id, msg_id, player)
        return
    elif data.startswith("order_supply_tier_"):
        tier = int(data.replace("order_supply_tier_", ""))
        handle_order_supply(call, player, db, tier)
        return
    elif data == "upgrade_supply_channel":
        handle_upgrade_supply_channel(call, player, db)
        return
    elif data == "claim_supply":
        handle_claim_supply(call, player, db)
        return

    # Solo Raids & Boss Ambush
    elif data == "menu_raids":
        bot.answer_callback_query(call.id)
        handle_menu_raids(chat_id, msg_id, player)
        return
    elif data.startswith("start_solo_raid_"):
        loc_key = data.replace("start_solo_raid_", "")
        handle_start_solo_raid(call, player, db, loc_key)
        return
    elif data == "boss_ambush_fight":
        handle_boss_ambush_fight(call, player, db)
        return
    elif data == "boss_ambush_retreat":
        handle_boss_ambush_retreat(call, player, db)
        return

    # Cooperative Raids (Up to 6 players)
    elif data in ("menu_coop_raids", "menu_coop"):
        bot.answer_callback_query(call.id)
        handle_menu_coop(chat_id, msg_id, player, db, bot)
        return
    elif data.startswith("coop_view_"):
        diff_key = data.replace("coop_view_", "")
        bot.answer_callback_query(call.id)
        handle_coop_difficulty_view(chat_id, msg_id, player, diff_key, bot)
        return
    elif data.startswith("create_coop_"):
        diff_key = data.replace("create_coop_", "")
        handle_create_coop_lobby(call, player, db, diff_key, bot)
        return
    elif data.startswith("join_coop_"):
        lobby_id = data.replace("join_coop_", "")
        handle_join_coop_lobby(call, player, db, lobby_id, bot)
        return
    elif data.startswith("leave_coop_"):
        lobby_id = data.replace("leave_coop_", "")
        handle_leave_coop_lobby(call, player, db, lobby_id, bot)
        return
    elif data.startswith("start_coop_"):
        lobby_id = data.replace("start_coop_", "")
        handle_start_coop_lobby(call, player, db, lobby_id, bot)
        return
    elif data.startswith("cancel_coop_"):
        lobby_id = data.replace("cancel_coop_", "")
        if lobby_id in db.get("coop_lobbies", {}):
            lobby = db["coop_lobbies"][lobby_id]
            if lobby.get("leader_id") != player["user_id"] and not is_admin(user_id, telegram_username):
                bot.answer_callback_query(call.id, "❌ Только лидер лобби может распустить его!", show_alert=True)
                return
            db["coop_lobbies"].pop(lobby_id, None)
            save_db(db)
            bot.answer_callback_query(call.id, "❌ Лобби распущено.")
            handle_menu_coop(chat_id, msg_id, player, db, bot)
        else:
            bot.answer_callback_query(call.id, "❌ Лобби не найдено.")
        return
    elif data.startswith("refresh_coop_"):
        lobby_id = data.replace("refresh_coop_", "")
        lobby = db.get("coop_lobbies", {}).get(lobby_id)
        if lobby:
            render_lobby_ui(chat_id, msg_id, lobby, player, bot)
            bot.answer_callback_query(call.id, "🔄 Лобби обновлено!")
        else:
            bot.answer_callback_query(call.id, "❌ Лобби закрыто.")
            handle_menu_coop(chat_id, msg_id, player, db, bot)
        return

    # Signature PMC SpecOps Raid (6h cooldown, 3x money/loot, invincible)
    elif data == "menu_signature_raid":
        bot.answer_callback_query(call.id)
        handle_menu_signature_raid(chat_id, msg_id, player, bot)
        return
    elif data == "start_signature_raid":
        handle_start_signature_raid(call, player, db, bot)
        return

    # Boss Summon Handlers (1% chance on scav hire)
    elif data.startswith("recruit_summoned_boss_"):
        b_key = data.replace("recruit_summoned_boss_", "")
        handle_recruit_summoned_boss(call, player, db, b_key, bot)
        return
    elif data.startswith("fight_summoned_boss_"):
        b_key = data.replace("fight_summoned_boss_", "")
        handle_fight_summoned_boss(call, player, db, b_key, bot)
        return
    elif data == "dismiss_summoned_boss":
        player.pop("pending_boss_summon", None)
        save_db(db)
        bot.answer_callback_query(call.id, "Вы мирно разошлись.")
        handle_menu_squad(chat_id, msg_id, player)
        return

    # Darkzone PvP
    elif data == "menu_darkzone":
        bot.answer_callback_query(call.id)
        handle_menu_darkzone(chat_id, msg_id, player, db)
        return
    elif data == "darkzone_search_bot":
        handle_darkzone_bot_duel(call, player, db)
        return
    elif data == "darkzone_create_pvp":
        handle_darkzone_create_pvp(call, player, db)
        return
    elif data.startswith("accept_pvp_"):
        duel_id = data.replace("accept_pvp_", "")
        handle_darkzone_accept_pvp(call, player, db, duel_id)
        return
    elif data.startswith("cancel_pvp_"):
        duel_id = data.replace("cancel_pvp_", "")
        handle_darkzone_cancel_pvp(call, player, db, duel_id)
        return

    # Containers
    elif data == "menu_containers":
        bot.answer_callback_query(call.id)
        handle_menu_containers(chat_id, msg_id, player)
        return
    elif data.startswith("open_container_"):
        cid = data.replace("open_container_", "")
        handle_open_container(call, player, db, cid)
        return

    # Airdrop
    elif data == "menu_airdrop":
        bot.answer_callback_query(call.id)
        handle_menu_airdrop(chat_id, msg_id, player, db)
        return
    elif data == "loot_airdrop_box":
        handle_loot_airdrop_box(call, player, db)
        return

    # Admin Panel
    elif data == "menu_admin":
        if not is_admin(user_id, telegram_username):
            bot.answer_callback_query(call.id, "❌ Доступ разрешен только @revenuts!", show_alert=True)
            return
        bot.answer_callback_query(call.id)
        handle_menu_admin(chat_id, msg_id, player)
        return
    elif data.startswith("admin_action_"):
        if not is_admin(user_id, telegram_username):
            bot.answer_callback_query(call.id, "❌ Доступ разрешен только @revenuts!", show_alert=True)
            return
        act = data.replace("admin_action_", "")
        handle_admin_action(call, player, db, act)
        return

    else:
                # Fallback for any unknown or obsolete button to prevent infinite UI spinning
        bot.answer_callback_query(call.id)
        return

@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    try:
        _handle_callback_query_inner(call)
    except Exception as e:
        logging.exception("Unhandled error in callback_handler for data '%s': %s", getattr(call, "data", ""), e)
        try:
            bot.answer_callback_query(call.id, "⚠️ Ошибка обработки запроса. Попробуйте снова.", show_alert=True)
        except Exception:
            pass

# ----------------- SECTION 1: PROFILE -----------------
def handle_menu_profile(chat_id, msg_id, player):
    pmc = player.get("pmc_signature", "Viper")
    pmc_display = player.get("custom_pmc_callsign") or pmc
    p_info = PMC_DEFINITIONS.get(pmc, {})
    pow_val, arm_val = calculate_squad_power(player)
    st = player.get("stats", {})

    # Signature PMC Avatar URL
    pmc_photo_url = PMC_AVATARS.get(pmc, PMC_AVATARS.get("Viper", "https://i.postimg.cc/Y9SZD0XJ/IMG-20260914-183339-584.jpg"))

    rank_title = "Рядовой ЧВК"
    if is_admin(player["user_id"], player.get("telegram_username")) or pmc == "Revenant":
        rank_title = "💀 [ADMIN] 💰 REVENANT GD 💰 💀"
    elif player.get("hideout_lvl", 1) >= 8:
        rank_title = "Генерал Норвинского Сектора"
    elif player.get("hideout_lvl", 1) >= 5:
        rank_title = "Командир Синдиката"
    elif player.get("hideout_lvl", 1) >= 3:
        rank_title = "Опытный Наемник"

    coop_injury_txt = ""
    if player.get("coop_cooldown_until", 0) > time.time():
        rem = int((player["coop_cooldown_until"] - time.time()) // 60)
        coop_injury_txt = f"\n⚠️ <b>ТРАВМА ОТРЯДА:</b> Медблок {rem} мин. (Пассивный бафф отключен!)"

    owned_relics = get_player_relics(player)
    active_bonuses = get_active_boss_bonuses_list(player)
    boss_sets_status = get_player_boss_sets(player)

    relics_txt = f"🏆 Реликвий Боссов: <b>{len(owned_relics)}/30</b>\n"
    if active_bonuses:
        relics_txt += "🔥 <b>Активные бонусы сетов:</b>\n"
        for b_desc in active_bonuses:
            relics_txt += f"  • {b_desc}\n"
    else:
        relics_txt += "<i>(Соберите 5/5 реликвий любого босса для активации бонуса сета)</i>\n"
    owned_mythics = get_player_mythics(player)
    if owned_mythics:
        mythics_txt = f"✨ <b>Мифические артефакты (150М):</b> <b>{len(owned_mythics)}/4</b>\n"
        for m in owned_mythics:
            mythics_txt += f"  • {m['badge']} <b>{m['name']}</b>\n"
    else:
        mythics_txt = "✨ <b>Мифические артефакты (150М):</b> <b>0/4</b> <i>(Смотрите «✨ Мифические Предметы»)</i>\n"

    # Equipped clothes status
    shoes_info, _ = get_equipped_item_in_slot(player, "shoes")
    head_info, _ = get_equipped_item_in_slot(player, "headwear")
    suit_info, _ = get_equipped_item_in_slot(player, "suit")
    acc_info, _ = get_equipped_item_in_slot(player, "accessory")

    clothes_txt = (
        f"👔 <b>ЭКИПИРОВКА ОДЕЖДЫ (ГАРДЕРОБ):</b>\n"
        f"• 🥾 Обувь: <b>{shoes_info['name'] if shoes_info else '— Не надето —'}</b>\n"
        f"• 🧢 Головной убор: <b>{head_info['name'] if head_info else '— Не надето —'}</b>\n"
        f"• 🥋 Костюм: <b>{suit_info['name'] if suit_info else '— Не надето —'}</b>\n"
        f"• ⌚ Аксессуар: <b>{acc_info['name'] if acc_info else '— Не надето —'}</b>\n"
    )

    p_lvl = get_player_level(player)
    total_earned = st.get("total_earned_rubles", 0)

    sync_player_titles(player)
    prof_custom_title = player.get("custom_title")
    prof_title_line = f"🏷️ Особый титул: <b>{prof_custom_title}</b>\n" if prof_custom_title else "🏷️ Титул: <i>[Стандартный ранг]</i>\n"
    p_prest = get_player_prestige(player)
    prest_line = f"🎖️ Престиж: <b>{get_prestige_badge(player)}</b>\n" if p_prest > 0 else ""
    bp_state = player.get("gd_battlepass", {})
    bp_line = f"🎖️ Боевой Пропуск GD: <b>Уровень {bp_state.get('level', 1)} / 150</b>\n" if player.get("special_businesses", {}).get("gd_shadow_agent") else ""
    txt = (
        f"<b>👤 ПРОФИЛЬ ОПЕРАТОРА ЧВК</b>\n"
        f"────────────────────────\n"
        f"Позывной: <b>@{player.get('username', 'PMC')}</b> (ID: <code>{player['user_id']}</code>)\n"
        f"{prof_title_line}"
        f"{prest_line}"
        f"{bp_line}"
        f"Ранг: <b>{rank_title}</b> (Уровень {p_lvl})\n"
        f"Класс ЧВК: {p_info.get('icon', '🎖️')} <b>{pmc_display}</b>\n"
        f"Бафф: <i>{p_info.get('desc')}</i>{coop_injury_txt}\n"
        f"────────────────────────\n"
        f"💰 Рубли: <b>{fmt_rub(player.get('money', 0))}</b>\n"
        f"🪙 Биткоины: <b>{player.get('btc', 0):.4f} BTC</b>\n"
        f"🏚️ Уровень Убежища: <b>{player.get('hideout_lvl', 1)}/10</b>\n"
        f"🚚 Канал снабжения: <b>{player.get('supply_channel_lvl', 1)}/10</b>\n"
        f"⚔️ Суммарная мощь: <b>{pow_val}</b> | 🛡️ Броня: <b>{arm_val}</b>\n"
        f"────────────────────────\n"
        f"{clothes_txt}"
        f"────────────────────────\n"
        f"{relics_txt}"
        f"────────────────────────\n"
        f"{mythics_txt}"
        f"────────────────────────\n"
        f"📊 <b>Боевая & финансовая статистика:</b>\n"
        f"• Всего заработано: <b>{fmt_rub(total_earned)}</b>\n"
        f"• Рейдов завершено: {st.get('raids_count', 0)}\n"
        f"• Кооп-рейдов: {st.get('coop_raids_count', 0)} (Побед: {st.get('coop_wins', 0)} | Разгромов: {st.get('coop_losses', 0)})\n"
        f"• PvP побед / поражений: {st.get('pvp_wins', 0)} / {st.get('pvp_losses', 0)}\n"
        f"• Захвачено эирдропов: {st.get('airdrop_looted', 0)}"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.row(
        types.InlineKeyboardButton("🖼️ Показать арт бойца (HD)", callback_data="show_pmc_avatar")
    )
    markup.row(
        types.InlineKeyboardButton("🥾 Обувь", callback_data="prof_cloth_shoes_1"),
        types.InlineKeyboardButton("🧢 Головной убор", callback_data="prof_cloth_headwear_1")
    )
    markup.row(
        types.InlineKeyboardButton("🥋 Костюм", callback_data="prof_cloth_suit_1"),
        types.InlineKeyboardButton("⌚ Аксессуар", callback_data="prof_cloth_accessory_1")
    )
    markup.row(
        types.InlineKeyboardButton("🏷️ Титулы и Звания", callback_data="menu_titles_collection"),
        types.InlineKeyboardButton("🔮 Все Пассивки ЧВК", callback_data="menu_passives")
    )
    markup.add(
        types.InlineKeyboardButton("🎖️ Боевой Пропуск GD", callback_data="menu_gd_battlepass"),
        types.InlineKeyboardButton("🎖️ Престиж ЧВК", callback_data="menu_prestige")
    )
    markup.add(
        types.InlineKeyboardButton("✨ Мифические Предметы (4 шт.)", callback_data="view_mythics_info"),
        types.InlineKeyboardButton("📊 Полная Статистика", callback_data="menu_bot_stats")
    )
    if p_lvl >= 10:
        markup.add(types.InlineKeyboardButton("⭐ Спецоперация Сигнатурного ЧВК (3x Лут)", callback_data="menu_signature_raid"))
    if has_mythic_item(player, "mythic_black_division_case"):
        markup.add(types.InlineKeyboardButton("💼 Спецоперация Black Division", callback_data="menu_black_division"))
    if has_mythic_item(player, "mythic_goons_token"):
        markup.add(types.InlineKeyboardButton("🎖️ Штаб Отступников (The Goons)", callback_data="menu_the_goons"))
    if has_mythic_item(player, "mythic_dsp_sensor"):
        markup.add(types.InlineKeyboardButton("👁️ Дозор Зрячего (Маяк)", callback_data="menu_zryachiy"))
    if has_mythic_item(player, "mythic_state_reserve_key"):
        markup.add(types.InlineKeyboardButton("🗝️ Спецхран Росрезерва (50 Броней & Грузовик)", callback_data="menu_reserve_vault"))
    if get_player_prestige(player) >= 5:
        markup.add(types.InlineKeyboardButton("👑 Черный Рейд Смотрителя (Престиж V)", callback_data="menu_prestige_black_raid"))
    try:
        from signature_skills_system import get_signature_pmc_progress
        p_prog = get_signature_pmc_progress(player, pmc)
        p_pts = p_prog.get("points", 0)
        markup.add(types.InlineKeyboardButton(f"⭐ Древо прокачки ЧВК {pmc} ({p_pts} очков)", callback_data=f"sig_tree_{pmc}"))
    except Exception:
        pass
    markup.add(
        types.InlineKeyboardButton("🏆 Коллекция Реликвий (30 шт)", callback_data="view_relics_collection"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )

    if msg_id:
        try:
            bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup, parse_mode="HTML")
            return
        except Exception:
            pass

    bot.send_message(chat_id, txt, reply_markup=markup, parse_mode="HTML")


def handle_show_pmc_avatar(chat_id, player, db=None):
    pmc = player.get("pmc_signature", "Viper")
    pmc_display = player.get("custom_pmc_callsign") or pmc
    p_info = PMC_DEFINITIONS.get(pmc, {})
    pmc_photo = player.get("custom_pmc_avatar") or get_pmc_avatar(pmc, db)
    caption = (
        "🖼️ <b>Фирменный арт оператора: " + str(pmc_display) + "</b> " + str(p_info.get("icon", "🎖️")) + "\n" +
        "<i>" + str(p_info.get("desc", "")) + "</i>"
    )
    close_markup = types.InlineKeyboardMarkup(row_width=1)
    close_markup.add(types.InlineKeyboardButton("🗑️ Закрыть фото", callback_data="delete_current_msg"))
    try:
        if isinstance(pmc_photo, str) and os.path.exists(pmc_photo):
            with open(pmc_photo, "rb") as f:
                bot.send_photo(chat_id, photo=f, caption=caption, parse_mode="HTML", reply_markup=close_markup)
        else:
            bot.send_photo(chat_id, photo=pmc_photo, caption=caption, parse_mode="HTML", reply_markup=close_markup)
    except Exception as e:
        logging.error(f"Error sending PMC avatar photo: {e}")
        bot.send_message(chat_id, f"❌ Не удалось отправить арт: {pmc_photo}")


def handle_view_relics_collection(chat_id, msg_id, player):
    owned_relics = get_player_relics(player)
    sets_status = get_player_boss_sets(player)
    from relics_system import get_player_duplicate_relics
    dupes = get_player_duplicate_relics(player)
    dupe_cnt = len(dupes)
    dupe_sum = dupe_cnt * 10000000

    lines = [
        "<b>🏆 КОЛЛЕКЦИЯ РЕЛИКВИЙ И СЕТОВ БОССОВ</b>",
        f"Собрано уникальных: <b>{len(owned_relics)}/30</b>",
        "────────────────────────",
        "Каждая реликвия оценивается в <b>10 000 000 ₽</b>.",
        "Полный сет из 5 реликвий одного Босса стоит <b>50 000 000 ₽</b> и дает мощный пассивный эффект!",
        ""
    ]
    if dupe_cnt > 0:
        lines.extend([
            f"📦 <b>Обнаружено дубликатов в схроне:</b> <b>{dupe_cnt} шт.</b> на сумму <b>+{fmt_rub(dupe_sum)}</b>.",
            "<i>Вы можете продать их в один клик без потери уникальных коллекционных реликвий!</i>",
            ""
        ])

    for b_key, b_info in sets_status.items():
        boss_data = BOSS_SETS[b_key]
        status_badge = "🔥 <b>[АКТИВЕН 5/5]</b>" if b_info["is_active"] else f"[{b_info['owned_count']}/5]"
        lines.append(f"{b_info['icon']} <b>{boss_data['boss_name']}</b> — {status_badge}")
        lines.append(f"✨ <i>Бонус (5/5): {boss_data['desc']}</i>")
        for r in boss_data["relics"]:
            is_owned = r["id"] in owned_relics
            check_icon = "✅" if is_owned else "❌"
            lines.append(f"  {check_icon} {r['name']} (10 000 000 ₽)")
        lines.append("")

    markup = types.InlineKeyboardMarkup(row_width=1)
    if dupe_cnt > 0:
        markup.add(types.InlineKeyboardButton(f"💰 Продать дубликаты ({dupe_cnt} шт. за +{fmt_rub(dupe_sum)})", callback_data="sell_relic_duplicates"))
    else:
        markup.add(types.InlineKeyboardButton("💎 Продать дубликаты (0 шт. — схрон чист)", callback_data="sell_relic_duplicates_empty"))

    markup.add(
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    txt = chr(10).join(lines)
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_view_mythics_info(chat_id, msg_id, player):
    owned_mythics = get_player_mythics(player)
    owned_ids = {m["id"] for m in owned_mythics}

    lines = [
        "<b>✨ МИФИЧЕСКИЕ ПРЕДМЕТЫ ТАРКОВА (150 000 000 ₽)</b>",
        "В игре существует <b>4 уникальных мифических артефакта</b>, открывающих глобальные механики:",
        "────────────────────────"
    ]

    for m_id, m_data in MYTHIC_ITEMS.items():
        is_owned = m_id in owned_ids
        st_badge = "🔥 <b>[АКТИВИРОВАН В СХРОНЕ]</b>" if is_owned else "🔒 <b>[НЕ НАЙДЕН]</b>"
        lines.append(f"{m_data['badge']} <b>{m_data['name']}</b> — {st_badge}")
        lines.append(f"💰 Стоимость: <b>150 000 000 ₽</b> | Редкость: <b>Мифический</b>")
        lines.append(f"📜 <i>{m_data['desc']}</i>\n")

    lines.extend([
        "────────────────────────",
        "📍 <b>Где выбить эти 4 предмета?</b>",
        "• 💼 <b>Дипломатический кейс Black Division:</b> выпадает со сверхредким шансом (до 3.0%) при триумфе в <b>Кооперативных рейдах на Боссов</b> (сложность Colossal)!",
        "• 🎖️ <b>Жетон Отступников (The Goons):</b> выпадает со сверхточным шансом <b>0.01% (1 из 10 000)</b> из Военного Кейса TerraGroup за 2 500 000 ₽!",
        "• 📟 <b>Закодированный датчик DSP Смотрителя:</b> выпадает со сверхредким шансом <b>0.1% (1 из 1 000)</b> из Теневого Каравана высшего тира (Контрабанда Тир 4)!",
        "• 🗝️ <b>Ключ от Спецхрана Росрезерва:</b> выпадает со шансом <b>0.1% (1 из 1 000)</b> в <b>Сигнатурных Спецоперациях ЧВК (30-50M)</b> и Кооп-рейдах на Боссов!",
        "────────────────────────",
        "🛡️ <b>Арсенал Росрезерва (через Ключ каждые 24ч):</b>",
        "• <b>50 уникальных мифических бронекомплектов</b> (Броня: <b>+150...+195</b>, Урон: <b>+15...+40</b>, Прочность: до 180)!",
        "• <b>Личный бронегрузовик контрабанды</b> раз в 3 часа: вывоз до 10 предметов со 100% рыночной выплатой!",
        "────────────────────────",
        "👁️ <b>Именная экипировка Зрячего (через Датчик DSP каждые 24ч):</b>",
        "1. 🎯 <b>AXMC «Глаз Зрячего» .338 Lapua</b> — Урон <b>+72</b>",
        "2. 🛡️ <b>Плитник Сектантов «Страж Маяка»</b> — Броня <b>+52</b>, Урон +8",
        "3. 👁️ <b>Капюшон и балаклава «Ослепленный Жнец»</b> — Броня <b>+22</b>, Урон +16"
    ])

    txt = "\n".join(lines)
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton("🛡️ Каталог 50 Мифических Бронекомплектов", callback_data="view_reserve_armors"))
    if "mythic_state_reserve_key" in owned_ids:
        markup.add(types.InlineKeyboardButton("🗝️ Спецхран Росрезерва (Бункер)", callback_data="menu_reserve_vault"))
    else:
        markup.add(types.InlineKeyboardButton("🗝️ О Ключе Росрезерва (🔒)", callback_data="menu_reserve_vault"))

    if "mythic_black_division_case" in owned_ids:
        markup.add(types.InlineKeyboardButton("💼 Спецоперация Black Division", callback_data="menu_black_division"))
    else:
        markup.add(types.InlineKeyboardButton("💼 О кейсе Black Division (🔒)", callback_data="menu_black_division"))

    if "mythic_goons_token" in owned_ids:
        markup.add(types.InlineKeyboardButton("🎖️ Штаб Отступников (The Goons)", callback_data="menu_the_goons"))
    else:
        markup.add(types.InlineKeyboardButton("🎖️ О жетоне The Goons (🔒)", callback_data="menu_the_goons"))

    if "mythic_dsp_sensor" in owned_ids:
        markup.add(types.InlineKeyboardButton("👁️ Дозор Зрячего (Маяк)", callback_data="menu_zryachiy"))
    else:
        markup.add(types.InlineKeyboardButton("👁️ О Датчике DSP Зрячего (🔒)", callback_data="menu_zryachiy"))

    markup.add(
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    _safe_edit_or_send(txt, chat_id, msg_id, markup)

def handle_menu_black_division(chat_id, msg_id, player, db=None):
    if not has_mythic_item(player, "mythic_black_division_case"):
        txt = (
            f"💼 <b>СПЕЦОПЕРАЦИЯ BLACK DIVISION</b>\n"
            f"────────────────────────\n"
            f"🔒 <b>ДОСТУП ЗАБЛОКИРОВАН!</b>\n\n"
            f"Для вызова элитного отряда Black Division требуется <b>Дипломатический кейс Black Division</b> (150 000 000 ₽).\n"
            f"Этот мифический артефакт можно выбить только при победе в Кооперативных рейдах на Боссов!"
        )
        markup = types.InlineKeyboardMarkup().add(
            types.InlineKeyboardButton("🔙 Назад", callback_data="menu_profile")
        )
        if db is None:
            db = load_db()
        photo = get_menu_photo("black_division", db)
        _safe_send_photo(photo, txt, chat_id, msg_id, markup)
        return

    can_launch, rem_sec = can_launch_black_division(player)
    markup = types.InlineKeyboardMarkup(row_width=2)

    if can_launch:
        txt = (
            f"💼 <b>СПЕЦОПЕРАЦИЯ ЧВК BLACK DIVISION (TERRAGROUP)</b>\n"
            f"────────────────────────\n"
            f"🟢 <b>ШТУРМОВАЯ ГРУППА ГОТОВА К БРОСКУ!</b>\n\n"
            f"Элитные оперативники в тяжелых экзоскелетах и глушителях ждут приказа.\n"
            f"Раз в 24 часа вы можете отправить их на ликвидацию любого Босса Таркова.\n\n"
            f"<b>Гарантированные награды:</b>\n"
            f"• 🏆 <b>Случайная реликвия выбранного босса</b> (приоритет недостающих реликвий в коллекцию!)\n"
            f"• 💰 <b>5 000 000 – 12 000 000 ₽</b> со счетов TerraGroup\n"
            f"• 🎁 2-3 единицы элитного снаряжения охраны\n"
            f"• 📈 +150 EXP\n\n"
            f"<i>Выберите Босса для спецоперации:</i>"
        )
        markup.row(
            types.InlineKeyboardButton("👑 Решала (Таможня)", callback_data="bd_target_reshala"),
            types.InlineKeyboardButton("🌲 Штурман (Лес)", callback_data="bd_target_shturman")
        )
        markup.row(
            types.InlineKeyboardButton("⚡ Килла (Развязка)", callback_data="bd_target_killa"),
            types.InlineKeyboardButton("🪖 Глухарь (Резерв)", callback_data="bd_target_glukhar")
        )
        markup.row(
            types.InlineKeyboardButton("💉 Санитар (Берег)", callback_data="bd_target_sanitar"),
            types.InlineKeyboardButton("🔨 Тагилла (Завод)", callback_data="bd_target_tagilla")
        )
    else:
        hrs = rem_sec // 3600
        mins = (rem_sec % 3600) // 60
        txt = (
            f"💼 <b>СПЕЦОПЕРАЦИЯ ЧВК BLACK DIVISION (TERRAGROUP)</b>\n"
            f"────────────────────────\n"
            f"⏳ <b>ОТРЯД НА ПЕРЕГРУППИРОВКЕ И СНАБЖЕНИИ</b>\n\n"
            f"Оперативники вернулись на секретный объект TerraGroup и пополняют боекомплект.\n"
            f"До следующего рейда осталось: <b>{hrs} ч. {mins} мин.</b>\n\n"
            f"<i>💡 Напоминание: Спецоперация гарантированно приносит недостающую реликвию выбранного босса!</i>"
        )

    markup.add(
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    if db is None:
        db = load_db()
    photo = get_menu_photo("black_division", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)


def handle_bd_target_boss(call, player, db, boss_key):
    can_launch, rem_sec = can_launch_black_division(player)
    if not can_launch:
        hrs = rem_sec // 3600
        mins = (rem_sec % 3600) // 60
        bot.answer_callback_query(call.id, f"⏳ Отряд на перезарядке! Доступно через {hrs} ч. {mins} мин.", show_alert=True)
        return

    bot.answer_callback_query(call.id)
    res = execute_black_division_raid(player, boss_key)
    save_db(db)

    relic = res["relic"]
    new_note = " 🌟 <b>[НОВАЯ В ВАШУ КОЛЛЕКЦИЮ!]</b>" if res["is_new_relic"] else " 🔄 [ДУБЛИКАТ]"

    txt = (
        f"💼 <b>ИТОГИ СПЕЦОПЕРАЦИИ BLACK DIVISION</b>\n"
        f"Цель: {res['boss_icon']} <b>{res['boss_name']}</b> — 💀 <b>ЛИКВИДИРОВАН!</b>\n"
        f"────────────────────────\n"
        f"Штурмовой отряд в маскировочном снаряжении нейтрализовал свиту босса и зачистил командный пункт!\n\n"
        f"🏆 <b>ДОБЫТА РЕЛИКВИЯ БОССА:</b>\n"
        f"• <b>{relic['name']}</b> (+10 000 000 ₽){new_note}\n\n"
        f"💰 <b>ТРОФЕИ И ВЫПЛАТЫ:</b>\n"
        f"• Выплата TerraGroup: <b>+{fmt_rub(res['rubles'])}</b>\n"
        f"• Боевой опыт: <b>+{res['exp']} EXP</b>\n"
        f"• Трофеи охраны: <b>{len(res['trophies'])} шт.</b> доставлено в ваш схрон!\n"
        f"────────────────────────\n"
        f"⏳ <i>Следующая спецоперация будет доступна через 24 часа.</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1).add(
        types.InlineKeyboardButton("🏆 Коллекция Реликвий (30 шт)", callback_data="view_relics_collection"),
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)


def handle_menu_the_goons(chat_id, msg_id, player, db=None):
    if not has_mythic_item(player, "mythic_goons_token"):
        txt = (
            f"🎖️ <b>ШТАБ ОТСТУПНИКОВ (THE GOONS)</b>\n"
            f"────────────────────────\n"
            f"🔒 <b>ДОСТУП ЗАБЛОКИРОВАН!</b>\n\n"
            f"Для вызова банды The Goons требуется <b>Жетон Отступников</b> (150 000 000 ₽).\n"
            f"Этот мифический артефакт можно получить только с шансом <b>0.01%</b> из Военного Кейса за 2 500 000 ₽!"
        )
        markup = types.InlineKeyboardMarkup().add(
            types.InlineKeyboardButton("🔙 Назад", callback_data="menu_profile")
        )
        if db is None:
            db = load_db()
        photo = get_menu_photo("the_goons", db)
        _safe_send_photo(photo, txt, chat_id, msg_id, markup)
        return

    can_supply, rem_supply = can_claim_goons_supply(player)
    can_raid, rem_raid = can_launch_goons_raid(player)

    txt = (
        f"🎖️ <b>ШТАБ БАНДЫ ОТСТУПНИКОВ (THE GOONS)</b>\n"
        f"────────────────────────\n"
        f"Командиры <b>Knight</b>, <b>Big Pipe</b> и <b>Birdeye</b> признали ваш авторитет!\n"
        f"Благодаря Жетону Отступников вам доступны 2 уникальные механики:\n\n"
        f"1️⃣ <b>Поставка уникальной экипировки (раз в 24ч):</b>\n"
        f"• Статус: "
    )

    if can_supply:
        txt += "🟢 <b>ГОТОВА К ПОЛУЧЕНИЮ!</b>\n"
    else:
        hrs = rem_supply // 3600
        mins = (rem_supply % 3600) // 60
        txt += f"⏳ Ожидание: <b>{hrs} ч. {mins} мин.</b>\n"

    txt += f"<i>(Шлемы Knight, гранатомет Big Pipe, снайперка Birdeye и др.)</i>\n\n"

    txt += (
        f"2️⃣ <b>Рейд Троицы Отступников в Тарков (раз в 24ч):</b>\n"
        f"• Статус: "
    )
    if can_raid:
        txt += "🟢 <b>ТРОИЦА ГОТОВА К ВЫХОДУ!</b>\n"
    else:
        hrs = rem_raid // 3600
        mins = (rem_raid % 3600) // 60
        txt += f"⏳ Ожидание: <b>{hrs} ч. {mins} мин.</b>\n"

    txt += (
        f"<i>(100% победа, 7–15М ₽, элитное оружие, +250 EXP, 35% шанс на чистый Bitcoin!)</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if can_supply:
        markup.add(types.InlineKeyboardButton("🎁 Забрать экипировку The Goons", callback_data="goons_claim_supply"))
    if can_raid:
        markup.add(types.InlineKeyboardButton("⚡ Отправить Троицу в рейд (Knight, Big Pipe, Birdeye)", callback_data="goons_start_raid"))

    markup.add(
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    if db is None:
        db = load_db()
    photo = get_menu_photo("the_goons", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)


def handle_goons_claim_supply(call, player, db):
    can_supply, rem_sec = can_claim_goons_supply(player)
    if not can_supply:
        hrs = rem_sec // 3600
        mins = (rem_sec % 3600) // 60
        bot.answer_callback_query(call.id, f"⏳ Поставка еще в пути! Доступно через {hrs} ч. {mins} мин.", show_alert=True)
        return

    bot.answer_callback_query(call.id)
    gear_item = claim_goons_gear_supply(player)
    save_db(db)

    stats_txt = []
    if gear_item.get("armor", 0) > 0:
        stats_txt.append(f"🛡️ Броня: +{gear_item['armor']}")
    if gear_item.get("combat", 0) > 0:
        stats_txt.append(f"⚔️ Мощь: +{gear_item['combat']}")
    stats_str = " | ".join(stats_txt)

    txt = (
        f"🎁 <b>ПОСТАВКА ЭКИПИРОВКИ ОТСТУПНИКОВ ПОЛУЧЕНА!</b>\n"
        f"────────────────────────\n"
        f"В ваш схрон доставлен культовый артефакт банды:\n\n"
        f"⭐ <b>{gear_item['name']}</b>\n"
        f"💰 Оценка черного рынка: <b>{fmt_rub(gear_item['price'])}</b>\n"
        f"📊 Характеристики: <b>{stats_str}</b>\n"
        f"📜 <i>{gear_item['desc']}</i>\n"
        f"────────────────────────\n"
        f"<i>Предмет успешно сохранен в вашем схроне. Вы можете надеть его на бойца или сохранить как реликвию!</i>\n"
        f"⏳ Следующая поставка экипировки через 24 часа."
    )

    markup = types.InlineKeyboardMarkup(row_width=1).add(
        types.InlineKeyboardButton("📦 Открыть Схрон", callback_data="menu_stash"),
        types.InlineKeyboardButton("🎖️ Штаб Отступников", callback_data="menu_the_goons"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)


def handle_goons_start_raid(call, player, db):
    can_raid, rem_sec = can_launch_goons_raid(player)
    if not can_raid:
        hrs = rem_sec // 3600
        mins = (rem_sec % 3600) // 60
        bot.answer_callback_query(call.id, f"⏳ Отступники отдыхают! Доступно через {hrs} ч. {mins} мин.", show_alert=True)
        return

    bot.answer_callback_query(call.id)
    res = execute_goons_raid(player)
    save_db(db)

    btc_txt = f"\n🪙 <b>ДЖЕКПОТ В КРИПТЕ: +{res['btc_won']:.1f} BTC!</b>" if res["btc_won"] > 0 else ""

    txt = (
        f"⚡ <b>РЕЙД ТРОИЦЫ ОТСТУПНИКОВ ЗАВЕРШЕН!</b>\n"
        f"Knight, Big Pipe и Birdeye вернулись с победой!\n"
        f"────────────────────────\n"
        f"🔥 <i>Knight протаранил оборону противника штурмовым щитом, Big Pipe залил окопы 40-мм гранатами, а Birdeye снял снайперов на дистанции 800 метров!</i>\n\n"
        f"💰 <b>ТРОФЕИ С ПОЛЯ БОЯ:</b>\n"
        f"• Наличные рубли: <b>+{fmt_rub(res['rubles'])}</b>{btc_txt}\n"
        f"• Опыт командования: <b>+{res['exp']} EXP</b>\n"
        f"• Элитная экипировка вражеских ЧВК: <b>{len(res['trophies'])} шт.</b> доставлено в схрон!\n"
        f"────────────────────────\n"
        f"⏳ <i>Следующий выход Троицы будет доступен через 24 часа.</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1).add(
        types.InlineKeyboardButton("🎖️ Штаб Отступников", callback_data="menu_the_goons"),
        types.InlineKeyboardButton("📦 Открыть Схрон", callback_data="menu_stash"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)


# ----------------- ZRYACHIY (LIGHTHOUSE) HANDLERS -----------------
def handle_menu_zryachiy(chat_id, msg_id, player, db=None):
    if not has_mythic_item(player, "mythic_dsp_sensor"):
        txt = (
            f"👁️ <b>ДОЗОР ЗРЯЧЕГО (ОСТРОВ МАЯКА)</b>\n"
            f"────────────────────────\n"
            f"🔒 <b>ДОСТУП ЗАБЛОКИРОВАН!</b>\n\n"
            f"Для доступа к частоте Зрячего требуется <b>📟 Закодированный датчик DSP Смотрителя</b> (150 000 000 ₽).\n"
            f"Этот мифический артефакт можно выбить с шансом <b>0.1% (1 из 1000)</b> из Теневого Каравана высшего тира (Контрабанда Тир 4) независимо от уровня поставок!"
        )
        markup = types.InlineKeyboardMarkup().add(
            types.InlineKeyboardButton("🔙 Назад к Профилю", callback_data="menu_profile")
        )
        if db is None:
            db = load_db()
        photo = get_menu_photo("zryachiy", db)
        _safe_send_photo(photo, txt, chat_id, msg_id, markup)
        return

    # Check auto-delivery first
    try:
        auto_del, _ = check_zryachiy_daily_supply(player)
        if auto_del:
            save_db(db)
    except Exception:
        pass

    can_supply, rem_supply = get_zryachiy_supply_status(player)

    txt = (
        f"👁️ <b>СВЯЗЬ СО СМОТРИТЕЛЕМ & ДОЗОР ЗРЯЧЕГО</b>\n"
        f"────────────────────────\n"
        f"Датчик DSP настроен на защищенную частоту Маяка. Зрячий держит ваши территории под постоянным прицелом винтовки AXMC .338 Lapua.\n\n"
        f"🛡️ <b>Оборона территорий и базы ЧВК:</b>\n"
        f"• Статус: 👁️ <b>100% ВЕЧНАЯ ЗАЩИТА (АКТИВНА)</b>\n"
        f"• <i>Мародеры, грабежи сейфа и рейдерский захват базы полностью исключены. Продлевать контракты охраны больше не нужно.</i>\n\n"
        f"📦 <b>Ежедневная поставка экипировки Зрячего (раз в 24ч):</b>\n"
        f"• Статус: "
    )

    if can_supply:
        txt += "🟢 <b>ГОТОВА К ПОЛУЧЕНИЮ!</b>\n"
    else:
        hrs = rem_supply // 3600
        mins = (rem_supply % 3600) // 60
        txt += f"⏳ Ожидание: <b>{hrs} ч. {mins} мин.</b>\n"

    txt += (
        f"\n🎯 <b>Именной арсенал Зрячего (выдаются все 3 предмета каждые 24ч):</b>\n"
        f"1. 🎯 <b>AXMC «Глаз Зрячего» .338 Lapua</b> — Урон: <b>+72</b> (42 000 000 ₽)\n"
        f"2. 🛡️ <b>Плитник Сектантов «Страж Маяка»</b> — Броня: <b>+52</b>, Урон: <b>+8</b> (38 000 000 ₽)\n"
        f"3. 👁️ <b>Капюшон «Ослепленный Жнец»</b> — Броня: <b>+22</b>, Урон: <b>+16</b> (24 000 000 ₽)\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if can_supply:
        markup.add(types.InlineKeyboardButton("🎁 Забрать комплект Зрячего (3 предмета)", callback_data="zryachiy_claim_supply"))
    if get_player_prestige(player) >= 5:
        markup.add(types.InlineKeyboardButton("👑 Черный Рейд Смотрителя (10-25M ₽ | Раз в 20ч)", callback_data="menu_prestige_black_raid"))
    markup.add(
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    if db is None:
        db = load_db()
    photo = get_menu_photo("zryachiy", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)


def handle_zryachiy_claim_supply(call, player, db):
    can_supply, rem_sec = get_zryachiy_supply_status(player)
    if not can_supply:
        hrs = rem_sec // 3600
        mins = (rem_sec % 3600) // 60
        bot.answer_callback_query(call.id, f"⏳ Поставка еще в пути! Доступно через {hrs} ч. {mins} мин.", show_alert=True)
        return

    delivered = claim_zryachiy_gear_supply(player)
    save_db(db)

    bot.answer_callback_query(call.id, "📦 Все 3 предмета Зрячего доставлены в схрон!", show_alert=True)
    handle_menu_zryachiy(call.message.chat.id, call.message.message_id, player, db)


# ----------------- SECTION 1.6: MYTHIC RESERVE VAULT (50 ARMORS & CONTRABAND TRUCK) -----------------
def handle_menu_reserve_vault(chat_id, msg_id, player, db=None):
    if not has_mythic_item(player, "mythic_state_reserve_key"):
        txt = (
            f"🗝️ <b>СПЕЦХРАН РОСРЕЗЕРВА (БУНКЕР)</b>\n"
            f"────────────────────────\n"
            f"🔒 <b>ДОСТУП ЗАБЛОКИРОВАН!</b>\n\n"
            f"Для доступа к арсеналу спецхранилища требуется <b>🗝️ Ключ от Спецхрана Росрезерва</b> (150 000 000 ₽).\n"
            f"Этот мифический артефакт выпадает со сверхредким шансом (0.1%) в <b>Сигнатурных Рейдах</b> (30-50M ₽) или Кооперативных рейдах на Боссов!\n\n"
            f"<b>Уникальные возможности ключа:</b>\n"
            f"1. 🛡️ <b>Раз в 24 часа:</b> выдает 1 случайную Мифическую броню из 50 брутальных тактических комплектов (Броня: 150–195, Прочность: до 180, Урон: +15..+40)!\n"
            f"2. 🚚 <b>Раз в 3 часа:</b> отправка бронегрузовика с контрабандой — загрузка до 10 любых предметов из схрона со 100% рыночной выплатой без комиссий и уценок!"
        )
        markup = types.InlineKeyboardMarkup(row_width=1).add(
            types.InlineKeyboardButton("✨ Все Мифические Предметы", callback_data="view_mythics_info"),
            types.InlineKeyboardButton("🔙 Назад к Профилю", callback_data="menu_profile")
        )
        if db is None:
            db = load_db()
        photo = get_menu_photo("reserve_vault", db)
        _safe_send_photo(photo, txt, chat_id, msg_id, markup)
        return

    can_armor, rem_armor = can_claim_reserve_armor(player)
    can_truck, rem_truck = can_send_reserve_contraband_truck(player)

    # Calculate stash stats for contraband truck
    stash = player.get("stash", [])
    equipped_uids = set()
    for fighter in player.get("squad", []):
        for slot in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
            if fighter.get(slot):
                equipped_uids.add(fighter[slot])

    unequipped = [
        itm for itm in stash
        if itm.get("uid") not in equipped_uids
        and itm.get("item_id") not in MYTHIC_ITEMS
        and itm.get("rarity") != "mythic"
        and ITEMS_BY_ID.get(itm.get("item_id"), {}).get("rarity") != "mythic"
        and ITEMS_BY_ID.get(itm.get("item_id"), {}).get("category") != "special"
    ]

    def get_item_val(itm):
        p = itm.get("price")
        if p is not None and p > 0:
            return p
        info = ITEMS_BY_ID.get(itm.get("item_id"), {})
        return info.get("price", 100000)

    unequipped.sort(key=get_item_val, reverse=True)
    top_10 = unequipped[:10]
    est_value = sum(get_item_val(i) for i in top_10)

    armor_status_str = (
        "🟢 <b>ГОТОВ К ВЫДАЧЕ!</b>" if can_armor
        else f"⏳ Ожидание: <b>{rem_armor // 3600}ч {(rem_armor % 3600) // 60}м</b>"
    )

    truck_status_str = (
        "🟢 <b>ГОТОВ К ОТПРАВКЕ!</b>" if can_truck
        else f"⏳ В пути: <b>{rem_truck // 3600}ч {(rem_truck % 3600) // 60}м</b>"
    )

    txt = (
        f"🗝️ <b>ПОДЗЕМНЫЙ СПЕЦХРАН РОСРЕЗЕРВА</b>\n"
        f"────────────────────────\n"
        f"Электронный мастер-ключ активирован. Вы подключены к закрытой сети снабжения и арсеналам глубокой консервации.\n\n"
        f"🛡️ <b>1. Арсенал тяжелой брони (раз в 24 часа):</b>\n"
        f"• Статус: {armor_status_str}\n"
        f"• Награда: <b>1 случайная Мифическая броня</b> из пула 50 брутальных тактических доспехов (Броня 150–195, Стойкость до 180, Урон +15..+40)!\n\n"
        f"🚚 <b>2. Личный грузовик с контрабандой (раз в 3 часа):</b>\n"
        f"• Статус: {truck_status_str}\n"
        f"• Вместимость: <b>до 10 предметов</b> из схрона\n"
        f"• Выплата: <b>100% полная рыночная стоимость</b> без налогов и потерь!\n"
        f"• 📦 Готово к отправке: <b>{len(top_10)} / 10 предметов</b> (Оценка партии: <b>{fmt_rub(est_value)}</b>)\n"
        f"────────────────────────\n"
        f"💰 Баланс: <b>{fmt_rub(player.get('money', 0))}</b>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if can_armor:
        markup.add(types.InlineKeyboardButton("🛡️ Получить мифическую броню (раз в 24ч)", callback_data="claim_reserve_armor"))
    else:
        markup.add(types.InlineKeyboardButton(f"⏳ Броня через: {rem_armor // 3600}ч {(rem_armor % 3600) // 60}м", callback_data="none"))

    if can_truck:
        markup.add(types.InlineKeyboardButton(f"🚚 Отправить грузовик с контрабандой ({len(top_10)} предм.)", callback_data="send_reserve_truck"))
    else:
        markup.add(types.InlineKeyboardButton(f"⏳ Грузовик в пути: {rem_truck // 3600}ч {(rem_truck % 3600) // 60}м", callback_data="none"))

    markup.add(
        types.InlineKeyboardButton("📜 Список 50 видов мифической брони", callback_data="view_reserve_armors")
    )
    markup.add(
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile"),
        types.InlineKeyboardButton("🏠 Главное Меню", callback_data="main_menu")
    )

    if db is None:
        db = load_db()
    photo = get_menu_photo("reserve_vault", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)


def handle_claim_reserve_armor(call, player, db):
    ok, item, msg = claim_reserve_armor_supply(player)
    if not ok:
        bot.answer_callback_query(call.id, f"❌ {msg}", show_alert=True)
        return

    save_db(db)
    alert_txt = (
        f"🎉 Из арсенала консервации получен мифический комплект!\n\n"
        f"{item['name']}\n"
        f"• 🛡️ Броня: +{item.get('armor', 170)}\n"
        f"• ⚔️ Боевая мощь: +{item.get('combat', 30)}\n"
        f"• 🔨 Прочность: {item.get('durability', 160)}\n"
        f"• 💰 Оценка: {fmt_rub(item.get('price', 45000000))}\n\n"
        f"Броня бережно упакована в ваш схрон!"
    )
    bot.answer_callback_query(call.id, alert_txt, show_alert=True)
    handle_menu_reserve_vault(call.message.chat.id, call.message.message_id, player, db)


def handle_send_reserve_truck(call, player, db):
    ok, msg, res = send_reserve_contraband_truck(player)
    if not ok:
        bot.answer_callback_query(call.id, f"❌ {msg}", show_alert=True)
        return

    save_db(db)
    alert_txt = (
        f"🚚 Бронегрузовик успешно доставил партию контрабанды!\n\n"
        f"• Отгружено предметов: {res.get('items_count', 0)} шт.\n"
        f"• Получено чистыми (100%): +{fmt_rub(res.get('total_value', 0))}\n"
        f"• Комиссия Скупщика: 0 ₽ (Спецканал Росрезерва)\n\n"
        f"Деньги моментально зачислены на ваш баланс!"
    )
    bot.answer_callback_query(call.id, alert_txt, show_alert=True)
    handle_menu_reserve_vault(call.message.chat.id, call.message.message_id, player, db)


def handle_view_reserve_armors(chat_id, msg_id, player, db=None):
    lines = [
        "<b>🛡️ АРСЕНАЛ ИЗ 50 МИФИЧЕСКИХ БРОНЕКОМПЛЕКТОВ РОСРЕЗЕРВА</b>",
        "────────────────────────",
        "Брутальные армейские бронежилеты и штурмовые панцири высшего класса стойкости (без хай-тека и фантастики):\n",
        "<b>1. Серия «Тяжелый Штурм и Саперы» (1-10):</b>",
        "• 🛡️ «Форт-Дубрава» (Броня: 185, Мощь: +35)",
        "• 🛡️ «Воевода-М» (Броня: 180, Мощь: +32)",
        "• 🛡️ «Заслон-У» (Броня: 175, Мощь: +30)",
        "• 🛡️ «Витязь-Ш» (Броня: 190, Мощь: +38)",
        "• 🛡️ «Броненосец» (Броня: 188, Мощь: +36)\n",
        "<b>2. Серия «Ветераны и Наемники» (11-20):</b>",
        "• 🛡️ «Грозный-95» (Броня: 160, Мощь: +24)",
        "• 🛡️ «ЧВК Волкодав» (Броня: 174, Мощь: +30)",
        "• 🛡️ «Окопный Мясник» (Броня: 166, Мощь: +25)",
        "• 🛡️ «Псы Войны» (Броня: 172, Мощь: +28)",
        "• 🛡️ «Дикая Дивизия» (Броня: 170, Мощь: +28)\n",
        "<b>3. Серия «Спецназ ГРУ и ФСБ» (21-30):</b>",
        "• 🛡️ «Альфа-Титан» (Броня: 186, Мощь: +35)",
        "• 🛡️ «Вымпел-Т» (Броня: 184, Мощь: +34)",
        "• 🛡️ «Град-Спецназ» (Броня: 180, Мощь: +32)",
        "• 🛡️ «Спектр-Т» (Броня: 175, Мощь: +30)",
        "• 🛡️ «Рысь-Т» (Броня: 185, Мощь: +35)\n",
        "<b>4. Серия «Трофеи Боссов Таркова» (31-40):</b>",
        "• 🛡️ «Тагилла-Варвар» (Броня: 182, Траки танка)",
        "• 🛡️ «Двойной 6Б13 Киллы» (Броня: 188, Мощь: +38)",
        "• 🛡️ «Резервный Титан Глухаря» (Броня: 180)",
        "• 🛡️ «Вепрь-6 Кабана» (Броня: 185)",
        "• 🛡️ «Черный Обряд Сектантов» (Броня: 169)\n",
        "<b>5. Серия «Контракты и Black Division» (41-50):</b>",
        "• 🛡️ Tier-1 «Obsidian Plate» (Броня: 195, Мощь: +40)",
        "• 🛡️ USEC «Iron Vanguard» (Броня: 180)",
        "• 🛡️ «Dreadnought-7» (Броня: 192)",
        "• 🛡️ «Colossus Level IV» (Броня: 187)",
        "• 🛡️ «Juggernaut-Rig» (Броня: 189)",
        "────────────────────────",
        "<i>Каждые 24 часа Ключ Росрезерва выдает 1 случайный комплект в схрон!</i>"
    ]
    txt = "\n".join(lines)
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton("📄 Постраничный каталог всех 50 броней (1-10 стр.)", callback_data="mythic_arm_p_1"))
    if has_mythic_item(player, "mythic_state_reserve_key"):
        markup.add(types.InlineKeyboardButton("🗝️ Открыть Спецхран Росрезерва", callback_data="menu_reserve_vault"))
    else:
        markup.add(types.InlineKeyboardButton("🗝️ О Ключе Росрезерва (🔒)", callback_data="menu_reserve_vault"))
    markup.add(
        types.InlineKeyboardButton("✨ Все 4 Мифических Предмета", callback_data="view_mythics_info"),
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile")
    )
    if db is None:
        db = load_db()
    photo = get_menu_photo("reserve_vault", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)


def handle_view_mythic_armors_catalog(chat_id, msg_id, player, page=1, db=None):
    from mythic_system import MYTHIC_ARMORS
    per_page = 5
    total_pages = (len(MYTHIC_ARMORS) + per_page - 1) // per_page
    page = max(1, min(total_pages, page))

    start_idx = (page - 1) * per_page
    page_armors = MYTHIC_ARMORS[start_idx:start_idx + per_page]

    stash_item_ids = {itm.get("item_id") for itm in player.get("stash", [])}

    lines = [
        "<b>🛡️ КАТАЛОГ МИФИЧЕСКИХ БРОНЕЙ РОСРЕЗЕРВА</b>",
        "────────────────────────",
        f"Страница <b>{page} / {total_pages}</b> (Всего 50 комплектов)",
        "<i>Выдаются раз в 24 часа владельцам 🗝️ Ключа от Спецхрана Росрезерва.</i>",
        "────────────────────────\n"
    ]
    for idx, arm in enumerate(page_armors, start=start_idx + 1):
        has_it = "✅ В схроне" if arm["id"] in stash_item_ids else "🔒 Не получен"
        lines.append(f"<b>{idx}. {arm['name']}</b> [{has_it}]")
        lines.append(f"• 🛡️ Броня: <b>+{arm['armor']}</b> | ⚔️ Урон: <b>+{arm['combat']}</b>")
        lines.append(f"• 🔨 Прочность: <b>{arm.get('durability', 160)}</b> | 💰 Стоимость: <b>{fmt_rub(arm['price'])}</b>")
        lines.append(f"• 📜 <i>{arm['desc']}</i>\n")

    txt = "\n".join(lines)
    markup = types.InlineKeyboardMarkup(row_width=3)
    nav_btns = []
    if page > 1:
        nav_btns.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"mythic_arm_p_{page - 1}"))
    nav_btns.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_btns.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"mythic_arm_p_{page + 1}"))
    markup.row(*nav_btns)

    if has_mythic_item(player, "mythic_state_reserve_key"):
        markup.add(types.InlineKeyboardButton("🗝️ Открыть Спецхран Росрезерва", callback_data="menu_reserve_vault"))
    markup.add(
        types.InlineKeyboardButton("📋 Обзор всех 5 серий", callback_data="view_reserve_armors"),
        types.InlineKeyboardButton("✨ Все 4 Мифических Предмета", callback_data="view_mythics_info")
    )
    markup.add(
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile"),
        types.InlineKeyboardButton("🏠 Главное Меню", callback_data="main_menu")
    )
    if db is None:
        db = load_db()
    photo = get_menu_photo("reserve_vault", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)

def handle_menu_squad(chat_id, msg_id, player):
    try:
        from boss_summon_system import ensure_boss_gear
        if ensure_boss_gear(player):
            save_db(load_db())
    except Exception:
        pass
    squad = player.get("squad", [])
    pow_val, arm_val = calculate_squad_power(player)
    stash = {itm["uid"]: itm for itm in player.get("stash", [])}
    max_squad = 6 if has_boss_set_bonus(player, "glukhar") else 5
    lvl = get_player_level(player)

    txt = (
        f"<b>🪖 БОЕВОЙ ОТРЯД ЧВК ({len(squad)}/{max_squad})</b>\n"
        f"Уровень профиля: <b>{lvl}</b> | Огневая мощь: <b>{pow_val}</b> | Броня: <b>{arm_val}</b>\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    for idx, f in enumerate(squad, start=1):
        if f.get("type") == "boss":
            f_type = "Босс"
        elif f.get("type") == "scav":
            f_type = "Дикий"
        else:
            f_type = "ЧВК"
        w_uid = f.get("weapon_uid")
        a_uid = f.get("armor_uid")
        h_uid = f.get("helmet_uid")
        hs_uid = f.get("headset_uid")

        w_name = ITEMS_BY_ID.get(stash[w_uid].get("item_id"), {}).get("name", "Нет") if w_uid and w_uid in stash else "Кулаки"
        a_name = ITEMS_BY_ID.get(stash[a_uid].get("item_id"), {}).get("name", "Нет") if a_uid and a_uid in stash else "Одежда"
        h_name = ITEMS_BY_ID.get(stash[h_uid].get("item_id"), {}).get("name", "Нет") if h_uid and h_uid in stash else "Нет"
        hs_name = ITEMS_BY_ID.get(stash[hs_uid].get("item_id"), {}).get("name", "Нет") if hs_uid and hs_uid in stash else "Нет"

        txt += (
            f"<b>{idx}. {f.get('name', f_type)}</b> [{f_type}]\n"
            f"   🔫 Оружие: <i>{w_name}</i>\n"
            f"   🛡️ Броня: <i>{a_name}</i>\n"
            f"   🪖 Шлем: <i>{h_name}</i>\n"
            f"   🎧 Наушники: <i>{hs_name}</i>\n\n"
        )
        if f.get("type") == "boss":
            markup.add(
                types.InlineKeyboardButton(f"👑 Инфо о Боссе", callback_data=f"view_fighter_{f['id']}"),
                types.InlineKeyboardButton("❌ Отпустить", callback_data=f"disband_fighter_{f['id']}")
            )
        else:
            markup.add(
                types.InlineKeyboardButton(f"⚙️ Экипировать {f.get('name', f_type)}", callback_data=f"view_fighter_{f['id']}"),
                types.InlineKeyboardButton("❌ Уволить", callback_data=f"disband_fighter_{f['id']}")
            )

    markup.add(
        types.InlineKeyboardButton("📦 Снарядить Всё Автоматом", callback_data="auto_equip")
    )
    if len(squad) < max_squad:
        scav_cost = get_fighter_hire_cost(player, "scav")
        pmc_cost = get_fighter_hire_cost(player, "pmc")
        markup.add(
            types.InlineKeyboardButton(f"➕ Нанять Дикого ({fmt_rub(scav_cost)})", callback_data="hire_scav"),
            types.InlineKeyboardButton(f"➕ Нанять ЧВК ({fmt_rub(pmc_cost)})", callback_data="hire_pmc")
        )

    if len(squad) == 0:
        scav_cost = get_fighter_hire_cost(player, "scav")
        has_items = any(not itm.get("equipped_to") for itm in player.get("stash", []))
        if player.get("money", 0) < scav_cost and not has_items:
            markup.add(types.InlineKeyboardButton("🆘 Пособие Прапора (+10 000 ₽)", callback_data="prapor_bankruptcy_aid"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_view_fighter(chat_id, msg_id, player, f_id):
    try:
        from boss_summon_system import ensure_boss_gear
        if ensure_boss_gear(player):
            save_db(load_db())
    except Exception:
        pass
    squad = player.get("squad", [])
    fighter = next((f for f in squad if f["id"] == f_id), None)
    if not fighter:
        handle_menu_squad(chat_id, msg_id, player)
        return

    f_type = fighter.get("type", "pmc")
    stash = {itm["uid"]: itm for itm in player.get("stash", [])}
    w_uid = fighter.get("weapon_uid")
    a_uid = fighter.get("armor_uid")
    h_uid = fighter.get("helmet_uid")
    hs_uid = fighter.get("headset_uid")

    w_name = ITEMS_BY_ID.get(stash[w_uid].get("item_id"), {}).get("name", "—") if w_uid and w_uid in stash else "Нет"
    a_name = ITEMS_BY_ID.get(stash[a_uid].get("item_id"), {}).get("name", "—") if a_uid and a_uid in stash else "Нет"
    h_name = ITEMS_BY_ID.get(stash[h_uid].get("item_id"), {}).get("name", "—") if h_uid and h_uid in stash else "Нет"
    hs_name = ITEMS_BY_ID.get(stash[hs_uid].get("item_id"), {}).get("name", "—") if hs_uid and hs_uid in stash else "Нет"

    if f_type == "scav":
        txt = (
            f"<b>⚠️ ДИКИЙ: {fighter.get('name')}</b>\n"
            f"────────────────────────\n"
            f"Стартовый комплект «бомж-снаряжения» (менять нельзя):\n\n"
            f"1. 🔫 Оружие: <b>{w_name}</b>\n"
            f"2. 🛡️ Бронежилет: <b>{a_name}</b>\n"
            f"3. 🪖 Шлем/Головной убор: <b>{h_name}</b>\n"
            f"4. 🎧 Наушники: <b>{hs_name}</b>\n"
        )
        markup = types.InlineKeyboardMarkup(row_width=1).add(
            types.InlineKeyboardButton("❌ Уволить Дикого", callback_data=f"disband_fighter_{f_id}"),
            types.InlineKeyboardButton("🔙 К Отряду", callback_data="menu_squad")
        )
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
        return

    if f_type == "signature":
        txt = (
            f"<b>🎖️ СИГНАТУРНЫЙ ЧВК: {fighter.get('name')}</b>\n"
            f"────────────────────────\n"
            f"Сигнатурный боец прибыл со своим уникальным сетом экипировки, менять его нельзя.\n\n"
            f"1. 🔫 Оружие: <b>{w_name}</b>\n"
            f"2. 🛡️ Бронежилет: <b>{a_name}</b>\n"
            f"3. 🪖 Шлем: <b>{h_name}</b>\n"
            f"4. 🎧 Наушники: <b>{hs_name}</b>\n"
        )
        markup = types.InlineKeyboardMarkup(row_width=1).add(
            types.InlineKeyboardButton("🔙 К Отряду", callback_data="menu_squad")
        )
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
        return

    if f_type == "boss":
        txt = (
            f"<b>👑 ЛЕГЕНДАРНЫЙ БОСС: {fighter.get('name')}</b>\n"
            f"────────────────────────\n"
            f"Босс сражается со своим персональным именным снаряжением. Снять, продать или заменить его оружие и броню <b>нельзя</b> — это его личные несъемные реликвии!\n\n"
            f"✨ <b>Способность:</b> «{fighter.get('perk_name', 'Спецспособность')}»\n"
            f"<i>{fighter.get('perk_desc', '')}</i>\n\n"
            f"1. 🔫 Именное оружие: <b>{w_name}</b> 🔒 <i>(Несъемное)</i>\n"
            f"2. 🛡️ Именная броня: <b>{a_name}</b> 🔒 <i>(Несъемная)</i>\n"
            f"3. 🪖 Шлем: <i>Не требуется</i>\n"
            f"4. 🎧 Наушники: <i>Не требуется</i>\n"
        )
        markup = types.InlineKeyboardMarkup(row_width=1).add(
            types.InlineKeyboardButton("❌ Отпустить Босса", callback_data=f"disband_fighter_{f_id}"),
            types.InlineKeyboardButton("🔙 К Отряду", callback_data="menu_squad")
        )
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
        return

    txt = (
        f"<b>⚙️ НАСТРОЙКА ЭКИПИРОВКИ ЧВК: {fighter.get('name')}</b>\n"
        f"Полная кастомизация 4 слотов снаряжения из вашего схрона:\n"
        f"────────────────────────\n"
        f"1. 🔫 Оружие: <b>{w_name}</b>\n"
        f"2. 🛡️ Бронежилет: <b>{a_name}</b>\n"
        f"3. 🪖 Шлем: <b>{h_name}</b>\n"
        f"4. 🎧 Наушники: <b>{hs_name}</b>\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    # Weapon Slot
    markup.add(
        types.InlineKeyboardButton(f"🔫 Оружие: {w_name[:14]}", callback_data=f"slot_choose_{f_id}_weapon_1"),
        types.InlineKeyboardButton("Снять 🔫", callback_data=f"slot_unequip_{f_id}_weapon")
    )
    # Armor Slot
    markup.add(
        types.InlineKeyboardButton(f"🛡️ Броня: {a_name[:14]}", callback_data=f"slot_choose_{f_id}_armor_1"),
        types.InlineKeyboardButton("Снять 🛡️", callback_data=f"slot_unequip_{f_id}_armor")
    )
    # Helmet Slot
    markup.add(
        types.InlineKeyboardButton(f"🪖 Шлем: {h_name[:14]}", callback_data=f"slot_choose_{f_id}_helmet_1"),
        types.InlineKeyboardButton("Снять 🪖", callback_data=f"slot_unequip_{f_id}_helmet")
    )
    # Headset Slot
    markup.add(
        types.InlineKeyboardButton(f"🎧 Наушники: {hs_name[:14]}", callback_data=f"slot_choose_{f_id}_headset_1"),
        types.InlineKeyboardButton("Снять 🎧", callback_data=f"slot_unequip_{f_id}_headset")
    )

    markup.add(types.InlineKeyboardButton("🔙 К Отряду", callback_data="menu_squad"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_slot_choose(chat_id, msg_id, player, f_id, slot_type, page=1):
    squad = player.get("squad", [])
    fighter = next((f for f in squad if f["id"] == f_id), None)
    if not fighter or fighter.get("type") != "pmc":
        bot.send_message(chat_id, "❌ Экипировать можно только обычных наемников ЧВК!")
        return

    stash = player.get("stash", [])
    matching_items = []

    for itm in stash:
        if itm.get("equipped_to") is None:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            cat = info.get("category")
            sub = info.get("subcategory")
            mcat = info.get("market_cat")
            name_low = info.get("name", "").lower()

            if slot_type == "weapon" and cat == "weapons":
                matching_items.append((itm, info))
            elif slot_type == "helmet" and (sub == "helmet" or "шлем" in name_low or "маска" in name_low or "бандана" in name_low or "капюшон" in name_low or itm.get("item_id") in ["goons_knight_skull_mask", "goons_bigpipe_bandana", "zryachiy_hood_mask"]):
                matching_items.append((itm, info))
            elif slot_type == "armor" and cat == "armor" and sub != "helmet" and "шлем" not in name_low and "маска" not in name_low and "бандана" not in name_low and "капюшон" not in name_low:
                matching_items.append((itm, info))
            elif slot_type == "headset" and (sub == "headset" or mcat == "Наушники" or "наушник" in name_low or "гарнитур" in name_low or "comtac" in name_low or itm.get("item_id") == "goons_birdeye_comtac"):
                matching_items.append((itm, info))

    per_page = 6
    total_pages = max(1, (len(matching_items) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start_idx = (page - 1) * per_page
    page_items = matching_items[start_idx : start_idx + per_page]

    slot_names = {"weapon": "Оружие", "armor": "Бронежилет", "helmet": "Шлем", "headset": "Наушники"}
    txt = (
        f"<b>🎒 СХРОН: {slot_names.get(slot_type, slot_type).upper()} (Стр. {page}/{total_pages})</b>\n"
        f"Выберите предмет для наемника <b>{fighter.get('name')}</b>:\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not page_items:
        txt += "<i>В вашем схроне нет доступных свободных предметов этого типа.</i>\n"
    else:
        for itm, info in page_items:
            r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(info.get("rarity"), "⬜")
            c_val = info.get("combat", 0)
            a_val = info.get("armor", 0)
            if c_val and a_val:
                stat = f"⚔️+{c_val} 🛡️+{a_val}"
            elif c_val:
                stat = f"⚔️+{c_val}"
            else:
                stat = f"🛡️+{a_val}"
            markup.add(
                types.InlineKeyboardButton(
                    f"{r_b} {info.get('name')[:20]} | {stat}",
                    callback_data=f"slot_equip_{f_id}_{slot_type}_{itm['uid']}"
                )
            )

    nav_btns = []
    if page > 1:
        nav_btns.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"slot_choose_{f_id}_{slot_type}_{page-1}"))
    nav_btns.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_btns.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"slot_choose_{f_id}_{slot_type}_{page+1}"))

    if nav_btns:
        markup.row(*nav_btns)

    markup.add(types.InlineKeyboardButton("🔙 К Бойцу", callback_data=f"view_fighter_{f_id}"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_slot_equip(call, player, db, f_id, slot_type, uid):
    squad = player.get("squad", [])
    fighter = next((f for f in squad if f["id"] == f_id), None)
    if not fighter:
        bot.answer_callback_query(call.id, "❌ Боец не найден!")
        return

    if fighter.get("type") != "pmc":
        bot.answer_callback_query(call.id, "❌ Экипировать можно только наемников ЧВК! Снаряжение Босса зафиксировано.", show_alert=True)
        return

    stash = player.get("stash", [])
    item_entry = next((i for i in stash if i.get("uid") == uid), None)
    if not item_entry or item_entry.get("equipped_to") is not None or item_entry.get("is_boss_locked"):
        bot.answer_callback_query(call.id, "❌ Предмет недоступен, уже надет или заблокирован у Босса!", show_alert=True)
        return

    slot_key = f"{slot_type}_uid"
    prev_uid = fighter.get(slot_key)
    if prev_uid:
        prev_entry = next((i for i in stash if i.get("uid") == prev_uid), None)
        if prev_entry:
            prev_entry["equipped_to"] = None

    fighter[slot_key] = uid
    item_entry["equipped_to"] = f_id
    save_db(db)

    info = ITEMS_BY_ID.get(item_entry.get("item_id"), {})
    bot.answer_callback_query(call.id, f"✅ Экипировано: {info.get('name')}")
    handle_view_fighter(call.message.chat.id, call.message.message_id, player, f_id)

def handle_slot_unequip(call, player, db, f_id, slot_type):
    squad = player.get("squad", [])
    fighter = next((f for f in squad if f["id"] == f_id), None)
    if not fighter:
        return

    if fighter.get("type") != "pmc":
        bot.answer_callback_query(call.id, "❌ Нельзя снимать снаряжение у этого бойца! Именное оружие и броня Босса несъемные.", show_alert=True)
        return

    slot_key = f"{slot_type}_uid"
    prev_uid = fighter.get(slot_key)
    if prev_uid:
        stash = player.get("stash", [])
        prev_entry = next((i for i in stash if i.get("uid") == prev_uid), None)
        if prev_entry and prev_entry.get("is_boss_locked"):
            bot.answer_callback_query(call.id, "❌ Нельзя снять именное снаряжение Босса!", show_alert=True)
            return
        if prev_entry:
            prev_entry["equipped_to"] = None
        fighter[slot_key] = None
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Слот освобожден!")
    else:
        bot.answer_callback_query(call.id, "⚠️ Слот и так пуст.")

    handle_view_fighter(call.message.chat.id, call.message.message_id, player, f_id)

def handle_auto_equip(call, player, db):
    try:
        from boss_summon_system import ensure_boss_gear
        ensure_boss_gear(player)
    except Exception:
        pass
    squad = player.get("squad", [])
    if not squad:
        bot.answer_callback_query(call.id, "❌ В отряде нет бойцов!", show_alert=True)
        return

    pmc_fighters = [f for f in squad if f.get("type") == "pmc"]
    if not pmc_fighters:
        bot.answer_callback_query(call.id, "ℹ️ В отряде нет наемников ЧВК для экипировки (у Диких и Сигнатурных сет фиксирован).", show_alert=True)
        return

    stash = player.get("stash", [])

    free_weapons = []
    free_armors = []
    free_helmets = []
    free_headsets = []

    for itm in stash:
        if itm.get("equipped_to") is None:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            cat = info.get("category")
            sub = info.get("subcategory")
            mcat = info.get("market_cat")
            name_low = info.get("name", "").lower()

            if cat == "weapons":
                free_weapons.append((info.get("combat", 0) + info.get("armor", 0), itm))
            elif sub == "helmet" or "шлем" in name_low or "маска" in name_low or "бандана" in name_low or itm.get("item_id") in ["goons_knight_skull_mask", "goons_bigpipe_bandana"]:
                free_helmets.append((info.get("armor", 0) + info.get("combat", 0), itm))
            elif cat == "armor" and sub != "helmet" and "шлем" not in name_low and "маска" not in name_low and "бандана" not in name_low:
                free_armors.append((info.get("armor", 0) + info.get("combat", 0), itm))
            elif sub == "headset" or mcat == "Наушники" or "наушник" in name_low or "гарнитур" in name_low or "comtac" in name_low or itm.get("item_id") == "goons_birdeye_comtac":
                free_headsets.append((info.get("combat", 0) + info.get("armor", 0), itm))

    free_weapons.sort(key=lambda x: x[0], reverse=True)
    free_armors.sort(key=lambda x: x[0], reverse=True)
    free_helmets.sort(key=lambda x: x[0], reverse=True)
    free_headsets.sort(key=lambda x: x[0], reverse=True)

    w_i = a_i = h_i = hs_i = 0
    equipped_count = 0

    for f in pmc_fighters:
        if not f.get("weapon_uid") and w_i < len(free_weapons):
            _, itm = free_weapons[w_i]
            w_i += 1
            f["weapon_uid"] = itm["uid"]
            itm["equipped_to"] = f["id"]
            equipped_count += 1
        if not f.get("armor_uid") and a_i < len(free_armors):
            _, itm = free_armors[a_i]
            a_i += 1
            f["armor_uid"] = itm["uid"]
            itm["equipped_to"] = f["id"]
            equipped_count += 1
        if not f.get("helmet_uid") and h_i < len(free_helmets):
            _, itm = free_helmets[h_i]
            h_i += 1
            f["helmet_uid"] = itm["uid"]
            itm["equipped_to"] = f["id"]
            equipped_count += 1
        if not f.get("headset_uid") and hs_i < len(free_headsets):
            _, itm = free_headsets[hs_i]
            hs_i += 1
            f["headset_uid"] = itm["uid"]
            itm["equipped_to"] = f["id"]
            equipped_count += 1

    save_db(db)
    bot.answer_callback_query(call.id, f"✅ Авто-экипировано {equipped_count} предметов для ЧВК!", show_alert=True)
    handle_menu_squad(call.message.chat.id, call.message.message_id, player)

def handle_hire_fighter(call, player, db, f_type, cost=None):
    max_squad = 6 if has_boss_set_bonus(player, "glukhar") else 5
    if len(player.get("squad", [])) >= max_squad:
        bot.answer_callback_query(call.id, f"❌ Отряд уже полон (макс. {max_squad} бойцов)!", show_alert=True)
        return
    if cost is None:
        cost = get_fighter_hire_cost(player, f_type)
    elif f_type == "scav" and has_buff(player, "scav_discount"):
        cost = int(cost * 0.8)
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно средств! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost

    if f_type == "scav" and is_boss_summon_triggered(player):
        boss_data = get_random_summoned_boss()
        player["pending_boss_summon"] = {
            "boss_id": boss_data["id"],
            "summoned_at": int(time.time())
        }
        save_db(db)
        bot.answer_callback_query(call.id, "⚡ СВЕРХРЕДКИЙ ВЫЗОВ БОССА (Шанс 1%)!", show_alert=True)
        render_boss_summon_screen(call.message.chat.id, call.message.message_id, player, boss_data, bot)
        return

    squad = player.setdefault("squad", [])
    new_id = max([f["id"] for f in squad] + [0]) + 1

    if f_type == "scav":
        # Guaranteed starting 'bomzh-gear' strictly from the database Common pool!
        scav_items, scav_uids = generate_scav_gear(new_id)
        player.setdefault("stash", []).extend(scav_items)
        squad.append({
            "id": new_id,
            "type": "scav",
            "name": f"Дикий #{new_id}",
            "weapon_uid": scav_uids["weapon_uid"],
            "armor_uid": scav_uids["armor_uid"],
            "helmet_uid": scav_uids["helmet_uid"],
            "headset_uid": scav_uids["headset_uid"]
        })
    else:
        squad.append({
            "id": new_id,
            "type": "pmc",
            "name": f"ЧВК #{new_id}",
            "weapon_uid": None,
            "armor_uid": None,
            "helmet_uid": None,
            "headset_uid": None
        })

    save_db(db)
    bot.answer_callback_query(call.id, f"✅ Новый боец нанят за {fmt_rub(cost)}!")
    handle_menu_squad(call.message.chat.id, call.message.message_id, player)

def handle_disband_fighter(call, player, db, f_id):
    squad = player.get("squad", [])
    fighter = next((f for f in squad if f["id"] == f_id), None)
    if not fighter:
        bot.answer_callback_query(call.id, "❌ Боец не найден!")
        return

    stash = player.get("stash", [])
    if fighter.get("type") in ("scav", "boss"):
        # Scav/Boss personal non-detachable gear leaves with them; cannot be kept in stash
        player["stash"] = [itm for itm in stash if itm.get("equipped_to") != f_id]
        msg = f"✅ {fighter.get('name')} покинул ваш отряд со своим личным снаряжением."
    else:
        # PMC gear is returned unequipped to player stash
        for itm in stash:
            if itm.get("equipped_to") == f_id:
                itm["equipped_to"] = None
        msg = f"✅ {fighter.get('name')} уволен, экипировка снята в схрон."

    player["squad"] = [f for f in squad if f["id"] != f_id]
    save_db(db)
    bot.answer_callback_query(call.id, msg)
    handle_menu_squad(call.message.chat.id, call.message.message_id, player)

def handle_prapor_bankruptcy_aid(call, player, db):
    squad = player.get("squad", [])
    scav_cost = get_fighter_hire_cost(player, "scav")
    has_items = any(not itm.get("equipped_to") for itm in player.get("stash", []))
    if len(squad) > 0 or player.get("money", 0) >= scav_cost or has_items:
        bot.answer_callback_query(call.id, "❌ Пособие доступно только при полном банкротстве (0 бойцов, нет денег и снаряжения)!", show_alert=True)
        return
    add_player_rubles(player, 10000)
    save_db(db)
    bot.answer_callback_query(call.id, "📦 Прапор выделил экстренное пособие выживания: +10 000 ₽!", show_alert=True)
    handle_menu_squad(call.message.chat.id, call.message.message_id, player)

# ----------------- SECTION 3: STASH & 5 WAREHOUSES -----------------
def handle_menu_stash(chat_id, msg_id, player, db=None):
    wh = player.get("warehouses", {})
    txt = (
        f"<b>📦 СКЛАДЫ И СХРОН ОПЕРАТОРА ЧВК</b>\n"
        f"────────────────────────\n"
        f"Вместимость ваших 5 специализированных складов и сейфа:\n\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    categories = [
        ("weapons", "🔫 Оружие"),
        ("armor", "🛡️ Броня"),
        ("gear", "🎧 Снаряжение & Наушники"),
        ("components", "🔩 Компоненты"),
        ("valuables", "💼 Ценности и документы")
    ]

    for cat_key, label in categories:
        cap = get_warehouse_capacity(player, cat_key)
        cnt = get_warehouse_count(player, cat_key)
        lvl = wh.get(cat_key, 1)
        txt += f"• <b>{label}:</b> {cnt}/{cap} (Ур. {lvl})\n"
        markup.add(
            types.InlineKeyboardButton(f"📂 Открыть {label}", callback_data=f"stash_cat_{cat_key}_1")
        )
        cost = get_warehouse_upgrade_cost(lvl)
        if cost is not None:
            markup.add(
                types.InlineKeyboardButton(f"🔼 {label} до {lvl+1} ур. | {fmt_rub(cost)}", callback_data=f"upgrade_wh_{cat_key}")
            )

    markup.add(types.InlineKeyboardButton("🗑️ Продать Прапору из всех складов:", callback_data="none"))
    markup.row(
        types.InlineKeyboardButton("⬜ Все Обычные", callback_data="prapor_sell_all_common"),
        types.InlineKeyboardButton("🟦 Все Редкие", callback_data="prapor_sell_all_rare")
    )
    markup.row(
        types.InlineKeyboardButton("🟪 Все Эпические", callback_data="prapor_sell_all_epic"),
        types.InlineKeyboardButton("🟨 Все Легендарные", callback_data="prapor_sell_all_legendary")
    )

    markup.add(types.InlineKeyboardButton("👔 Шмот (Гардероб)", callback_data="stash_clothes_menu"))
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    if db is None:
        db = load_db()
    photo = get_menu_photo("stash", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)

def handle_stash_category(chat_id, msg_id, player, cat_key, page=1):
    db = load_db()
    stash = player.get("stash", [])
    matching = []

    def is_val(info):
        cat = info.get("category", "")
        mcat = info.get("market_cat", "")
        name = info.get("name", "").lower()
        i_id = info.get("id", "").lower()
        return (
            cat in ["relic", "valuable", "valuables"] or
            mcat == "Драгоценности" or
            "keycard" in i_id or
            "ключ-карт" in name or
            "документ" in name or
            "флешк" in name or
            i_id.startswith("relic_")
        )

    for itm in stash:
        info = ITEMS_BY_ID.get(itm.get("item_id"), {})
        if cat_key == "valuables":
            if is_val(info):
                matching.append((itm, info))
        elif cat_key == "gear":
            if info.get("category") == "gear" and not is_val(info):
                matching.append((itm, info))
        elif info.get("category") == cat_key:
            matching.append((itm, info))

    per_page = 6
    total_pages = max(1, (len(matching) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start_idx = (page - 1) * per_page
    page_items = matching[start_idx : start_idx + per_page]

    prapor_rate = 0.40 if has_buff(player, "prapor_bonus") else 0.30

    txt = (
        f"<b>📂 СКЛАД: {WAREHOUSE_NAMES.get(cat_key, cat_key).upper()} (Стр. {page}/{total_pages})</b>\n"
        f"Выкуп Прапора: <b>{int(prapor_rate*100)}%</b> от рыночной стоимости с учетом кризиса\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not page_items:
        txt += "<i>В этом складе нет предметов.</i>\n"
    else:
        for itm, info in page_items:
            r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(info.get("rarity"), "⬜")
            cr_p = get_crisis_price(info.get("price", 10000), info.get("market_cat"), db)
            buyout = int(cr_p * prapor_rate)
            if itm.get("is_boss_locked"):
                eq_status = " 🔒 [Именное снаряжение Босса]"
            elif itm.get("equipped_to"):
                eq_status = f" [Надет #{itm['equipped_to']}]"
            else:
                eq_status = ""

            txt += (
                f"{r_b} <b>{info.get('name')}</b>{eq_status}\n"
                f"   🏷️ Каталог: {fmt_rub(cr_p)} | 💰 Выкуп Прапора: <b>{fmt_rub(buyout)}</b>\n"
            )
            if not itm.get("equipped_to") and not itm.get("is_boss_locked"):
                markup.add(
                    types.InlineKeyboardButton(f"💸 Продать Прапору (+{fmt_rub(buyout)})", callback_data=f"prapor_sell_{itm['uid']}")
                )

    nav_btns = []
    if page > 1:
        nav_btns.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"stash_cat_{cat_key}_{page-1}"))
    nav_btns.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_btns.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"stash_cat_{cat_key}_{page+1}"))

    if nav_btns:
        markup.row(*nav_btns)

    markup.add(types.InlineKeyboardButton(f"🗑️ Продать Прапору из этой категории:", callback_data="none"))
    markup.row(
        types.InlineKeyboardButton("⬜ Обычные", callback_data=f"prapor_sell_cat_{cat_key}_common"),
        types.InlineKeyboardButton("🟦 Редкие", callback_data=f"prapor_sell_cat_{cat_key}_rare")
    )
    markup.row(
        types.InlineKeyboardButton("🟪 Эпические", callback_data=f"prapor_sell_cat_{cat_key}_epic"),
        types.InlineKeyboardButton("🟨 Легендарные", callback_data=f"prapor_sell_cat_{cat_key}_legendary")
    )

    markup.add(types.InlineKeyboardButton("🔙 К Складам", callback_data="menu_stash"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_prapor_sell(call, player, db, uid):
    if uid.startswith("cloth_") or is_clothing_uid(player, uid):
        bot.answer_callback_query(call.id, "❌ Одежду из магазина «Шота у Ашота» нельзя продать! Ее можно только носить или выбросить.", show_alert=True)
        return
    stash = player.get("stash", [])
    entry = next((i for i in stash if i.get("uid") == uid), None)
    if not entry:
        bot.answer_callback_query(call.id, "❌ Предмет не найден!", show_alert=True)
        return
    if entry.get("equipped_to") or entry.get("is_boss_locked"):
        bot.answer_callback_query(call.id, "❌ Нельзя продать именное снаряжение Босса или надетый предмет!", show_alert=True)
        return

    info = ITEMS_BY_ID.get(entry.get("item_id"), {})
    cr_p = get_crisis_price(info.get("price", 10000), info.get("market_cat"), db)
    prapor_rate = 0.40 if has_buff(player, "prapor_bonus") else 0.30
    lav_lvl = player.get("modules", {}).get("lavatory", 0)
    prapor_rate += lav_lvl * 0.01
    try:
        from signature_skills_system import get_signature_skill_bonus
        pmc_k = player.get("pmc_signature", "Viper")
        v_bonus = get_signature_skill_bonus(player, pmc_k, "vendor_sell_bonus")
        prapor_rate += v_bonus
        if is_val(info):
            val_bonus = get_signature_skill_bonus(player, pmc_k, "valuable_sell_bonus")
            prapor_rate += val_bonus
    except Exception:
        pass
    buyout = int(cr_p * prapor_rate)

    stash.remove(entry)
    add_player_rubles(player, buyout)
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"✅ Прапор выкупил {info.get('name')[:18]}!\n💰 Получено: +{fmt_rub(buyout)} ({int(prapor_rate*100)}%)",
        show_alert=True
    )
    handle_stash_category(call.message.chat.id, call.message.message_id, player, info.get("category", "gear"))

def handle_prapor_sell_rarity(call, player, db, cat_key, rarity):
    stash = player.get("stash", [])
    rarity_titles = {
        "common": "Обычные",
        "rare": "Редкие",
        "epic": "Эпические",
        "legendary": "Легендарные"
    }
    r_name = rarity_titles.get(rarity, rarity)

    def is_val(info):
        cat = info.get("category", "")
        mcat = info.get("market_cat", "")
        name = info.get("name", "").lower()
        i_id = info.get("id", "").lower()
        return (
            cat in ["relic", "valuable", "valuables"] or
            mcat == "Драгоценности" or
            "keycard" in i_id or
            "ключ-карт" in name or
            "документ" in name or
            "флешк" in name or
            i_id.startswith("relic_")
        )

    to_sell = []
    for itm in list(stash):
        if itm.get("equipped_to") or itm.get("is_boss_locked"):
            continue
        info = ITEMS_BY_ID.get(itm.get("item_id"), {})
        if info.get("rarity") != rarity:
            continue
        # Protect Boss Relics from bulk sales
        if info.get("category") == "relic" or info.get("id") in RELICS_BY_ID or str(info.get("id", "")).startswith("relic_"):
            continue
        if cat_key:
            if cat_key == "valuables":
                if not is_val(info):
                    continue
            elif cat_key == "gear":
                if info.get("category") != "gear" or is_val(info):
                    continue
            elif info.get("category") != cat_key:
                continue
        to_sell.append((itm, info))

    if not to_sell:
        cat_str = f" в складе '{WAREHOUSE_NAMES.get(cat_key, cat_key)}'" if cat_key else ""
        bot.answer_callback_query(call.id, f"❌ Нет свободных предметов [{r_name}]{cat_str} для продажи!", show_alert=True)
        return

    prapor_rate = 0.40 if has_buff(player, "prapor_bonus") else 0.30
    lav_lvl = player.get("modules", {}).get("lavatory", 0)
    prapor_rate += lav_lvl * 0.01
    try:
        from signature_skills_system import get_signature_skill_bonus
        pmc_k = player.get("pmc_signature", "Viper")
        v_bonus = get_signature_skill_bonus(player, pmc_k, "vendor_sell_bonus")
        prapor_rate += v_bonus
        if is_val(info):
            val_bonus = get_signature_skill_bonus(player, pmc_k, "valuable_sell_bonus")
            prapor_rate += val_bonus
    except Exception:
        pass

    total_buyout = 0
    for itm, info in to_sell:
        cr_p = get_crisis_price(info.get("price", 10000), info.get("market_cat"), db)
        buyout = int(cr_p * prapor_rate)
        total_buyout += buyout
        if itm in stash:
            stash.remove(itm)

    add_player_rubles(player, total_buyout)
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"✅ Прапор выкупил {len(to_sell)} шт. [{r_name}]!\n💰 Выручка: +{fmt_rub(total_buyout)}",
        show_alert=True
    )
    if cat_key:
        handle_stash_category(call.message.chat.id, call.message.message_id, player, cat_key, 1)
    else:
        handle_menu_stash(call.message.chat.id, call.message.message_id, player)

def handle_upgrade_warehouse(call, player, db, cat_key):
    wh = player.setdefault("warehouses", {})
    current_lvl = wh.get(cat_key, 1)
    if current_lvl >= 10:
        bot.answer_callback_query(call.id, "❌ Склад уже максимального 10 уровня!", show_alert=True)
        return

    cost = get_warehouse_upgrade_cost(current_lvl)
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    wh[cat_key] = current_lvl + 1
    save_db(db)

    bot.answer_callback_query(call.id, f"🎉 {WAREHOUSE_NAMES.get(cat_key)} улучшен до {current_lvl + 1} уровня!", show_alert=True)
    handle_menu_stash(call.message.chat.id, call.message.message_id, player)

# ----------------- SECTION 4: FLEA MARKET & P2P -----------------
def handle_menu_market(chat_id, msg_id, player, db=None):
    btc_rate = get_current_btc_rate()
    if has_boss_set_bonus(player, "reshala"):
        tax_rate = 0
    elif has_buff(player, "market_tax"):
        tax_rate = 5
    else:
        tax_rate = 10

    crisis = db.get("economic_crisis", {})

    crisis_txt = ""
    if crisis and crisis.get("expires_at", 0) > time.time():
        crisis_txt = f"\n🚨 <b>АКТИВНЫЙ ЭКОНОМИЧЕСКИЙ КРИЗИС:</b> {crisis.get('headline')}\n"

    reshala_note = " (Сет Решалы: 0% налог! 🔥)" if has_boss_set_bonus(player, "reshala") else ""

    txt = (
        f"<b>🏪 БАРАХОЛКА ТАРКОВА & P2P РЫНОК</b>\n"
        f"────────────────────────\n"
        f"🪙 Курс Bitcoin: <b>{fmt_rub(btc_rate)} / 1 BTC</b>\n"
        f"Баланс BTC: <b>{player.get('btc', 0):.4f} BTC</b>\n"
        f"Комиссия P2P: <b>{tax_rate}%</b>{reshala_note}\n"
        f"{crisis_txt}"
        f"────────────────────────\n"
        f"Выберите категорию товаров магазина Прапора:"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("🔫 Оружие", callback_data="market_cat_Оружие"),
        types.InlineKeyboardButton("🛡️ Броня", callback_data="market_cat_Экипировка")
    )
    markup.add(
        types.InlineKeyboardButton("🪖 Шлемы", callback_data="market_cat_Шлемы"),
        types.InlineKeyboardButton("🎧 Наушники", callback_data="market_cat_Наушники")
    )
    markup.add(
        types.InlineKeyboardButton("💉 Медицина", callback_data="market_cat_Медицина"),
        types.InlineKeyboardButton("💎 Драгоценности", callback_data="market_cat_Драгоценности")
    )
    markup.add(
        types.InlineKeyboardButton("🔩 Компоненты", callback_data="market_cat_Компоненты")
    )

    if player.get("btc", 0) > 0.001:
        markup.add(types.InlineKeyboardButton(f"💰 Продать все BTC | +{fmt_rub(player.get('btc', 0) * btc_rate)}", callback_data="market_sell_btc"))

    markup.add(types.InlineKeyboardButton("👕 Магазин «Шота у Ашота» (Одежда)", callback_data="ashot_shop_main"))
    markup.add(types.InlineKeyboardButton("👕 Магазин «Шота у Ашота» (Одежда)", callback_data="ashot_shop_main"))
    markup.add(types.InlineKeyboardButton("🛒 P2P Торговля Игроков", callback_data="market_p2p"))
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    if db is None:
        db = load_db()
    photo = get_menu_photo("market", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)

def handle_market_catalog(chat_id, msg_id, player, db, cat_name, page=1):
    # Only Common and Rare non-relic items are allowed for sale by Prapor
    eligible = [i for i in ITEMS_LIST if i.get("rarity") in ["common", "rare"] and i.get("category") != "relic"]

    if cat_name == "Шлемы":
        items = [i for i in eligible if i.get("subcategory") == "helmet" or ("шлем" in i.get("name", "").lower() and i.get("category") == "armor")]
    elif cat_name == "Экипировка":
        items = [i for i in eligible if i.get("market_cat") == "Экипировка" and i.get("subcategory") != "helmet" and "шлем" not in i.get("name", "").lower()]
    else:
        items = [i for i in eligible if i.get("market_cat") == cat_name]

    per_page = 6
    total_pages = max(1, (len(items) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start_idx = (page - 1) * per_page
    page_items = items[start_idx : start_idx + per_page]

    crisis = db.get("economic_crisis", {})
    is_crisis_cat = crisis and crisis.get("expires_at", 0) > time.time() and crisis.get("category") == cat_name

    txt = (
        f"<b>🏪 БАРАХОЛКА: {cat_name.upper()} (Стр. {page}/{total_pages})</b>\n"
        f"В наличии у торговца: <b>{len(items)}</b> товаров (Обычные & Редкие)\n"
    )
    if is_crisis_cat:
        sign = "+" if crisis.get("direction") == "surge" else "-"
        txt += f"🚨 <b>КРИЗИС КАТЕГОРИИ:</b> Цены изменены на {sign}{crisis.get('shift_pct')}%\n"
    txt += "────────────────────────\n"

    markup = types.InlineKeyboardMarkup(row_width=1)
    for itm in page_items:
        r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        price = get_crisis_price(itm.get("price", 10000), itm.get("market_cat", cat_name), db)

        txt += f"{r_b} <b>{itm['name']}</b> — <b>{fmt_rub(price)}</b>\n<i>{itm.get('desc', '')}</i>\n\n"
        cat_code = MKT_CAT_TO_CODE.get(cat_name, cat_name)
        markup.add(
            types.InlineKeyboardButton(f"🛒 Купить {itm['name'][:18]} | {fmt_rub(price)}", callback_data=f"mktbuy:{itm['id']}:{cat_code}:{page}")
        )

    nav_buttons = []
    if page > 1:
        nav_buttons.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"market_page_{cat_name}_{page-1}"))
    nav_buttons.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_buttons.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"market_page_{cat_name}_{page+1}"))

    if nav_buttons:
        markup.row(*nav_buttons)

    markup.add(types.InlineKeyboardButton("🔙 К Барахолке", callback_data="menu_market"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_market_buy_action(call, player, db, item_id, cat_name, page):
    try:
        info = ITEMS_BY_ID.get(item_id)
        if not info:
            bot.answer_callback_query(call.id, "❌ Предмет не найден на Барахолке!", show_alert=True)
            return
        if info.get("rarity") not in ["common", "rare"] or info.get("category") == "relic":
            bot.answer_callback_query(call.id, "❌ Прапор продает только Обычные (Common) и Редкие (Rare) предметы! Эпик и Легендарки ищите в рейдах или на P2P!", show_alert=True)
            return
        price = get_crisis_price(info.get("price", 10000), info.get("market_cat", cat_name), db)
        try:
            from signature_skills_system import get_signature_skill_bonus
            pmc_k = player.get("pmc_signature", "Viper")
            disc = get_signature_skill_bonus(player, pmc_k, "shop_discount")
            if disc > 0:
                price = max(100, int(price * (1.0 - disc)))
        except Exception:
            pass
        if player.get("money", 0) < price:
            bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(price)}", show_alert=True)
            return
        cat = info.get("category", "gear")
        if not can_store_item(player, item_id):
            wh_name = WAREHOUSE_NAMES.get(cat, 'Склад')
            bot.answer_callback_query(call.id, f"❌ Склад '{wh_name}' переполнен! Улучшите склад.", show_alert=True)
            return
        player["money"] -= price
        player.setdefault("stash", []).append({
            "uid": f"mkt_{int(time.time())}_{random.randint(100,999)}",
            "item_id": item_id,
            "equipped_to": None
        })
        save_db(db)
        bot.answer_callback_query(call.id, f"✅ Куплено: {info.get('name')} за {fmt_rub(price)}!", show_alert=True)
        handle_market_catalog(call.message.chat.id, call.message.message_id, player, db, cat_name, page)
    except Exception as e:
        logging.error(f"handle_market_buy_action exception: {e}")
        bot.answer_callback_query(call.id, "❌ Ошибка совершения сделки!", show_alert=True)


def handle_sell_btc(call, player, db):
    btc = player.get("btc", 0.0)
    if btc < 0.001:
        bot.answer_callback_query(call.id, "❌ У вас нет Биткоинов для продажи!", show_alert=True)
        return
    rate = get_current_btc_rate()
    rub = int(btc * rate)
    try:
        from signature_skills_system import get_signature_skill_bonus
        pmc_k = player.get("pmc_signature", "Viper")
        btc_b = get_signature_skill_bonus(player, pmc_k, "btc_sell_bonus")
        if btc_b > 0:
            rub = int(rub * (1.0 + btc_b))
    except Exception:
        pass
    add_player_rubles(player, rub)
    player["btc"] = 0.0
    save_db(db)
    bot.answer_callback_query(
        call.id,
        f"✅ Продано {btc:.4f} BTC!\n📊 Курс: {fmt_rub(rate)}\n💰 Получено: +{fmt_rub(rub)}",
        show_alert=True
    )
    handle_menu_market(call.message.chat.id, call.message.message_id, player, db)

def get_p2p_tax_rate(u):
    if not u:
        return 0.10
    if u.get("special_businesses", {}).get("fence_protection"):
        return 0.0
    if has_boss_set_bonus(u, "reshala"):
        return 0.0
    if has_buff(u, "market_tax"):
        return 0.05
    return 0.10

def handle_p2p_market(chat_id, msg_id, player, db, page=1):
    npc_notif = check_npc_p2p_auto_buyout(player, db)
    if npc_notif:
        save_db(db)

    lots = db.get("p2p_market", [])
    tax_pct = get_p2p_tax_rate(player)
    tax_rate = int(tax_pct * 100)

    per_page = 6
    total_pages = max(1, (len(lots) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start_idx = (page - 1) * per_page
    page_lots = lots[start_idx : start_idx + per_page]

    unread = player.pop("notifications", [])
    notif_block = ""
    if unread:
        notif_block = "\n\n".join(unread) + "\n────────────────────────\n"
        save_db(db)

    txt = (
        f"{notif_block}"
        f"<b>🛒 P2P РЫНОК ИГРОКОВ (Стр. {page}/{total_pages})</b>\n"
        f"Комиссия на продажу: <b>{tax_rate}%</b> | Активных лотов: <b>{len(lots)}</b>\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not lots:
        txt += "<i>Сейчас на P2P рынке нет выставленных предметов.</i>\n"
    else:
        for lot in page_lots:
            itm = lot["item"]
            r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
            txt += (
                f"{r_b} <b>{itm['name']}</b>\n"
                f"   💰 Цена покупки: <b>{fmt_rub(lot['price'])}</b>\n"
                f"   👤 Продавец: @{lot.get('seller_name', 'Player')}\n"
            )
            if lot.get("seller_id") != player["user_id"]:
                markup.add(types.InlineKeyboardButton(f"🛒 Купить {itm['name'][:18]} | {fmt_rub(lot['price'])}", callback_data=f"buy_p2p_{lot['lot_id']}"))
            else:
                markup.add(types.InlineKeyboardButton(f"❌ Снять с продажи: {itm['name'][:18]}", callback_data=f"cancel_p2p_{lot['lot_id']}"))

    nav_btns = []
    if page > 1:
        nav_btns.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"p2p_market_page_{page-1}"))
    nav_btns.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_btns.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"p2p_market_page_{page+1}"))

    if nav_btns:
        markup.row(*nav_btns)

    markup.add(
        types.InlineKeyboardButton("📤 Выставить предмет из схрона", callback_data="p2p_list_menu"),
        types.InlineKeyboardButton("🔙 К Барахолке", callback_data="menu_market")
    )
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_p2p_list_menu(chat_id, msg_id, player, db, page=1):
    stash = [i for i in player.get("stash", []) if not i.get("equipped_to") and not i.get("is_boss_locked")]
    tax_pct = get_p2p_tax_rate(player)
    tax_rate = int(tax_pct * 100)

    per_page = 6
    total_pages = max(1, (len(stash) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start_idx = (page - 1) * per_page
    page_items = stash[start_idx : start_idx + per_page]

    txt = (
        f"<b>📤 ВЫСТАВИТЬ ПРЕДМЕТ НА P2P РЫНОК (Стр. {page}/{total_pages})</b>\n"
        f"Комиссия Барахолки: <b>{tax_rate}%</b> | Свободных в схроне: <b>{len(stash)}</b>\n\n"
        f"<i>Выберите предмет из вашего свободного схрона:</i>\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not stash:
        txt += "<i>В вашем схроне нет свободных предметов для выставления.</i>\n"
    else:
        for itm in page_items:
            info = ITEMS_BY_ID.get(itm.get("item_id"))
            if not info:
                continue
            p = get_crisis_price(info.get("price", 10000), info.get("market_cat"), db)
            fee = int(p * tax_pct)
            net = p - fee
            r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(info.get("rarity"), "⬜")
            name_str = info.get("name", "Предмет")[:18]
            markup.add(
                types.InlineKeyboardButton(
                    f"{r_b} {name_str} | {fmt_rub(p)} (Вам: +{fmt_rub(net)})",
                    callback_data=f"p2p_list_{itm['uid']}"
                )
            )

    nav_btns = []
    if page > 1:
        nav_btns.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"p2p_list_page_{page-1}"))
    nav_btns.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_btns.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"p2p_list_page_{page+1}"))

    if nav_btns:
        markup.row(*nav_btns)

    markup.add(types.InlineKeyboardButton("🔙 Назад к P2P", callback_data="market_p2p"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_p2p_list_action(call, player, db, uid):
    if uid.startswith("cloth_") or is_clothing_uid(player, uid):
        bot.answer_callback_query(call.id, "❌ Одежду нельзя выставить на P2P! Ее можно только носить или выбросить.", show_alert=True)
        return
    stash = player.get("stash", [])
    item_entry = next((i for i in stash if i.get("uid") == uid), None)
    if not item_entry or item_entry.get("equipped_to") or item_entry.get("is_boss_locked"):
        bot.answer_callback_query(call.id, "❌ Предмет недоступен для выставки на P2P!", show_alert=True)
        return

    info = ITEMS_BY_ID.get(item_entry.get("item_id"))
    if not info:
        bot.answer_callback_query(call.id, "❌ Неизвестный предмет!", show_alert=True)
        return
    price = get_crisis_price(info.get("price", 10000), info.get("market_cat"), db)
    tax_pct = get_p2p_tax_rate(player)
    fee = int(price * tax_pct)
    net = price - fee

    stash.remove(item_entry)
    db.setdefault("p2p_market", []).append({
        "lot_id": f"lot_{int(time.time())}_{random.randint(100,999)}",
        "seller_id": player["user_id"],
        "seller_name": player.get("username", "PMC"),
        "price": price,
        "item": info
    })
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"✅ Лот выставлен на P2P рынок!\n📦 {info.get('name')}\n🏷️ Цена: {fmt_rub(price)}\n💰 К выплате при покупке: +{fmt_rub(net)}",
        show_alert=True
    )
    handle_p2p_market(call.message.chat.id, call.message.message_id, player, db)

def handle_buy_p2p_lot(call, player, db, lot_id):
    with DB_LOCK:
        if db is None:
            db = load_db()
        player = db["users"].get(str(call.from_user.id), player)
        lots = db.get("p2p_market", [])
        lot = next((l for l in lots if l["lot_id"] == lot_id), None)
        if not lot:
            bot.answer_callback_query(call.id, "❌ Этот лот уже выкуплен другим игроком!", show_alert=True)
            handle_p2p_market(call.message.chat.id, call.message.message_id, player, db)
            return

        if lot.get("seller_id") == player["user_id"]:
            bot.answer_callback_query(call.id, "❌ Вы не можете купить собственный лот! Используйте 'Снять с продажи'.", show_alert=True)
            return

        if player.get("money", 0) < lot["price"]:
            bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(lot['price'])}", show_alert=True)
            return

        item_info = lot["item"]
        if not can_store_item(player, item_info["id"]):
            bot.answer_callback_query(call.id, "❌ Ваш склад переполнен! Улучшите склад.", show_alert=True)
            return

        player["money"] -= lot["price"]
        player.setdefault("stash", []).append({
            "uid": f"p2p_{int(time.time())}_{random.randint(100,999)}",
            "item_id": item_info["id"],
            "equipped_to": None
        })

        # Payout to seller minus tax
        seller_id = str(lot["seller_id"])
        seller = db["users"].get(seller_id)
        tax_pct = get_p2p_tax_rate(seller)
        seller_payout = lot["price"] - int(lot["price"] * tax_pct)
        if seller:
            add_player_rubles(seller, seller_payout)

        lots.remove(lot)
        save_db(db)

    bot.answer_callback_query(call.id, f"🎉 Лот успешно выкуплен! {item_info['name']} отправлен в ваш схрон.", show_alert=True)
    handle_p2p_market(call.message.chat.id, call.message.message_id, player, db)

def handle_cancel_p2p_lot(call, player, db, lot_id):
    with DB_LOCK:
        if db is None:
            db = load_db()
        player = db["users"].get(str(call.from_user.id), player)
        lots = db.get("p2p_market", [])
        lot = next((l for l in lots if l["lot_id"] == lot_id), None)
        if not lot:
            bot.answer_callback_query(call.id, "❌ Лот не найден!")
            return

        if lot.get("seller_id") != player["user_id"]:
            bot.answer_callback_query(call.id, "❌ Это не ваш лот!")
            return

        item_info = lot["item"]
        if not can_store_item(player, item_info["id"]):
            bot.answer_callback_query(call.id, "❌ Ваш склад переполнен! Нельзя вернуть предмет в переполненный схрон.", show_alert=True)
            return

        player.setdefault("stash", []).append({
            "uid": f"ret_{int(time.time())}_{random.randint(100,999)}",
            "item_id": item_info["id"],
            "equipped_to": None
        })
        lots.remove(lot)
        save_db(db)

    bot.answer_callback_query(call.id, f"✅ Лот {item_info['name']} снят с продажи и возвращен в схрон.", show_alert=True)
    handle_p2p_market(call.message.chat.id, call.message.message_id, player, db)

# ----------------- SECTION 5: HIDEOUT & BUSINESSES -----------------
def handle_menu_hideout(chat_id, msg_id, player):
    hlvl = player.get("hideout_lvl", 1)
    mods = player.get("modules", {})
    bizs = player.get("businesses", {})
    h_cost = HIDEOUT_UPGRADE_COSTS.get(hlvl)

    guard_stat = get_guard_status(player)

    txt = (
        f"<b>🏚️ УБЕЖИЩЕ ЧВК & ТЕНЕВЫЕ БИЗНЕСЫ (Уровень {hlvl}/10)</b>\n"
        f"────────────────────────\n"
        f"🛡️ <b>Оборона Базы: {guard_stat['badge']} {guard_stat['title']}</b>\n"
        f"<i>{guard_stat['desc']}</i>\n\n"
        f"<b>Статус модулей Убежища:</b>\n"
    )
    for m_key, m_name in MODULE_NAMES.items():
        m_lvl = mods.get(m_key, 0)
        eff_desc = MODULE_EFFECTS.get(m_key, "")
        txt += f"• {m_name}: <b>Ур. {m_lvl}/{hlvl}</b>\n  └ <i>{eff_desc}</i>\n"

    txt += "\n<b>Теневые бизнесы (пассивный доход ₽/час):</b>\n"
    if player.get("businesses_blocked") or player.get("is_base_captured"):
        txt += "🚨 <i>ВНИМАНИЕ: Все предприятия заблокированы рейдерами Отступников! Доход не поступает.</i>\n"

    total_rub_hr = 0
    for b_key, b_name in BUSINESS_NAMES.items():
        b_lvl = bizs.get(b_key, 0)
        hr_p = get_business_hourly_income(b_key, b_lvl, user=player)
        if has_buff(player, "business_income"):
            hr_p = int(hr_p * 1.15)
        total_rub_hr += hr_p
        txt += f"• {b_name}: <b>Ур. {b_lvl}/{hlvl}</b> (+{fmt_rub(hr_p)}/час)\n"

    spec_inc, spec_items = get_special_businesses_income(player)
    total_rub_hr += spec_inc
    if spec_items:
        txt += "\n<b>🏢 Элитные бизнес-объекты:</b>\n"
        for s_name, s_p in spec_items:
            txt += f"• {s_name}: <b>В строю</b> (+{fmt_rub(s_p)}/час)\n"

    btc_hr = get_mining_hourly_btc(mods.get("mining_farm", 0), user=player)
    if has_buff(player, "btc_bonus"):
        btc_hr = round(btc_hr * 1.15, 4)
    txt += f"• ⛏️ Майнинг-ферма BTC: <b>+{btc_hr} BTC/час</b>\n"
    txt += f"────────────────────────\nСуммарный доход: <b>+{fmt_rub(total_rub_hr)}/час</b>"

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("🏢 Элитные Бизнесы (3)", callback_data="menu_special_businesses"),
        types.InlineKeyboardButton("🎖️ Боевой Пропуск GD", callback_data="menu_gd_battlepass")
    )
    markup.add(types.InlineKeyboardButton(f"{guard_stat['badge']} Охрана Базы & Контракты", callback_data="menu_base_guard"))

    if player.get("is_base_captured"):
        markup.add(types.InlineKeyboardButton("⚔️ Штурмовать базу (Спецоперация)", callback_data="base_assault"))
        markup.add(types.InlineKeyboardButton("🤝 Откуп у Скупщика (1 BTC + 40% ₽)", callback_data="base_fence_buyout"))

    if h_cost:
        markup.add(types.InlineKeyboardButton(f"🔼 Улучшить Убежище до {hlvl+1} ур. ({fmt_rub(h_cost)})", callback_data="upgrade_hideout"))

    for m_key, m_name in MODULE_NAMES.items():
        m_lvl = mods.get(m_key, 0)
        if m_lvl < hlvl and m_lvl < 10:
            c = get_module_upgrade_cost(m_lvl)
            markup.add(types.InlineKeyboardButton(f"⚙️ {m_name} {m_lvl+1} ур. ({fmt_rub(c)})", callback_data=f"upgrade_module_{m_key}"))

    for b_key, b_name in BUSINESS_NAMES.items():
        b_lvl = bizs.get(b_key, 0)
        if b_lvl < hlvl and b_lvl < 10:
            c = get_business_upgrade_cost(b_key, b_lvl)
            if c:
                markup.add(types.InlineKeyboardButton(f"💼 {b_name[:14]} {b_lvl+1} ур. ({fmt_rub(c)})", callback_data=f"upgrade_biz_{b_key}"))

    markup.add(types.InlineKeyboardButton("🎁 Забрать Накопленный Доход", callback_data="claim_income"))
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_menu_special_businesses(chat_id, msg_id, player, db=None):
    if db is None:
        db = load_db()

    # Check auto-buyout
    npc_notif = check_npc_p2p_auto_buyout(player, db)
    if npc_notif:
        save_db(db)

    spec = player.get("special_businesses", {})
    has_fleet = spec.get("smugglers_fleet", False)
    has_fence = spec.get("fence_protection", False)
    has_gd = spec.get("gd_shadow_agent", False)
    has_d2_mine = spec.get("d2_underground_btc_mine", False)

    fleet_inc = 1500000
    fence_inc = 3500000
    gd_inc = 25000000
    d2_inc = 15000000
    mods = player.get("modules", {})
    gen_bonus = mods.get("generator", 0) * 0.03
    water_bonus = mods.get("water_collector", 0) * 0.02
    mult = 1.0 + gen_bonus + water_bonus
    if has_boss_set_bonus(player, "reshala"):
        mult *= 1.5
    if has_buff(player, "business_income"):
        mult *= 1.15

    eff_fleet = int(fleet_inc * mult)
    eff_fence = int(fence_inc * mult)
    eff_gd = int(gd_inc * mult)
    eff_d2 = int(d2_inc * mult)

    fleet_status = "🟢 <b>Построен и функционирует</b>" if has_fleet else "🔴 <b>Не построен</b>"
    fence_status = "🟢 <b>Доля оформлена (Активна)</b>" if has_fence else "🔴 <b>Не приобретена</b>"
    gd_status = "🟢 <b>Контракт Синдиката заключен (Активен)</b>" if has_gd else "🔴 <b>Не нанят</b>"
    d2_status = "🟢 <b>Построена и функционирует</b>" if has_d2_mine else "🔴 <b>Не построена</b>"

    last_b = player.get("last_npc_p2p_buyout", 0)
    now = int(time.time())
    cooldown = 3 * 3600
    if not has_fence:
        buyout_status = "<i>(Требуется покупка доли)</i>"
    elif last_b == 0 or (now - last_b >= cooldown):
        buyout_status = "🟢 <b>Готов к выкупу</b> (выставьте лот на P2P)"
    else:
        rem = cooldown - (now - last_b)
        h = rem // 3600
        m = (rem % 3600) // 60
        buyout_status = f"⏳ До следующего автовыкупа: <b>{h}ч {m}мин</b>"

    bp_state = get_gd_bp_state(player)
    bp_lvl = bp_state.get("level", 1)
    bp_exp = bp_state.get("current_exp", 0)
    unclaimed_cnt = get_unclaimed_rewards_count(player)

    unread = player.pop("notifications", [])
    notif_block = ""
    if unread:
        notif_block = "\n\n".join(unread) + "\n────────────────────────\n"
        save_db(db)

    txt = (
        f"{notif_block}"
        f"<b>🏢 ЭЛИТНЫЕ БИЗНЕС-ОБЪЕКТЫ СИНДИКАТА</b>\n"
        f"────────────────────────\n"
        f"Стратегические предприятия высшего эшелона с уникальными привилегиями и колоссальным пассивным доходом.\n\n"
        f"1️⃣ 🚚 <b>Автопарк «Контрабандисты Резерва»</b>\n"
        f"• Статус: {fleet_status}\n"
        f"• Стоимость постройки: <b>200 000 000 ₽</b>\n"
        f"• Пассивный доход: <b>+{fmt_rub(eff_fleet)}/час</b>\n"
        f"• ⚡ <b>Особая механика:</b> Контрабандный груз (Канал снабжения) едет <b>втрое (3x) быстрее</b>!\n"
        f"• <i>Описание: Собственный моторизованный парк тяжелых армейских тягачей и бронегрузовиков на конспиративной базе Резерва.</i>\n\n"
        f"────────────────────────\n\n"
        f"2️⃣ 💼 <b>Доля в бизнесе Скупщика («Крышевание Барахолки»)</b>\n"
        f"• Статус: {fence_status}\n"
        f"• Стоимость покупки: <b>500 000 000 ₽</b>\n"
        f"• Пассивный доход: <b>+{fmt_rub(eff_fence)}/час</b>\n"
        f"• ⚡ <b>Механика 1 (Удаление налога):</b> <b>0% налог/комиссия</b> бота при выставлении любых личных лотов на P2P-барахолку!\n"
        f"• ⚡ <b>Механика 2 (Автовыкуп лотов):</b> Раз в 3 часа богатый теневой NPC <b>автоматически выкупает 1 ваш активный лот</b> на P2P с полной выплатой!\n"
        f"• ⏱️ Статус автовыкупа: {buyout_status}\n"
        f"• <i>Описание: Прямой теневой контроль над Барахолкой Таркова под личной протекцией Скупщика.</i>\n\n"
        f"────────────────────────\n\n"
        f"3️⃣ 🛰️ <b>Теневой сотрудник GD Military</b>\n"
        f"• Статус: {gd_status}\n"
        f"• Стоимость контракта: <b>5 000 000 000 ₽ (5 млрд)</b>\n"
        f"• Пассивный доход: <b>+{fmt_rub(eff_gd)}/час</b>\n"
        f"• ⚡ <b>Механика 1 (Боевой Пропуск):</b> Сезонный пропуск на <b>150 уровней</b> (награды за рейды, 26 видов оружия, титулы, BTC)!\n"
        f"• ⚡ <b>Механика 2 (Спутниковый радар GD):</b> <b>+15% к выживанию</b> в рейдах и <b>-35% шанс засад боссов</b>!\n"
        f"• ⚡ <b>Механика 3 (Арсенал дропа):</b> Разблокировка дропа <b>26 видов элитного оружия GD</b> во всех рейдах!\n"
        f"• 🏆 Текущий уровень пропуска: <b>{bp_lvl} / 150</b> (Опыт: {bp_exp:,} XP)\n"
        f"• <i>Описание: Высший теневой контракт частной военной корпорации GD Military. Полный доступ к закрытым спутниковым системам и элитным каналам снабжения.</i>\n\n"
        f"────────────────────────\n\n"
        f"4️⃣ ⚡ <b>Подземная Биткоин-шахта в бункере Д-2</b>\n"
        f"• Статус: {d2_status}\n"
        f"• Стоимость постройки: <b>2 500 000 000 ₽ (2.5 млрд)</b>\n"
        f"• Пассивный доход: <b>+{fmt_rub(eff_d2)}/час</b>\n"
        f"• ⚡ <b>Особая механика:</b> <b>Удвоение добычи биткоина фермы (x2 BTC)</b> благодаря подземным реакторам бункера!\n"
        f"• <i>Описание: Сверхмощный вычислительный дата-центр и шахта в глубинах гермобункера Д-2 военной базы Резерв.</i>\n"
        f"────────────────────────\n"
        f"💰 Ваш баланс: <b>{fmt_rub(player.get('money', 0))}</b>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not has_fleet:
        markup.add(types.InlineKeyboardButton("🚚 Построить Автопарк (200 000 000 ₽)", callback_data="buy_spec_smugglers_fleet"))
    else:
        markup.add(types.InlineKeyboardButton("✅ Автопарк в строю (+1.5M ₽/ч | Снабжение x3)", callback_data="none"))

    if not has_fence:
        markup.add(types.InlineKeyboardButton("💼 Купить Долю Скупщика (500 000 000 ₽)", callback_data="buy_spec_fence_protection"))
    else:
        markup.add(types.InlineKeyboardButton("✅ Крышевание Барахолки активно (+3.5M ₽/ч | Налог 0%)", callback_data="none"))

    if not has_gd:
        markup.add(types.InlineKeyboardButton("🛰️ Нанять Сотрудника GD (5 000 000 000 ₽)", callback_data="buy_spec_gd_shadow_agent"))
    else:
        bp_btn_label = f"🎖️ Открыть Боевой Пропуск GD ({bp_lvl}/150)"
        if unclaimed_cnt > 0:
            bp_btn_label += f" [🎁 {unclaimed_cnt}]"
        markup.add(types.InlineKeyboardButton(bp_btn_label, callback_data="menu_gd_battlepass"))
        markup.add(types.InlineKeyboardButton("✅ Контракт GD активен (+25M ₽/ч | Радар)", callback_data="none"))

    if not has_d2_mine:
        markup.add(types.InlineKeyboardButton("⚡ Построить Биткоин-шахту Д-2 (2 500 000 000 ₽)", callback_data="buy_spec_d2_underground_btc_mine"))
    else:
        markup.add(types.InlineKeyboardButton("✅ Шахта Д-2 в строю (+15M ₽/ч | 2x BTC)", callback_data="none"))

    markup.add(
        types.InlineKeyboardButton("🔙 Назад в Убежище", callback_data="menu_hideout"),
        types.InlineKeyboardButton("🏠 Главное Меню", callback_data="main_menu")
    )

    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception as e:
        logging.error(f"handle_menu_special_businesses error: {e}")

def handle_buy_special_business(call, player, db, biz_id):
    spec = player.setdefault("special_businesses", {})
    if biz_id == "smugglers_fleet":
        if spec.get("smugglers_fleet"):
            bot.answer_callback_query(call.id, "❌ Автопарк уже построен!", show_alert=True)
            return
        cost = 200_000_000
        if player.get("money", 0) < cost:
            bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
            return
        player["money"] -= cost
        spec["smugglers_fleet"] = True
        save_db(db)
        bot.answer_callback_query(
            call.id,
            "🎉 Поздравляем! Автопарк «Контрабандисты Резерва» построен!\n"
            "• Доход: +1 500 000 ₽/час\n"
            "• Контрабандный груз едет втрое (3x) быстрее!",
            show_alert=True
        )
    elif biz_id == "fence_protection":
        if spec.get("fence_protection"):
            bot.answer_callback_query(call.id, "❌ Доля в бизнесе Скупщика уже оформлена!", show_alert=True)
            return
        cost = 500_000_000
        if player.get("money", 0) < cost:
            bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
            return
        player["money"] -= cost
        spec["fence_protection"] = True
        player["last_npc_p2p_buyout"] = int(time.time())
        save_db(db)
        bot.answer_callback_query(
            call.id,
            "🎉 Поздравляем! Доля в бизнесе Скупщика оформлена!\n"
            "• Доход: +3 500 000 ₽/час\n"
            "• Налог P2P-барахолки: 0%\n"
            "• Автовыкуп лотов богатым NPC каждые 3 часа!",
            show_alert=True
        )
    elif biz_id == "gd_shadow_agent":
        if spec.get("gd_shadow_agent"):
            bot.answer_callback_query(call.id, "❌ Контракт с GD Military уже оформлен!", show_alert=True)
            return
        cost = 5_000_000_000
        if player.get("money", 0) < cost:
            bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)} (5 млрд ₽)", show_alert=True)
            return
        player["money"] -= cost
        spec["gd_shadow_agent"] = True
        st = get_gd_bp_state(player)
        if 1 not in st.get("claimed_levels", []):
            _apply_level_reward(player, 1, GD_BATTLEPASS_LEVELS[0])
        save_db(db)
        bot.answer_callback_query(
            call.id,
            "🎉 Поздравляем! Заключен высший контракт «Теневой сотрудник GD Military»!\n"
            "• Доход: +25 000 000 ₽/час\n"
            "• Открыт Боевой Пропуск на 150 уровней!\n"
            "• Спутниковый радар рейдов активирован (+15% выживание, -35% засады боссов)!\n"
            "• Открыт дроп 26 видов оружия GD во всех рейдах!",
            show_alert=True
        )
    elif biz_id == "d2_underground_btc_mine":
        if spec.get("d2_underground_btc_mine"):
            bot.answer_callback_query(call.id, "❌ Подземная Биткоин-шахта уже построена!", show_alert=True)
            return
        cost = 2_500_000_000
        if player.get("money", 0) < cost:
            bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)} (2.5 млрд ₽)", show_alert=True)
            return
        player["money"] -= cost
        spec["d2_underground_btc_mine"] = True
        save_db(db)
        bot.answer_callback_query(
            call.id,
            "🎉 Поздравляем! Развернута «Подземная Биткоин-шахта в бункере Д-2»!\n"
            "• Доход: +15 000 000 ₽/час\n"
            "• Ферма Биткоинов: добыча ускорена в 2 раза (x2 BTC)!",
            show_alert=True
        )
    handle_menu_special_businesses(call.message.chat.id, call.message.message_id, player, db)

def handle_menu_gd_battlepass(chat_id, msg_id, player, db=None):
    if db is None:
        db = load_db()
    txt, markup = render_bp_main_menu(player)
    try:
        if msg_id:
            bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
        else:
            bot.send_message(chat_id, txt, reply_markup=markup)
    except Exception as e:
        logging.error(f"handle_menu_gd_battlepass error: {e}")

def handle_gd_bp_stage_view(chat_id, msg_id, player, db=None, stage_num=1):
    if db is None:
        db = load_db()
    txt, markup = render_bp_stage_view(player, stage_num)
    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception as e:
        logging.error(f"handle_gd_bp_stage_view error: {e}")

def handle_gd_bp_levels_page(chat_id, msg_id, player, db=None, page=1):
    if db is None:
        db = load_db()
    txt, markup = render_bp_levels_page(player, page)
    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception as e:
        logging.error(f"handle_gd_bp_levels_page error: {e}")

def handle_gd_bp_weapons_page(chat_id, msg_id, player, db=None, page=1):
    if db is None:
        db = load_db()
    txt, markup = render_bp_weapons_page(page)
    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception as e:
        logging.error(f"handle_gd_bp_weapons_page error: {e}")

def handle_gd_bp_claim_all(call, player, db):
    count, claimed_titles = claim_all_unclaimed_rewards(player)
    if count == 0:
        bot.answer_callback_query(call.id, "ℹ️ Все доступные награды вашего уровня уже получены!", show_alert=True)
        return
    save_db(db)
    summary_text = "\n".join(claimed_titles[:5])
    if len(claimed_titles) > 5:
        summary_text += f"\n...и еще {len(claimed_titles) - 5} наград!"
    bot.answer_callback_query(
        call.id,
        f"🎉 Успешно получено наград: {count} шт.!\n{summary_text}",
        show_alert=True
    )
    handle_menu_gd_battlepass(call.message.chat.id, call.message.message_id, player, db)

# ----------------- PASSIVES & TITLES HANDLERS -----------------
def handle_menu_passives(chat_id, msg_id, player, db=None, tab="summary", page=1):
    if db is None:
        db = load_db()
    txt, markup = render_passives_menu(player, db, tab=tab, page=page)
    try:
        if msg_id:
            bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
        else:
            bot.send_message(chat_id, txt, reply_markup=markup)
    except Exception as e:
        logging.error(f"handle_menu_passives error: {e}")
        bot.send_message(chat_id, txt, reply_markup=markup)

def handle_menu_titles(chat_id, msg_id, player, page=1):
    txt, markup = render_titles_menu(player, page=page)
    _safe_edit_or_send(txt, chat_id, msg_id, markup)

def handle_menu_all_titles(chat_id, msg_id, player, page=1):
    txt, markup = render_all_titles_catalog(player, page=page)
    _safe_edit_or_send(txt, chat_id, msg_id, markup)

def handle_select_title(call, player, db, title_name):
    real_name = resolve_title_from_id(player, title_name) or title_name
    success = equip_title(player, real_name)
    if success:
        save_db(db)
        bot.answer_callback_query(call.id, f"✅ Вы надели титул: {real_name}!", show_alert=False)
    else:
        bot.answer_callback_query(call.id, "❌ Этот титул еще не разблокирован!", show_alert=True)
    handle_menu_titles(call.message.chat.id, call.message.message_id, player, page=1)

def handle_unselect_title(call, player, db):
    unequip_title(player)
    save_db(db)
    bot.answer_callback_query(call.id, "✅ Особый титул снят. Отображается стандартный ранг.", show_alert=False)
    handle_menu_titles(call.message.chat.id, call.message.message_id, player, page=1)

def handle_menu_bot_stats(chat_id, msg_id, player, db=None):
    if db is None:
        db = load_db()
    txt, markup = render_bot_stats(player, db)
    _safe_edit_or_send(txt, chat_id, msg_id, markup)

def handle_menu_prestige(chat_id, msg_id, player, view_tier=None):
    txt, markup = render_prestige_menu(player, view_tier=view_tier)
    _safe_edit_or_send(txt, chat_id, msg_id, markup)

def handle_prestige_confirm(chat_id, msg_id, player, target_tier):
    txt, markup = render_prestige_confirm(player, target_tier)
    _safe_edit_or_send(txt, chat_id, msg_id, markup)

def handle_prestige_execute(call, player, db, target_tier):
    success = execute_prestige_reset(player, target_tier)
    if success:
        save_db(db)
        cfg = PRESTIGE_TIERS.get(target_tier, {})
        bot.answer_callback_query(call.id, f"🎉 Поздравляем! Вы достигли {cfg.get('name')}!", show_alert=True)
        handle_menu_profile(call.message.chat.id, call.message.message_id, player)
    else:
        bot.answer_callback_query(call.id, "❌ Не удалось выполнить переход на престиж. Проверьте требования!", show_alert=True)

def handle_menu_prestige_mastery(chat_id, msg_id, player):
    txt, markup = render_prestige_mastery_menu(player)
    _safe_edit_or_send(txt, chat_id, msg_id, markup)

def handle_prestige_alloc(call, player, db, skill_id):
    ok, msg = allocate_prestige_skill(player, skill_id)
    if ok:
        save_db(db)
        bot.answer_callback_query(call.id, f"✅ {msg}", show_alert=False)
        handle_menu_prestige_mastery(call.message.chat.id, call.message.message_id, player)
    else:
        bot.answer_callback_query(call.id, f"❌ {msg}", show_alert=True)

def handle_prestige_reset_mastery(call, player, db):
    ok, msg = reset_prestige_skills(player)
    if ok:
        save_db(db)
        bot.answer_callback_query(call.id, f"🔄 {msg}", show_alert=True)
        handle_menu_prestige_mastery(call.message.chat.id, call.message.message_id, player)
    else:
        bot.answer_callback_query(call.id, f"❌ {msg}", show_alert=True)

def handle_menu_prestige_black_raid(chat_id, msg_id, player):
    txt, markup = render_prestige_black_raid_menu(player)
    _safe_edit_or_send(txt, chat_id, msg_id, markup)

def handle_prestige_launch_black_raid(call, player, db):
    success, res = execute_prestige_black_raid(player)
    if not success:
        bot.answer_callback_query(call.id, f"❌ {res.get('reason', 'Ошибка высадки')}", show_alert=True)
        return
    save_db(db)
    bot.answer_callback_query(call.id, "👑 Черный Рейд Смотрителя успешно завершен!", show_alert=True)

    items_list_str = "\n".join([f"  • {name}" for name in res["items_names"]]) if res["items_names"] else "  • Схрон был переполнен"
    btc_str = f"\n• 🪙 Найден чистый Bitcoin: <b>+{res['btc_found']:.1f} BTC!</b>" if res["btc_found"] > 0 else ""

    txt = (
        f"👑 <b>ЧЕРНЫЙ РЕЙД СМОТРИТЕЛЯ: ТРИУМФ ОПЕРАЦИИ!</b>\n"
        f"────────────────────────\n"
        f"{res['sniper_log']}"
        f"Отряд Смотрителя обеспечил чистый коридор через минные поля и мост Маяка. "
        f"Все ключевые склады были вскрыты под плотным прикрытием снайперов.\n\n"
        f"💰 <b>Захваченные рубли:</b> +<b>{fmt_rub(res['rubles'])}</b>\n"
        f"🎖️ <b>Полученный опыт:</b> +<b>{res['exp']} EXP</b>"
        f"{btc_str}\n\n"
        f"📦 <b>Эвакуированное снаряжение:</b>\n"
        f"{items_list_str}\n"
        f"────────────────────────\n"
        f"<i>Следующий Черный Рейд будет доступен через 20 часов.</i>"
    )
    markup = types.InlineKeyboardMarkup(row_width=1).add(
        types.InlineKeyboardButton("👁️ Вернуться к Зрячему", callback_data="menu_zryachiy"),
        types.InlineKeyboardButton("📦 Открыть Схрон", callback_data="menu_stash")
    )
    _safe_edit_or_send(txt, call.message.chat.id, call.message.message_id, markup)


def handle_upgrade_hideout(call, player, db):
    hlvl = player.get("hideout_lvl", 1)
    cost = HIDEOUT_UPGRADE_COSTS.get(hlvl)
    if not cost or hlvl >= 10:
        bot.answer_callback_query(call.id, "❌ Убежище уже максимального уровня!", show_alert=True)
        return
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    player["hideout_lvl"] = hlvl + 1
    save_db(db)
    bot.answer_callback_query(call.id, f"🎉 Убежище прокачано до {hlvl + 1} уровня!", show_alert=True)
    handle_menu_hideout(call.message.chat.id, call.message.message_id, player)

def handle_upgrade_module(call, player, db, mod_key):
    hlvl = player.get("hideout_lvl", 1)
    mods = player.setdefault("modules", {})
    cur_lvl = mods.get(mod_key, 0)
    if cur_lvl >= hlvl:
        bot.answer_callback_query(call.id, f"❌ Модуль ограничен уровнем Убежища ({hlvl})! Сначала прокачайте Убежище.", show_alert=True)
        return
    cost = get_module_upgrade_cost(cur_lvl)
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    mods[mod_key] = cur_lvl + 1
    save_db(db)
    bot.answer_callback_query(call.id, f"✅ Модуль {MODULE_NAMES.get(mod_key)} прокачан до {cur_lvl + 1} ур.!")
    handle_menu_hideout(call.message.chat.id, call.message.message_id, player)

def handle_upgrade_business(call, player, db, biz_key):
    hlvl = player.get("hideout_lvl", 1)
    bizs = player.setdefault("businesses", {})
    cur_lvl = bizs.get(biz_key, 0)
    if cur_lvl >= hlvl:
        bot.answer_callback_query(call.id, f"❌ Бизнес ограничен уровнем Убежища ({hlvl})! Сначала прокачайте Убежище.", show_alert=True)
        return
    cost = get_business_upgrade_cost(biz_key, cur_lvl)
    if not cost or player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    bizs[biz_key] = cur_lvl + 1
    save_db(db)
    bot.answer_callback_query(call.id, f"✅ {BUSINESS_NAMES.get(biz_key)} расширен до {cur_lvl + 1} уровня!")
    handle_menu_hideout(call.message.chat.id, call.message.message_id, player)

def handle_claim_income(call, player, db):
    if player.get("businesses_blocked") or player.get("is_base_captured"):
        bot.answer_callback_query(
            call.id,
            "🚨 ДОХОД ЗАБЛОКИРОВАН! База захвачена Отступниками. Бандиты заблокировали предприятия и забирают прибыль себе! Освободите базу в Убежище.",
            show_alert=True
        )
        return

    now = int(time.time())
    last_claim = player.get("last_income_claim", now)
    diff = max(0, min(now - last_claim, 86400)) # Up to 24h offline pool
    if diff < 60:
        bot.answer_callback_query(call.id, "⏳ Доход начисляется поминутно! Подождите немного.", show_alert=True)
        return

    hours = diff / 3600.0
    bizs = player.get("businesses", {})
    mods = player.get("modules", {})

    total_rub_hr = 0
    for b_key in BUSINESS_NAMES:
        lvl = bizs.get(b_key, 0)
        p = get_business_hourly_income(b_key, lvl, user=player)
        if has_buff(player, "business_income"):
            p = int(p * 1.15)
        total_rub_hr += p

    spec_inc, _ = get_special_businesses_income(player)
    total_rub_hr += spec_inc

    earned_rubles = int(total_rub_hr * hours)

    btc_hr = get_mining_hourly_btc(mods.get("mining_farm", 0), user=player)
    if has_buff(player, "btc_bonus"):
        btc_hr = round(btc_hr * 1.15, 4)
    earned_btc = round(btc_hr * hours, 4)

    if earned_rubles == 0 and earned_btc == 0.0:
        bot.answer_callback_query(call.id, "⚠️ У вас еще нет работающих бизнесов или фермы! Постройте их в Убежище.", show_alert=True)
        return

    add_player_rubles(player, earned_rubles)
    player["btc"] = round(player.get("btc", 0.0) + earned_btc, 4)
    player["last_income_claim"] = now
    save_db(db)

    mins = int(diff // 60)
    bot.answer_callback_query(
        call.id,
        f"🎁 Доход собран за {mins} мин. работы!\n💰 +{fmt_rub(earned_rubles)}\n🪙 +{earned_btc:.4f} BTC",
        show_alert=True
    )
    show_main_menu(call.message.chat.id, player)

# ----------------- BASE GUARD & SECURITY HANDLERS -----------------
def handle_menu_base_guard(chat_id, msg_id, player, db=None):
    try:
        auto_del, _ = check_zryachiy_daily_supply(player)
        if auto_del:
            save_db(db)
    except Exception:
        pass

    guard_stat = get_guard_status(player)
    txt = (
        f"<b>🛡️ СИСТЕМА ОХРАНЫ БАЗЫ ЧВК</b>\n"
        f"────────────────────────\n"
        f"Статус охраны: <b>{guard_stat['badge']} {guard_stat['title']}</b>\n"
        f"<i>{guard_stat['desc']}</i>\n\n"
    )

    if has_mythic_item(player, "mythic_dsp_sensor"):
        txt += (
            "✨ <b>ВЕЧНЫЙ СНАЙПЕРСКИЙ ДОЗОР ЗРЯЧЕГО АКТИВЕН!</b>\n"
            "Благодаря <b>📟 Закодированному датчику DSP Смотрителя</b> все ваши территории и база ЧВК находятся под 100% постоянной защитой Зрячего.\n"
            "Покупка контрактов охраны больше не требуется — база неуязвима для мародеров и захватов!\n\n"
            "📦 <i>Каждые 24 часа Зрячий автоматически поставляет в ваш схрон 3 именных предмета экипировки.</i>"
        )
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("👁️ Дозор Зрячего (Маяк)", callback_data="menu_zryachiy"),
            types.InlineKeyboardButton("🔙 Назад в Убежище", callback_data="menu_hideout")
        )
        if db is None:
            db = load_db()
        photo = get_menu_photo("base_guard", db)
        _safe_send_photo(photo, txt, chat_id, msg_id, markup)
        return

    if player.get("is_base_captured"):
        txt += (
            "🚨 <b>БАЗА ПОД КОНТРОЛЕМ ОТСТУПНИКОВ (ROGUES)!</b>\n"
            "Все 4 теневых бизнеса захвачены. Пассивный доход перехвачен бандитами.\n"
            "Склады повреждены огнем.\n\n"
            "<b>Варианты возвращения базы:</b>\n"
            "1. <b>«Спецоперация: Штурм базы»</b>: Кровавый бой вашего отряда с боссом рейдеров. При победе — освобождение базы, возврат части награбленного (включая BTC и рубли) и трофейный легендарный лут! При поражении — гибель Диких и потеря оружия/брони ЧВК.\n"
            "2. <b>«Откуп у Скупщика»</b>: Мирное решение через связи Скупщика. Фиксированная плата: <b>40% всех ваших денег</b> (не менее 1 000 000 ₽) + <b>1.0 BTC</b>. База и бизнесы возвращаются мгновенно, но сгоревшие уровни складов не восстанавливаются."
        )
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("⚔️ Начать Штурм Базы (Бой отряда)", callback_data="base_assault"),
            types.InlineKeyboardButton("🤝 Откупиться через Скупщика (1 BTC + 40% ₽)", callback_data="base_fence_buyout"),
            types.InlineKeyboardButton("🔙 Назад в Убежище", callback_data="menu_hideout")
        )
        if db is None:
            db = load_db()
        photo = get_menu_photo("base_guard", db)
        _safe_send_photo(photo, txt, chat_id, msg_id, markup)
        return

    incidents = player.get("security_incidents", [])
    if incidents:
        txt += "<b>Последние происшествия на периметре:</b>\n"
        for inc in incidents[-3:]:
            txt += f"• <i>{inc}</i>\n"
        txt += "\n"

    txt += (
        "<b>Доступные контракты охраны:</b>\n"
        "<i>Каждый контракт гарантирует полную защиту от проникновения мародеров и рейдеров.</i>\n\n"
    )
    for c_key, c_info in BASE_GUARD_CONTRACTS.items():
        dur_h = c_info["duration"] // 3600
        txt += f"• {c_info['icon']} <b>{c_info['name']}</b>\n  ├ Срок: <b>{dur_h} ч.</b> | Стоимость: <b>{fmt_rub(c_info['cost'])}</b>\n  └ <i>{c_info['desc']}</i>\n\n"

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🤠 Сторож-Дикий (15 000 ₽ / 3ч)", callback_data="buy_guard_scav_watchman"),
        types.InlineKeyboardButton("👮‍♂️ Патруль ЧВК (75 000 ₽ / 8ч)", callback_data="buy_guard_pmc_patrol"),
        types.InlineKeyboardButton("🛡️ Спецгруппа Охраны (250 000 ₽ / 20ч)", callback_data="buy_guard_elite_pmc"),
        types.InlineKeyboardButton("🔙 Назад в Убежище", callback_data="menu_hideout")
    )
    if db is None:
        db = load_db()
    photo = get_menu_photo("base_guard", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)

def handle_buy_guard_contract(call, player, db, contract_id):
    ok, msg = buy_guard_contract(player, contract_id)
    bot.answer_callback_query(call.id, msg, show_alert=True)
    if ok:
        save_db(db)
        handle_menu_base_guard(call.message.chat.id, call.message.message_id, player, db)

def handle_base_assault(call, player, db):
    squad = player.get("squad", [])
    if not squad:
        bot.answer_callback_query(call.id, "❌ В вашем отряде нет бойцов для штурма базы!", show_alert=True)
        return

    ok, res = recover_base_assault(player)
    save_db(db)

    chat_id = call.message.chat.id
    msg_id = call.message.message_id
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🏚️ В Убежище", callback_data="menu_hideout"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )

    if ok:
        bot.answer_callback_query(call.id, "🎉 ШТУРМ УВЕНЧАЛСЯ УСПЕХОМ! БАЗА ОСВОБОЖДЕНА!", show_alert=True)
        trophy_str = f"\n🏆 <b>Трофей с главаря рейдеров:</b> {res['boss_trophy']['name']}" if res.get("boss_trophy") else ""
        txt = (
            f"🎉 <b>ПОБЕДА! СПЕЦОПЕРАЦИЯ ПО ШТУРМУ БАЗЫ УСПЕШНА!</b>\n"
            f"────────────────────────\n"
            f"Шанс на успех составлял: <b>{res['win_chance_pct']}%</b>\n\n"
            f"Ваш отряд выбил бандитов Отступников из каждого бункера и вернул контроль над базой!\n"
            f"• Возвращено похищенного хабара: <b>{res['recovered_items_count']} предм.</b>\n"
            f"• Отбито наличных: +<b>{fmt_rub(res['recovered_rubles'])}</b>\n"
            f"• Возвращено биткоинов: +<b>{res['recovered_btc']:.4f} BTC</b>\n"
            f"• Опыт: +<b>250 EXP</b>{trophy_str}\n\n"
            f"🛡️ База переведена на чрезвычайное положение (выставлена охрана на 3 часа)."
        )
    else:
        bot.answer_callback_query(call.id, "💀 ШТУРМ ПРОВАЛЕН! ОТРЯД ПОНЕС СОКРУШИТЕЛЬНЫЕ ПОТЕРИ!", show_alert=True)
        txt = (
            f"💀 <b>ШТУРМ ЗАХЛЕБНУЛСЯ КРОВЬЮ!</b>\n"
            f"────────────────────────\n"
            f"Шанс на успех был: <b>{res.get('win_chance_pct', 0)}%</b>\n\n"
            f"Отступники укрепились в ваших зданиях и встретили бойцов шквальным огнем!\n"
            f"• Погибло Диких: <b>{res.get('dead_scavs', 0)}</b> (погибли безвозвратно)\n"
            f"• Контужено ЧВК: <b>{res.get('injured_pmcs', 0)}</b>\n"
            f"• Уничтожено/захвачено брони и оружия: <b>{res.get('stripped_items_count', 0)} ед.</b>\n\n"
            f"База остается под контролем рейдеров. Наймите новых бойцов или обратитесь к Скупщику!"
        )

    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_base_fence_buyout(call, player, db):
    ok, msg = recover_base_fence(player)
    if ok:
        save_db(db)
        bot.answer_callback_query(call.id, "🤝 Сделка со Скупщиком оформлена!", show_alert=True)
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("🏚️ В Убежище", callback_data="menu_hideout"),
            types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
        )
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, reply_markup=markup)
    else:
        bot.answer_callback_query(call.id, "❌ Недостаточно средств для выкупа у Скупщика!", show_alert=True)
        markup = types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            types.InlineKeyboardButton("🔙 Назад к Охране", callback_data="menu_base_guard"),
            types.InlineKeyboardButton("🏚️ В Убежище", callback_data="menu_hideout")
        )
        bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, reply_markup=markup)

# ----------------- SECTION 6: SUPPLIES (КОНТРАБАНДА) -----------------
TIER_SUPPLY_CONFIG = {
    1: {"name": "📦 Партия медикаментов и патронов", "cost": 25000, "time": 45, "min_lvl": 1, "desc": "2-3 предмета (медицина, патроны, обвес) + 20-45k ₽ кэша"},
    2: {"name": "🎖️ Военный конвой UNTAR", "cost": 75000, "time": 120, "min_lvl": 1, "desc": "3-4 военных предмета (броня 4-5 кл, винтовки) + 70-150k ₽ кэша"},
    3: {"name": "🧪 Спец-контрабанда TerraGroup Labs", "cost": 180000, "time": 240, "min_lvl": 1, "desc": "4-5 элитных предметов (броня 5-6 кл, мета-оружие, GPU) + 180-360k ₽ + шанс BTC"},
    4: {"name": "👑 Теневой караван Черного Рынка", "cost": 450000, "time": 360, "min_lvl": 5, "desc": "5-6 топ-предметов Синдиката + 450-900k ₽ + шанс BTC, Кейсов и 📟 Датчика DSP Зрячего (0.1%)"}
}

def handle_menu_supply(chat_id, msg_id, player, db=None):
    ch_lvl = player.get("supply_channel_lvl", 1)
    act_del = player.get("active_delivery")
    now = int(time.time())
    cash_bonus = (ch_lvl - 1) * 5

    txt = (
        f"<b>🚚 КОНТРАБАНДНЫЙ ТРАФИК (Канал снабжения: {ch_lvl}/10 ур.)</b>\n"
        f"────────────────────────\n"
        f"• 💰 <b>Бонус к выручке от контрабандистов:</b> +{cash_bonus}%\n"
        f"• 🎯 <b>Редкость груза:</b> растет с каждым уровнем канала\n"
    )
    has_fleet = bool(player.get("special_businesses", {}).get("smugglers_fleet"))
    if has_fleet:
        txt += "• ⚡ <b>Автопарк «Контрабандисты Резерва»:</b> доставка втрое быстрее (3x) и скидка -20% на логистику!\n"
    txt += "────────────────────────\n\n"

    markup = types.InlineKeyboardMarkup(row_width=1)

    if act_del:
        rem = act_del["finish_time"] - now
        tier_cur = act_del.get("tier", 1)
        tier_cfg = TIER_SUPPLY_CONFIG.get(tier_cur, TIER_SUPPLY_CONFIG[1])
        if rem <= 0:
            txt += f"📦 <b>КАРАВАН ПРИБЫЛ!</b>\nКонтрабандисты выгрузили ящики: <b>{tier_cfg['name']}</b> на конспиративной базе.\n"
            markup.add(types.InlineKeyboardButton("🎁 Вскрыть доставленную контрабанду", callback_data="claim_supply"))
        else:
            txt += f"⏳ <b>Караван в пути:</b> {tier_cfg['name']}\nДо прибытия груза осталось: <b>{rem} сек.</b>\n"
            markup.add(types.InlineKeyboardButton("🔄 Обновить статус каравана", callback_data="menu_supply"))
    else:
        txt += "Выберите партию контрабанды для отправки каравана:\n\n"
        for t_idx, cfg in TIER_SUPPLY_CONFIG.items():
            min_l = cfg.get("min_lvl", 1)
            cost = cfg["cost"]
            t_time = cfg["time"]

            if has_fleet:
                cost = int(cost * 0.8)
                t_time = max(1, t_time // 3)
            if has_buff(player, "supply_speed"):
                t_time = int(t_time * 0.8)

            if ch_lvl < min_l:
                txt += f"🔒 <b>Тир {t_idx}: {cfg['name']}</b>\n<i>Откроется на {min_l} уровне канала поставок</i>\n\n"
            else:
                txt += f"• <b>Тир {t_idx}: {cfg['name']}</b>\n🏷️ Цена: <b>{fmt_rub(cost)}</b> | ⏱️ Время: <b>{t_time} сек.</b>\n📝 <i>{cfg['desc']}</i>\n\n"
                markup.add(types.InlineKeyboardButton(f"Заказать Тир {t_idx} ({fmt_rub(cost)})", callback_data=f"order_supply_tier_{t_idx}"))

    up_cost = SUPPLY_CHANNEL_COSTS.get(ch_lvl)
    if up_cost:
        markup.add(types.InlineKeyboardButton(f"🔼 Улучшить канал до {ch_lvl+1} ур. ({fmt_rub(up_cost)})", callback_data="upgrade_supply_channel"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    try:
        if db is None:
            db = load_db()
        photo = get_menu_photo("supply", db)
        _safe_send_photo(photo, txt, chat_id, msg_id, markup)
    except Exception as e:
        logging.error("Error in handle_menu_supply: %s", e)

def handle_order_supply(call, player, db, tier):
    if player.get("active_delivery"):
        bot.answer_callback_query(call.id, "❌ У вас уже есть активная доставка в пути!", show_alert=True)
        return

    cfg = TIER_SUPPLY_CONFIG.get(tier, TIER_SUPPLY_CONFIG[1])
    ch_lvl = player.get("supply_channel_lvl", 1)
    if ch_lvl < cfg.get("min_lvl", 1):
        bot.answer_callback_query(call.id, f"❌ Этот тир контрабанды доступен только с {cfg['min_lvl']} уровня канала!", show_alert=True)
        return

    cost = cfg["cost"]
    dur = cfg["time"]

    has_fleet = bool(player.get("special_businesses", {}).get("smugglers_fleet"))
    if has_fleet:
        cost = int(cost * 0.8)
        dur = max(1, dur // 3)

    if has_buff(player, "supply_speed"):
        dur = int(dur * 0.8)

    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    now = int(time.time())
    player["money"] -= cost
    player["active_delivery"] = {
        "tier": tier,
        "start_time": now,
        "finish_time": now + dur
    }
    save_db(db)

    bot.answer_callback_query(call.id, f"🚚 Караван «{cfg['name']}» отправлен! Ожидание: {dur} сек.")
    handle_menu_supply(call.message.chat.id, call.message.message_id, player)

def handle_claim_supply(call, player, db):
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass

    act = player.get("active_delivery")
    if not act:
        bot.answer_callback_query(call.id, "❌ Нет активной доставки!", show_alert=True)
        return

    now = int(time.time())
    if act["finish_time"] > now:
        rem = act["finish_time"] - now
        bot.answer_callback_query(call.id, f"⏳ Караван еще в пути! Осталось: {rem} сек.", show_alert=True)
        return

    ch_lvl = player.get("supply_channel_lvl", 1)
    tier = act.get("tier", 1)
    cargo = generate_supply_drop(ch_lvl, player, tier=tier)
    items = cargo.get("items", [])

    # Check warehouse capacities
    cat_counts = {}
    for itm in items:
        c = itm.get("category", "gear")
        cat_counts[c] = cat_counts.get(c, 0) + 1

    for c, needed in cat_counts.items():
        cur_cnt = get_warehouse_count(player, c)
        cap = get_warehouse_capacity(player, c)
        if cur_cnt + needed > cap:
            w_name = WAREHOUSE_NAMES.get(c, "Склад")
            bot.answer_callback_query(
                call.id,
                f"❌ Склад '{w_name}' переполнен! Требуется еще {cur_cnt + needed - cap} мест. Освободите схрон!",
                show_alert=True
            )
            return

    # Add items to stash
    player["active_delivery"] = None
    stored_items_text = []
    for idx, itm in enumerate(items, 1):
        uid = f"sup_{now}_{idx}_{random.randint(100, 999)}"
        player.setdefault("stash", []).append({
            "uid": uid,
            "item_id": itm["id"],
            "equipped_to": None
        })
        r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        stored_items_text.append(f"• {r_b} <b>{itm['name']}</b> ({fmt_rub(itm.get('price', 0))})")

    # Add cash
    rubles = cargo.get("rubles", 0)
    player["money"] = player.get("money", 0) + rubles

    # Add BTC
    btc = cargo.get("btc", 0.0)
    if btc > 0:
        player["btc"] = round(player.get("btc", 0.0) + btc, 4)

    # Add bonus crate if any
    bonus_crate = cargo.get("bonus_crate")
    crate_text = ""
    if bonus_crate:
        c_def = CONTAINER_DEFINITIONS.get(bonus_crate)
        if c_def:
            crate_text = f"\n🧰 <b>БОНУСНЫЙ ТРОФЕЙ:</b> Найден {c_def['name']}!\n"
            # Open the container right away into stash if capacity allows, or give value
            c_res = generate_container_loot(bonus_crate, player)
            for c_itm in c_res.get("items", []):
                if can_store_item(player, c_itm["id"]):
                    c_uid = f"box_{now}_{random.randint(1000, 9999)}"
                    player.setdefault("stash", []).append({"uid": c_uid, "item_id": c_itm["id"], "equipped_to": None})

    # Check if mythic_dsp_sensor won (0.1% chance on Tier 4)
    dsp_text = ""
    if cargo.get("mythic_dsp_won"):
        add_mythic_item_to_player(player, "mythic_dsp_sensor")
        player["guard_until"] = 2147483647
        player["is_base_captured"] = False
        # Deliver first batch of Zryachiy gear immediately
        check_zryachiy_daily_supply(player)
        dsp_text = (
            "\n\n🔥 <b>НЕВЕРОЯТНЫЙ МИФИЧЕСКИЙ ТРОФЕЙ (Шанс 0.1%)!</b>\n"
            "В ящиках контрабандистов найден <b>📟 Закодированный датчик DSP Смотрителя</b> (150 000 000 ₽)!\n"
            "👁️ Зрячий взял все ваши базы и территории под 100% вечный дозор, а 3 предмета его персонального комплекта уже доставлены в схрон!\n"
        )

    save_db(db)

    # Build detailed result message
    res_lines = [
        f"🚚 <b>ПАРТИЯ КОНТРАБАНДЫ ВЫГРУЖЕНА (Тир {tier})!</b>",
        "────────────────────────",
        f"📦 <b>Доставленный груз ({len(items)} предм.):</b>",
        *stored_items_text,
        "",
        f"💵 <b>Кэш контрабандистов:</b> +{fmt_rub(rubles)}"
    ]
    if btc > 0:
        res_lines.append(f"🪙 <b>Биткоин-вознаграждение:</b> +{btc} BTC")
    if crate_text:
        res_lines.append(crate_text.strip())
    if dsp_text:
        res_lines.append(dsp_text.strip())
    res_lines.append("────────────────────────")
    res_lines.append("<i>Все предметы успешно размещены по соответствующим складам схрона.</i>")
    res_msg = chr(10).join(res_lines)
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🚚 Заказать следующий караван", callback_data="menu_supply"),
        types.InlineKeyboardButton("📦 Открыть Схрон", callback_data="menu_stash"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    if db is None:
        db = load_db()
    photo = get_menu_photo("supply", db)
    _safe_send_photo(photo, res_msg, call.message.chat.id, call.message.message_id, markup)


def handle_upgrade_supply_channel(call, player, db):
    ch_lvl = player.get("supply_channel_lvl", 1)
    cost = SUPPLY_CHANNEL_COSTS.get(ch_lvl)
    if not cost or ch_lvl >= 10:
        bot.answer_callback_query(call.id, "❌ Канал поставок уже максимального уровня!", show_alert=True)
        return
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    player["supply_channel_lvl"] = ch_lvl + 1
    save_db(db)
    bot.answer_callback_query(call.id, f"🎉 Канал поставок улучшен до {ch_lvl + 1} уровня!")
    handle_menu_supply(call.message.chat.id, call.message.message_id, player)

# ----------------- SECTION 7: SOLO RAIDS -----------------
def handle_menu_raids(chat_id, msg_id, player):
    pow_val, arm_val = calculate_squad_power(player)
    squad = player.get("squad", [])
    has_fighters = len(squad) > 0
    txt = (
        "<b>⚔️ РЕЙДЫ В ЗОНУ ТАРКОВА (БЕЗ КУЛДАУНА)</b>\n"
        f"Огневая мощь вашего отряда: <b>{pow_val}</b> | Броня: <b>{arm_val}</b>\n"
        "────────────────────────\n"
    )
    if not has_fighters:
        txt += (
            "⚠️ <b>В ВАШЕМ ОТРЯДЕ НЕТ БОЙЦОВ!</b>\n"
            "Все прошлые бойцы погибли в бою или отряд еще не нанят.\n"
            "Выход в рейд без бойцов невозможен! Сначала наймите бойцов в меню Отряда.\n\n"
        )
    else:
        txt += (
            "Шанс выживания зависит от силы бойцов и надетого снаряжения (оружие, броня, шлемы, наушники).\n"
            "⚡ Одиночные рейды доступны мгновенно и без таймера ожидания!\n\n"
        )
    markup = types.InlineKeyboardMarkup(row_width=1)
    if get_player_prestige(player) >= 5:
        markup.add(types.InlineKeyboardButton("👑 Черный Рейд Смотрителя (10-25M ₽ | Раз в 20ч)", callback_data="menu_prestige_black_raid"))
    markup.add(
        types.InlineKeyboardButton("⭐ Спецоперация Сигнатурного ЧВК (3x Лут | Бессмертие)", callback_data="menu_signature_raid"),
        types.InlineKeyboardButton("👥 Кооперативные рейды (до 6 бойцов)", callback_data="menu_coop_raids")
    )
    if has_mythic_item(player, "mythic_black_division_case"):
        markup.add(types.InlineKeyboardButton("💼 Спецоперация Black Division (Охота на Босса)", callback_data="menu_black_division"))
    if has_mythic_item(player, "mythic_goons_token"):
        markup.add(types.InlineKeyboardButton("🎖️ Рейд Троицы Отступников (The Goons)", callback_data="menu_the_goons"))
    if has_fighters:
        for loc_key, loc in RAID_LOCATIONS.items():
            win_ch = calculate_raid_win_chance(loc_key, player, pow_val, arm_val)
            win_ch_pct = round(win_ch * 100, 1)
            loc_name_safe = html.escape(str(loc['name']))
            txt += f"• <b>{loc_name_safe}</b>: Шанс успеха ~<b>{win_ch_pct}%</b>\n"
            markup.add(types.InlineKeyboardButton(f"🚀 В рейд: {loc['name']} (~{win_ch_pct}%)", callback_data=f"start_solo_raid_{loc_key}"))
    else:
        markup.add(types.InlineKeyboardButton("➕ Нанять бойцов в Отряд", callback_data="menu_squad"))
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    db = load_db()
    photo = get_raids_menu_photo(db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)


def render_boss_ambush_view(chat_id, msg_id, player, ambush):
    pow_val, arm_val = calculate_squad_power(player)
    loc_key = ambush.get("location_key") or player.get("pending_boss_ambush", {}).get("location_key", "factory")
    loc = RAID_LOCATIONS.get(loc_key, RAID_LOCATIONS["factory"])
    boss_diff = int(loc["difficulty"] * 1.8)
    combined_stat = (pow_val * 1.3) + (arm_val * 0.9)
    ratio = combined_stat / max(1, boss_diff)
    win_ch = min(0.88, max(0.10, (ratio / (ratio + 0.95)) * 1.30))
    if has_buff(player, "pvp_bonus"):
        win_ch = min(0.92, win_ch + 0.10)
    if has_boss_set_bonus(player, "killa"):
        win_ch = min(0.96, win_ch + 0.50)
    squad = player.get("squad", [])
    scav_count = sum(1 for f in squad if f.get("type") == "scav")
    pmc_count = sum(1 for f in squad if f.get("type") != "scav")
    if pmc_count == 0 and scav_count > 0:
        win_ch = min(0.35, win_ch)
    win_pct = round(win_ch * 100, 1)
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(f"⚔️ Принять бой (~{win_pct}% шанс, Джекпот)", callback_data="boss_ambush_fight"),
        types.InlineKeyboardButton("🏃‍♂️ Отступить с боем (Тактический отход)", callback_data="boss_ambush_retreat")
    )
    esc = html.escape
    b_title = esc(str(ambush.get('title', 'Засада Босса')))
    b_name = esc(str(ambush.get('boss_name', 'Босс')))
    b_desc = esc(str(ambush.get('desc', '')))
    b_intro = esc(str(ambush.get('intro', '')))
    b_icon = ambush.get('icon', '⚠️')

    txt = (
        f"🚨 <b>{b_title}</b>\n"
        "────────────────────────\n"
        f"{b_icon} <b>Враг: {b_name}</b>\n\n"
        f"<i>{b_desc}</i>\n\n"
        "⚠️ <b>ОБСТАНОВКА:</b>\n"
        f"{b_intro}\n\n"
        "Вам предстоит принять мгновенное тактическое решение:\n"
        "1. <b>«Принять бой»</b>: Сложность локации <b>утраивается (x3)</b>! В случае победы — джекпот в сотни тысяч рублей, элитное оружие и шанс выбить реликвию босса! В случае поражения — мгновенная гибель бойцов и утрата всей экипировки.\n"
        "2. <b>«Отступить с боем»</b>: Дымовая завеса и маневр уклонения. Отряд теряет предмет для сброса погони или получает повреждение брони прикрывающего бойца."
    )
    _safe_edit_or_send(txt, chat_id, msg_id, markup)


def handle_start_solo_raid(call, player, db, loc_key):
    try:
        bot.answer_callback_query(call.id)
    except Exception:
        pass
    squad = player.get("squad", [])
    if not squad or len(squad) == 0:
        try:
            bot.answer_callback_query(call.id, "❌ Выход в рейд невозможен! В вашем отряде нет бойцов.", show_alert=True)
        except Exception:
            pass
        handle_menu_raids(call.message.chat.id, call.message.message_id, player)
        return

    now = int(time.time())

    # Check for Boss Ambush (5-8% chance)
    skip_ambush = getattr(bot, "_disable_ambush_for_test", False) or player.get("_force_no_ambush")
    if not skip_ambush and simulate_raid.__module__ == 'loot_generator':
        ambush = roll_boss_ambush(loc_key)
        if ambush and has_gd_business(player):
            # Satellite Radar reduces ambush chance by 35%
            if random.random() < 0.35:
                ambush = None
        if ambush:
            player["pending_boss_ambush"] = {
                "location_key": loc_key,
                "boss_info": ambush,
                "timestamp": now
            }
            save_db(db)
            render_boss_ambush_view(call.message.chat.id, call.message.message_id, player, ambush)
            return

    pow_val, arm_val = calculate_squad_power(player)
    res = simulate_raid(loc_key, player, pow_val, arm_val)

    player["last_raid_time"] = now
    player.setdefault("stats", {})["raids_count"] = player.get("stats", {}).get("raids_count", 0) + 1

    esc = html.escape
    loc_name = esc(str(res.get('location', 'Тарков')))

    txt = (
        f"<b>⚔️ РЕЙД: {loc_name}</b>\n"
        f"Расчетный шанс на выживание был: <b>{res['win_chance']}%</b>\n"
        "────────────────────────\n"
    )

    if res["success"]:
        txt += f"🎉 <b>УСПЕШНАЯ ЭВАКУАЦИЯ!</b>\nОтряд вынес из зоны: +<b>{fmt_rub(res['rubles'])}</b>\n"
        m_perks = res.get("mythic_perks") or {}
        if m_perks.get("rubles_mult", 1.0) > 1.0:
            txt += f"🔥 <b>ТРОФЕИ ОТСТУПНИКОВ:</b> Множитель хабара x{m_perks['rubles_mult']:.2f} применился к добыче!\n"
        if res.get("btc_won"):
            txt += "🪙 <b>СЕТ ОТСТУПНИКОВ:</b> В тайнике рейда найден чистый <b>Биткоин (+1.0 BTC)</b>!\n"
        add_player_rubles(player, res["rubles"])
        exp_gain = int(50 * m_perks.get("exp_mult", 1.0))
        leveled_up = add_player_exp(player, exp_gain)
        p_lvl = get_player_level(player)
        txt += f"⚡ <b>Опыт ЧВК:</b> +<b>{exp_gain} EXP</b> (Уровень: {p_lvl}/10)\n"
        if leveled_up:
            txt += f"⭐ <b>НОВЫЙ УРОВЕНЬ ОПЕРАТОРА: {p_lvl} / 10!</b>\n"
        txt += "\n<b>Найденный хабар:</b>\n" 
        stored_items = 0
        dropped_items = 0
        for itm in res["items"]:
            r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
            safe_name = esc(str(itm.get("name", "Предмет")))
            if can_store_item(player, itm["id"]):
                txt += f"{r_b} {safe_name} ({fmt_rub(itm.get('price', 0))})\n"
                player.setdefault("stash", []).append({
                    "uid": f"raid_{now}_{random.randint(1000,9999)}",
                    "item_id": itm["id"],
                    "equipped_to": None
                })
                stored_items += 1
            else:
                txt += f"❌ {safe_name} (не влезло на склад)\n"
                dropped_items += 1
        if dropped_items > 0:
            txt += f"\n⚠️ <b>{dropped_items} предм.</b> не поместились на переполненных складах и были брошены в зоне!"

        # GD Military Battle Pass Progression & Weapon Drops
        if has_gd_business(player):
            bp_res = add_gd_bp_exp(player, 450)
            if bp_res["leveled_up"]:
                txt += f"\n\n🎖️ <b>БОЕВОЙ ПРОПУСК GD:</b> +450 XP! <b>Новый уровень: {bp_res['new_level']} / 150!</b>\n"
                for r in bp_res.get("new_rewards", []):
                    safe_title = esc(str(r.get('title', 'Награда')))
                    txt += f"   🎁 Получена награда: <b>{safe_title}</b>!\n"
            else:
                if bp_res.get("new_level", 1) >= 150:
                    txt += f"\n\n🎖️ <b>БОЕВОЙ ПРОПУСК GD:</b> +450 XP (Ур. 150 / 150 | <b>МАКСИМАЛЬНЫЙ УРОВЕНЬ</b>)\n"
                else:
                    c_exp = bp_res.get("current_exp", 0)
                    n_exp = bp_res.get("need_exp", 0)
                    txt += f"\n\n🎖️ <b>БОЕВОЙ ПРОПУСК GD:</b> +450 XP (Ур. {bp_res.get('new_level', 1)} | Прогресс: {c_exp}/{n_exp} XP)\n"

            # Check special GD weapon drop
            gd_weapon = roll_gd_raid_weapon(player, loc_key)
            if gd_weapon:
                safe_gdw = esc(str(gd_weapon.get("name", "Оружие GD")))
                if can_store_item(player, gd_weapon["id"]):
                    w_uid = f"gdw_{now}_{random.randint(1000, 9999)}"
                    player.setdefault("stash", []).append({
                        "uid": w_uid,
                        "item_id": gd_weapon["id"],
                        "equipped_to": None
                    })
                    txt += f"🛰️ <b>СПУТНИКОВЫЙ ДРОП GD:</b> В закрытом схроне зоны обнаружено <b>{safe_gdw}</b> (Урон/мощь: +{gd_weapon['combat']})!\n"
                else:
                    txt += f"🛰️ <b>СПУТНИКОВЫЙ ДРОП GD:</b> Обнаружено оружие <b>{safe_gdw}</b>, но оружейный склад переполнен!\n"
    else:
        txt += (
            "💀 <b>ОТРЯД ПОЛНОСТЬЮ ПОГИБ В БОЮ!</b>\n"
            "Вы попали в засаду превосходящих сил противника.\n"
        )
        if has_boss_set_bonus(player, "tagilla"):
            txt += "🛡️ <b>СЕТ ТАГИЛЛЫ:</b> Благодаря несокрушимой броне Тагиллы всё снаряжение и бойцы отряда спасены (0% потерь)!\n"
        else:
            stash = player.get("stash", [])
            dead_scavs = 0
            dead_pmcs = 0
            saved_mythics = []

            for f in squad:
                for slot_key in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
                    uid = f.get(slot_key)
                    if uid:
                        item_entry = next((i for i in stash if i.get("uid") == uid), None)
                        if item_entry:
                            item_id = item_entry.get("item_id")
                            info = ITEMS_BY_ID.get(item_id, {})
                            if info.get("rarity") == "mythic" or str(item_id).startswith(("mythic_", "zryachiy_", "goons_")) or info.get("mythic", False):
                                item_entry["equipped_to"] = None
                                saved_mythics.append(info.get("name", item_id))
                            else:
                                stash.remove(item_entry)
                        f[slot_key] = None

                if f.get("type") == "scav":
                    dead_scavs += 1
                else:
                    dead_pmcs += 1

            player["squad"] = []
            loss_parts = []
            if dead_pmcs > 0:
                loss_parts.append(f"{dead_pmcs} ЧВК")
            if dead_scavs > 0:
                loss_parts.append(f"{dead_scavs} Диких")
            loss_str = ", ".join(loss_parts) if loss_parts else "Все бойцы"

            txt += (
                f"\n💀 <b>Все бойцы отряда погибли ({esc(loss_str)})!</b>\n"
                "Обычное надетое снаряжение безвозвратно потеряно в зоне.\n"
            )
            if saved_mythics:
                txt += (
                    f"\n📡 <b>МИФИЧЕСКИЙ ЭВАКУАЦИОННЫЙ МАЯЧОК:</b>\n"
                    f"Спутниковая система спасла ценнейшую экипировку ({len(saved_mythics)} предм.):\n"
                )
                for sm in saved_mythics:
                    txt += f"• 🔴 <b>{esc(str(sm))}</b> возвращен в схрон!\n"
            txt += "\n⚠️ Отряд пуст! Чтобы снова выходить в рейды, наймите бойцов за рубли в меню Отряда.\n"

        if has_gd_business(player):
            bp_res = add_gd_bp_exp(player, 120)
            txt += f"\n🎖️ <b>ОПЕРАТИВНЫЙ ОПЫТ GD:</b> +120 XP в Боевой Пропуск за огневой контакт (Ур. {bp_res['new_level']}).\n"

    save_db(db)
    markup = types.InlineKeyboardMarkup(row_width=1)
    if has_gd_business(player):
        markup.add(types.InlineKeyboardButton("🎖️ Боевой Пропуск GD", callback_data="menu_gd_battlepass"))
    markup.add(
        types.InlineKeyboardButton("🔙 К Меню Рейдов", callback_data="menu_raids")
    )
    loc_photo = get_location_photo(loc_key, db)
    _safe_send_photo(loc_photo, txt, call.message.chat.id, call.message.message_id, markup)


def handle_boss_ambush_fight(call, player, db):
    ambush_data = player.get("pending_boss_ambush")
    if not ambush_data:
        try:
            bot.answer_callback_query(call.id, "⚠️ Данные засады устарели.", show_alert=True)
        except Exception:
            pass
        handle_menu_raids(call.message.chat.id, call.message.message_id, player)
        return
    try:
        bot.answer_callback_query(call.id, "⚔️ Вы приняли бой с Боссом!", show_alert=False)
    except Exception:
        pass
    loc_key = ambush_data["location_key"]
    boss_info = ambush_data["boss_info"]
    now = int(time.time())

    pow_val, arm_val = calculate_squad_power(player)
    res = simulate_boss_combat(loc_key, boss_info, player, pow_val, arm_val)
    player["pending_boss_ambush"] = None
    player["last_raid_time"] = now
    player.setdefault("stats", {})["raids_count"] = player.get("stats", {}).get("raids_count", 0) + 1

    chat_id = call.message.chat.id
    msg_id = call.message.message_id
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("⚔️ В Меню Рейдов", callback_data="menu_raids"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )

    esc = html.escape
    boss_name_safe = esc(str(boss_info.get('boss_name', 'Босс')))

    sniper_banner = res.get("sniper_log", "")
    if res["success"]:
        add_player_rubles(player, res["rubles"])
        add_player_exp(player, res.get("exp", 200))
        # Signature PMC bonus point for boss kill
        pmc_k = player.get("pmc_signature", "Viper")
        try:
            from signature_skills_system import award_signature_pmc_points
            b_pts = award_signature_pmc_points(player, pmc_k, 1, f"Ликвидация босса {boss_info.get('boss_name', 'Босс')}")
            sniper_banner += f"\n⭐ <b>БОЕВАЯ НАГРАДА {pmc_k.upper()}:</b> +1 очко навыков за ликвидацию Босса! (Всего: {b_pts})\n"
        except Exception:
            pass
        txt = (
            f"{sniper_banner}"
            f"👑 <b>ТРИУМФ НАД БОССОМ! {boss_name_safe.upper()} УНИЧТОЖЕН!</b>\n"
            "────────────────────────\n"
            f"Сложность схватки: <b>{res['boss_diff']} (x3)</b> | Шанс победы был: <b>{res['win_chance_pct']}%</b>\n\n"
            "🎉 <b>ДЖЕКПОТ ЗА ПОБЕДУ:</b>\n"
            f"• Наличные трофеи: +<b>{fmt_rub(res['rubles'])}</b>\n"
            f"• Боевой опыт: +<b>{res.get('exp', 200)} EXP</b>\n\n"
            "<b>Выбитые редкие трофеи:</b>\n"
        )
        stored = 0
        dropped = 0
        for itm in res["items"]:
            r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
            safe_name = esc(str(itm.get("name", "Трофей")))
            if can_store_item(player, itm["id"]):
                txt += f"{r_b} {safe_name} ({fmt_rub(itm.get('price', 0))})\n"
                player.setdefault("stash", []).append({
                    "uid": f"boss_{now}_{random.randint(1000,9999)}",
                    "item_id": itm["id"],
                    "equipped_to": None
                })
                stored += 1
            else:
                txt += f"❌ {safe_name} (не влезло на склад)\n"
                dropped += 1
        if dropped > 0:
            txt += f"\n⚠️ <i>{dropped} предм. не поместились на переполненных складах.</i>"
    else:
        txt = (
            "💀 <b>РАЗГРОМ В БОЮ С БОССОМ!</b>\n"
            "────────────────────────\n"
            f"{boss_name_safe} сокрушил ваш отряд на локации!\n"
            f"Шанс выживания в утроенной сложности был всего: <b>{res['win_chance_pct']}%</b>\n\n"
        )
        if has_boss_set_bonus(player, "tagilla"):
            txt += "🛡️ <b>СЕТ ТАГИЛЛЫ:</b> Несокрушимая броня спасла бойцов отряда от гибели (0% потерь)!\n"
        else:
            squad = player.get("squad", [])
            stash = player.get("stash", [])
            dead_scavs = 0
            dead_pmcs = 0
            saved_mythics = []

            for f in squad:
                for slot_key in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
                    uid = f.get(slot_key)
                    if uid:
                        item_entry = next((i for i in stash if i.get("uid") == uid), None)
                        if item_entry:
                            item_id = item_entry.get("item_id")
                            info = ITEMS_BY_ID.get(item_id, {})
                            if info.get("rarity") == "mythic" or str(item_id).startswith(("mythic_", "zryachiy_", "goons_")) or info.get("mythic", False):
                                item_entry["equipped_to"] = None
                                saved_mythics.append(info.get("name", item_id))
                            else:
                                stash.remove(item_entry)
                        f[slot_key] = None

                if f.get("type") == "scav":
                    dead_scavs += 1
                else:
                    dead_pmcs += 1

            player["squad"] = []
            loss_parts = []
            if dead_pmcs > 0:
                loss_parts.append(f"{dead_pmcs} ЧВК")
            if dead_scavs > 0:
                loss_parts.append(f"{dead_scavs} Диких")
            loss_str = ", ".join(loss_parts) if loss_parts else "Все бойцы"

            txt += (
                f"💀 <b>Все бойцы отряда погибли ({esc(loss_str)})!</b>\n"
                "Обычное надетое снаряжение безвозвратно утрачено.\n"
            )
            if saved_mythics:
                txt += (
                    f"\n📡 <b>МИФИЧЕСКИЙ ЭВАКУАЦИОННЫЙ МАЯЧОК:</b>\n"
                    f"Спутниковая система спасла ценнейшую экипировку ({len(saved_mythics)} предм.):\n"
                )
                for sm in saved_mythics:
                    txt += f"• 🔴 <b>{esc(str(sm))}</b> возвращен в схрон!\n"
            txt += "\n⚠️ Наймите новых бойцов в меню Отряда для продолжения игры.\n"

        if has_gd_business(player):
            bp_res = add_gd_bp_exp(player, 150)
            txt += f"\n🎖️ <b>ОПЕРАТИВНЫЙ ОПЫТ GD:</b> +150 XP в Боевой Пропуск за бой с Боссом (Ур. {bp_res['new_level']}).\n"

    save_db(db)
    _safe_edit_or_send(txt, chat_id, msg_id, markup)


def handle_boss_ambush_retreat(call, player, db):
    ambush_data = player.get("pending_boss_ambush")
    if not ambush_data:
        try:
            bot.answer_callback_query(call.id, "⚠️ Данные засады не найдены.")
        except Exception:
            pass
        handle_menu_raids(call.message.chat.id, call.message.message_id, player)
        return
    try:
        bot.answer_callback_query(call.id, "🏃‍♂️ Отряд отступает из зоны поражения!", show_alert=False)
    except Exception:
        pass
    loc_key = ambush_data["location_key"]
    boss_info = ambush_data["boss_info"]
    res = simulate_boss_retreat(loc_key, boss_info, player)
    player["pending_boss_ambush"] = None
    save_db(db)

    chat_id = call.message.chat.id
    msg_id = call.message.message_id
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("⚔️ В Меню Рейдов", callback_data="menu_raids"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )

    esc = html.escape
    boss_name_safe = esc(str(boss_info.get('boss_name', 'Босс')))

    if res["retreat_type"] == "safe":
        drop_safe = esc(str(res.get('dropped_name', 'Снаряжение')))
        txt = (
            "🏃‍♂️ <b>ТАКТИЧЕСКИЙ ОТХОД УСПЕШЕН!</b>\n"
            "────────────────────────\n"
            f"Отряд поставил плотную дымовую завесу и сбросил преследование {boss_name_safe}.\n"
            "Бойцы живы и вернулись на базу.\n"
            f"• Потеряно при спешном отходе: <b>{drop_safe}</b>"
        )
    else:
        destroyed_str = ", ".join(res["destroyed_gear_names"]) if res["destroyed_gear_names"] else "Броня"
        dest_safe = esc(str(destroyed_str))
        injured_safe = esc(str(res.get('injured_fighter_name', 'Боец')))
        txt = (
            "⚠️ <b>ОТХОД ПОД ПЛОТНЫМ ОГНЕМ!</b>\n"
            "────────────────────────\n"
            "Свита босса открыла огонь вдогонку отступающему отряду!\n"
            f"• Боец <b>{injured_safe}</b> ранен в арьергарде.\n"
            f"• Броня бойца уничтожена попаданиями: <i>{dest_safe}</i>\n"
            "Отряд сумел дотащить раненого до точки эвакуации и спасти жизнь."
        )
    _safe_edit_or_send(txt, chat_id, msg_id, markup)


def handle_menu_darkzone(chat_id, msg_id, player, db=None):
    pow_val, arm_val = calculate_squad_power(player)
    txt = (
        "<b>💀 ДАРКЗОН — ЗОНА ТОТАЛЬНОГО PVP</b>\n"
        "────────────────────────\n"
        f"Ваша боевая мощь: <b>{pow_val}</b> | Броня: <b>{arm_val}</b>\n\n"
        "В Даркзоне нет правил. Победитель забирает крупный денежный куш и трофеи!\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🤖 Быстрая дуэль с ЧВК-ботом", callback_data="darkzone_search_bot"),
        types.InlineKeyboardButton("⚔️ Бросить вызов в чат (Ставка: 100 000 ₽)", callback_data="darkzone_create_pvp"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    if db is None:
        db = load_db()
    photo = get_menu_photo("darkzone", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)

def handle_darkzone_bot_duel(call, player, db):
    squad = player.get("squad", [])
    if not squad or len(squad) == 0:
        bot.answer_callback_query(call.id, "❌ Бой невозможен! В вашем отряде нет бойцов.", show_alert=True)
        return

    bot.answer_callback_query(call.id)
    pow_val, arm_val = calculate_squad_power(player)
    bot_power = random.randint(max(20, pow_val - 25), pow_val + 35)

    player_score = pow_val * random.uniform(0.8, 1.25)
    if has_buff(player, "pvp_bonus"):
        player_score *= 1.15
    if has_boss_set_bonus(player, "killa"):
        player_score *= 1.75
    bot_score = bot_power * random.uniform(0.8, 1.25)

    txt = (
        "<b>💀 ДАРКЗОН: БОЙ С ВРАЖЕСКИМ ЧВК</b>\n"
        f"Ваша сила: <b>{pow_val}</b> vs Сила врага: <b>{bot_power}</b>\n"
        "────────────────────────\n"
    )

    now = int(time.time())
    if player_score >= bot_score:
        reward = random.randint(45000, 110000)
        loot = roll_strict_tarkov_loot(player)
        add_player_rubles(player, reward)
        add_player_exp(player, 40)
        stored_note = ""
        if can_store_item(player, loot["id"]):
            player.setdefault("stash", []).append({
                "uid": f"dz_{now}_{random.randint(100,999)}",
                "item_id": loot["id"],
                "equipped_to": None
            })
            stored_note = f"\n🎁 Снятый трофей: <b>{loot['name']}</b> (помещен в схрон)"
        else:
            cat = loot.get("category", "gear")
            stored_note = f"\n⚠️ Трофей <b>{loot['name']}</b> не влез в переполненный склад '{WAREHOUSE_NAMES.get(cat, 'Склад')}' и был брошен!"

        player.setdefault("stats", {})["pvp_wins"] = player.get("stats", {}).get("pvp_wins", 0) + 1
        txt += (
            f"🏆 <b>ПОБЕДА! Вражеский ЧВК ликвидирован!</b>\n"
            f"💰 Забрано наличными: +<b>{fmt_rub(reward)}</b>"
            f"{stored_note}\n"
        )
    else:
        loss_rub = min(player.get("money", 0), random.randint(20000, 50000))
        player["money"] = max(0, player.get("money", 0) - loss_rub)
        player.setdefault("stats", {})["pvp_losses"] = player.get("stats", {}).get("pvp_losses", 0) + 1
        txt += (
            "💀 <b>ПОРАЖЕНИЕ!</b> Враг оказался быстрее и точнее.\n"
            f"Вам удалось спастись бегством, потеряв: -<b>{fmt_rub(loss_rub)}</b>\n"
        )

    save_db(db)
    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🔙 К Даркзону", callback_data="menu_darkzone")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)

def handle_darkzone_create_pvp(call, player, db):
    squad = player.get("squad", [])
    if not squad or len(squad) == 0:
        bot.answer_callback_query(call.id, "❌ Создание дуэли невозможно! В вашем отряде нет бойцов.", show_alert=True)
        return

    stake = 100000
    if player.get("money", 0) < stake:
        bot.answer_callback_query(call.id, f"❌ Для ставки требуется {fmt_rub(stake)} наличными!", show_alert=True)
        return

    player["money"] -= stake
    duel_id = f"duel_{int(time.time())}_{random.randint(100,999)}"
    db.setdefault("active_duels", {})[duel_id] = {
        "creator_id": player["user_id"],
        "creator_name": player.get("username", "PMC"),
        "stake": stake,
        "created_at": int(time.time())
    }
    save_db(db)

    bot.answer_callback_query(call.id, f"⚔️ Вызов на PvP опубликован! Ставка {fmt_rub(stake)} внесена в банк.")
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton(f"💀 ПРИНЯТЬ БОЙ ({fmt_rub(stake)})", callback_data=f"accept_pvp_{duel_id}"))
    markup.add(types.InlineKeyboardButton("❌ Отменить вызов (Возврат)", callback_data=f"cancel_pvp_{duel_id}"))

    duel_t_badge = f" [{player.get('custom_title')}]" if player.get("custom_title") else ""
    bot.send_message(
        call.message.chat.id,
        f"⚔️ <b>ОПЕРАТОР @{player.get('username')}{duel_t_badge} БРОСАЕТ ВЫЗОВ В ДАРКЗОНЕ!</b>\n"
        f"Ставка поединка: <b>{fmt_rub(stake)}</b> (Банк победителю: {fmt_rub(stake * 2)})\n"
        f"Нажмите кнопку ниже, чтобы принять смертельный бой:",
        reply_markup=markup
    )

def handle_darkzone_cancel_pvp(call, player, db, duel_id):
    duel = db.get("active_duels", {}).get(duel_id)
    if not duel:
        bot.answer_callback_query(call.id, "❌ Вызов не найден или уже завершен!", show_alert=True)
        return
    if duel.get("creator_id") != player["user_id"] and not is_admin(player["user_id"], player.get("telegram_username")):
        bot.answer_callback_query(call.id, "❌ Только создатель дуэли может отменить её!", show_alert=True)
        return

    stake = duel.get("stake", 100000)
    creator_id = str(duel["creator_id"])
    creator = db["users"].get(creator_id)
    if creator:
        creator["money"] = creator.get("money", 0) + stake
    db["active_duels"].pop(duel_id, None)
    save_db(db)
    bot.answer_callback_query(call.id, f"✅ Дуэль отменена, ставка {fmt_rub(stake)} возвращена!")
    try:
        bot.edit_message_text(f"❌ <i>Дуэль отменена создателем @{duel.get('creator_name')}. Ставка возвращена.</i>", call.message.chat.id, call.message.message_id)
    except Exception:
        pass

def handle_darkzone_accept_pvp(call, player, db, duel_id):
    with DB_LOCK:
        if db is None:
            db = load_db()
        player = db["users"].get(str(call.from_user.id), player)
        squad = player.get("squad", [])
        if not squad or len(squad) == 0:
            bot.answer_callback_query(call.id, "❌ Принятие дуэли невозможно! В вашем отряде нет бойцов.", show_alert=True)
            return

        duel = db.get("active_duels", {}).get(duel_id)
        if not duel:
            bot.answer_callback_query(call.id, "❌ Вызов уже недействителен или бой состоялся!", show_alert=True)
            return

        if player["user_id"] == duel["creator_id"]:
            bot.answer_callback_query(call.id, "❌ Вы не можете сражаться сами с собой!", show_alert=True)
            return

        stake = duel["stake"]
        if player.get("money", 0) < stake:
            bot.answer_callback_query(call.id, f"❌ У вас недостаточно денег для ставки {fmt_rub(stake)}!", show_alert=True)
            return

        creator_id = str(duel["creator_id"])
        creator = db["users"].get(creator_id)
        if not creator:
            bot.answer_callback_query(call.id, "❌ Создатель дуэли не найден!", show_alert=True)
            db["active_duels"].pop(duel_id, None)
            save_db(db)
            return

        creator_squad = creator.get("squad", [])
        if not creator_squad or len(creator_squad) == 0:
            bot.answer_callback_query(call.id, "❌ У создателя дуэли больше нет бойцов в отряде! Вызов аннулирован.", show_alert=True)
            creator["money"] = creator.get("money", 0) + stake
            db["active_duels"].pop(duel_id, None)
            save_db(db)
            return

        player["money"] -= stake

        # Calculate combat
        c_pow, _ = calculate_squad_power(creator)
        p_pow, _ = calculate_squad_power(player)

        c_mult = random.uniform(0.85, 1.25)
        p_mult = random.uniform(0.85, 1.25)

        if has_boss_set_bonus(creator, "shturman"):
            c_mult *= 1.25
        if has_boss_set_bonus(player, "shturman"):
            p_mult *= 1.25

        if has_boss_set_bonus(creator, "tagilla"):
            c_mult = max(1.05, c_mult)
        if has_boss_set_bonus(player, "tagilla"):
            p_mult = max(1.05, p_mult)

        if has_buff(creator, "pvp_bonus"):
            c_mult *= 1.15
        if has_buff(player, "pvp_bonus"):
            p_mult *= 1.15

        c_score = c_pow * c_mult
        p_score = p_pow * p_mult

        if c_score >= p_score:
            winner = creator
            loser = player
            w_score = int(c_score)
            l_score = int(p_score)
        else:
            winner = player
            loser = creator
            w_score = int(p_score)
            l_score = int(c_score)

        add_player_rubles(winner, stake * 2)
        winner.setdefault("stats", {})["pvp_wins"] = winner.get("stats", {}).get("pvp_wins", 0) + 1
        loser.setdefault("stats", {})["pvp_losses"] = loser.get("stats", {}).get("pvp_losses", 0) + 1

        # FULL LOOT: Strip all equipment from loser's fighters and wipe loser squad!
        loser_squad = loser.get("squad", [])
        loser_stash = loser.get("stash", [])
        winner_stash = winner.setdefault("stash", [])

        equipped_uids = set()
        for f in loser_squad:
            for slot in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
                u = f.get(slot)
                if u:
                    equipped_uids.add(u)

        looted_items = []
        burned_items = []

        loser_remaining_stash = []
        for itm in loser_stash:
            if itm.get("uid") in equipped_uids:
                item_id = itm.get("item_id")
                info = ITEMS_BY_ID.get(item_id, {})
                if can_store_item(winner, item_id):
                    itm["equipped_to"] = None
                    winner_stash.append(itm)
                    looted_items.append(info)
                else:
                    burned_items.append(info)
            else:
                loser_remaining_stash.append(itm)

        loser["stash"] = loser_remaining_stash
        # All fighters in the loser's squad are wiped
        loser["squad"] = []

        db["active_duels"].pop(duel_id, None)
        save_db(db)

    loot_txt = ""
    if looted_items:
        loot_txt += "\n<b>🎒 Захваченное снаряжение проигравшего (FULL LOOT):</b>\n"
        for itm in looted_items:
            r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
            loot_txt += f"• {r_b} {itm.get('name')} ({fmt_rub(itm.get('price', 0))})\n"
    if burned_items:
        loot_txt += f"\n⚠️ <i>{len(burned_items)} предметов уничтожено из-за переполнения складов победителя!</i>\n"

    bot.send_message(
        call.message.chat.id,
        f"☠️ <b>КРОВАВАЯ ДУЭЛЬ В ДАРКЗОНЕ (FULL LOOT)!</b>\n"
        f"────────────────────────\n"
        f"🏆 Победитель: <b>@{winner.get('username')}</b> (Боевой счет: {w_score})\n"
        f"💀 Проигравший: <b>@{loser.get('username')}</b> (Боевой счет: {l_score})\n\n"
        f"💰 Победитель забрал ставку: +<b>{fmt_rub(stake)}</b>\n"
        f"⚠️ Отряд @{loser.get('username')} полностью ликвидирован (бойцы погибли)!\n"
        f"{loot_txt}"
    )

# ----------------- SECTION 9: CONTAINERS -----------------
def handle_menu_containers(chat_id, msg_id, player, db=None):
    txt = (
        "<b>🧰 ВОЕННЫЕ КЕЙСЫ И КОНТЕЙНЕРЫ</b>\n"
        "────────────────────────\n"
        "Вскрытие контейнеров сопряжено с риском. Лут может не окупить цену покупки!\n"
        "• Шанс выпадения Epic предметов: <b>3%</b>\n"
        "• Шанс выпадения Legendary предметов: <b>менее 0.5%</b>\n\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    for c_id, c in CONTAINER_DEFINITIONS.items():
        txt += f"• <b>{c['name']}</b> — <b>{fmt_rub(c['price'])}</b>\n<i>{c['desc']}</i>\n\n"
        markup.add(types.InlineKeyboardButton(f"Вскрыть {c['badge']} ({fmt_rub(c['price'])})", callback_data=f"open_container_{c_id}"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    if db is None:
        db = load_db()
    photo = get_menu_photo("containers", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)

def handle_open_container(call, player, db, c_id):
    c_def = CONTAINER_DEFINITIONS.get(c_id)
    if not c_def:
        bot.answer_callback_query(call.id, "❌ Неизвестный контейнер!", show_alert=True)
        return
    cost = c_def["price"]
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    bot.answer_callback_query(call.id)
    player["money"] -= cost
    res = generate_container_loot(c_id, player)
    now = int(time.time())

    batch_uids = []
    total_fullprice = 0
    stored_items = []
    dropped_count = 0

    for itm in res["items"]:
        if can_store_item(player, itm["id"]):
            uid = f"box_{now}_{random.randint(1000,9999)}"
            batch_uids.append(uid)
            total_fullprice += itm.get("price", 0)
            player.setdefault("stash", []).append({
                "uid": uid,
                "item_id": itm["id"],
                "equipped_to": None
            })
            stored_items.append(itm)
        else:
            dropped_count += 1

    player["last_opened_box"] = {
        "uids": batch_uids,
        "total_fullprice": total_fullprice,
        "timestamp": now,
        "container_name": c_def["name"]
    }
    save_db(db)

    out_msg = "📉 НЕОКУП" if res["delta"] < 0 else "📈 ОКУП!"
    txt = (
        f"<b>{c_def['badge']} ВСКРЫТИЕ: {c_def['name']}</b>\n"
        f"Затрачено: <b>{fmt_rub(cost)}</b>\n"
        f"Суммарная ценность лута: <b>{fmt_rub(res['total_value'])}</b> ({out_msg})\n"
        f"────────────────────────\n"
        f"<b>Выпавшие предметы:</b>\n"
    )
    for itm in res["items"]:
        r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        txt += f"{r_b} <b>{itm['name']}</b> — {fmt_rub(itm.get('price', 0))}\n"

    if dropped_count > 0:
        txt += f"\n⚠️ <b>{dropped_count} предм.</b> не поместились в переполненный склад и пропали!\n"

    if res.get("relic_won"):
        txt += (
            f"\n🏆 <b>СВЕРХРЕДКИЙ ДЖЕКПОТ (Шанс 1%)!</b>\n"
            f"Вам выпала Реликвия Босса: <b>{res['relic_won']['name']}</b> (+10 000 000 ₽)!\n"
            f"<i>💡 Напоминание: Сет-бонус 5/5 активируется в Профиле только при сборе всех 5 реликвий одного босса!</i>\n"
        )

    if res.get("mythic_won"):
        m_it = res["mythic_won"]
        add_mythic_item_to_player(player, m_it["id"])
        save_db(db)
        from prestige import get_player_prestige, get_goons_token_drop_chance
        p_lvl = get_player_prestige(player)
        ch_pct = get_goons_token_drop_chance(player) * 100
        txt += (
            f"\n🔥 <b>НЕВЕРОЯТНЫЙ МИФИЧЕСКИЙ ДЖЕКПОТ (Шанс {ch_pct:.2f}% на Престиже {p_lvl})!</b>\n"
            f"Вам выпал: <b>{m_it['name']}</b> (150 000 000 ₽)!\n"
            f"<i>💡 Открыт доступ к меню Отступников: ежедневная экипировка The Goons и рейд троицы каждые 24ч!</i>\n"
        )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if total_fullprice > 0:
        markup.add(types.InlineKeyboardButton(f"💰 Продать всё за фуллпрайс (+{fmt_rub(total_fullprice)})", callback_data="container_sell_all"))
    markup.add(
        types.InlineKeyboardButton("🔙 К Кейсам", callback_data="menu_containers"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)

def handle_container_sell_all(call, player, db):
    last_box = player.get("last_opened_box")
    if not last_box or not last_box.get("uids"):
        bot.answer_callback_query(call.id, "❌ Нет предметов для продажи за фуллпрайс или они уже проданы!", show_alert=True)
        return

    uids_to_sell = set(last_box.get("uids", []))
    stash = player.get("stash", [])
    sold_items = []
    gained_rubles = 0
    protected_items = []

    new_stash = []
    for itm in stash:
        if itm.get("uid") in uids_to_sell and not itm.get("equipped_to"):
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            # Protect Mythics and Boss Relics from accidental one-click bulk selling!
            if info.get("rarity") == "mythic" or itm.get("item_id", "").startswith("mythic_") or info.get("price", 0) >= 10000000:
                protected_items.append(info.get("name", "Реликвия/Мифик"))
                new_stash.append(itm)
                continue
            base_p = info.get("price", 0)
            gained_rubles += base_p
            sold_items.append(info)
        else:
            new_stash.append(itm)

    player["stash"] = new_stash
    add_player_rubles(player, gained_rubles)
    player.pop("last_opened_box", None)
    save_db(db)

    alert_msg = f"✅ Продано {len(sold_items)} предметов за {fmt_rub(gained_rubles)} (100% стоимости)!"
    if protected_items:
        alert_msg += f" (🛡️ {len(protected_items)} мификов/реликвий сохранены в схроне)"
    bot.answer_callback_query(call.id, alert_msg, show_alert=True)

    txt = (
        f"<b>💰 МГНОВЕННАЯ РАСПРОДАЖА КЕЙСА ЗА ФУЛЛПРАЙС</b>\n"
        f"────────────────────────\n"
        f"Все {len(sold_items)} предметов из последнего вскрытия были сданы по 100% каталожной стоимости без комиссии!\n\n"
        f"💵 Начислено оператору: +<b>{fmt_rub(gained_rubles)}</b>\n"
        f"Текущий баланс: <b>{fmt_rub(player.get('money', 0))}</b>\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1).add(
        types.InlineKeyboardButton("🧰 Открыть еще кейс", callback_data="menu_containers"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)

# ----------------- SECTION 10: AIRDROP -----------------
def handle_menu_airdrop(chat_id, msg_id, player, db):
    airdrop = db.get("airdrop", {})
    now = int(time.time())
    last_s = airdrop.get("last_spawn", 0)

    txt = "<b>📦 ВОЕННЫЙ ЭИРДРОП СЕКТОРА ТАРКОВА</b>\n────────────────────────\n"
    markup = types.InlineKeyboardMarkup()

    if airdrop.get("active"):
        txt += "🚨 <b>ВНИМАНИЕ! САМОЛЕТ ИЛ-76 СБРОСИЛ КОНТЕЙНЕР НА ПАРАШЮТЕ!</b>\nКто первым успеет нажать кнопку — заберет весь армейский лут и реликвии боссов!\n"
        markup.add(types.InlineKeyboardButton("📦 ЗАБРАТЬ ЭИРДРОП", callback_data="loot_airdrop_box"))
    else:
        txt += "Над Норвинской областью периодически пролетает военно-транспортный самолет Ил-76.\n"
        if is_admin(player["user_id"], player.get("telegram_username")):
            markup.add(types.InlineKeyboardButton("✈️ Вызвать Ил-76 (Admin @revenuts)", callback_data="admin_action_airdrop"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_loot_airdrop_box(call, player, db):
    with DB_LOCK:
        # Always reload fresh database state under DB_LOCK to prevent multi-click or race condition exploits
        if db is None:
            db = load_db()
        player = db["users"].get(str(call.from_user.id))
        if not player:
            player, _ = get_player(call.from_user.id, call.from_user.username)
            db["users"][str(call.from_user.id)] = player

        airdrop = db.get("airdrop", {})
        if not airdrop.get("active"):
            bot.answer_callback_query(call.id, "❌ Эирдроп уже забран другим игроком!", show_alert=True)
            try:
                bot.edit_message_text("📦 <i>Ящик военного эирдропа уже пуст и обыскан другим выжившим!</i>", call.message.chat.id, call.message.message_id)
            except Exception:
                pass
            return

        # Deactivate immediately
        airdrop["active"] = False
        now = int(time.time())
        airdrop["looted_by"] = player.get("username") or str(player["user_id"])
        airdrop["looted_at"] = now

        loot = generate_airdrop_loot()

        add_player_rubles(player, loot["rubles"])
        player["btc"] = round(player.get("btc", 0.0) + loot["btc"], 3)
        player.setdefault("stats", {})["airdrop_looted"] = player.get("stats", {}).get("airdrop_looted", 0) + 1

        dropped_air_items = 0
        for itm in loot["items"]:
            if can_store_item(player, itm["id"]):
                player.setdefault("stash", []).append({
                    "uid": f"air_{now}_{random.randint(100,999)}",
                    "item_id": itm["id"],
                    "equipped_to": None
                })
            else:
                dropped_air_items += 1
        save_db(db)

    # Edit caller message so others see it's looted
    try:
        looter_tag = f"@{player.get('username')}" if player.get("username") else f"Боец #{player['user_id']}"
        bot.edit_message_text(
            f"📦 <b>ВОЕННЫЙ ЭИРДРОП ОБЫСКАН!</b>\n"
            f"Счастливчик {looter_tag} первым добрался до контейнера и забрал военный груз!",
            call.message.chat.id,
            call.message.message_id
        )
    except Exception:
        pass

    txt = (
        f"🎉 <b>ВЫ ПЕРВЫМ ДОБРАЛИСЬ ДО ЭИРДРОПА!</b>\n"
        f"💰 Наличные: +<b>{fmt_rub(loot['rubles'])}</b>\n"
        f"🪙 Биткоины: +<b>{loot['btc']} BTC</b>\n\n"
        f"<b>Захваченное армейское снаряжение:</b>\n"
    )
    for itm in loot["items"]:
        r_b = {"mythic": "🔴", "legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        price_str = f" ({fmt_rub(itm.get('price', 0))})" if itm.get("price") else ""
        txt += f"{r_b} <b>{itm['name']}</b>{price_str}\n"

    if dropped_air_items > 0:
        txt += f"\n⚠️ <b>{dropped_air_items} предм.</b> не поместились в переполненный склад и пропали!\n"

    markup = types.InlineKeyboardMarkup(row_width=1).add(
        types.InlineKeyboardButton("📦 Открыть Схрон", callback_data="menu_stash"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.send_message(call.message.chat.id, txt, reply_markup=markup)
    bot.answer_callback_query(call.id, "✅ Эирдроп успешно залутан!")

# ----------------- SECTION 11: ADMIN PANEL (@revenuts) -----------------
def handle_menu_admin(chat_id, msg_id, player):
    txt = (
        "<b>💀 ПАНЕЛЬ УПРАВЛЕНИЯ РАЗРАБОТЧИКА / АДМИНИСТРАТОРА</b>\n"
        "Ранг: <b>💀 [ADMIN] 💰 REVENANT GD 💰 💀</b>\n"
        "────────────────────────\n"
        "Быстрые функции отладки и административные команды:\n"
        "────────────────────────\n"
        "<b>👑 Команды выдачи одежды и титулов:</b>\n"
        "• <code>/give_headwear @ник Название</code> (Шапки/шлемы)\n"
        "• <code>/give_suit @ник Название</code> (Костюмы/верх)\n"
        "• <code>/give_shoes @ник Название</code> (Обувь/берцы)\n"
        "• <code>/give_accessory @ник Название</code> (Аксессуары)\n"
        "• <code>/give_cloth @ник слот Название</code>\n"
        "• <code>/set_title @ник Текст титула</code>\n"
        "• <code>/clear_title @ник</code>\n"
        "<i>(Все команды также работают через Reply на сообщение игрока)</i>\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("💰 +1 000 000 ₽", callback_data="admin_action_give1m"),
        types.InlineKeyboardButton("💰 +10 000 000 ₽", callback_data="admin_action_give10m")
    )
    markup.add(
        types.InlineKeyboardButton("🪙 +10 BTC", callback_data="admin_action_give10btc"),
        types.InlineKeyboardButton("🔑 3x Ключ-карты Лабы", callback_data="admin_action_givekeycards")
    )
    markup.add(
        types.InlineKeyboardButton("📟 Выдать Датчик DSP", callback_data="admin_action_givedsp"),
        types.InlineKeyboardButton("🎯 Сет Зрячего (3 шт)", callback_data="admin_action_givezryachiy")
    )
    markup.add(
        types.InlineKeyboardButton("💼 Выдать Кейс Black Div.", callback_data="admin_action_givecase"),
        types.InlineKeyboardButton("🎖️ Выдать Жетон Goons", callback_data="admin_action_givetoken")
    )
    markup.add(
        types.InlineKeyboardButton("💀 Выдать Сет Goons (9 предм)", callback_data="admin_action_givegoonsset"),
        types.InlineKeyboardButton("🪖 Топ-Экипировка", callback_data="admin_action_topgear")
    )
    markup.add(
        types.InlineKeyboardButton("🔩 Редкие Компоненты", callback_data="admin_action_components"),
        types.InlineKeyboardButton("✈️ Сбросить Эирдроп", callback_data="admin_action_airdrop")
    )
    markup.add(
        types.InlineKeyboardButton("🏚️ Макс. Убежище (Ур. 10)", callback_data="admin_action_maxhideout"),
        types.InlineKeyboardButton("🏢 Макс. Склады (Ур. 10)", callback_data="admin_action_maxwarehouses")
    )
    markup.add(
        types.InlineKeyboardButton("⏳ Сбросить Кулдауны", callback_data="admin_action_resetcds"),
        types.InlineKeyboardButton("📉 Сменить Кризис", callback_data="admin_action_newcrisis")
    )
    markup.add(
        types.InlineKeyboardButton("🔄 Сбросить профиль", callback_data="admin_action_reset"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    if msg_id:
        try:
            bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
            return
        except Exception:
            pass
    bot.send_message(chat_id, txt, reply_markup=markup)

def handle_admin_action(call, player, db, act):
    now = int(time.time())
    if act == "give1m":
        player["money"] = player.get("money", 0) + 1000000
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Начислено +1 000 000 ₽")
    elif act == "give10m":
        player["money"] = player.get("money", 0) + 10000000
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Начислено +10 000 000 ₽")
    elif act == "give10btc":
        player["btc"] = round(player.get("btc", 0.0) + 10.0, 4)
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Начислено +10 BTC")
    elif act == "givekeycards":
        for i in range(3):
            player.setdefault("stash", []).append({
                "uid": f"adm_kc_{now}_{i}",
                "item_id": "lab_keycard_red_legendary",
                "equipped_to": None
            })
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Выдано 3x Красных Ключ-карты Лаборатории!")
    elif act == "topgear":
        items = ["mk18_mjolnir_legendary", "slick_armor_legendary", "vulkan5_helmet_legendary", "headset_amp_epic"]
        for idx, tid in enumerate(items):
            player.setdefault("stash", []).append({"uid": f"adm_{now}_{idx}", "item_id": tid, "equipped_to": None})
        save_db(db)
        bot.answer_callback_query(call.id, "✅ В схрон добавлены Mk-18, Slick, Вулкан-5 и Ops-Core AMP!")
    elif act == "components":
        for i in range(5):
            player.setdefault("stash", []).append({"uid": f"adm_cmp_{now}_{i}", "item_id": "comp_circuit_board_epic", "equipped_to": None})
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Добавлены военные платы!")
    elif act == "airdrop":
        db.setdefault("airdrop", {})["active"] = True
        db["airdrop"]["last_spawn"] = now
        save_db(db)
        bot.answer_callback_query(call.id, "🚨 Эирдроп активирован в зоне!")
        bot.send_message(
            call.message.chat.id,
            "✈️ <b>ВНИМАНИЕ! ИЛ-76 СБРОСИЛ ВОЕННЫЙ ЭИРДРОП!</b>\n"
            "Контейнер опустился на парашюте! Кто первый нажмет кнопку — заберет лут!",
            reply_markup=types.InlineKeyboardMarkup().add(
                types.InlineKeyboardButton("📦 ОБЫСКАТЬ ЯЩИК", callback_data="loot_airdrop_box")
            )
        )
    elif act == "maxhideout":
        player["hideout_lvl"] = 10
        for m in player.get("modules", {}):
            player["modules"][m] = 10
        for b in player.get("businesses", {}):
            player["businesses"][b] = 10
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Убежище, модули и бизнесы прокачаны до 10 уровня!")
    elif act == "maxwarehouses":
        wh = player.setdefault("warehouses", {})
        for cat in BASE_WAREHOUSE_CAPS:
            wh[cat] = 10
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Все 4 склада прокачаны до 10 уровня!")
    elif act == "resetcds":
        player["last_raid_time"] = 0
        player["coop_cooldown_until"] = 0
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Все кулдауны и травмы отряда сброшены!")
    elif act == "newcrisis":
        db["economic_crisis"]["expires_at"] = 0
        check_and_update_economic_crisis(db)
        save_db(db)
        bot.answer_callback_query(call.id, "📉 Новый экономический кризис сгенерирован!")
    elif act == "givedsp":
        add_mythic_item_to_player(player, "mythic_dsp_sensor")
        player["guard_until"] = now + 86400 * 365
        player["is_base_captured"] = False
        claim_zryachiy_gear_supply(player)
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Выдан Датчик DSP + 3 предмета Зрячего доставлены в схрон!", show_alert=True)
    elif act == "givezryachiy":
        add_mythic_item_to_player(player, "mythic_dsp_sensor")
        player["guard_until"] = now + 86400 * 365
        player["is_base_captured"] = False
        for itm in ZRYACHIY_GEAR:
            player.setdefault("stash", []).append({
                "uid": f"adm_zry_{now}_{random.randint(100,999)}",
                "item_id": itm["id"],
                "equipped_to": None
            })
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Выдан Датчик DSP + AXMC .338, Плитник Сектантов и Капюшон Зрячего!", show_alert=True)
    elif act == "givecase":
        add_mythic_item_to_player(player, "mythic_black_division_case")
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Выдан Дипломатический кейс Black Division!", show_alert=True)
    elif act == "givetoken":
        add_mythic_item_to_player(player, "mythic_goons_token")
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Выдан Жетон Отступников (The Goons)!", show_alert=True)
    elif act == "givegoonsset":
        add_mythic_item_to_player(player, "mythic_goons_token")
        for itm in GOONS_GEAR:
            player.setdefault("stash", []).append({
                "uid": f"adm_goon_{now}_{random.randint(100,999)}",
                "item_id": itm["id"],
                "equipped_to": None
            })
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Выдан Жетон + все 9 предметов The Goons!", show_alert=True)
    elif act == "list_menu_photos":
        txt = "🖼️ <b>КАТАЛОГ ОБЛОЖЕК МЕНЮ:</b>\n────────────────────────\n"
        for m_key, m_title in MENU_NAMES_MAP.items():
            cur = get_menu_photo(m_key, db)
            is_custom = "Кастомное ✅" if db.get("menu_photos", {}).get(m_key) else "Стандартное ⚙️"
            txt += f"• <b>{m_title}</b> (<code>{m_key}</code>): {is_custom}\n<code>{cur[:65]}...</code>\n\n"
        txt += "<i>Установка: отправьте фото с подписью <code>/set_supply_photo</code>, ответом на фото или <code>/set_menu_photo supply &lt;url&gt;</code></i>"
        bot.send_message(call.message.chat.id, txt, parse_mode="HTML")
        bot.answer_callback_query(call.id)
        return
    elif act == "reset":
        db["users"][str(player["user_id"])] = create_new_player(player["user_id"], player.get("username"), "Revenant")
        save_db(db)
        bot.answer_callback_query(call.id, "🔄 Профиль сброшен к начальному состоянию!")
    handle_menu_admin(call.message.chat.id, call.message.message_id, db["users"][str(player["user_id"])])

# Admin Text Commands
@bot.message_handler(commands=['airdrop', 'spawn_airdrop'])
def cmd_airdrop(message):
    if not is_admin(message.from_user.id, message.from_user.username):
        bot.reply_to(message, "❌ Вызывать самолет Ил-76 с эирдропом может только администратор!")
        return
    db = load_db()
    db.setdefault("airdrop", {})["active"] = True
    db["airdrop"]["last_spawn"] = int(time.time())
    save_db(db)
    bot.send_message(
        message.chat.id,
        "✈️ <b>ВОЕННЫЙ ЭИРДРОП СБРОШЕН В СЕКТОРЕ!</b>\n"
        "Нажмите кнопку, чтобы забрать армейский лут!",
        reply_markup=types.InlineKeyboardMarkup().add(
            types.InlineKeyboardButton("📦 ОБЫСКАТЬ ЯЩИК", callback_data="loot_airdrop_box")
        )
    )

def find_target_player(db, target_str, caller_id):
    if not target_str:
        u = db["users"].get(str(caller_id))
        if not u:
            u = db["users"].get(caller_id)
        if not u:
            u = create_new_player(caller_id, "Admin", "Revenant")
            db["users"][str(caller_id)] = u
            save_db(db)
        return u
    clean = target_str.lstrip("@").lower().strip()
    if clean in db["users"]:
        return db["users"][clean]
    for u in db["users"].values():
        if str(u.get("user_id")) == clean:
            return u
        if (u.get("username") or "").lower().lstrip("@") == clean:
            return u
        if (u.get("telegram_username") or "").lower().lstrip("@") == clean:
            return u
    return None

def resolve_item_alias(arg):
    if not arg:
        return None
    raw = arg.lower().strip()
    if arg in ITEMS_BY_ID:
        return arg
    if raw in ITEMS_BY_ID:
        return raw

    alias_map = {
        "dsp": "mythic_dsp_sensor",
        "sensor": "mythic_dsp_sensor",
        "dsp_sensor": "mythic_dsp_sensor",
        "mythic_dsp": "mythic_dsp_sensor",
        "датчик": "mythic_dsp_sensor",
        "зрячий": "mythic_dsp_sensor",
        "zryachiy": "mythic_dsp_sensor",
        "маяк": "mythic_dsp_sensor",
        "lighthouse": "mythic_dsp_sensor",
        "axmc": "zryachiy_axmc_338",
        "zryachiy_axmc": "zryachiy_axmc_338",
        "снайперка": "zryachiy_axmc_338",
        "винтовка": "zryachiy_axmc_338",
        "vest": "zryachiy_cultist_vest",
        "плитник": "zryachiy_cultist_vest",
        "броня": "zryachiy_cultist_vest",
        "zryachiy_vest": "zryachiy_cultist_vest",
        "hood": "zryachiy_hood_mask",
        "капюшон": "zryachiy_hood_mask",
        "жнец": "zryachiy_hood_mask",
        "zryachiy_hood": "zryachiy_hood_mask",
        "zryachiy_reaper_hood": "zryachiy_hood_mask",
        "case": "mythic_black_division_case",
        "кейс": "mythic_black_division_case",
        "дипломат": "mythic_black_division_case",
        "black_division": "mythic_black_division_case",
        "blackdivision": "mythic_black_division_case",
        "token": "mythic_goons_token",
        "жетон": "mythic_goons_token",
        "goons": "mythic_goons_token",
        "the_goons": "mythic_goons_token",
        "отступники": "mythic_goons_token"
    }
    if raw in alias_map:
        return alias_map[raw]

    for k, v in ITEMS_BY_ID.items():
        if raw == k.lower():
            return k
    return None

@bot.message_handler(commands=['admin', 'panel', 'dev'])
def cmd_open_admin_panel(message):
    if not is_admin(message.from_user.id, message.from_user.username):
        bot.reply_to(message, f"❌ Доступ разрешен только администратору.\nВаш ID: {message.from_user.id}, @{message.from_user.username or 'ник не задан'}.\nДля доступа укажите ADMIN_USER_ID={message.from_user.id} в файле .env.")
        return
    db = load_db()
    u = find_target_player(db, None, message.from_user.id)
    handle_menu_admin(message.chat.id, None, u)


def parse_admin_target_and_payload(message, db):
    """
    Parses admin command targeting a player via reply_to_message or @username / user_id.
    Returns (target_player, remaining_text, target_label)
    """
    raw_text = message.text or ""
    parts = raw_text.split(maxsplit=1)
    if len(parts) < 2:
        if getattr(message, 'reply_to_message', None) and message.reply_to_message.from_user:
            reply_uid = str(message.reply_to_message.from_user.id)
            target = find_target_player(db, reply_uid, message.from_user.id)
            lbl = f"@{message.reply_to_message.from_user.username or message.reply_to_message.from_user.id}"
            return target, "", lbl
        return None, "", ""

    rest = parts[1].strip()

    # Reply handling
    if getattr(message, 'reply_to_message', None) and message.reply_to_message.from_user:
        words = rest.split(maxsplit=1)
        first_word = words[0]
        if first_word.startswith("@") or (first_word.isdigit() and len(first_word) >= 5):
            found = find_target_player(db, first_word, message.from_user.id)
            if found:
                payload = words[1].strip() if len(words) > 1 else ""
                return found, payload, first_word
        reply_uid = str(message.reply_to_message.from_user.id)
        target = find_target_player(db, reply_uid, message.from_user.id)
        lbl = f"@{message.reply_to_message.from_user.username or message.reply_to_message.from_user.id}"
        return target, rest, lbl

    # No reply: first token is target
    words = rest.split(maxsplit=1)
    first_word = words[0]
    target = find_target_player(db, first_word, message.from_user.id)
    if target:
        payload = words[1].strip() if len(words) > 1 else ""
        return target, payload, first_word
    else:
        return None, rest, first_word

def extract_photo_from_message(message, caller_id=None):
    """
    Safely extracts a photo file_id or image document from:
    1. The current message's attached photo
    2. The current message's attached image document
    3. The replied-to message's attached photo
    4. The replied-to message's attached image document
    5. The caller's recently uploaded photo buffer (PENDING_ADMIN_PHOTOS)
    """
    if getattr(message, "photo", None) and len(message.photo) > 0:
        return message.photo[-1].file_id
    if getattr(message, "document", None) and getattr(message.document, "mime_type", "").startswith("image/"):
        return message.document.file_id
    rep = getattr(message, "reply_to_message", None)
    if rep:
        if getattr(rep, "photo", None) and len(rep.photo) > 0:
            return rep.photo[-1].file_id
        if getattr(rep, "document", None) and getattr(rep.document, "mime_type", "").startswith("image/"):
            return rep.document.file_id
    if caller_id and PENDING_ADMIN_PHOTOS.get(caller_id):
        return PENDING_ADMIN_PHOTOS.get(caller_id)
    return None

@bot.message_handler(commands=[
    'give_money', 'give_item', 'give', 'give_mythic',
    'give_dsp', 'givedsp', 'give_zryachiy', 'give_case', 'give_goons', 'give_gear',
    'set_module', 'set_level', 'reset_player',
    'give_headwear', 'give_hat', 'give_cap',
    'give_suit', 'give_costume', 'give_top',
    'give_shoes', 'give_boots',
    'give_accessory', 'give_acc',
    'give_cloth', 'give_clothes', 'give_shmot',
    'set_title', 'settitle', 'title',
    'clear_title', 'remove_title', 'removetitle', 'del_title',
    'set_bp_max', 'max_bp', 'set_bp', 'setbp',
    'set_prestige', 'setprestige', 'max_prestige', 'prestige_max', 'prestige5', 'give_prestige',
    'set_user_photo', 'set_avatar', 'set_user_avatar', 'reset_user_photo', 'del_user_photo',
    'set_callsign', 'set_pmc_name', 'callsign', 'reset_callsign', 'del_callsign',
    'set_raids_photo', 'set_raid_photo', 'raids_photo', 'reset_raids_photo', 'del_raids_photo',
    'set_loc_photo', 'set_location_photo', 'reset_loc_photo', 'del_loc_photo',
    'list_menu_photos', 'menu_photos',
    'set_menu_photo', 'set_menu_art', 'reset_menu_photo', 'del_menu_photo',
    'set_supply_photo', 'set_supply', 'supply_photo', 'reset_supply_photo', 'del_supply_photo',
    'set_containers_photo', 'set_containers', 'containers_photo', 'set_cases_photo', 'set_cases', 'cases_photo', 'reset_containers_photo', 'reset_cases_photo', 'del_containers_photo', 'del_cases_photo',
    'set_stash_photo', 'set_stash', 'stash_photo', 'reset_stash_photo', 'del_stash_photo',
    'set_market_photo', 'set_market', 'market_photo', 'reset_market_photo', 'del_market_photo',
    'set_ashot_photo', 'set_ashot', 'ashot_photo', 'reset_ashot_photo', 'del_ashot_photo',
    'set_goons_photo', 'set_goons', 'goons_photo', 'reset_goons_photo', 'del_goons_photo',
    'set_black_division_photo', 'set_bd_photo', 'set_black_division', 'set_bd', 'bd_photo', 'reset_black_division_photo', 'reset_bd_photo', 'del_black_division_photo', 'del_bd_photo',
    'set_zryachiy_photo', 'set_zryachiy', 'zryachiy_photo', 'reset_zryachiy_photo', 'del_zryachiy_photo',
    'set_darkzone_photo', 'set_darkzone', 'darkzone_photo', 'reset_darkzone_photo', 'del_darkzone_photo',
    'set_base_guard_photo', 'set_base_guard', 'set_guard_photo', 'set_guard', 'guard_photo', 'reset_base_guard_photo', 'reset_guard_photo', 'del_base_guard_photo', 'del_guard_photo',
    'set_signature_photo', 'set_signature_raid_photo', 'set_signature', 'signature_photo', 'reset_signature_photo', 'reset_signature_raid_photo', 'del_signature_photo'
], content_types=['text', 'photo', 'document'])
def cmd_admin_commands(message):
    u_name = getattr(message.from_user, "username", None)
    if not is_admin(message.from_user.id, u_name):
        bot.reply_to(message, f"❌ Доступ разрешен только администратору.\nВаш ID: {message.from_user.id}, @{u_name or 'ник не задан'}.\nДля доступа укажите ADMIN_USER_ID={message.from_user.id} в файле .env.")
        return

    raw_text = (getattr(message, "text", None) or getattr(message, "caption", None) or "").strip()
    if not raw_text:
        return
    parts = raw_text.split()
    cmd = parts[0].lower()
    if "@" in cmd:
        cmd = cmd.split("@")[0]

    db = load_db()
    caller_id = message.from_user.id
    if getattr(message, "photo", None) and len(message.photo) > 0:
        PENDING_ADMIN_PHOTOS[caller_id] = message.photo[-1].file_id
    elif getattr(message, "document", None) and getattr(message.document, "mime_type", "").startswith("image/"):
        PENDING_ADMIN_PHOTOS[caller_id] = message.document.file_id
    now = int(time.time())

    try:
        # Clothes administration: /give_headwear, /give_suit, /give_shoes, /give_accessory, /give_cloth
        if cmd in ["/give_headwear", "/give_hat", "/give_cap",
                   "/give_suit", "/give_costume", "/give_top",
                   "/give_shoes", "/give_boots",
                   "/give_accessory", "/give_acc",
                   "/give_cloth", "/give_clothes", "/give_shmot"]:
            if cmd in ["/give_headwear", "/give_hat", "/give_cap"]:
                fixed_slot = "headwear"
            elif cmd in ["/give_suit", "/give_costume", "/give_top"]:
                fixed_slot = "suit"
            elif cmd in ["/give_shoes", "/give_boots"]:
                fixed_slot = "shoes"
            elif cmd in ["/give_accessory", "/give_acc"]:
                fixed_slot = "accessory"
            else:
                fixed_slot = None

            target_player, payload, target_lbl = parse_admin_target_and_payload(message, db)
            if not target_player:
                bot.reply_to(
                    message,
                    f"❌ <b>Игрок не найден!</b>\n"
                    f"Использование: <code>{cmd} @username Название вещи</code>\n"
                    f"Или ответьте (Reply) на сообщение игрока: <code>{cmd} Название вещи</code>"
                )
                return

            if fixed_slot:
                slot_to_use = fixed_slot
                item_name = payload.strip()
            else:
                cloth_tokens = payload.split(maxsplit=1)
                if len(cloth_tokens) < 2:
                    bot.reply_to(
                        message,
                        "❌ <b>Укажите категорию и название!</b>\n"
                        f"Пример: <code>{cmd} @username headwear Шапка \"Russia\"</code>\n"
                        "Доступные категории: <code>headwear</code>, <code>suit</code>, <code>shoes</code>, <code>accessory</code>"
                    )
                    return
                slot_to_use = cloth_tokens[0]
                item_name = cloth_tokens[1].strip()

            if not item_name:
                bot.reply_to(message, f"❌ Укажите название предмета!\nПример: <code>{cmd} @username Шапка \"Russia\"</code>")
                return

            ok, res_msg, entry, is_custom = admin_grant_clothing(target_player, slot_to_use, item_name)
            if not ok:
                bot.reply_to(message, res_msg)
                return

            save_db(db)

            cat_info = CLOTHES_CATEGORIES.get(entry["slot"], {"name": "Одежда", "icon": "👕"})
            target_chat_id = target_player.get("user_id")
            if target_chat_id and str(target_chat_id) != str(caller_id):
                try:
                    bot.send_message(
                        target_chat_id,
                        f"🎁 <b>ПОДАРОК ОТ АДМИНИСТРАЦИИ!</b>\n"
                        f"────────────────────────\n"
                        f"Вам выдан предмет в <b>Гардероб</b>:\n"
                        f"• {cat_info['icon']} <b>{entry['name']}</b> ({cat_info['name']})\n"
                        f"<i>Статус: {'🌟 Эксклюзив от Админа' if is_custom else '📦 Каталог Ашота'}</i>\n\n"
                        f"👉 Откройте <i>Схрон → Шмот (Гардероб)</i>, чтобы примерить обновку!"
                    )
                except Exception:
                    pass

            bot.reply_to(
                message,
                f"✅ <b>ВЫДАЧА ОДЕЖДЫ ВЫПОЛНЕНА УСПЕШНО!</b>\n"
                f"────────────────────────\n"
                f"👤 Получатель: <b>@{target_player.get('username') or target_player.get('user_id')}</b>\n"
                f"📂 Категория: {cat_info['icon']} <b>{cat_info['name']}</b>\n"
                f"🎽 Предмет: <b>{entry['name']}</b>\n"
                f"✨ Тип: <b>{'🌟 Новый сгенерированный эксклюзив' if is_custom else '📦 Из каталога'}</b>\n"
                f"🆔 UID: <code>{entry['uid']}</code>\n\n"
                f"<i>Игрок может надеть вещь прямо сейчас в меню «Гардероб».</i>"
            )
            return

        # Title administration: /set_title, /clear_title
        elif cmd in ["/set_title", "/settitle", "/title"]:
            target_player, payload, target_lbl = parse_admin_target_and_payload(message, db)
            if not target_player:
                bot.reply_to(
                    message,
                    f"❌ <b>Игрок не найден!</b>\n"
                    f"Использование: <code>{cmd} @username Текст титула</code>\n"
                    f"Или ответьте (Reply) на сообщение игрока: <code>{cmd} Текст титула</code>"
                )
                return

            title_text = payload.strip()
            if not title_text:
                bot.reply_to(message, "❌ Укажите текст титула!\nПример: <code>/set_title @username 👑 Легенда Таркова 👑</code>")
                return

            ok, res_msg = admin_set_player_title(target_player, title_text)
            if not ok:
                bot.reply_to(message, res_msg)
                return

            save_db(db)

            target_chat_id = target_player.get("user_id")
            if target_chat_id and str(target_chat_id) != str(caller_id):
                try:
                    bot.send_message(
                        target_chat_id,
                        f"🎖️ <b>ВАМ ПРИСВОЕН ОСОБЫЙ ТИТУЛ!</b>\n"
                        f"────────────────────────\n"
                        f"Администрация установила вам почетный титул:\n"
                        f"🏷️ <b>{target_player['custom_title']}</b>\n\n"
                        f"<i>Титул теперь виден в Главном Меню, в профиле ЧВК, карточках PvP-дуэлей и кооп-рейдов!</i>"
                    )
                except Exception:
                    pass

            bot.reply_to(
                message,
                f"✅ <b>ТИТУЛ УСПЕШНО УСТАНОВЛЕН!</b>\n"
                f"────────────────────────\n"
                f"👤 Игрок: <b>@{target_player.get('username') or target_player.get('user_id')}</b>\n"
                f"🏷️ Новый титул: <b>{target_player['custom_title']}</b>\n\n"
                f"<i>Отображается во всех меню профиля и рейдов.</i>"
            )
            return

        elif cmd in ["/clear_title", "/remove_title", "/removetitle", "/del_title"]:
            target_player, payload, target_lbl = parse_admin_target_and_payload(message, db)
            if not target_player:
                bot.reply_to(
                    message,
                    f"❌ <b>Игрок не найден!</b>\n"
                    f"Использование: <code>{cmd} @username</code>\n"
                    f"Или ответьте (Reply) на сообщение игрока: <code>{cmd}</code>"
                )
                return

            ok, res_msg = admin_clear_player_title(target_player)
            save_db(db)

            bot.reply_to(
                message,
                f"✅ <b>ТИТУЛ СНЯТ!</b>\n"
                f"👤 Игрок: <b>@{target_player.get('username') or target_player.get('user_id')}</b>\n"
                f"{res_msg}"
            )
            return

        # Quick commands for DSP / Zryachiy
        if cmd in ["/give_dsp", "/givedsp", "/give_zryachiy"]:
            target_arg = parts[1] if len(parts) >= 2 else None
            u = find_target_player(db, target_arg, caller_id)
            if not u:
                bot.reply_to(message, "❌ Игрок не найден.")
                return
            add_mythic_item_to_player(u, "mythic_dsp_sensor")
            u["guard_until"] = now + 86400 * 365
            u["is_base_captured"] = False
            claim_zryachiy_gear_supply(u)
            save_db(db)
            bot.reply_to(
                message,
                f"✅ <b>ДАТЧИК DSP И СЕТ ЗРЯЧЕГО ВЫДАНЫ!</b>\n"
                f"👤 Получатель: @{u.get('username') or u.get('user_id')}\n"
                f"• 📟 <b>Закодированный датчик DSP Смотрителя</b> (150 000 000 ₽) активирован!\n"
                f"• 👁️ <b>100% Вечная защита базы ЧВК</b> активирована (мародеры и кражи отключены)!\n"
                f"• 📦 <b>3 предмета экипировки Зрячего</b> (AXMC .338, Плитник, Капюшон) доставлены в схрон!"
            )
            return

        
                # Menu photo commands
        # Menu photo commands
        elif cmd in ["/list_menu_photos", "/menu_photos"]:
            txt = "🖼️ <b>КАТАЛОГ ОБЛОЖЕК МЕНЮ:</b>\n────────────────────────\n"
            for m_key, m_title in MENU_NAMES_MAP.items():
                cur = get_menu_photo(m_key, db)
                is_custom = "Кастомное ✅" if db.get("menu_photos", {}).get(m_key) else "Стандартное ⚙️"
                txt += f"• <b>{m_title}</b> (<code>{m_key}</code>): {is_custom}\n<code>{cur[:65]}...</code>\n\n"
            txt += "<i>Установка: отправьте фото с подписью <code>/set_supply_photo</code>, ответом на фото или <code>/set_menu_photo supply &lt;url&gt;</code></i>"
            bot.reply_to(message, txt, parse_mode="HTML")
            return
        elif cmd in ["/set_menu_photo", "/set_menu_art"]:
            if len(parts) < 2:
                bot.reply_to(message, "❌ Использование: <code>/set_menu_photo <меню> [url]</code>\nМеню: supply, containers, stash, market, ashot, the_goons, black_division, zryachiy, darkzone, base_guard, signature_raid", parse_mode="HTML")
                return
            m_raw = parts[1].lower()
            m_key = MENU_ALIASES.get(m_raw)
            if not m_key:
                bot.reply_to(message, f"❌ Неизвестное меню: <code>{m_raw}</code>.\nДопустимые: " + ", ".join(sorted(list(MENU_NAMES_MAP.keys()))), parse_mode="HTML")
                return
            photo_url = parts[2] if len(parts) > 2 and (parts[2].startswith("http://") or parts[2].startswith("https://") or parts[2].startswith("AgAC")) else None
            if not photo_url:
                photo_url = extract_photo_from_message(message, caller_id)
            if not photo_url:
                bot.reply_to(message, "❌ Фото не указано! Отправьте команду вместе с URL, ответом на фото или прикрепите фото к сообщению.", parse_mode="HTML")
                return
            db.setdefault("menu_photos", {})[m_key] = photo_url
            save_db(db)
            m_name = MENU_NAMES_MAP.get(m_key, m_key)
            bot.reply_to(message, f"✅ Фото для меню <b>«{m_name}»</b> успешно обновлено!", parse_mode="HTML")
            return
        elif cmd in ["/reset_menu_photo", "/del_menu_photo"]:
            if len(parts) < 2:
                bot.reply_to(message, "❌ Использование: <code>/reset_menu_photo <меню></code>", parse_mode="HTML")
                return
            m_raw = parts[1].lower()
            m_key = MENU_ALIASES.get(m_raw)
            if not m_key:
                bot.reply_to(message, f"❌ Неизвестное меню: <code>{m_raw}</code>.", parse_mode="HTML")
                return
            if "menu_photos" in db:
                db["menu_photos"].pop(m_key, None)
            save_db(db)
            m_name = MENU_NAMES_MAP.get(m_key, m_key)
            bot.reply_to(message, f"✅ Фото для меню <b>«{m_name}»</b> сброшено к стандартному арту.", parse_mode="HTML")
            return
        elif cmd in [
            "/set_supply_photo", "/set_supply", "/supply_photo",
            "/set_containers_photo", "/set_containers", "/containers_photo",
            "/set_cases_photo", "/set_cases", "/cases_photo",
            "/set_stash_photo", "/set_stash", "/stash_photo",
            "/set_market_photo", "/set_market", "/market_photo",
            "/set_ashot_photo", "/set_ashot", "/ashot_photo",
            "/set_goons_photo", "/set_goons", "/goons_photo",
            "/set_black_division_photo", "/set_bd_photo", "/set_black_division", "/set_bd", "/bd_photo",
            "/set_zryachiy_photo", "/set_zryachiy", "/zryachiy_photo",
            "/set_darkzone_photo", "/set_darkzone", "/darkzone_photo",
            "/set_base_guard_photo", "/set_guard_photo", "/set_base_guard", "/set_guard", "/guard_photo",
            "/set_signature_photo", "/set_signature_raid_photo", "/set_signature", "/signature_photo"
        ]:
            shortcut_map = {
                "/set_supply_photo": "supply",
                "/set_supply": "supply",
                "/supply_photo": "supply",
                "/set_containers_photo": "containers",
                "/set_containers": "containers",
                "/containers_photo": "containers",
                "/set_cases_photo": "containers",
                "/set_cases": "containers",
                "/cases_photo": "containers",
                "/set_stash_photo": "stash",
                "/set_stash": "stash",
                "/stash_photo": "stash",
                "/set_market_photo": "market",
                "/set_market": "market",
                "/market_photo": "market",
                "/set_ashot_photo": "ashot",
                "/set_ashot": "ashot",
                "/ashot_photo": "ashot",
                "/set_goons_photo": "the_goons",
                "/set_goons": "the_goons",
                "/goons_photo": "the_goons",
                "/set_black_division_photo": "black_division",
                "/set_bd_photo": "black_division",
                "/set_black_division": "black_division",
                "/set_bd": "black_division",
                "/bd_photo": "black_division",
                "/set_zryachiy_photo": "zryachiy",
                "/set_zryachiy": "zryachiy",
                "/zryachiy_photo": "zryachiy",
                "/set_darkzone_photo": "darkzone",
                "/set_darkzone": "darkzone",
                "/darkzone_photo": "darkzone",
                "/set_base_guard_photo": "base_guard",
                "/set_guard_photo": "base_guard",
                "/set_base_guard": "base_guard",
                "/set_guard": "base_guard",
                "/guard_photo": "base_guard",
                "/set_signature_photo": "signature_raid",
                "/set_signature_raid_photo": "signature_raid",
                "/set_signature": "signature_raid",
                "/signature_photo": "signature_raid",
            }
            m_key = shortcut_map[cmd]
            photo_url = parts[1] if len(parts) > 1 and (parts[1].startswith("http://") or parts[1].startswith("https://") or parts[1].startswith("AgAC")) else None
            if not photo_url:
                photo_url = extract_photo_from_message(message, caller_id)
            if not photo_url:
                bot.reply_to(message, "❌ Фото не указано! Отправьте команду вместе с URL, ответом на фото или прикрепите фото к сообщению.", parse_mode="HTML")
                return
            db.setdefault("menu_photos", {})[m_key] = photo_url
            save_db(db)
            m_name = MENU_NAMES_MAP.get(m_key, m_key)
            bot.reply_to(message, f"✅ Фото для меню <b>«{m_name}»</b> успешно обновлено!", parse_mode="HTML")
            return
        elif cmd in [
            "/reset_supply_photo", "/reset_supply", "/del_supply_photo",
            "/reset_containers_photo", "/reset_containers", "/reset_cases_photo", "/reset_cases", "/del_containers_photo", "/del_cases_photo",
            "/reset_stash_photo", "/reset_stash", "/del_stash_photo",
            "/reset_market_photo", "/reset_market", "/del_market_photo",
            "/reset_ashot_photo", "/reset_ashot", "/del_ashot_photo",
            "/reset_goons_photo", "/reset_goons", "/del_goons_photo",
            "/reset_black_division_photo", "/reset_bd_photo", "/reset_black_division", "/reset_bd", "/del_black_division_photo", "/del_bd_photo",
            "/reset_zryachiy_photo", "/reset_zryachiy", "/del_zryachiy_photo",
            "/reset_darkzone_photo", "/reset_darkzone", "/del_darkzone_photo",
            "/reset_base_guard_photo", "/reset_guard_photo", "/reset_base_guard", "/reset_guard", "/del_base_guard_photo", "/del_guard_photo",
            "/reset_signature_photo", "/reset_signature_raid_photo", "/reset_signature", "/del_signature_photo"
        ]:
            shortcut_reset_map = {
                "/reset_supply_photo": "supply",
                "/reset_supply": "supply",
                "/del_supply_photo": "supply",
                "/reset_containers_photo": "containers",
                "/reset_containers": "containers",
                "/reset_cases_photo": "containers",
                "/reset_cases": "containers",
                "/del_containers_photo": "containers",
                "/del_cases_photo": "containers",
                "/reset_stash_photo": "stash",
                "/reset_stash": "stash",
                "/del_stash_photo": "stash",
                "/reset_market_photo": "market",
                "/reset_market": "market",
                "/del_market_photo": "market",
                "/reset_ashot_photo": "ashot",
                "/reset_ashot": "ashot",
                "/del_ashot_photo": "ashot",
                "/reset_goons_photo": "the_goons",
                "/reset_goons": "the_goons",
                "/del_goons_photo": "the_goons",
                "/reset_black_division_photo": "black_division",
                "/reset_bd_photo": "black_division",
                "/reset_black_division": "black_division",
                "/reset_bd": "black_division",
                "/del_black_division_photo": "black_division",
                "/del_bd_photo": "black_division",
                "/reset_zryachiy_photo": "zryachiy",
                "/reset_zryachiy": "zryachiy",
                "/del_zryachiy_photo": "zryachiy",
                "/reset_darkzone_photo": "darkzone",
                "/reset_darkzone": "darkzone",
                "/del_darkzone_photo": "darkzone",
                "/reset_base_guard_photo": "base_guard",
                "/reset_guard_photo": "base_guard",
                "/reset_base_guard": "base_guard",
                "/reset_guard": "base_guard",
                "/del_base_guard_photo": "base_guard",
                "/del_guard_photo": "base_guard",
                "/reset_signature_photo": "signature_raid",
                "/reset_signature_raid_photo": "signature_raid",
                "/reset_signature": "signature_raid",
                "/del_signature_photo": "signature_raid",
            }
            m_key = shortcut_reset_map[cmd]
            if "menu_photos" in db:
                db["menu_photos"].pop(m_key, None)
            save_db(db)
            m_name = MENU_NAMES_MAP.get(m_key, m_key)
            bot.reply_to(message, f"✅ Фото для меню <b>«{m_name}»</b> сброшено к стандарту.", parse_mode="HTML")
            return
        elif cmd in ["/set_raids_photo", "/set_raid_photo", "/raids_photo"]:
            photo_file_id = extract_photo_from_message(message, caller_id)
            if not photo_file_id:
                bot.reply_to(message, "❌ Фото не найдено в буфере!\nПрикрепите фото к сообщению, отправьте команду ответом (reply) на фото или отправьте фото боту.", parse_mode="HTML")
                return
            db["raids_menu_photo"] = photo_file_id
            save_db(db)
            bot.reply_to(
                message,
                f"✅ <b>Фото для меню «Рейды в Тарков» успешно обновлено!</b>\n\n"
                f"🔑 <b>Telegram file_id:</b>\n<code>{photo_file_id}</code>\n\n"
                f"<i>Теперь все игроки видят этот арт над текстом меню рейдов.</i>",
                parse_mode="HTML"
            )
            return
        elif cmd in ["/reset_raids_photo", "/del_raids_photo"]:
            db.pop("raids_menu_photo", None)
            save_db(db)
            bot.reply_to(message, "✅ Фото меню рейдов сброшено к стандартному арту.", parse_mode="HTML")
            return
        elif cmd in ["/set_loc_photo", "/set_location_photo"]:
            loc_arg = (parts[1].lower() if len(parts) > 1 else "").strip()
            loc_alias = {
                "завод": "factory", "factory": "factory",
                "таможня": "customs", "customs": "customs",
                "лес": "woods", "woods": "woods",
                "резерв": "reserve", "reserve": "reserve",
                "лаборатория": "labs", "лаба": "labs", "лаб": "labs", "labs": "labs"
            }
            loc_key = loc_alias.get(loc_arg)
            if not loc_key:
                bot.reply_to(message, "❌ Укажите локацию: <code>/set_loc_photo factory</code> (или customs, woods, reserve, labs, завод, таможня, лес, резерв, лаборатория)", parse_mode="HTML")
                return
            photo_file_id = extract_photo_from_message(message, caller_id)
            if not photo_file_id:
                bot.reply_to(message, "❌ Фото не найдено в буфере!\nПрикрепите фото к сообщению, отправьте команду ответом (reply) на фото или отправьте фото боту.", parse_mode="HTML")
                return
            db.setdefault("location_photos", {})[loc_key] = photo_file_id
            save_db(db)
            loc_title = LOC_NAMES_MAP.get(loc_key, loc_key)
            bot.reply_to(
                message,
                f"✅ <b>Фото результатов рейда на локации «{loc_title}» успешно обновлено!</b>\n\n"
                f"🔑 <b>Telegram file_id:</b>\n<code>{photo_file_id}</code>\n\n"
                f"<i>Теперь игроки после завершения рейда на этой локации видят этот арт над результатами.</i>",
                parse_mode="HTML"
            )
            return
        elif cmd in ["/reset_loc_photo", "/del_loc_photo"]:
            loc_arg = (parts[1].lower() if len(parts) > 1 else "").strip()
            loc_alias = {
                "завод": "factory", "factory": "factory",
                "таможня": "customs", "customs": "customs",
                "лес": "woods", "woods": "woods",
                "резерв": "reserve", "reserve": "reserve",
                "лаборатория": "labs", "лаба": "labs", "лаб": "labs", "labs": "labs"
            }
            loc_key = loc_alias.get(loc_arg)
            if not loc_key:
                bot.reply_to(message, "❌ Укажите локацию: <code>/reset_loc_photo factory</code>", parse_mode="HTML")
                return
            if "location_photos" in db:
                db["location_photos"].pop(loc_key, None)
            save_db(db)
            loc_title = LOC_NAMES_MAP.get(loc_key, loc_key)
            bot.reply_to(message, f"✅ Фото для локации «{loc_title}» сброшено к стандартному арту.", parse_mode="HTML")
            return
        elif cmd in ["/set_user_photo", "/set_avatar", "/set_user_avatar"]:
            target_player, payload, target_lbl = parse_admin_target_and_payload(message, db)
            if not target_player:
                bot.reply_to(message, "❌ Игрок не найден.\nИспользование: <code>/set_user_photo @username</code> (ответом на фото или после отправки фото боту).", parse_mode="HTML")
                return
            photo_file_id = extract_photo_from_message(message, caller_id)
            if not photo_file_id:
                bot.reply_to(message, "❌ Фото не найдено в буфере!\nПрикрепите фото к сообщению, отправьте команду ответом (reply) на фото или отправьте фото боту.", parse_mode="HTML")
                return
            target_player["custom_pmc_avatar"] = photo_file_id
            save_db(db)
            u_name = target_player.get("username") or target_player.get("user_id")
            bot.reply_to(
                message,
                f"✅ <b>Персональный арт ЧВК успешно привязан к @{u_name}!</b>\n\n"
                f"🔑 <b>Telegram file_id:</b>\n<code>{photo_file_id}</code>\n\n"
                f"<i>Игрок теперь видит этот арт в своем профиле и в HD-просмотре.</i>",
                parse_mode="HTML"
            )
            return
        elif cmd in ["/reset_user_photo", "/del_user_photo"]:
            target_player, payload, target_lbl = parse_admin_target_and_payload(message, db)
            if not target_player:
                bot.reply_to(message, "❌ Игрок не найден. Использование: <code>/reset_user_photo @username</code>", parse_mode="HTML")
                return
            target_player.pop("custom_pmc_avatar", None)
            save_db(db)
            u_name = target_player.get("username") or target_player.get("user_id")
            bot.reply_to(message, f"✅ Индивидуальное фото игрока @{u_name} сброшено к стандартному арту класса.", parse_mode="HTML")
            return
        # Custom visual PMC callsign commands
        elif cmd in ["/set_callsign", "/set_pmc_name", "/callsign"]:
            target_player, payload, target_lbl = parse_admin_target_and_payload(message, db)
            if not target_player:
                bot.reply_to(message, "❌ Игрок не найден.\nИспользование: <code>/set_callsign @username НовыйПозывной</code>", parse_mode="HTML")
                return
            new_callsign = payload.strip()
            if not new_callsign:
                bot.reply_to(message, "❌ Укажите позывной!\nПример: <code>/set_callsign @username Медведь</code>", parse_mode="HTML")
                return

            target_player["custom_pmc_callsign"] = new_callsign
            save_db(db)
            orig_class = target_player.get("pmc_signature", "Viper")
            p_info = PMC_DEFINITIONS.get(orig_class, {})
            u_name = target_player.get("username") or target_player.get("user_id")
            bot.reply_to(
                message,
                f"✅ <b>Визуальный позывной ЧВК для @{u_name} изменен!</b>\n\n"
                f"• 🏷️ Новый позывной: <b>{new_callsign}</b>\n"
                f"• 🎖️ Исходный класс: <b>{orig_class}</b> {p_info.get('icon', '🎖️')}\n"
                f"• ⚡ Эффект и бафф класса: <i>{p_info.get('desc', '—')}</i> (<b>сохранены на 100%</b>)\n\n"
                f"<i>В главном меню, профиле и арте теперь отображается: {p_info.get('icon', '🎖️')} {new_callsign}</i>",
                parse_mode="HTML"
            )
            return

        elif cmd in ["/reset_callsign", "/del_callsign"]:
            target_player, payload, target_lbl = parse_admin_target_and_payload(message, db)
            if not target_player:
                bot.reply_to(message, "❌ Игрок не найден. Использование: <code>/reset_callsign @username</code>", parse_mode="HTML")
                return
            target_player.pop("custom_pmc_callsign", None)
            save_db(db)
            orig_class = target_player.get("pmc_signature", "Viper")
            u_name = target_player.get("username") or target_player.get("user_id")
            bot.reply_to(message, f"✅ Позывной игрока @{u_name} сброшен к названию класса: <b>{orig_class}</b>", parse_mode="HTML")
            return

        elif cmd == "/give_case":
            target_arg = parts[1] if len(parts) >= 2 else None
            u = find_target_player(db, target_arg, caller_id)
            if not u:
                bot.reply_to(message, "❌ Игрок не найден.")
                return
            add_mythic_item_to_player(u, "mythic_black_division_case")
            save_db(db)
            bot.reply_to(message, f"✅ Выдан 💼 <b>Дипломатический кейс Black Division</b> (150 000 000 ₽) игроку @{u.get('username') or u.get('user_id')}!")
            return

        elif cmd == "/give_goons":
            target_arg = parts[1] if len(parts) >= 2 else None
            u = find_target_player(db, target_arg, caller_id)
            if not u:
                bot.reply_to(message, "❌ Игрок не найден.")
                return
            add_mythic_item_to_player(u, "mythic_goons_token")
            save_db(db)
            bot.reply_to(message, f"✅ Выдан 🎖️ <b>Жетон Отступников (The Goons)</b> (150 000 000 ₽) игроку @{u.get('username') or u.get('user_id')}!")
            return

        elif cmd == "/give_gear":
            set_type = parts[1].lower() if len(parts) >= 2 else "zryachiy"
            target_arg = parts[2] if len(parts) >= 3 else None
            u = find_target_player(db, target_arg, caller_id)
            if not u:
                bot.reply_to(message, "❌ Игрок не найден.")
                return
            if set_type in ["zryachiy", "зрячий", "маяк", "dsp"]:
                add_mythic_item_to_player(u, "mythic_dsp_sensor")
                u["guard_until"] = now + 86400 * 365
                u["is_base_captured"] = False
                for itm in ZRYACHIY_GEAR:
                    u.setdefault("stash", []).append({
                        "uid": f"adm_zry_{now}_{random.randint(100,999)}",
                        "item_id": itm["id"],
                        "equipped_to": None
                    })
                save_db(db)
                bot.reply_to(message, f"✅ Выдан Датчик DSP + 3 предмета Зрячего (AXMC, Плитник, Капюшон) игроку @{u.get('username') or u.get('user_id')}!")
            elif set_type in ["goons", "отступники", "гунсы"]:
                add_mythic_item_to_player(u, "mythic_goons_token")
                for itm in GOONS_GEAR:
                    u.setdefault("stash", []).append({
                        "uid": f"adm_goon_{now}_{random.randint(100,999)}",
                        "item_id": itm["id"],
                        "equipped_to": None
                    })
                save_db(db)
                bot.reply_to(message, f"✅ Выдан Жетон + 9 предметов The Goons игроку @{u.get('username') or u.get('user_id')}!")
            return

        elif cmd == "/give_money":
            if len(parts) >= 2:
                amount = int(parts[1])
                target_arg = parts[2] if len(parts) >= 3 else None
                u = find_target_player(db, target_arg, caller_id)
                if u:
                    u["money"] = u.get("money", 0) + amount
                    save_db(db)
                    bot.reply_to(message, f"✅ Выдано {fmt_rub(amount)} игроку @{u.get('username')}")
                else:
                    bot.reply_to(message, "❌ Игрок не найден")
            else:
                bot.reply_to(message, "Использование: /give_money <сумма> [@юзер]")

        elif cmd in ["/give_item", "/give", "/give_mythic"]:
            if len(parts) < 2:
                bot.reply_to(
                    message,
                    "<b>💡 Использование команды /give:</b>\n"
                    "• <code>/give dsp</code> — выдать себе Датчик DSP Смотрителя + 3 предмета Зрячего\n"
                    "• <code>/give zryachiy</code> — выдать себе Датчик DSP + полный сет Зрячего\n"
                    "• <code>/give case</code> — выдать себе Дипломатический кейс Black Division\n"
                    "• <code>/give goons</code> — выдать себе Жетон Отступников (The Goons)\n"
                    "• <code>/give <id_предмета> [@username]</code> — выдать любой предмет\n"
                    "• Быстрые команды: <code>/give_dsp</code>, <code>/give_case</code>, <code>/give_goons</code>, <code>/give_gear zryachiy</code>\n"
                    "• Интерактивная панель: <code>/admin</code>"
                )
                return

            arg1 = parts[1]
            arg2 = parts[2] if len(parts) >= 3 else None

            # Detect which arg is item and which is target user
            resolved_item_1 = resolve_item_alias(arg1)
            resolved_item_2 = resolve_item_alias(arg2) if arg2 else None

            if resolved_item_1:
                item_id = resolved_item_1
                target_arg = arg2
            elif resolved_item_2:
                item_id = resolved_item_2
                target_arg = arg1
            else:
                clean1 = arg1.lower().strip()
                if clean1 in ["zryachiy_set", "сет_зрячего"]:
                    u = find_target_player(db, arg2, caller_id)
                    if not u:
                        bot.reply_to(message, "❌ Игрок не найден")
                        return
                    add_mythic_item_to_player(u, "mythic_dsp_sensor")
                    u["guard_until"] = now + 86400 * 365
                    u["is_base_captured"] = False
                    claim_zryachiy_gear_supply(u)
                    save_db(db)
                    bot.reply_to(message, f"✅ Выдан полный сет Зрячего (Датчик DSP + AXMC, Плитник, Капюшон) игроку @{u.get('username') or u.get('user_id')}!")
                    return
                elif clean1 in ["goons_set", "сет_гунсов"]:
                    u = find_target_player(db, arg2, caller_id)
                    if not u:
                        bot.reply_to(message, "❌ Игрок не найден")
                        return
                    add_mythic_item_to_player(u, "mythic_goons_token")
                    for itm in GOONS_GEAR:
                        u.setdefault("stash", []).append({
                            "uid": f"adm_goon_{now}_{random.randint(100,999)}",
                            "item_id": itm["id"],
                            "equipped_to": None
                        })
                    save_db(db)
                    bot.reply_to(message, f"✅ Выдан Жетон + все 9 предметов The Goons игроку @{u.get('username') or u.get('user_id')}!")
                    return
                else:
                    bot.reply_to(message, f"❌ Предмет '{arg1}' не найден в базе предметов. Попробуйте <code>/give dsp</code> или <code>/give mythic_dsp_sensor</code>.")
                    return

            u = find_target_player(db, target_arg, caller_id)
            if not u:
                bot.reply_to(message, "❌ Игрок не найден")
                return

            u.setdefault("stash", []).append({
                "uid": f"cmd_{now}_{random.randint(100,999)}",
                "item_id": item_id,
                "equipped_to": None
            })

            extra_note = ""
            if item_id in MYTHIC_ITEMS:
                add_mythic_item_to_player(u, item_id)
                if item_id == "mythic_dsp_sensor":
                    u["guard_until"] = now + 86400 * 365
                    u["is_base_captured"] = False
                    claim_zryachiy_gear_supply(u)
                    extra_note = "\n👁️ 100% Вечная защита базы активирована, и 3 предмета Зрячего (AXMC, Плитник, Капюшон) доставлены в схрон!"
                elif item_id == "mythic_goons_token":
                    claim_goons_gear_supply(u)
                    extra_note = "\n🎖️ Первая суточная поставка экипировки The Goons доставлена в схрон!"

            save_db(db)
            item_obj = ITEMS_BY_ID.get(item_id, {})
            item_name = item_obj.get("name", item_id)
            bot.reply_to(message, f"✅ Предмет <b>{item_name}</b> (<code>{item_id}</code>) успешно добавлен игроку @{u.get('username') or u.get('user_id')}!{extra_note}")

        elif cmd == "/set_module":
            if len(parts) >= 3:
                mod_key = parts[1]
                lvl = int(parts[2])
                target_arg = parts[3] if len(parts) >= 4 else None
                u = find_target_player(db, target_arg, caller_id)
                if u:
                    u.setdefault("modules", {})[mod_key] = max(0, min(10, lvl))
                    save_db(db)
                    bot.reply_to(message, f"✅ Модуль {mod_key} игрока @{u.get('username')} установлен на {lvl}")
        elif cmd == "/set_level":
            if len(parts) >= 2:
                lvl = int(parts[1])
                target_arg = parts[2] if len(parts) >= 3 else None
                u = find_target_player(db, target_arg, caller_id)
                if u:
                    u["hideout_lvl"] = max(1, min(10, lvl))
                    save_db(db)
                    bot.reply_to(message, f"✅ Уровень Убежища игрока @{u.get('username')} установлен на {lvl}")
        elif cmd == "/reset_player":
            if len(parts) >= 2:
                target_arg = parts[1]
                u = find_target_player(db, target_arg, caller_id)
                if u:
                    uid = u["user_id"]
                    uname = u.get("username")
                    db["users"][str(uid)] = create_new_player(uid, uname, "Revenant" if (uname or "").lower() in ["reventus", "revenuts"] else "Viper")
                    save_db(db)
                    bot.reply_to(message, f"✅ Профиль игрока @{uname} сброшен")

        elif cmd in ["/set_bp_max", "/max_bp"]:
            target_player, payload, target_lbl = parse_admin_target_and_payload(message, db)
            u = target_player or find_target_player(db, None, caller_id)
            if not u:
                bot.reply_to(message, "❌ Игрок не найден")
                return
            u.setdefault("special_businesses", {})["gd_shadow_agent"] = True
            bp_state = u.setdefault("gd_battlepass", {})
            bp_state["level"] = 150
            bp_state["exp"] = 0
            # Unlock all 26 BP weapons
            all_bp_weapons = list(GD_WEAPONS_CATALOG.keys())
            bp_state["unlocked_weapons"] = list(set(bp_state.get("unlocked_weapons", []) + all_bp_weapons))
            # Unlock highest BP titles
            u.setdefault("unlocked_titles", [])
            for t_name in ["[Теневой Агент GD]", "[Элитный Ликвидатор]", "[Призрак Синдиката]", "[Абсолютный Повелитель Таркова]"]:
                if t_name not in u["unlocked_titles"]:
                    u["unlocked_titles"].append(t_name)
            save_db(db)
            bot.reply_to(message, (
                f"👑 <b>МАКСИМАЛЬНЫЙ БОЕВОЙ ПРОПУСК УСТАНОВЛЕН!</b>\n"
                f"Игроку @{u.get('username') or u.get('user_id')} выдан <b>150 уровень</b> GD Battle Pass!\n"
                f"• Разблокированы все 26 видов вооружения GD\n"
                f"• Доступны все спец-награды и элитные титулы\n"
                f"• Бизнес «Теневой Агент GD» (150М ₽/ч) активирован!"
            ))

        elif cmd in ["/set_bp", "/setbp"]:
            target_player, payload, target_lbl = parse_admin_target_and_payload(message, db)
            u = target_player or find_target_player(db, None, caller_id)
            if not u:
                bot.reply_to(message, "❌ Игрок не найден")
                return
            try:
                lvl_val = int(payload.strip().split()[0]) if payload.strip() else int(parts[1])
            except Exception:
                lvl_val = 150
            lvl_val = max(1, min(150, lvl_val))
            u.setdefault("special_businesses", {})["gd_shadow_agent"] = True
            bp_state = u.setdefault("gd_battlepass", {})
            bp_state["level"] = lvl_val
            eligible_weapons = [
                w_id for w_id, w_lvl in BP_WEAPONS_LEVEL_MAP.items()
                if w_lvl <= lvl_val
            ]
            bp_state["unlocked_weapons"] = list(set(bp_state.get("unlocked_weapons", []) + eligible_weapons))
            save_db(db)
            bot.reply_to(message, f"✅ Игроку @{u.get('username') or u.get('user_id')} установлен <b>{lvl_val}/150 уровень</b> Боевого Пропуска (Разблокировано {len(bp_state['unlocked_weapons'])} пушек)!")

        elif cmd in ["/set_prestige", "/setprestige", "/max_prestige", "/prestige_max", "/prestige5", "/give_prestige"]:
            target_player, payload, target_lbl = parse_admin_target_and_payload(message, db)
            u = target_player or find_target_player(db, None, caller_id)
            if not u:
                bot.reply_to(message, "❌ Игрок не найден")
                return
            if cmd in ["/max_prestige", "/prestige_max", "/prestige5"]:
                t_val = 5
            else:
                try:
                    t_val = int(payload.strip().split()[0]) if payload.strip() else int(parts[1])
                except Exception:
                    t_val = 5
            t_val = max(0, min(5, t_val))
            u["prestige"] = t_val
            
            # If setting 5th prestige, automatically unlock DSP sensor & max generator for full legendary experience
            if t_val == 5:
                if not has_player_dsp_sensor(u):
                    add_mythic_item_to_player(u, "mythic_dsp_sensor")
                u.setdefault("modules", {})["generator"] = 10
            
            save_db(db)
            cfg = PRESTIGE_TIERS.get(t_val, {})
            badge = cfg.get("badge", f"[Престиж {t_val}]") if t_val > 0 else "[Без Престижа]"
            if t_val == 5:
                bot.reply_to(message, (
                    f"👑 <b>УСТАНОВЛЕН 5-Й РАНГ ПРЕСТИЖА: {badge}!</b>\n"
                    "────────────────────────\n"
                    "• 🪖 <b>Рота ЧВК:</b> базовый размер отряда 6 бойцов (до 7 с сетом Глухаря)\n"
                    "• 🎯 <b>Снайперское прикрытие Зрячего:</b> выстрел AXMC .338 AP на старте боя (+15% винрейт, -30% брони босса)\n"
                    "• 📟 <b>Датчик DSP Смотрителя:</b> активирован и добавлен в схрон\n"
                    "• ⚡ <b>Реактор Terragroup:</b> Генератор 10 ур. (+100% майнинг BTC, +30% пассив)\n"
                    "• 💰 <b>Денежный множитель:</b> x1.5 к добыче во всех рейдах\n"
                    "• 👑 <b>Черный Рейд Смотрителя:</b> доступен в меню /prestige\n"
                    "• 🌟 <b>Жетоны Мастерства:</b> 5 очков в Древе Навыков (/prestige)\n"
                    f"✅ Профиль игрока @{u.get('username') or u.get('user_id')} успешно обновлен!"
                ))
            else:
                bot.reply_to(message, f"✅ Игроку @{u.get('username') or u.get('user_id')} установлен уровень Престижа: <b>{t_val}/5 ({badge})</b>!")

    except Exception as e:
        bot.reply_to(message, f"❌ Ошибка выполнения: {e}")

# =========================================================================
# SECTION 10: "ШОТА У АШОТА" (CLOTHES SHOP) & WARDROBE SYSTEM
# =========================================================================

# _safe_edit_or_send defined at top of bot.py


@bot.message_handler(commands=["battlepass", "bp", "pass", "gdpass"])
def cmd_battlepass(message):
    user_id = message.from_user.id
    telegram_username = getattr(message.from_user, "username", None)
    display_name = message.from_user.username or message.from_user.first_name or f"PMC_{user_id}"
    player, db = get_player(user_id, display_name, telegram_username)
    if not player:
        bot.send_message(message.chat.id, "⚠️ Начните игру через /start")
        return
    handle_menu_gd_battlepass(message.chat.id, None, player, db)


@bot.message_handler(commands=["passives", "perks", "passivki"])
def cmd_passives(message):
    user_id = message.from_user.id
    telegram_username = getattr(message.from_user, "username", None)
    display_name = message.from_user.username or message.from_user.first_name or f"PMC_{user_id}"
    player, db = get_player(user_id, display_name, telegram_username)
    if not player:
        bot.send_message(message.chat.id, "⚠️ Начните игру через /start")
        return
    handle_menu_passives(message.chat.id, None, player, db, tab="summary")


@bot.message_handler(commands=["titles", "title", "titul", "tituly"])
def cmd_titles(message):
    user_id = message.from_user.id
    telegram_username = getattr(message.from_user, "username", None)
    display_name = message.from_user.username or message.from_user.first_name or f"PMC_{user_id}"
    player, db = get_player(user_id, display_name, telegram_username)
    if not player:
        bot.send_message(message.chat.id, "⚠️ Начните игру через /start")
        return
    handle_menu_titles(message.chat.id, None, player, page=1)


@bot.message_handler(commands=["stats", "stat", "statistics"])
def cmd_stats(message):
    user_id = message.from_user.id
    telegram_username = getattr(message.from_user, "username", None)
    display_name = message.from_user.username or message.from_user.first_name or f"PMC_{user_id}"
    player, db = get_player(user_id, display_name, telegram_username)
    if not player:
        bot.send_message(message.chat.id, "⚠️ Начните игру через /start")
        return
    handle_menu_bot_stats(message.chat.id, None, player, db)


@bot.message_handler(commands=["prestige"])
def cmd_prestige(message):
    user_id = message.from_user.id
    telegram_username = getattr(message.from_user, "username", None)
    display_name = message.from_user.username or message.from_user.first_name or f"PMC_{user_id}"
    player, db = get_player(user_id, display_name, telegram_username)
    if not player:
        bot.send_message(message.chat.id, "⚠️ Начните игру через /start")
        return
    handle_menu_prestige(message.chat.id, None, player)


PENDING_ADMIN_PHOTOS = {}

@bot.message_handler(content_types=['photo', 'document'])
def handle_admin_photo_upload(message):
    user_id = message.from_user.id
    telegram_username = getattr(message.from_user, "username", None)
    if not is_admin(user_id, telegram_username):
        return

    file_id = None
    width = 1280
    height = 720
    if getattr(message, "photo", None) and len(message.photo) > 0:
        best_photo = message.photo[-1]
        file_id = best_photo.file_id
        width = getattr(best_photo, 'width', 1280)
        height = getattr(best_photo, 'height', 720)
    elif getattr(message, "document", None) and getattr(message.document, "mime_type", "").startswith("image/"):
        file_id = message.document.file_id

    if not file_id:
        return

    PENDING_ADMIN_PHOTOS[user_id] = file_id
    caption = (getattr(message, "caption", "") or getattr(message, "text", "") or "").strip()
    db = load_db()

    # 0. Check if caption is an admin command (starts with /)
    if caption.startswith("/"):
        cmd_admin_commands(message)
        return

    # 0.5 Check if caption matches a menu category name or alias directly
    cap_lower = caption.lower()
    if cap_lower in MENU_ALIASES:
        m_key = MENU_ALIASES[cap_lower]
        db.setdefault("menu_photos", {})[m_key] = file_id
        save_db(db)
        m_name = MENU_NAMES_MAP.get(m_key, m_key)
        bot.reply_to(
            message,
            f"✅ <b>Фото для меню «{m_name}» успешно обновлено через Telegram CDN!</b>\n\n"
            f"📐 <b>Разрешение:</b> {width}x{height}\n"
            f"🔑 <b>Telegram file_id:</b>\n<code>{file_id}</code>\n\n"
            f"<i>Теперь все игроки видят это фото в категории «{m_name}».</i>",
            parse_mode="HTML"
        )
        return

    for word in cap_lower.split():
        if word in MENU_ALIASES:
            m_key = MENU_ALIASES[word]
            db.setdefault("menu_photos", {})[m_key] = file_id
            save_db(db)
            m_name = MENU_NAMES_MAP.get(m_key, m_key)
            bot.reply_to(
                message,
                f"✅ <b>Фото для меню «{m_name}» успешно привязано через Telegram CDN!</b>\n\n"
                f"📐 <b>Разрешение:</b> {width}x{height}\n"
                f"🔑 <b>Telegram file_id:</b>\n<code>{file_id}</code>\n\n"
                f"<i>Теперь все игроки видят это фото в категории «{m_name}».</i>",
                parse_mode="HTML"
            )
            return

    # 1. Target specific user if mentioned in caption (@username or numeric user_id)
    target_user = None
    for word in caption.split():
        if word.startswith("@") or (word.isdigit() and len(word) >= 5):
            cand = find_target_player(db, word, user_id)
            if cand:
                target_user = cand
                break
    if target_user:
        target_user["custom_pmc_avatar"] = file_id
        save_db(db)
        u_name = target_user.get("username") or target_user.get("user_id")
        reply_msg = (
            f"✅ <b>Персональное фото ЧВК успешно привязано к @{u_name}!</b>\n\n"
            f"📐 <b>Разрешение:</b> {width}x{height}\n"
            f"🔑 <b>Telegram file_id:</b>\n<code>{file_id}</code>\n\n"
            f"<i>Теперь боец @{u_name} видит это фото в своем профиле и в HD-арте.</i>"
        )
        bot.reply_to(message, reply_msg, parse_mode="HTML")
        return

    # 1.5 Check if caption is for raids menu or locations
    if cap_lower in ["рейды", "рейд", "raids", "raid"]:
        db["raids_menu_photo"] = file_id
        save_db(db)
        bot.reply_to(
            message,
            f"✅ <b>Фото для меню «Рейды в Тарков» успешно привязано!</b>\n\n"
            f"📐 <b>Разрешение:</b> {width}x{height}\n"
            f"🔑 <b>file_id:</b> <code>{file_id}</code>\n\n"
            f"<i>Отображается над текстом списка локаций в меню рейдов.</i>",
            parse_mode="HTML"
        )
        return

    loc_alias_map = {
        "завод": "factory", "factory": "factory",
        "таможня": "customs", "customs": "customs",
        "лес": "woods", "woods": "woods",
        "резерв": "reserve", "reserve": "reserve",
        "лаборатория": "labs", "лаба": "labs", "лаб": "labs", "labs": "labs"
    }
    for alias_key, loc_code in loc_alias_map.items():
        if alias_key in cap_lower.split():
            db.setdefault("location_photos", {})[loc_code] = file_id
            save_db(db)
            loc_title = LOC_NAMES_MAP.get(loc_code, loc_code)
            bot.reply_to(
                message,
                f"✅ <b>Фото для локации «{loc_title}» успешно привязано!</b>\n\n"
                f"📐 <b>Разрешение:</b> {width}x{height}\n"
                f"🔑 <b>file_id:</b> <code>{file_id}</code>\n\n"
                f"<i>Отображается над результатами рейда на локации {loc_title}.</i>",
                parse_mode="HTML"
            )
            return

    # 2. Check class in caption
    matched_pmc = None
    for p_name in PMC_DEFINITIONS.keys():
        if p_name.lower() in caption.lower():
            matched_pmc = p_name
            break
    if matched_pmc:
        db.setdefault("pmc_custom_avatars", {})[matched_pmc] = file_id
        save_db(db)
        bot.reply_to(
            message,
            f"✅ <b>Аватар для класса {matched_pmc} успешно привязан через Telegram CDN!</b>\n\n"
            f"📐 <b>Разрешение:</b> {width}x{height}\n"
            f"🔑 <b>Telegram file_id:</b>\n<code>{file_id}</code>\n\n"
            f"<i>Теперь все игроки с классом {matched_pmc} видят этот арт в оригинальном качестве без сжатия хостингами.</i>",
            parse_mode="HTML"
        )
        return

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("📦 Поставки (Supply)", callback_data="set_menu_art_supply"),
        types.InlineKeyboardButton("🧰 Контейнеры", callback_data="set_menu_art_containers")
    )
    markup.add(
        types.InlineKeyboardButton("🎒 Схрон", callback_data="set_menu_art_stash"),
        types.InlineKeyboardButton("⚖️ Барахолка", callback_data="set_menu_art_market")
    )
    markup.add(
        types.InlineKeyboardButton("👔 Шота у Ашота", callback_data="set_menu_art_ashot"),
        types.InlineKeyboardButton("💀 The Goons", callback_data="set_menu_art_the_goons")
    )
    markup.add(
        types.InlineKeyboardButton("🦅 Black Division", callback_data="set_menu_art_black_division"),
        types.InlineKeyboardButton("👁️ Дозор Зрячего", callback_data="set_menu_art_zryachiy")
    )
    markup.add(
        types.InlineKeyboardButton("☣️ Даркзон", callback_data="set_menu_art_darkzone"),
        types.InlineKeyboardButton("🛡️ Охрана базы", callback_data="set_menu_art_base_guard")
    )
    markup.add(
        types.InlineKeyboardButton("🎖️ Сигнатурный рейд", callback_data="set_menu_art_signature_raid"),
        types.InlineKeyboardButton("⚔️ Меню Рейдов", callback_data="set_raid_art_menu")
    )
    markup.add(
        types.InlineKeyboardButton("🏭 Завод", callback_data="set_loc_art_factory"),
        types.InlineKeyboardButton("🌲 Таможня", callback_data="set_loc_art_customs")
    )
    markup.add(
        types.InlineKeyboardButton("🌲 Лес", callback_data="set_loc_art_woods"),
        types.InlineKeyboardButton("🏢 Резерв", callback_data="set_loc_art_reserve")
    )
    markup.add(
        types.InlineKeyboardButton("🧪 Лаборатория", callback_data="set_loc_art_labs")
    )

    pmc_list = list(PMC_DEFINITIONS.keys())
    for i in range(0, len(pmc_list), 2):
        row = [types.InlineKeyboardButton(f"{PMC_DEFINITIONS[pmc_list[i]]['icon']} {pmc_list[i]}", callback_data=f"set_pmc_art_{pmc_list[i]}")]
        if i + 1 < len(pmc_list):
            row.append(types.InlineKeyboardButton(f"{PMC_DEFINITIONS[pmc_list[i+1]]['icon']} {pmc_list[i+1]}", callback_data=f"set_pmc_art_{pmc_list[i+1]}"))
        markup.row(*row)

    markup.add(types.InlineKeyboardButton("❌ Отмена", callback_data="delete_current_msg"))

    bot.reply_to(
        message,
        f"📸 <b>Получено фото в HD качестве ({width}x{height})!</b>\n\n"
        f"🔑 <b>Telegram file_id:</b>\n<code>{file_id}</code>\n\n"
        "💡 <b>Как назначить это фото:</b>\n"
        "• Нажмите кнопку раздела выше (Поставки, Контейнеры, Схрон, Рейды...)\n"
        "• Либо отправьте команду: <code>/set_supply_photo</code> (или <code>/set_menu_photo supply</code>)\n"
        "• Также можно сразу присылать фото с подписью <code>/set_supply_photo</code> или ответом на фото\n"
        "• Для игрока ЧВК: <code>/set_user_photo @username</code>",
        reply_markup=markup,
        parse_mode="HTML"
    )
@bot.message_handler(commands=["avatars_admin", "pmc_art", "file_ids"])
def cmd_avatars_admin(message):
    user_id = message.from_user.id
    telegram_username = getattr(message.from_user, "username", None)
    if not is_admin(user_id, telegram_username):
        return
    db = load_db()
    custom = db.get("pmc_custom_avatars", {})
    txt = (
        "🎨 <b>УПРАВЛЕНИЕ АВАТАРАМИ ЧВК (HD КАЧЕСТВО)</b>\n"
        "────────────────────────\n"
        "Чтобы привязать арт в оригинальном качестве без хостингов:\n"
        "1. Просто <b>отправьте боту фото</b> в личные сообщения.\n"
        "2. В подписи к фото укажите класс (например: <code>Viper</code> или <code>Revenant</code>),\n"
        "   либо просто нажмите на кнопку с нужным ЧВК под фото!\n\n"
        "<b>Текущий статус привязки:</b>\n"
    )
    for p_name, p_data in PMC_DEFINITIONS.items():
        if p_name in custom:
            c_val = custom[p_name]
            short_id = c_val[:16] + "..." if len(c_val) > 16 else c_val
            txt += f"• {p_data['icon']} <b>{p_name}</b>: <code>{short_id}</code> (Telegram CDN ✅)\n"
        elif os.path.exists(os.path.join("assets", "avatars", f"{p_name.lower()}.jpg")):
            txt += f"• {p_data['icon']} <b>{p_name}</b>: Локальный файл на сервере 📁\n"
        else:
            txt += f"• {p_data['icon']} <b>{p_name}</b>: По умолчанию (Web URL) 🌐\n"
    bot.send_message(message.chat.id, txt, parse_mode="HTML")



@bot.message_handler(commands=["ashot", "clothes"])
def cmd_ashot(message):
    user_id = message.from_user.id
    telegram_username = getattr(message.from_user, "username", None)
    display_name = message.from_user.username or message.from_user.first_name or f"PMC_{user_id}"
    player, db = get_player(user_id, display_name, telegram_username)
    if not player:
        bot.send_message(message.chat.id, "⚠️ Начните игру через /start")
        return
    handle_ashot_shop(message.chat.id, None, player)


@bot.message_handler(commands=["wardrobe", "shmot", "garderob"])
def cmd_wardrobe(message):
    user_id = message.from_user.id
    telegram_username = getattr(message.from_user, "username", None)
    display_name = message.from_user.username or message.from_user.first_name or f"PMC_{user_id}"
    player, db = get_player(user_id, display_name, telegram_username)
    if not player:
        bot.send_message(message.chat.id, "⚠️ Начните игру через /start")
        return
    handle_stash_clothes_menu(message.chat.id, None, player)


def handle_ashot_shop(chat_id, msg_id, player, db=None):
    if db is None:
        db = load_db()
    txt = (
        "👕 <b>МАГАЗИН ОДЕЖДЫ «ШОТА У АШОТА»</b>\n"
        "────────────────────────\n"
        "<i>«Эй, дорогой! Проходи, примеряй! У Ашота самый дерзкий шмот на всем Таркове!\n"
        "Обувь скрипит, кепка фартит, костюм сидит как влитой!\n"
        "Учти: шмот у меня эксклюзивный. Продать Прапору или выставить на рынок нельзя — "
        "только носить с гордостью или выбросить!»</i>\n\n"
        f"💰 Ваш баланс: <b>{fmt_rub(player.get('money', 0))}</b>\n"
        "────────────────────────\n"
        "Выберите категорию гардероба:"
    )
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("🥾 Обувь (50)", callback_data="ashot_cat_shoes_1"),
        types.InlineKeyboardButton("🧢 Головные уборы (50)", callback_data="ashot_cat_headwear_1")
    )
    markup.add(
        types.InlineKeyboardButton("🥋 Костюмы (50)", callback_data="ashot_cat_suit_1"),
        types.InlineKeyboardButton("⌚ Аксессуары (50)", callback_data="ashot_cat_accessory_1")
    )
    markup.add(
        types.InlineKeyboardButton("👔 Мой Гардероб (Шмот)", callback_data="stash_clothes_menu")
    )
    markup.add(
        types.InlineKeyboardButton("🔙 К Барахолке", callback_data="menu_market")
    )
    photo = get_menu_photo("ashot", db)
    _safe_send_photo(photo, txt, chat_id, msg_id, markup)


def handle_ashot_category(chat_id, msg_id, player, db, cat_key, page=1):
    cat_info = CLOTHES_CATEGORIES.get(cat_key, {"name": "Одежда", "icon": "👕"})
    items = CLOTHES_BY_CATEGORY.get(cat_key, [])
    per_page = 5
    total_pages = max(1, (len(items) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start_idx = (page - 1) * per_page
    page_items = items[start_idx : start_idx + per_page]

    equipped_info, _ = get_equipped_item_in_slot(player, cat_key)
    equipped_id = equipped_info.get("id") if equipped_info else None

    txt = (
        f"{cat_info['icon']} <b>МАГАЗИН АШОТА: {cat_info['name'].upper()}</b>\n"
        "────────────────────────\n"
        f"💰 Баланс: <b>{fmt_rub(player.get('money', 0))}</b>\n"
        f"Экипировано: <b>{equipped_info['name'] if equipped_info else '— Не надето —'}</b>\n"
        "────────────────────────\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    for itm in page_items:
        is_equipped = (itm["id"] == equipped_id)
        is_owned = player_owns_clothing(player, itm["id"])

        status_tag = ""
        if is_equipped:
            status_tag = " [НАДЕТО ✅]"
        elif is_owned:
            status_tag = " [В ГАРДЕРОБЕ 🎒]"

        txt += f"• <b>{itm['name']}</b>{status_tag}\n"
        txt += f"  Цена: <b>{fmt_rub(itm['price'])}</b>\n\n"

        if is_equipped:
            markup.add(
                types.InlineKeyboardButton("✅ Надето | В гардероб", callback_data=f"prof_cloth_{cat_key}_1")
            )
        elif is_owned:
            markup.add(
                types.InlineKeyboardButton("🎒 Куплено | Надеть", callback_data=f"prof_cloth_{cat_key}_1")
            )
        else:
            markup.add(
                types.InlineKeyboardButton(f"🛒 Купить | {fmt_rub(itm['price'])}", callback_data=f"ashot_buy:{cat_key}:{itm['id']}:{page}")
            )

    nav_btns = []
    if page > 1:
        nav_btns.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"ashot_cat_{cat_key}_{page-1}"))
    nav_btns.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_btns.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"ashot_cat_{cat_key}_{page+1}"))
    if nav_btns:
        markup.row(*nav_btns)

    markup.add(
        types.InlineKeyboardButton("👔 Мой Гардероб (Шмот)", callback_data="stash_clothes_menu"),
        types.InlineKeyboardButton("👕 Все категории Ашота", callback_data="ashot_shop_main"),
        types.InlineKeyboardButton("🔙 К Барахолке", callback_data="menu_market")
    )
    _safe_edit_or_send(txt, chat_id, msg_id, markup)


def handle_ashot_buy_action(call, player, db, cat_key, item_id, page):
    try:
        success, msg, uid = buy_clothing_item(player, item_id)
        if not success:
            try:
                bot.answer_callback_query(call.id, msg, show_alert=True)
            except Exception:
                pass
            return
        save_db(db)
        try:
            bot.answer_callback_query(call.id, msg, show_alert=True)
        except Exception:
            pass
        handle_ashot_category(call.message.chat.id, call.message.message_id, player, db, cat_key, page)
    except Exception as e:
        logging.error("ashot buy error: %s", e)
        try:
            bot.answer_callback_query(call.id, f"❌ Ошибка покупки: {str(e)[:40]}", show_alert=True)
        except Exception:
            pass


def handle_profile_clothes_category(chat_id, msg_id, player, db, slot, page=1):
    cat_info = CLOTHES_CATEGORIES.get(slot, {"name": "Одежда", "icon": "👕"})
    equipped_info, equipped_uid = get_equipped_item_in_slot(player, slot)

    stash = get_player_clothes_stash(player)
    owned_in_slot = [e for e in stash if e.get("slot") == slot]

    per_page = 4
    total_pages = max(1, (len(owned_in_slot) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start_idx = (page - 1) * per_page
    page_items = owned_in_slot[start_idx : start_idx + per_page]

    txt = (
        f"{cat_info['icon']} <b>ГАРДЕРОБ: {cat_info['name'].upper()}</b>\n"
        "────────────────────────\n"
        "Текущая экипировка:\n"
        f"👉 <b>{equipped_info['name'] if equipped_info else '— Не экипировано —'}</b>\n"
        "────────────────────────\n"
        f"Всего предметов в категории: <b>{len(owned_in_slot)}</b>\n\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    if not owned_in_slot:
        txt += (
            f"<i>У вас пока нет купленных предметов в категории «{cat_info['name']}».\n"
            "Их можно приобрести у Ашота на Барахолке!</i>\n"
        )
        markup.add(
            types.InlineKeyboardButton(f"🛒 В магазин Ашота ({cat_info['name']})", callback_data=f"ashot_cat_{slot}_1")
        )
    else:
        for entry in page_items:
            uid = entry.get("uid")
            item_info = CLOTHES_BY_ID.get(entry.get("item_id"), {})
            name = item_info.get("name", entry.get("name", "Одежда"))
            if entry.get("exclusive") or entry.get("custom"):
                name += " ⭐ [Эксклюзив]"
            is_equipped = (uid == equipped_uid)

            status_str = " [НАДЕТО ✅]" if is_equipped else ""
            txt += f"• <b>{name}</b>{status_str}\n"

            row_btns = []
            if is_equipped:
                row_btns.append(types.InlineKeyboardButton("❎ Снять", callback_data=f"cloth_unequip:{slot}:{uid}:{page}"))
            else:
                row_btns.append(types.InlineKeyboardButton("🎽 Надеть", callback_data=f"cloth_equip:{slot}:{uid}:{page}"))

            row_btns.append(types.InlineKeyboardButton("🗑️ Выбросить", callback_data=f"cloth_discard:{slot}:{uid}:{page}"))
            markup.row(*row_btns)

    nav_btns = []
    if page > 1:
        nav_btns.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"prof_cloth_{slot}_{page-1}"))
    if total_pages > 1:
        nav_btns.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_btns.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"prof_cloth_{slot}_{page+1}"))
    if nav_btns:
        markup.row(*nav_btns)

    markup.add(
        types.InlineKeyboardButton(f"🛒 Купить шмот в «Шота у Ашота»", callback_data=f"ashot_cat_{slot}_1")
    )
    markup.row(
        types.InlineKeyboardButton("👤 В Профиль", callback_data="menu_profile"),
        types.InlineKeyboardButton("👔 Весь Гардероб", callback_data="stash_clothes_menu")
    )
    _safe_edit_or_send(txt, chat_id, msg_id, markup)


def handle_cloth_equip(call, player, db, slot, uid, page):
    try:
        success, msg = equip_clothing_item(player, uid)
        save_db(db)
        try:
            bot.answer_callback_query(call.id, msg, show_alert=True)
        except Exception:
            pass
        handle_profile_clothes_category(call.message.chat.id, call.message.message_id, player, db, slot, page)
    except Exception as e:
        logging.error("cloth equip error: %s", e)
        try:
            bot.answer_callback_query(call.id, "❌ Ошибка при экипировке!", show_alert=True)
        except Exception:
            pass


def handle_cloth_unequip(call, player, db, slot, uid, page):
    try:
        success, msg = unequip_clothing_item(player, slot)
        save_db(db)
        try:
            bot.answer_callback_query(call.id, msg, show_alert=True)
        except Exception:
            pass
        handle_profile_clothes_category(call.message.chat.id, call.message.message_id, player, db, slot, page)
    except Exception as e:
        logging.error("cloth unequip error: %s", e)
        try:
            bot.answer_callback_query(call.id, "❌ Ошибка при снятии!", show_alert=True)
        except Exception:
            pass


def handle_cloth_discard(call, player, db, slot, uid, page):
    try:
        # Check equipped status before deletion (strict validation)
        success, msg = discard_clothing_item(player, uid)
        if not success:
            try:
                bot.answer_callback_query(call.id, msg, show_alert=True)
            except Exception:
                pass
            return
        save_db(db)
        try:
            bot.answer_callback_query(call.id, msg, show_alert=True)
        except Exception:
            pass
        handle_profile_clothes_category(call.message.chat.id, call.message.message_id, player, db, slot, page)
    except Exception as e:
        logging.error("cloth discard error: %s", e)
        try:
            bot.answer_callback_query(call.id, "❌ Ошибка при удалении!", show_alert=True)
        except Exception:
            pass


def handle_stash_clothes_menu(chat_id, msg_id, player):
    stash = get_player_clothes_stash(player)

    shoes_info, _ = get_equipped_item_in_slot(player, "shoes")
    head_info, _ = get_equipped_item_in_slot(player, "headwear")
    suit_info, _ = get_equipped_item_in_slot(player, "suit")
    acc_info, _ = get_equipped_item_in_slot(player, "accessory")

    shoes_cnt = len([e for e in stash if e.get("slot") == "shoes"])
    head_cnt = len([e for e in stash if e.get("slot") == "headwear"])
    suit_cnt = len([e for e in stash if e.get("slot") == "suit"])
    acc_cnt = len([e for e in stash if e.get("slot") == "accessory"])

    txt = (
        "👔 <b>ГАРДЕРОБ ОПЕРАТОРА (ШМОТ)</b>\n"
        "────────────────────────\n"
        "Здесь хранится ваша коллекция одежды из магазина «Шота у Ашота».\n"
        "<i>Одежду нельзя продать Прапору или на рынке — только надеть или выбросить.</i>\n\n"
        "<b>Текущая экипировка:</b>\n"
        f"• 🥾 Обувь: <b>{shoes_info['name'] if shoes_info else '— Не надето —'}</b>\n"
        f"• 🧢 Головной убор: <b>{head_info['name'] if head_info else '— Не надето —'}</b>\n"
        f"• 🥋 Костюм: <b>{suit_info['name'] if suit_info else '— Не надето —'}</b>\n"
        f"• ⌚ Аксессуар: <b>{acc_info['name'] if acc_info else '— Не надето —'}</b>\n"
        "────────────────────────\n"
        "Выберите категорию для управления вещами:"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton(f"🥾 Обувь ({shoes_cnt})", callback_data="prof_cloth_shoes_1"),
        types.InlineKeyboardButton(f"🧢 Головной убор ({head_cnt})", callback_data="prof_cloth_headwear_1")
    )
    markup.add(
        types.InlineKeyboardButton(f"🥋 Костюм ({suit_cnt})", callback_data="prof_cloth_suit_1"),
        types.InlineKeyboardButton(f"⌚ Аксессуар ({acc_cnt})", callback_data="prof_cloth_accessory_1")
    )
    markup.add(
        types.InlineKeyboardButton("👕 В магазин «Шота у Ашота»", callback_data="ashot_shop_main"),
        types.InlineKeyboardButton("📦 Вернуться в Схрон", callback_data="menu_stash")
    )
    _safe_edit_or_send(txt, chat_id, msg_id, markup)


if __name__ == "__main__":
    print("🚀 Starting Escape from Tarkov MMO Telegram Bot...")
    try:
        bot.infinity_polling(timeout=20, long_polling_timeout=20)
    except Exception as e:
        print(f"Bot crashed: {e}")
