# -*- coding: utf-8 -*-
"""
Signature PMC Talent & Skill System for Escape from Tarkov MMO Telegram Bot.

All 11 Signature PMCs:
1. Viper     - Speed & Infiltration
2. Nomad     - Master of Scavenging & Desert Survival
3. Ronin     - Master of Combat & Relics
4. Specter   - Stealth Reconnaissance & Lab Vaults
5. Ares      - Heavy Assault & Defense Industry
6. Zenith    - Cyber-Tech & Crypto-Empire
7. Fenrir    - Wolfpack Leader & Relic Hunter
8. Stalker   - Secret Cache of Tarkov & Pripyat Lore
9. Siren     - Syndicate Logistics & GD Pharma
10. Pharaoh  - Treasury & Golden Dynasty
11. Revenant - Shadow PMC Titan & GD Military Empire

CRITICAL RULES:
- Signature PMCs do NOT lead the regular squad and do not alter regular squad power/armor.
- No non-existent mechanics (no durability, no radiation/anomalies, no squad health bars, no Therapist trader).
- All mechanics strictly integrate with existing bot systems (Signature Raids, GD Businesses, Bitcoin Farm, Stash, Shop, Boss Battles, Relics).
- Points are earned from Signature PMC Special Operations (+2 pts) and Boss kills (+1 pt).
"""

import time
import random
from telebot import types

# ─────────────────────────────────────────────────────────────────────────────
# 11 FULL SIGNATURE PMC TALENT TREES (3 BRANCHES × 3 SKILLS = 99 SKILLS)
# ─────────────────────────────────────────────────────────────────────────────

SIGNATURE_PMC_TREES = {
    "Viper": {
        "name": "Viper",
        "icon": "⚡",
        "tagline": "Мастер стремительных спецопераций и молниеносного проникновения",
        "branches": {
            "speed": {
                "name": "Гипер-Драйв",
                "icon": "🏎️",
                "desc": "Сокращение времени подготовки и форсирование эвакуации",
                "skills": {
                    "nitro_sprint": {
                        "name": "Форсаж Спецопераций",
                        "icon": "💨",
                        "desc": "Снижает кулдаун спецоперации Вайпера на 30 мин. за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 1800  # 30 min in seconds
                    },
                    "adrenaline_loot": {
                        "name": "Молниеносный Обыск",
                        "icon": "🎒",
                        "desc": "Спецоперация приносит +2 дополнительных элитных предмета за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_extra_loot",
                        "bonus_per_lvl": 2
                    },
                    "instant_reaction": {
                        "name": "Сверхзвуковой Выход",
                        "icon": "⚡",
                        "desc": "Дополнительно снижает кулдаун спецоперации еще на 45 мин. за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700  # 45 min in seconds
                    }
                }
            },
            "assault": {
                "name": "Тактический Прорыв",
                "icon": "🎯",
                "desc": "Максимизация рублевой добычи и сокрушение вызванных боссов",
                "skills": {
                    "shock_assault": {
                        "name": "Шоковый Залп",
                        "icon": "💥",
                        "desc": "+6 000 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 6000000
                    },
                    "lethal_strike": {
                        "name": "Точечная Ликвидация",
                        "icon": "🩸",
                        "desc": "+25% к урону в дуэлях с Боссами Таркова при их вызове за ур.",
                        "max_lvl": 3,
                        "bonus_type": "boss_damage_pct",
                        "bonus_per_lvl": 0.25
                    },
                    "apex_predator": {
                        "name": "Апекс-Хищник",
                        "icon": "🏆",
                        "desc": "+10 000 000 ₽ к финальному кушу спецоперации за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 10000000
                    }
                }
            },
            "logistics": {
                "name": "Спец-Снабжение",
                "icon": "📦",
                "desc": "Расширение схрона и взлом секретных хранилищ TerraGroup",
                "skills": {
                    "cargo_expansion": {
                        "name": "Грузовой Отсек",
                        "icon": "🗄️",
                        "desc": "+30 дополнительных слотов к вместимости схрона за уровень",
                        "max_lvl": 3,
                        "bonus_type": "stash_slots_bonus",
                        "bonus_per_lvl": 30
                    },
                    "vault_heist": {
                        "name": "Сейфы TerraGroup",
                        "icon": "🪙",
                        "desc": "Шанс найти чистый Биткоин в спецоперации (+25% за уровень)",
                        "max_lvl": 3,
                        "bonus_type": "sig_btc_chance",
                        "bonus_per_lvl": 0.25
                    },
                    "viper_relic_hunt": {
                        "name": "Охота за Реликвиями",
                        "icon": "🔮",
                        "desc": "+30% к шансу получить Реликвию Босса при спецоперации за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_relic_bonus_chance",
                        "bonus_per_lvl": 0.30
                    }
                }
            }
        }
    },

    "Nomad": {
        "name": "Nomad",
        "icon": "🏜️",
        "tagline": "Мастер дальних экспедиций, тайников пустошей и добычи ценностей",
        "branches": {
            "survival": {
                "name": "Следопыт Пустошей",
                "icon": "🧭",
                "desc": "Снижение перезарядки спецопераций и форсированный набор опыта",
                "skills": {
                    "wasteland_scout": {
                        "name": "Маршруты Номада",
                        "icon": "🗺️",
                        "desc": "Снижает кулдаун спецоперации Номада на 35 мин. за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2100
                    },
                    "hardened_path": {
                        "name": "Трофейный Опыт",
                        "icon": "⭐",
                        "desc": "+25% к получаемому EXP профиля во всех операциях за уровень",
                        "max_lvl": 3,
                        "bonus_type": "exp_gain_mult",
                        "bonus_per_lvl": 0.25
                    },
                    "nomad_endurance": {
                        "name": "Выносливость Номада",
                        "icon": "💪",
                        "desc": "+7 000 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 7000000
                    }
                }
            },
            "scavenger": {
                "name": "Тайники Таркова",
                "icon": "🔍",
                "desc": "Обнаружение скрытых схронов и сверхприбыльная продажа ценностей",
                "skills": {
                    "hidden_stash_radar": {
                        "name": "Сканер Схронов",
                        "icon": "📦",
                        "desc": "Спецоперация приносит +3 дополнительных предмета хабара за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_extra_loot",
                        "bonus_per_lvl": 3
                    },
                    "electronic_salvage": {
                        "name": "Сбыт Ценностей",
                        "icon": "💎",
                        "desc": "+20% к цене продажи любых найденных драгоценностей и электроники",
                        "max_lvl": 3,
                        "bonus_type": "valuable_sell_bonus",
                        "bonus_per_lvl": 0.20
                    },
                    "bitcoin_cache": {
                        "name": "Крипто-Схрон",
                        "icon": "🪙",
                        "desc": "Шанс вынести чистый Биткоин из спецоперации (+30% за уровень)",
                        "max_lvl": 3,
                        "bonus_type": "sig_btc_chance",
                        "bonus_per_lvl": 0.30
                    }
                }
            },
            "ambush_tactics": {
                "name": "Охота из Засады",
                "icon": "🎯",
                "desc": "Превосходство в ликвидации Боссов и редкие трофеи",
                "skills": {
                    "counter_ambush": {
                        "name": "Упреждающий Удар",
                        "icon": "💥",
                        "desc": "+30% к урону против вызванных Боссов Таркова за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "boss_damage_pct",
                        "bonus_per_lvl": 0.30
                    },
                    "trophy_collection": {
                        "name": "Сбор Реликвий",
                        "icon": "🏆",
                        "desc": "+35% к шансу получить Реликвию Босса в спецоперации за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_relic_bonus_chance",
                        "bonus_per_lvl": 0.35
                    },
                    "nomad_mastery": {
                        "name": "Мастер Пустошей",
                        "icon": "👑",
                        "desc": "+10 000 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 10000000
                    }
                }
            }
        }
    },

    "Ronin": {
        "name": "Ronin",
        "icon": "🗡️",
        "tagline": "Одинокий самурай, охотник на чемпионов Таркова и мастер клинка",
        "branches": {
            "bushido": {
                "name": "Кодекс Бусидо",
                "icon": "🥋",
                "desc": "Истинное мастерство поединка и сокращение кулдауна спецопераций",
                "skills": {
                    "blade_focus": {
                        "name": "Фокус Клинка",
                        "icon": "⚔️",
                        "desc": "+30% к урону в дуэлях со всеми Боссами Таркова за уровень",
                        "max_lvl": 3,
                        "bonus_type": "boss_damage_pct",
                        "bonus_per_lvl": 0.30
                    },
                    "honor_code": {
                        "name": "Кодекс Чести",
                        "icon": "📜",
                        "desc": "+6 500 000 ₽ к кушу спецоперации Ронина за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 6500000
                    },
                    "master_stride": {
                        "name": "Шаг Мастера",
                        "icon": "⚡",
                        "desc": "Снижает время перезарядки спецоперации Ронина на 45 мин. за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    }
                }
            },
            "execution": {
                "name": "Рассечение Брони",
                "icon": "🩸",
                "desc": "Критические удары по щитам Боссов и повышенные награды за их ликвидацию",
                "skills": {
                    "armor_pierce": {
                        "name": "Смертельный Выпад",
                        "icon": "🗡️",
                        "desc": "+35% к сумме рублей за победу над любым вызванным Боссом за ур.",
                        "max_lvl": 3,
                        "bonus_type": "boss_loot_mult",
                        "bonus_per_lvl": 0.35
                    },
                    "katana_slash": {
                        "name": "Виртуозный Разрез",
                        "icon": "✨",
                        "desc": "+8 000 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 8000000
                    },
                    "boss_slayer": {
                        "name": "Охотник на Чемпионов",
                        "icon": "👑",
                        "desc": "+40% к шансу получить Реликвию Босса в спецоперации за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_relic_bonus_chance",
                        "bonus_per_lvl": 0.40
                    }
                }
            },
            "ronin_specops": {
                "name": "Теневой Додзе",
                "icon": "🏯",
                "desc": "Элитное вооружение и триумфальные спецоперации",
                "skills": {
                    "zen_patience": {
                        "name": "Дзен-Медитация",
                        "icon": "🧘",
                        "desc": "Снижает кулдаун спецоперации Ронина еще на 45 мин. за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    },
                    "dojo_armory": {
                        "name": "Арсенал Додзе",
                        "icon": "🛡️",
                        "desc": "Спецоперация приносит +3 элитных оружия или шлема за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_extra_loot",
                        "bonus_per_lvl": 3
                    },
                    "shogun_triumph": {
                        "name": "Триумф Сегуна",
                        "icon": "🏆",
                        "desc": "+12 000 000 ₽ к кушу спецоперации за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 12000000
                    }
                }
            }
        }
    },

    "Specter": {
        "name": "Specter",
        "icon": "👁️",
        "tagline": "Призрак ночных спецопераций и снайпер высшей категории",
        "branches": {
            "stealth": {
                "name": "Фантомный След",
                "icon": "👤",
                "desc": "Снайперская разведка, устранение ключевых целей и быстрый отход",
                "skills": {
                    "ghost_strike": {
                        "name": "Снайперская Точность",
                        "icon": "🎯",
                        "desc": "+6 000 000 ₽ к кушу спецоперации Спектра за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 6000000
                    },
                    "cold_calculation": {
                        "name": "Холодный Расчет",
                        "icon": "❄️",
                        "desc": "Снижает кулдаун спецоперации Спектра на 40 мин. за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2400
                    },
                    "phantom_veil": {
                        "name": "Око Спектра",
                        "icon": "👁️",
                        "desc": "+30% к урону против Боссов Таркова при вызове за уровень",
                        "max_lvl": 3,
                        "bonus_type": "boss_damage_pct",
                        "bonus_per_lvl": 0.30
                    }
                }
            },
            "artifact_hunting": {
                "name": "Поиск Сокровищ Лабы",
                "icon": "💳",
                "desc": "Архивы TerraGroup, ключ-карты Лаборатории и топовая оптика",
                "skills": {
                    "lab_keycards": {
                        "name": "Архивы Лаборатории",
                        "icon": "📑",
                        "desc": "Повышает шанс найти цветные ключ-карты TerraGroup в спецоперациях",
                        "max_lvl": 3,
                        "bonus_type": "keycard_drop_mult",
                        "bonus_per_lvl": 0.50
                    },
                    "elite_optics": {
                        "name": "Тепловизионная Разведка",
                        "icon": "🔭",
                        "desc": "Спецоперация приносит +3 дополнительных предмета хабара за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_extra_loot",
                        "bonus_per_lvl": 3
                    },
                    "specter_relic": {
                        "name": "Призрачный Трофей",
                        "icon": "🏆",
                        "desc": "+35% к шансу получить Реликвию Босса в спецоперации за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_relic_bonus_chance",
                        "bonus_per_lvl": 0.35
                    }
                }
            },
            "specops_ghost": {
                "name": "Теневая Ликвидация",
                "icon": "🌙",
                "desc": "Максимальный вынос миллионов и перехват цифровых активов",
                "skills": {
                    "clean_infiltrate": {
                        "name": "Чистая Зачистка",
                        "icon": "🚪",
                        "desc": "+8 000 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 8000000
                    },
                    "silent_takeover": {
                        "name": "Бесшумный Отход",
                        "icon": "👣",
                        "desc": "Дополнительно снижает кулдаун спецоперации на 45 мин. за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    },
                    "crypto_intercept": {
                        "name": "Перехват Данных",
                        "icon": "🪙",
                        "desc": "Шанс вынести чистый Биткоин из спецоперации (+25% за уровень)",
                        "max_lvl": 3,
                        "bonus_type": "sig_btc_chance",
                        "bonus_per_lvl": 0.25
                    }
                }
            }
        }
    },

    "Ares": {
        "name": "Ares",
        "icon": "🛡️",
        "tagline": "Тяжелый штурмовик, военный магнат и опора оборонной индустрии GD",
        "branches": {
            "heavy_assault": {
                "name": "Штурмовой Калибр",
                "icon": "💥",
                "desc": "Тяжелое вооружение, сокрушение Боссов и рекордный куш спецопераций",
                "skills": {
                    "titan_slug": {
                        "name": "Крупный Калибр .338",
                        "icon": "🎯",
                        "desc": "+7 000 000 ₽ к кушу спецоперации Ареса за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 7000000
                    },
                    "devastating_impact": {
                        "name": "Сокрушительный Удар",
                        "icon": "🔨",
                        "desc": "+30% к урону в поединках с Боссами Таркова за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "boss_damage_pct",
                        "bonus_per_lvl": 0.30
                    },
                    "rapid_deployment": {
                        "name": "Штурмовая Готовность",
                        "icon": "⏱️",
                        "desc": "Снижает время перезарядки спецоперации на 45 мин. за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    }
                }
            },
            "military_contracts": {
                "name": "Оборонный Комплекс",
                "icon": "🏭",
                "desc": "Пассивный доход оружейного завода GD Military и оптовые скидки",
                "skills": {
                    "gd_armory_boost": {
                        "name": "Оборонный Заказ",
                        "icon": "📈",
                        "desc": "+30% к пассивному доходу оружейного завода GD Military за ур.",
                        "max_lvl": 3,
                        "bonus_type": "gd_business_income_mult",
                        "bonus_per_lvl": 0.30
                    },
                    "arms_dealer": {
                        "name": "Оружейный Барон",
                        "icon": "🏷️",
                        "desc": "Скидка 20% на покупку любого оружия и брони в магазине за ур.",
                        "max_lvl": 3,
                        "bonus_type": "shop_discount",
                        "bonus_per_lvl": 0.20
                    },
                    "elite_supply": {
                        "name": "Военные Поставки",
                        "icon": "🦺",
                        "desc": "Спецоперация приносит +3 тяжелых бронежилета 6 класса за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_extra_loot",
                        "bonus_per_lvl": 3
                    }
                }
            },
            "fortification": {
                "name": "Неприступный Бастион",
                "icon": "🏰",
                "desc": "Расширение хранилища рублей и огромные складские мощности",
                "skills": {
                    "safe_expansion": {
                        "name": "Титановые Сейфы",
                        "icon": "🏦",
                        "desc": "Лимит хранилища рублей увеличен на +100 000 000 ₽ за уровень",
                        "max_lvl": 3,
                        "bonus_type": "vault_capacity_mult",
                        "bonus_per_lvl": 1.0
                    },
                    "stash_reinforce": {
                        "name": "Склад Боеприпасов",
                        "icon": "📦",
                        "desc": "+40 дополнительных слотов к вместимости схрона за ур.",
                        "max_lvl": 3,
                        "bonus_type": "stash_slots_bonus",
                        "bonus_per_lvl": 40
                    },
                    "ares_supremacy": {
                        "name": "Абсолютная Гегемония",
                        "icon": "👑",
                        "desc": "+10 000 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 10000000
                    }
                }
            }
        }
    },

    "Zenith": {
        "name": "Zenith",
        "icon": "💻",
        "tagline": "Кибер-инженер, крипто-магнат и архитектор цифровой инфраструктуры",
        "branches": {
            "crypto_matrix": {
                "name": "Крипто-Матрица",
                "icon": "🪙",
                "desc": "Разгон фермы биткоинов, выгодный P2P-курс и майнинг в спецоперациях",
                "skills": {
                    "overclock_asics": {
                        "name": "Разгон Асиков",
                        "icon": "⚡",
                        "desc": "+30% к скорости генерации биткоинов на криптоферме за уровень",
                        "max_lvl": 3,
                        "bonus_type": "btc_speed_mult",
                        "bonus_per_lvl": 0.30
                    },
                    "p2p_arbitrage": {
                        "name": "Крипто-Арбитраж",
                        "icon": "📈",
                        "desc": "Продажа Биткоина приносит на +2 000 000 ₽ больше за каждый BTC",
                        "max_lvl": 3,
                        "bonus_type": "btc_sell_bonus",
                        "bonus_per_lvl": 2000000
                    },
                    "crypto_harvest": {
                        "name": "Майнинг в Спецоперациях",
                        "icon": "💎",
                        "desc": "Шанс вынести чистый Биткоин из спецоперации (+35% за уровень)",
                        "max_lvl": 3,
                        "bonus_type": "sig_btc_chance",
                        "bonus_per_lvl": 0.35
                    }
                }
            },
            "cyber_intel": {
                "name": "Кибер-Разведка",
                "icon": "🛰️",
                "desc": "Взлом серверов TerraGroup, спутниковый радар и элитный хабар",
                "skills": {
                    "terragroup_hack": {
                        "name": "Взлом Баз TerraGroup",
                        "icon": "💾",
                        "desc": "+7 500 000 ₽ к кушу спецоперации Зенита за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 7500000
                    },
                    "satellite_link": {
                        "name": "Спутниковый Канал",
                        "icon": "📡",
                        "desc": "Снижает кулдаун спецоперации Зенита на 45 мин. за каждый ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    },
                    "quantum_loot": {
                        "name": "Квантовое Сканирование",
                        "icon": "🔬",
                        "desc": "Спецоперация приносит +3 ценных предмета микроэлектроники (LEDX)",
                        "max_lvl": 3,
                        "bonus_type": "sig_extra_loot",
                        "bonus_per_lvl": 3
                    }
                }
            },
            "high_tech": {
                "name": "Высокие Технологии",
                "icon": "🖥️",
                "desc": "Цифровизация схрона, выгодная продажа хай-тека и электронные реликвии",
                "skills": {
                    "server_expansion": {
                        "name": "Дата-Центр Схрона",
                        "icon": "🗄️",
                        "desc": "+50 дополнительных слотов к вместимости схрона за уровень",
                        "max_lvl": 3,
                        "bonus_type": "stash_slots_bonus",
                        "bonus_per_lvl": 50
                    },
                    "tech_market": {
                        "name": "Сбыт Хай-Тека",
                        "icon": "💰",
                        "desc": "+25% к цене продажи любой электроники и процессоров торговцам",
                        "max_lvl": 3,
                        "bonus_type": "valuable_sell_bonus",
                        "bonus_per_lvl": 0.25
                    },
                    "zenith_relic": {
                        "name": "Электронный Ключ",
                        "icon": "🏆",
                        "desc": "+30% к шансу получить Реликвию Босса в спецоперации за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_relic_bonus_chance",
                        "bonus_per_lvl": 0.30
                    }
                }
            }
        }
    },

    "Fenrir": {
        "name": "Fenrir",
        "icon": "🐺",
        "tagline": "Вожак волчьей стаи, свирепый рейдер и охотник за топовым оружием",
        "branches": {
            "predator": {
                "name": "Хищный Набег",
                "icon": "🐾",
                "desc": "Свирепый натиск, куш спецопераций и превосходство над Боссами",
                "skills": {
                    "wolf_frenzy": {
                        "name": "Свирепый Натиск",
                        "icon": "⚡",
                        "desc": "+7 000 000 ₽ к кушу спецоперации Фенрира за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 7000000
                    },
                    "pack_speed": {
                        "name": "Волчий Бег",
                        "icon": "⏱️",
                        "desc": "Снижает кулдаун спецоперации Фенрира на 40 мин. за каждый ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2400
                    },
                    "alpha_strike": {
                        "name": "Удар Вожака",
                        "icon": "🩸",
                        "desc": "+35% к урону в дуэлях со всеми Боссами Таркова за уровень",
                        "max_lvl": 3,
                        "bonus_type": "boss_damage_pct",
                        "bonus_per_lvl": 0.35
                    }
                }
            },
            "plunder": {
                "name": "Трофейный Арсенал",
                "icon": "⚔️",
                "desc": "Вынос элитного оружия 5-6 тира (ВСС, HK416, AXMC) и скидки на снаряжение",
                "skills": {
                    "trophy_weapons": {
                        "name": "Элитный Арсенал",
                        "icon": "🔫",
                        "desc": "Спецоперация гарантированно приносит +3 топовых оружия или брони",
                        "max_lvl": 3,
                        "bonus_type": "sig_extra_loot",
                        "bonus_per_lvl": 3
                    },
                    "military_surplus": {
                        "name": "Армейский Склад",
                        "icon": "🏷️",
                        "desc": "Скидка 20% на покупку патронов, экипировки и шлемов в магазине",
                        "max_lvl": 3,
                        "bonus_type": "shop_discount",
                        "bonus_per_lvl": 0.20
                    },
                    "fenrir_relic_fang": {
                        "name": "Клык Фенрира",
                        "icon": "🏆",
                        "desc": "+35% к шансу получить Реликвию Босса в спецоперации за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_relic_bonus_chance",
                        "bonus_per_lvl": 0.35
                    }
                }
            },
            "feral_instinct": {
                "name": "Звериное Чутье",
                "icon": "🌙",
                "desc": "Мгновенное пополнение припасов и максимальный куш стаи",
                "skills": {
                    "blood_scent": {
                        "name": "Запах Добычи",
                        "icon": "💰",
                        "desc": "+8 500 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 8500000
                    },
                    "pack_stamina": {
                        "name": "Выносливость Стаи",
                        "icon": "💨",
                        "desc": "Дополнительно снижает кулдаун спецоперации на 45 мин. за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    },
                    "fenrir_dominance": {
                        "name": "Абсолютный Доминант",
                        "icon": "👑",
                        "desc": "+12 000 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 12000000
                    }
                }
            }
        }
    },

    "Stalker": {
        "name": "Stalker",
        "icon": "☢️",
        "tagline": "Ветеран глубин Таркова, знаток забытых складов Припяти и тайников",
        "branches": {
            "hidden_caches": {
                "name": "Тайники Зоны",
                "icon": "🧭",
                "desc": "Скрытые схроны Таркова, сокращение перезарядки и богатый хабар",
                "skills": {
                    "secret_stash": {
                        "name": "Скрытые Схроны",
                        "icon": "🎒",
                        "desc": "+6 500 000 ₽ к кушу спецоперации Сталкера за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 6500000
                    },
                    "zone_shortcuts": {
                        "name": "Тайные Тропы",
                        "icon": "🗺️",
                        "desc": "Снижает кулдаун спецоперации Сталкера на 45 мин. за каждый ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    },
                    "deep_stalk": {
                        "name": "Мародерство Сталкера",
                        "icon": "📦",
                        "desc": "Спецоперация приносит +3 редких предмета хабара за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_extra_loot",
                        "bonus_per_lvl": 3
                    }
                }
            },
            "pripyat_expedition": {
                "name": "Склады Припяти",
                "icon": "🏭",
                "desc": "Поиск редчайших микросхем, видеокарт, колоссальный опыт и реликвии",
                "skills": {
                    "military_caches": {
                        "name": "Военные Склады",
                        "icon": "💻",
                        "desc": "Повышает шанс найти топовые видеокарты и LEDX в спецоперациях",
                        "max_lvl": 3,
                        "bonus_type": "sig_extra_loot",
                        "bonus_per_lvl": 2
                    },
                    "zone_lore": {
                        "name": "Опыт Ветерана Зоны",
                        "icon": "⭐",
                        "desc": "+30% к получаемому EXP профиля во всех операциях за уровень",
                        "max_lvl": 3,
                        "bonus_type": "exp_gain_mult",
                        "bonus_per_lvl": 0.30
                    },
                    "stalker_relic": {
                        "name": "Трофеи Зоны",
                        "icon": "🏆",
                        "desc": "+35% к шансу найти Реликвию Босса в спецоперации за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_relic_bonus_chance",
                        "bonus_per_lvl": 0.35
                    }
                }
            },
            "smuggler_trade": {
                "name": "Торговля со Скупщиком",
                "icon": "🤝",
                "desc": "Прямые связи со Скупщиком, выгодный сбыт и чистые биткоины",
                "skills": {
                    "fence_favors": {
                        "name": "Связи со Скупщиком",
                        "icon": "💰",
                        "desc": "+20% к цене продажи любых предметов и трофеев торговцам за ур.",
                        "max_lvl": 3,
                        "bonus_type": "vendor_sell_bonus",
                        "bonus_per_lvl": 0.20
                    },
                    "gold_ruble": {
                        "name": "Золотой Рубль",
                        "icon": "🪙",
                        "desc": "+8 000 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 8000000
                    },
                    "stalker_legend": {
                        "name": "Легенда Таркова",
                        "icon": "👑",
                        "desc": "Шанс вынести чистый Биткоин из спецоперации (+30% за уровень)",
                        "max_lvl": 3,
                        "bonus_type": "sig_btc_chance",
                        "bonus_per_lvl": 0.30
                    }
                }
            }
        }
    },

    "Siren": {
        "name": "Siren",
        "icon": "🧜‍♀️",
        "tagline": "Командир Синдиката, логист GD Pharma и мастер теневых сделок",
        "branches": {
            "gd_pharma": {
                "name": "Фармацевтический Картель",
                "icon": "💉",
                "desc": "Усиление медицинского бизнеса GD Military и поставки стимуляторов",
                "skills": {
                    "pharma_business": {
                        "name": "Фарм-Завод GD",
                        "icon": "🏭",
                        "desc": "+35% к пассивному доходу всех бизнесов убежища за уровень",
                        "max_lvl": 3,
                        "bonus_type": "business_income_mult",
                        "bonus_per_lvl": 0.35
                    },
                    "stim_supplies": {
                        "name": "Снабжение Стимуляторами",
                        "icon": "📦",
                        "desc": "Спецоперация приносит +3 элитных медицинских препарата (LEDX/Grizzly)",
                        "max_lvl": 3,
                        "bonus_type": "sig_extra_loot",
                        "bonus_per_lvl": 3
                    },
                    "pharma_speed": {
                        "name": "Экспресс-Логистика",
                        "icon": "⏱️",
                        "desc": "Снижает кулдаун спецоперации Сирены на 45 мин. за каждый ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    }
                }
            },
            "syndicate_diplomacy": {
                "name": "Синдикат & Черный Рынок",
                "icon": "🤝",
                "desc": "Выгоднейший сбыт медикаментов и скидки на модернизацию Убежища",
                "skills": {
                    "black_market_deals": {
                        "name": "Теневые Сделки",
                        "icon": "💰",
                        "desc": "+25% к цене продажи медицинских предметов и ценностей торговцам",
                        "max_lvl": 3,
                        "bonus_type": "valuable_sell_bonus",
                        "bonus_per_lvl": 0.25
                    },
                    "peacekeeper_contract": {
                        "name": "Связи Синдиката",
                        "icon": "🏷️",
                        "desc": "Скидка 20% на все улучшения модулей Убежища за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "hideout_cost_discount",
                        "bonus_per_lvl": 0.20
                    },
                    "siren_charm": {
                        "name": "Шарм Сирены",
                        "icon": "💎",
                        "desc": "+7 500 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 7500000
                    }
                }
            },
            "siren_specops": {
                "name": "Песнь Сирены",
                "icon": "🎵",
                "desc": "Безупречные спецоперации без сопротивления охраны и охота за реликвиями",
                "skills": {
                    "hypnotic_heist": {
                        "name": "Гипнотический Налет",
                        "icon": "🚪",
                        "desc": "+8 000 000 ₽ к кушу спецоперации за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 8000000
                    },
                    "siren_cooldown": {
                        "name": "Благословение Сирены",
                        "icon": "⏳",
                        "desc": "Снижает кулдаун спецоперации Сирены еще на 45 мин. за уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    },
                    "siren_relic": {
                        "name": "Дар Сирены",
                        "icon": "🏆",
                        "desc": "+35% к шансу получить Реликвию Босса в спецоперации за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_relic_bonus_chance",
                        "bonus_per_lvl": 0.35
                    }
                }
            }
        }
    },

    "Pharaoh": {
        "name": "Pharaoh",
        "icon": "👑",
        "tagline": "Владыка золотого запаса, антикварных сокровищ и царской казны",
        "branches": {
            "treasury": {
                "name": "Золотая Казна",
                "icon": "💰",
                "desc": "Пассивное обогащение, чеканка монет и гигантские хранилища рублей",
                "skills": {
                    "golden_scepter": {
                        "name": "Царский Скипетр",
                        "icon": "🔱",
                        "desc": "+35% к пассивному доходу всех бизнесов убежища за уровень",
                        "max_lvl": 3,
                        "bonus_type": "business_income_mult",
                        "bonus_per_lvl": 0.35
                    },
                    "tomb_minting": {
                        "name": "Чеканка Монет",
                        "icon": "🪙",
                        "desc": "Каждый час автоматически приносит +1 000 000 ₽ в казну за ур.",
                        "max_lvl": 3,
                        "bonus_type": "hourly_rubles_flat",
                        "bonus_per_lvl": 1000000
                    },
                    "pyramid_bank": {
                        "name": "Золотое Хранилище",
                        "icon": "🏦",
                        "desc": "Вместимость сейфа рублей увеличена в 2 раза (+100% за ур.)",
                        "max_lvl": 3,
                        "bonus_type": "vault_capacity_mult",
                        "bonus_per_lvl": 1.0
                    }
                }
            },
            "dynasty": {
                "name": "Вечная Династия",
                "icon": "🏛️",
                "desc": "Колоссальное расширение схрона, опыт фараонов и выгодный сбыт",
                "skills": {
                    "anubis_tribute": {
                        "name": "Дань Анубиса",
                        "icon": "⭐",
                        "desc": "+25% к опыту профиля во всех активностях за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "exp_gain_mult",
                        "bonus_per_lvl": 0.25
                    },
                    "pharaoh_stash": {
                        "name": "Царская Сокровищница",
                        "icon": "📦",
                        "desc": "+50 дополнительных слотов к вместимости схрона за уровень",
                        "max_lvl": 3,
                        "bonus_type": "stash_slots_bonus",
                        "bonus_per_lvl": 50
                    },
                    "ra_fortune": {
                        "name": "Благословение Ра",
                        "icon": "☀️",
                        "desc": "+25% к цене продажи любых предметов и хабара торговцам за ур.",
                        "max_lvl": 3,
                        "bonus_type": "vendor_sell_bonus",
                        "bonus_per_lvl": 0.25
                    }
                }
            },
            "pharaoh_specops": {
                "name": "Гробница Фараона",
                "icon": "🏺",
                "desc": "Экспроприация сокровищниц TerraGroup и древние реликвии",
                "skills": {
                    "gold_bounty": {
                        "name": "Царский Куш",
                        "icon": "💰",
                        "desc": "+8 000 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 8000000
                    },
                    "sun_chariot": {
                        "name": "Солнечная Колесница",
                        "icon": "🏎️",
                        "desc": "Снижает время перезарядки спецоперации ЧВК на 45 мин. за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    },
                    "pharaoh_relic": {
                        "name": "Печать Фараона",
                        "icon": "🏆",
                        "desc": "Спецоперация приносит Реликвию Босса с шансом 50% за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_relic_bonus_chance",
                        "bonus_per_lvl": 0.50
                    }
                }
            }
        }
    },

    "Revenant": {
        "name": "Revenant",
        "icon": "💀",
        "tagline": "Теневой титан GD Military, каратель Боссов и повелитель спецопераций",
        "branches": {
            "shadow_titan": {
                "name": "Теневой Титан",
                "icon": "🛡️",
                "desc": "Рублевая страховка неудач, огромный куш спецопераций и марш смерти",
                "skills": {
                    "insurance_fund": {
                        "name": "Теневая Страховка",
                        "icon": "💼",
                        "desc": "При неудачном обычном рейде отряда компенсирует 50% стоимости рублями",
                        "max_lvl": 3,
                        "bonus_type": "insurance_rebate",
                        "bonus_per_lvl": 0.50
                    },
                    "revenant_payout": {
                        "name": "Кровавый Куш",
                        "icon": "🩸",
                        "desc": "+8 500 000 ₽ к кушу спецоперации Ревенанта за каждый уровень",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 8500000
                    },
                    "death_march": {
                        "name": "Марш Смерти",
                        "icon": "⏱️",
                        "desc": "Снижает кулдаун спецоперации Ревенанта на 45 мин. за каждый ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_cooldown_reduction",
                        "bonus_per_lvl": 2700
                    }
                }
            },
            "gd_empire": {
                "name": "Империя GD Military",
                "icon": "🏭",
                "desc": "Максимизация прибыли бизнесов GD, оружейный арсенал и турбо-пропуск",
                "skills": {
                    "gd_business_overdrive": {
                        "name": "Спец-Дивизион GD",
                        "icon": "📈",
                        "desc": "+35% к пассивному доходу от всех бизнесов GD Military за уровень",
                        "max_lvl": 3,
                        "bonus_type": "gd_business_income_mult",
                        "bonus_per_lvl": 0.35
                    },
                    "arsenal_resonance": {
                        "name": "Оружейный Комплекс GD",
                        "icon": "🏷️",
                        "desc": "Скидка 25% на экипировку и модули оружия в магазине за ур.",
                        "max_lvl": 3,
                        "bonus_type": "shop_discount",
                        "bonus_per_lvl": 0.25
                    },
                    "bp_overclock": {
                        "name": "Турбо-Пропуск GD",
                        "icon": "🚀",
                        "desc": "Опыт Боевого Пропуска GD начисляется на +50% быстрее за ур.",
                        "max_lvl": 3,
                        "bonus_type": "bp_exp_mult",
                        "bonus_per_lvl": 0.50
                    }
                }
            },
            "apocalypse": {
                "name": "Протокол Судного Дня",
                "icon": "🔥",
                "desc": "Максимальное истребление секторов TerraGroup и гарантированные реликвии",
                "skills": {
                    "apocalypse_plunder": {
                        "name": "Жатва Судного Дня",
                        "icon": "💥",
                        "desc": "+10 000 000 ₽ к кушу спецоперации за каждый уровень прокачки",
                        "max_lvl": 3,
                        "bonus_type": "sig_money_bonus",
                        "bonus_per_lvl": 10000000
                    },
                    "boss_annihilation": {
                        "name": "Истребление Боссов",
                        "icon": "👑",
                        "desc": "+40% к урону в дуэлях с Боссами Таркова при их вызове за уровень",
                        "max_lvl": 3,
                        "bonus_type": "boss_damage_pct",
                        "bonus_per_lvl": 0.40
                    },
                    "reaper_relic": {
                        "name": "Трофей Жнеца",
                        "icon": "🏆",
                        "desc": "Спецоперация приносит Реликвию Босса с шансом 60% за ур.",
                        "max_lvl": 3,
                        "bonus_type": "sig_relic_bonus_chance",
                        "bonus_per_lvl": 0.60
                    }
                }
            }
        }
    }
}

# ─────────────────────────────────────────────────────────────────────────────
# PROGRESSION & HELPER FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def get_signature_pmc_progress(player, pmc_key):
    """Retrieves or initializes the skill tree progress dict for the given PMC."""
    if not pmc_key:
        pmc_key = player.get("pmc_signature", "Viper")
    all_prog = player.setdefault("signature_pmc_skills", {})
    if pmc_key not in all_prog:
        all_prog[pmc_key] = {
            "points": 5,          # Initial starter points for experimenting
            "total_earned": 5,
            "skills": {},         # {skill_id: lvl}
            "resets_used": 0
        }
    return all_prog[pmc_key]


def award_signature_pmc_points(player, pmc_key, amount=1, reason=""):
    """Awards talent points specifically to the specified signature PMC."""
    if not pmc_key:
        pmc_key = player.get("pmc_signature", "Viper")
    prog = get_signature_pmc_progress(player, pmc_key)
    prog["points"] = prog.get("points", 0) + amount
    prog["total_earned"] = prog.get("total_earned", 0) + amount
    return prog["points"]


def get_signature_skill_bonus(player, pmc_key, bonus_type):
    """Calculates cumulative active bonus for the given bonus_type on the active PMC."""
    if not pmc_key:
        pmc_key = player.get("pmc_signature", "Viper")
    pmc_tree = SIGNATURE_PMC_TREES.get(pmc_key)
    if not pmc_tree:
        return 0.0
    prog = player.get("signature_pmc_skills", {}).get(pmc_key, {})
    skills = prog.get("skills", {})
    
    total_val = 0.0
    for b_id, b_data in pmc_tree.get("branches", {}).items():
        for s_id, s_data in b_data.get("skills", {}).items():
            if s_data.get("bonus_type") == bonus_type:
                lvl = skills.get(s_id, 0)
                if lvl > 0:
                    total_val += lvl * s_data.get("bonus_per_lvl", 0)
    return total_val


def render_signature_skills_menu(player, pmc_key=None, view_branch=None):
    """
    Renders Telegram interactive markup for the Signature PMC 3-Branch Talent Tree.
    Returns (txt, markup).
    """
    if not pmc_key:
        pmc_key = player.get("pmc_signature", "Viper")
    pmc_tree = SIGNATURE_PMC_TREES.get(pmc_key, SIGNATURE_PMC_TREES["Viper"])
    prog = get_signature_pmc_progress(player, pmc_key)
    points = prog.get("points", 0)
    learned = prog.get("skills", {})

    txt = (
        f"⭐ <b>ДРЕВО НАВЫКОВ СИГНАТУРНОГО ЧВК: {pmc_tree['name'].upper()}</b>\n"
        f"────────────────────────\n"
        f"{pmc_tree['icon']} <b>Специализация:</b> <i>{pmc_tree['tagline']}</i>\n"
        f"🌟 <b>Доступно очков талантов:</b> <b>{points}</b>\n\n"
        f"ℹ️ <i>Сигнатурные ЧВК — автономные элитные агенты. Они совершают собственные "
        f"сверхприбыльные Спецоперации (30-50M ₽ | 3x Лут | Бессмертие) и не состоят в рядовом отряде. "
        f"Очки начисляются за каждую Спецоперацию (+2 очка) и ликвидацию Боссов (+1 очко).</i>\n\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)

    branches = pmc_tree.get("branches", {})

    if view_branch and view_branch in branches:
        # Detailed single branch view
        b_data = branches[view_branch]
        txt += (
            f"🔹 <b>ВЕТКА: {b_data['icon']} {b_data['name'].upper()}</b>\n"
            f"<i>{b_data['desc']}</i>\n"
            f"────────────────────────\n"
        )
        for s_id, s_data in b_data.get("skills", {}).items():
            cur_lvl = learned.get(s_id, 0)
            max_lvl = s_data.get("max_lvl", 3)
            bars = "🟩" * cur_lvl + "⬜" * (max_lvl - cur_lvl)
            txt += (
                f"\n{s_data['icon']} <b>{s_data['name']}</b> [{bars} {cur_lvl}/{max_lvl}]\n"
                f"• {s_data['desc']}\n"
            )
            if cur_lvl < max_lvl:
                can_up = points >= 1
                up_label = f"➕ Вкачать: {s_data['name']} (1 очко)" if can_up else f"🔒 Не хватает очков ({points}/1)"
                cb_data = f"sig_up_{pmc_key}_{s_id}" if can_up else "none"
                markup.add(types.InlineKeyboardButton(up_label, callback_data=cb_data))
            else:
                markup.add(types.InlineKeyboardButton(f"✅ {s_data['name']} (МАКСИМУМ)", callback_data="none"))
        
        markup.add(types.InlineKeyboardButton("🔙 Ко всем веткам ЧВК", callback_data=f"sig_tree_{pmc_key}"))
    else:
        # Overview of all 3 branches
        for b_id, b_data in branches.items():
            b_points_invested = sum(learned.get(s, 0) for s in b_data.get("skills", {}))
            max_b_points = sum(s.get("max_lvl", 3) for s in b_data.get("skills", {}).values())
            txt += (
                f"🔹 <b>{b_data['icon']} {b_data['name']}</b> ({b_points_invested}/{max_b_points} очков)\n"
                f"<i>{b_data['desc']}</i>\n"
            )
            for s_id, s_data in b_data.get("skills", {}).items():
                cur_lvl = learned.get(s_id, 0)
                max_lvl = s_data.get("max_lvl", 3)
                mark = "🟢" if cur_lvl == max_lvl else ("🟡" if cur_lvl > 0 else "⚪")
                txt += f"  {mark} {s_data['name']}: <b>{cur_lvl}/{max_lvl}</b>\n"
            txt += "\n"
            markup.add(types.InlineKeyboardButton(
                f"📂 Открыть ветку: {b_data['name']} ({b_points_invested}/{max_b_points})",
                callback_data=f"sig_branch_{pmc_key}_{b_id}"
            ))

        # Reset button (free reset to encourage builds)
        markup.add(types.InlineKeyboardButton("🔄 Бесплатный сброс всех очков ЧВК", callback_data=f"sig_reset_{pmc_key}"))

    # Return navigation
    markup.add(
        types.InlineKeyboardButton("🚀 Меню Спецоперации ЧВК", callback_data="menu_signature_raid"),
        types.InlineKeyboardButton("🔙 К Меню Рейдов", callback_data="menu_raids")
    )

    return txt, markup


def handle_upgrade_signature_skill(call, player, db, bot):
    """Processes leveling up a skill in the Signature PMC Tree."""
    # Data format: sig_up_{pmc_key}_{skill_id}
    parts = call.data.split("_")
    if len(parts) < 4:
        bot.answer_callback_query(call.id, "❌ Неверные параметры!", show_alert=True)
        return
    pmc_key = parts[2]
    skill_id = "_".join(parts[3:])

    pmc_tree = SIGNATURE_PMC_TREES.get(pmc_key)
    if not pmc_tree:
        bot.answer_callback_query(call.id, "❌ ЧВК не найден!", show_alert=True)
        return

    # Find skill definition
    skill_def = None
    branch_id = None
    for b_id, b_data in pmc_tree.get("branches", {}).items():
        if skill_id in b_data.get("skills", {}):
            skill_def = b_data["skills"][skill_id]
            branch_id = b_id
            break

    if not skill_def:
        bot.answer_callback_query(call.id, "❌ Навык не найден!", show_alert=True)
        return

    prog = get_signature_pmc_progress(player, pmc_key)
    if prog.get("points", 0) < 1:
        bot.answer_callback_query(call.id, "❌ Недостаточно очков талантов!", show_alert=True)
        return

    cur_lvl = prog.setdefault("skills", {}).get(skill_id, 0)
    max_lvl = skill_def.get("max_lvl", 3)
    if cur_lvl >= max_lvl:
        bot.answer_callback_query(call.id, "✅ Навык уже изучен на максимум!", show_alert=True)
        return

    # Level up!
    prog["points"] -= 1
    prog["skills"][skill_id] = cur_lvl + 1

    from tarkov_engine import save_db
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"⚡ Навык «{skill_def['name']}» улучшен до {cur_lvl + 1}/{max_lvl}!",
        show_alert=False
    )

    # Re-render the branch view
    txt, markup = render_signature_skills_menu(player, pmc_key, branch_id)
    try:
        bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
    except Exception:
        try:
            bot.send_message(call.message.chat.id, txt, reply_markup=markup, parse_mode="HTML")
        except Exception:
            pass


def handle_reset_signature_skills(call, player, db, bot):
    """Refunds all invested talent points for the signature PMC."""
    parts = call.data.split("_")
    pmc_key = parts[2] if len(parts) > 2 else player.get("pmc_signature", "Viper")

    prog = get_signature_pmc_progress(player, pmc_key)
    invested = sum(prog.get("skills", {}).values())
    if invested <= 0:
        bot.answer_callback_query(call.id, "ℹ️ В этом древе еще нет прокачанных навыков!", show_alert=True)
        return

    prog["points"] = prog.get("points", 0) + invested
    prog["skills"] = {}
    prog["resets_used"] = prog.get("resets_used", 0) + 1

    from tarkov_engine import save_db
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"🔄 Все очки навыков ({invested} шт.) успешно возвращены!",
        show_alert=True
    )

    txt, markup = render_signature_skills_menu(player, pmc_key)
    try:
        bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
    except Exception:
        try:
            bot.send_message(call.message.chat.id, txt, reply_markup=markup, parse_mode="HTML")
        except Exception:
            pass
