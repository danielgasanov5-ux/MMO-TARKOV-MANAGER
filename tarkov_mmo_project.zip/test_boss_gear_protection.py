# -*- coding: utf-8 -*-
"""
Verification suite for Boss Gear Lock & Weapon/Armor Protection rules:
- When Boss is recruited:
  - Equipment is non-detachable (cannot unequip).
  - Equipment cannot be sold to Prapor or Prapor bulk sell.
  - Equipment cannot be listed on P2P market.
  - Equipment cannot be equipped to anyone else.
  - Disbanding boss takes his gear with him (cannot exploit stash retention).
- When Boss is defeated in combat:
  - Player earns trophy item in stash which CAN be equipped on PMC.
"""

import copy
from tarkov_engine import save_db
from boss_summon_system import SUMMONED_BOSSES, handle_recruit_summoned_boss, handle_fight_summoned_boss
from bot import (
    handle_slot_unequip, handle_slot_equip, handle_disband_fighter,
    handle_prapor_sell, handle_prapor_sell_rarity, handle_p2p_list_action,
    handle_p2p_list_menu
)

class MockCall:
    def __init__(self, user_id, data=""):
        self.id = "mock_call_1"
        self.data = data
        self.message = type("MockMsg", (), {
            "chat": type("MockChat", (), {"id": user_id})(),
            "message_id": 999
        })()

class MockBot:
    def __init__(self):
        self.alerts = []
        self.sent_messages = []
        self.edited_messages = []

    def answer_callback_query(self, call_id, text=None, show_alert=False):
        self.alerts.append({"text": text, "alert": show_alert})

    def send_message(self, chat_id, text, **kwargs):
        self.sent_messages.append({"chat_id": chat_id, "text": text, "kwargs": kwargs})

    def edit_message_text(self, text, chat_id, message_id, **kwargs):
        self.edited_messages.append({"chat_id": chat_id, "msg_id": message_id, "text": text, "kwargs": kwargs})

def run_test():
    mock_bot = MockBot()
    import bot
    import boss_summon_system
    bot.bot = mock_bot
    boss_summon_system.bot = mock_bot

    db = {
        "players": {
            "100": {
                "user_id": 100,
                "username": "TestStalker",
                "money": 500000,
                "exp": 1000,
                "squad": [],
                "stash": [],
                "modules": {}
            }
        },
        "coop_lobbies": {},
        "p2p_market": []
    }
    player = db["players"]["100"]

    print("--- TEST 1: Recruit Boss (Partisan) ---")
    player["pending_boss_summon"] = {
        "boss_key": "partisan",
        "timestamp": 123456
    }
    call = MockCall(100, "recruit_summoned_boss")
    handle_recruit_summoned_boss(call, player, db, "partisan", mock_bot)

    assert len(player["squad"]) == 1, "Boss should be in squad"
    boss_fighter = player["squad"][0]
    assert boss_fighter["type"] == "boss", "Fighter type must be boss"
    assert boss_fighter["boss_key"] == "partisan"
    print(f"✓ Boss recruited: {boss_fighter['name']}")

    # Check stash items
    boss_items = [i for i in player["stash"] if i.get("is_boss_locked")]
    assert len(boss_items) == 2, f"Boss should have 2 locked items in stash, found {len(boss_items)}"
    weapon_item = next(i for i in boss_items if "partisan_svd" in i["item_id"])
    armor_item = next(i for i in boss_items if "partisan_rig" in i["item_id"])
    print("✓ Boss items created with is_boss_locked=True")

    print("--- TEST 2: Attempt to unequip Boss weapon ---")
    mock_bot.alerts.clear()
    handle_slot_unequip(call, player, db, boss_fighter["id"], "weapon")
    assert any("Нельзя" in a["text"] for a in mock_bot.alerts), "Unequip should be blocked with alert"
    assert boss_fighter["weapon_uid"] == weapon_item["uid"], "Weapon must remain equipped"
    print("✓ Unequip boss weapon was successfully BLOCKED")

    print("--- TEST 3: Attempt to unequip Boss armor ---")
    mock_bot.alerts.clear()
    handle_slot_unequip(call, player, db, boss_fighter["id"], "armor")
    assert any("Нельзя" in a["text"] for a in mock_bot.alerts), "Unequip armor should be blocked with alert"
    assert boss_fighter["armor_uid"] == armor_item["uid"], "Armor must remain equipped"
    print("✓ Unequip boss armor was successfully BLOCKED")

    print("--- TEST 4: Attempt to sell Boss item to Prapor ---")
    mock_bot.alerts.clear()
    handle_prapor_sell(call, player, db, weapon_item["uid"])
    assert any("Нельзя продать" in a["text"] for a in mock_bot.alerts), "Selling boss item to Prapor must be blocked"
    assert any(i["uid"] == weapon_item["uid"] for i in player["stash"]), "Weapon must still be in stash"
    print("✓ Selling boss gear to Prapor was successfully BLOCKED")

    print("--- TEST 5: Prapor bulk sell does not sell Boss gear ---")
    initial_rub = player["money"]
    handle_prapor_sell_rarity(call, player, db, None, "legendary")
    assert player["money"] == initial_rub, "Bulk sell legendary must not sell boss weapon"
    assert any(i["uid"] == weapon_item["uid"] for i in player["stash"]), "Weapon must remain in stash"
    print("✓ Prapor bulk sell correctly IGNORED boss locked gear")

    print("--- TEST 6: P2P Market listing is blocked ---")
    mock_bot.alerts.clear()
    handle_p2p_list_action(call, player, db, weapon_item["uid"])
    assert any("недоступен" in a["text"].lower() for a in mock_bot.alerts), "P2P listing must be blocked"
    assert len(db.get("p2p_market", [])) == 0, "No item should be listed on P2P"
    print("✓ P2P market listing was successfully BLOCKED")

    print("--- TEST 7: Disbanding Boss cleans his locked gear from stash ---")
    mock_bot.alerts.clear()
    handle_disband_fighter(call, player, db, boss_fighter["id"])
    assert len(player["squad"]) == 0, "Squad must be empty"
    remaining_boss_items = [i for i in player["stash"] if i.get("is_boss_locked")]
    assert len(remaining_boss_items) == 0, "Boss gear must leave with boss when disbanded"
    print("✓ Boss disbanded: boss left with his gear, zero exploit retention in stash")

    print("--- TEST 8: Fighting Boss yields legitimate trophy item in stash ---")
    import random
    random.seed(1)
    player["pending_boss_summon"] = {
        "boss_key": "kollontay",
        "timestamp": 123456
    }
    # Set high player power to ensure combat victory
    player["squad"] = [{
        "id": 99,
        "type": "pmc",
        "name": "SuperPMC",
        "base_power": 500,
        "base_armor": 500,
        "weapon_uid": None,
        "armor_uid": None,
        "helmet_uid": None,
        "headset_uid": None
    }]
    mock_bot.edited_messages.clear()
    call = MockCall(100, "fight_summoned_boss")
    handle_fight_summoned_boss(call, player, db, "kollontay", mock_bot)

    # Check trophy in stash
    trophies = [i for i in player["stash"] if "kollontay" in i.get("item_id", "")]
    assert len(trophies) > 0, "Combat victory must award boss trophy"
    trophy = trophies[0]
    assert trophy.get("is_boss_locked") is not True, "Combat trophy is legitimate loot and NOT locked to a boss"
    assert trophy.get("equipped_to") is None, "Trophy is unequipped in stash"
    print(f"✓ Combat victory awarded trophy: {trophy['item_id']} (usable by player PMC!)")

    print("\n========================================================")
    print("🎉 ALL BOSS GEAR PROTECTION AUDIT CHECKS PASSED 100%!")
    print("========================================================")

if __name__ == "__main__":
    run_test()
