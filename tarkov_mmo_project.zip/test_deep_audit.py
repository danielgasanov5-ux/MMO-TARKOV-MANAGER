import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))

import tarkov_engine as te
import coop_system as cs
import bot as tb

class DummyCall:
    def __init__(self, uid, data):
        self.id = "mock_call_deep"
        self.data = data
        self.message = type("msg", (), {"chat": type("c", (), {"id": 12345})(), "message_id": 99})()
        self.from_user = type("u", (), {"id": uid, "username": "revenuts", "first_name": "Test"})()

class DummyBot:
    def __init__(self):
        self.answers = []
        self.messages = []
        self.last_edited_text = ""
        self.last_markup = None
    def answer_callback_query(self, call_id, text=None, show_alert=False):
        self.answers.append((call_id, text, show_alert))
    def send_message(self, chat_id, text, reply_markup=None):
        self.messages.append((chat_id, text))
    def edit_message_text(self, text, chat_id, message_id, reply_markup=None):
        self.last_edited_text = text
        self.last_markup = reply_markup
        self.messages.append((chat_id, text))

mock_bot = DummyBot()
tb.bot = mock_bot

print("==================================================")
print("     STARTING DEEP GAME AUDIT & EDGE CASE SUITE   ")
print("==================================================")

# AUDIT 1: Bankruptcy Relief vs Anti-Exploit Protection
print("\n[AUDIT 1] Bankruptcy Soft-Lock & Anti-Exploit Protection...")
bankrupt_player = te.create_new_player(77001, "BankruptOperator", "Viper")
bankrupt_player["money"] = 0
bankrupt_player["squad"] = []
bankrupt_player["stash"] = []
mock_db = {"users": {str(bankrupt_player["user_id"]): bankrupt_player}}

tb.handle_menu_squad(12345, 99, bankrupt_player)
btn_texts = [b.text for row in mock_bot.last_markup.keyboard for b in row]
assert any("Пособие Прапора" in t for t in btn_texts), "Bankrupt player was not offered Prapor emergency aid!"

call_aid = DummyCall(bankrupt_player["user_id"], "prapor_bankruptcy_aid")
tb.handle_prapor_bankruptcy_aid(call_aid, bankrupt_player, mock_db)
assert bankrupt_player["money"] == 10000, f"Expected 10,000 ₽, got {bankrupt_player['money']}"
assert any("10 000" in str(a) for a in mock_bot.answers), "Did not notify player of aid"

mock_bot.answers.clear()
tb.handle_prapor_bankruptcy_aid(call_aid, bankrupt_player, mock_db)
assert bankrupt_player["money"] == 10000, "Money should not increase when not bankrupt!"
assert any("только при полном банкротстве" in str(a) for a in mock_bot.answers), "Exploit not blocked!"
print("✅ Bankruptcy Soft-Lock & Anti-Exploit: PASSED (Protected from soft-lock and abuse)")

# AUDIT 2: Boss Relic Bulk Sale Safeguard
print("\n[AUDIT 2] Boss Relic Safeguard from Bulk Rarity Sales...")
collector_player = te.create_new_player(77002, "CollectorOperator", "Viper")
collector_player["stash"] = [
    {"uid": "std_legendary_1", "item_id": "keycard_black_legendary", "equipped_to": None},
    {"uid": "boss_relic_killa", "item_id": "relic_killa_helmet", "equipped_to": None},
    {"uid": "boss_relic_tagilla", "item_id": "relic_tagilla_sledgehammer", "equipped_to": None},
]
mock_db["users"][str(collector_player["user_id"])] = collector_player

call_sell_legendary = DummyCall(collector_player["user_id"], "prapor_sell_all_legendary")
tb.handle_prapor_sell_rarity(call_sell_legendary, collector_player, mock_db, None, "legendary")

stash_uids = [i["uid"] for i in collector_player["stash"]]
assert "std_legendary_1" not in stash_uids, "Standard legendary was not sold!"
assert "boss_relic_killa" in stash_uids, "Boss relic Killa was accidentally sold!"
assert "boss_relic_tagilla" in stash_uids, "Boss relic Tagilla was accidentally sold!"
print("✅ Boss Relic Bulk Sale Safeguard: PASSED (Boss relics protected from accidental bulk wipes)")

# AUDIT 3: P2P Self-Purchase Prevention & DB_LOCK Integrity
print("\n[AUDIT 3] P2P Self-Purchase Prevention...")
trader_player = te.create_new_player(77003, "TraderOperator", "Viper")
trader_player["money"] = 500000
mock_db["users"][str(trader_player["user_id"])] = trader_player
mock_db["p2p_market"] = [{
    "lot_id": "lot_self_buy",
    "seller_id": trader_player["user_id"],
    "seller_name": "TraderOperator",
    "price": 50000,
    "item": te.ITEMS_BY_ID["ak74m_common"]
}]

mock_bot.answers.clear()
call_buy_self = DummyCall(trader_player["user_id"], "buy_p2p_lot_self_buy")
tb.handle_buy_p2p_lot(call_buy_self, trader_player, mock_db, "lot_self_buy")
assert any("Вы не можете купить собственный лот" in str(a) for a in mock_bot.answers), "Self-purchase was not blocked!"
assert len(mock_db["p2p_market"]) == 1, "Lot was removed on illegal self purchase!"
print("✅ P2P Self-Purchase Prevention: PASSED")

# AUDIT 4: Darkzone Ghost Squads and Complete Loser Wiping
print("\n[AUDIT 4] Darkzone Ghost Squad & Full Squad Wiping...")
pvp_creator = te.create_new_player(77004, "PvpCreator", "Viper")
pvp_joiner = te.create_new_player(77005, "PvpJoiner", "Grizzly")
mock_db["users"][str(pvp_creator["user_id"])] = pvp_creator
mock_db["users"][str(pvp_joiner["user_id"])] = pvp_joiner
mock_db["active_duels"] = {}

pvp_creator["money"] = 200000
pvp_joiner["money"] = 200000

call_pvp_cr = DummyCall(pvp_creator["user_id"], "darkzone_create_pvp")
tb.handle_darkzone_create_pvp(call_pvp_cr, pvp_creator, mock_db)
duel_id = list(mock_db["active_duels"].keys())[0]

# Simulate creator squad dying in a raid while duel is pending
pvp_creator["squad"] = []

mock_bot.answers.clear()
call_pvp_acc = DummyCall(pvp_joiner["user_id"], f"accept_pvp_{duel_id}")
tb.handle_darkzone_accept_pvp(call_pvp_acc, pvp_joiner, mock_db, duel_id)
assert any("больше нет бойцов" in str(a) for a in mock_bot.answers), "Ghost squad duel was not rejected!"
assert pvp_creator["money"] == 200000, "Creator escrow was not refunded on ghost squad duel!"
assert len(mock_db["active_duels"]) == 0, "Duel was not cancelled!"
print("✅ Darkzone Ghost Squad Edge Case: PASSED (Handled ghost squad safely with full refund)")

# Test real duel: verify loser squad is completely wiped
pvp_creator["squad"] = [{"id": 1, "type": "scav", "name": "Дикий", "weapon_uid": None, "armor_uid": None, "helmet_uid": None, "headset_uid": None}]
pvp_joiner["squad"] = [{"id": 1, "type": "pmc", "name": "ЧВК", "weapon_uid": None, "armor_uid": None, "helmet_uid": None, "headset_uid": None}]
tb.handle_darkzone_create_pvp(call_pvp_cr, pvp_creator, mock_db)
duel_id2 = list(mock_db["active_duels"].keys())[0]

tb.handle_darkzone_accept_pvp(call_pvp_acc, pvp_joiner, mock_db, duel_id2)
loser = pvp_creator if len(pvp_creator["squad"]) == 0 else pvp_joiner
winner = pvp_joiner if loser == pvp_creator else pvp_creator
assert len(loser["squad"]) == 0, f"Loser squad was not wiped! Found {len(loser['squad'])} fighters"
print(f"✅ Darkzone Loser Wiping: PASSED (Loser @{loser['username']} squad was completely wiped to 0)")

# AUDIT 5: Coop Ghost Squad & Defeat Mechanics
print("\n[AUDIT 5] Coop Lobby Ghost Squad & Defeat Mechanics...")
coop_leader = te.create_new_player(77006, "CoopLeader", "Viper")
coop_leader["squad"] = []
mock_db["users"][str(coop_leader["user_id"])] = coop_leader
mock_db["coop_lobbies"] = {
    "lobby_ghost": {
        "id": "lobby_ghost",
        "leader_id": coop_leader["user_id"],
        "leader_name": "CoopLeader",
        "diff_key": "easy",
        "members": [{"user_id": coop_leader["user_id"], "username": "CoopLeader", "pmc_signature": "Viper", "power": 50, "armor": 20}],
        "status": "waiting"
    }
}
mock_bot.answers.clear()
call_coop_start = DummyCall(coop_leader["user_id"], "start_coop_lobby_ghost")
cs.handle_start_coop_lobby(call_coop_start, coop_leader, mock_db, "lobby_ghost", mock_bot)
assert mock_db["coop_lobbies"].get("lobby_ghost") is None, "Lobby was not completed/cleared"
assert mock_bot.last_edited_text and "ИТОГИ КООПЕРАТИВНОГО РЕЙДА" in mock_bot.last_edited_text, "Raid debriefing was not rendered"
print("✅ Coop Raid Launch with Signature PMC: PASSED (Raid launched successfully without empty squad block)")

# AUDIT 6: Airdrop Concurrency & Single Claim
print("\n[AUDIT 6] Airdrop Single Claim Concurrency Safety...")
mock_db["airdrop"] = {"active": True, "last_spawn": int(time.time())}
air_user1 = te.create_new_player(77007, "FastLooter", "Viper")
air_user2 = te.create_new_player(77008, "SlowLooter", "Viper")
mock_db["users"][str(air_user1["user_id"])] = air_user1
mock_db["users"][str(air_user2["user_id"])] = air_user2

call_air1 = DummyCall(air_user1["user_id"], "loot_airdrop_box")
call_air2 = DummyCall(air_user2["user_id"], "loot_airdrop_box")

tb.handle_loot_airdrop_box(call_air1, air_user1, mock_db)
assert mock_db["airdrop"]["active"] == False, "Airdrop did not deactivate"
assert air_user1["money"] > 50000, "Looter 1 did not get rubles"

mock_bot.answers.clear()
tb.handle_loot_airdrop_box(call_air2, air_user2, mock_db)
assert any("уже забран другим" in str(a) for a in mock_bot.answers), "Looter 2 was not blocked from claimed airdrop!"
print("✅ Airdrop Claim Concurrency Safety: PASSED")

# AUDIT 7: Mining & Economic Math Sanity
print("\n[AUDIT 7] Mining & Hourly Income Calculations...")
miner = te.create_new_player(77009, "MinerOperator", "Viper")
miner["hideout_lvl"] = 3
miner["modules"] = {"mining_farm": 3, "generator": 2}
btc_hourly = te.get_mining_hourly_btc(miner)
assert btc_hourly > 0, f"Mining rate must be > 0, got {btc_hourly}"
btc_hourly_lvl = te.get_mining_hourly_btc(3, user=miner)
assert btc_hourly_lvl == btc_hourly, f"Mismatch: {btc_hourly_lvl} vs {btc_hourly}"
rub_hourly = te.get_business_hourly_income("moonshine_still", 2, user=miner)
assert rub_hourly > 0, f"Business income must be > 0, got {rub_hourly}"
print(f"✅ Economic Income Math: PASSED (Hourly BTC: {btc_hourly}, Moonshine: {rub_hourly} ₽/h)")

print("\n==================================================")
print("     🎉 ALL 7 AUDIT CHECKS PASSED FLAWLESSLY!     ")
print("==================================================")
