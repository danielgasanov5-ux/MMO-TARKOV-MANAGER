import os
import sys
import time

sys.path.append(os.path.join(os.path.dirname(__file__), "backend"))

from tarkov_engine import (
    create_new_player, BASE_GUARD_CONTRACTS, get_guard_status,
    evaluate_base_security, buy_guard_contract, recover_base_assault,
    recover_base_fence, save_db, load_db
)
from loot_generator import (
    BOSS_AMBUSH_DEFINITIONS, roll_boss_ambush, simulate_boss_combat, simulate_boss_retreat
)

def run_tests():
    print("==================================================")
    print("   RUNNING HARDCORE MECHANICS TEST SUITE          ")
    print("==================================================")

    now = int(time.time())

    # 1. Base Guard Contracts
    print("[TEST 1] Base Guard Contracts Purchase & Status...")
    p = create_new_player(99901, "GuardTester", "usec")
    p["money"] = 500000

    # Initially expired or no guard
    p["guard_until"] = 0
    status = get_guard_status(p)
    assert status["active"] is False
    assert "без охраны" in status["title"].lower()

    # Buy Watchman (3h, 15k)
    ok, msg = buy_guard_contract(p, "scav_watchman")
    assert ok is True
    assert p["money"] == 485000
    assert p["guard_until"] >= now + 3 * 3600 - 5
    status = get_guard_status(p)
    assert status["active"] is True
    assert "Охрана активна" in status["title"]

    # Buy PMC Patrol (stacks / extends +8h, 75k)
    prev_until = p["guard_until"]
    ok, msg = buy_guard_contract(p, "pmc_patrol")
    assert ok is True
    assert p["money"] == 410000
    assert p["guard_until"] >= prev_until + 8 * 3600 - 5

    # Buy without money fails
    p["money"] = 100
    ok, msg = buy_guard_contract(p, "elite_pmc")
    assert ok is False
    print("✅ Base Guard Contracts: PASSED")

    # 2. Base Security Check & Phased Degradation
    print("[TEST 2] Base Security Incidents & Rogue Capture...")
    p = create_new_player(99902, "SecurityTester", "bear")
    p["money"] = 1000000
    p["warehouses"] = {"gear": 2, "weapon": 2, "ammo": 2, "valuable": 2}
    p["businesses"] = {"moonshine": 1, "bitfarm": 1, "intel": 1, "workshop": 1}

    # Case A: Protected - no incidents
    p["guard_until"] = now + 3600
    incidents = evaluate_base_security(p)
    assert len(incidents) == 0
    assert p["is_base_captured"] is False

    # Case B: Expired 5 hours ago (Phase 1 & 2: Warehouse Theft & Safe Robbery)
    p["guard_until"] = now - 5 * 3600
    p["last_security_check"] = now - 5 * 3600
    incidents = evaluate_base_security(p)
    assert len(incidents) > 0
    assert any("Фаза" in inc for inc in incidents)
    assert p["is_base_captured"] is False

    # Case C: Expired 25 hours ago (Phase 3: Base Captured by Rogues)
    p["guard_until"] = now - 25 * 3600
    p["last_security_check"] = now - 25 * 3600
    incidents = evaluate_base_security(p)
    assert p["is_base_captured"] is True
    assert p["businesses_blocked"] is True
    assert len(p.get("stolen_stash", [])) > 0 or p.get("stolen_money", 0) > 0
    print("✅ Base Security Phased Incidents: PASSED")

    # 3. Base Recovery: Assault
    print("[TEST 3] Base Recovery: Assault Operation...")
    p["squad"] = [
        {"id": 1, "name": "Боец 1", "type": "pmc", "power": 80, "armor": 50},
        {"id": 2, "name": "Боец 2", "type": "scav", "power": 40, "armor": 20},
    ]
    ok, res = recover_base_assault(p)
    assert "win_chance_pct" in res
    # If assault succeeded:
    if ok:
        assert p["is_base_captured"] is False
        assert p["businesses_blocked"] is False
        assert p["guard_until"] > now
        assert "recovered_items_count" in res
    else:
        # Base still captured
        assert p["is_base_captured"] is True
    print(f"✅ Base Recovery Assault: PASSED (Outcome: {'Victory' if ok else 'Defeat'})")

    # 4. Base Recovery: Fence Buyout
    print("[TEST 4] Base Recovery: Fence Buyout...")
    p["is_base_captured"] = True
    p["businesses_blocked"] = True
    p["money"] = 2000000
    p["btc"] = 1.5

    ok, msg = recover_base_fence(p)
    assert ok is True
    assert p["is_base_captured"] is False
    assert p["businesses_blocked"] is False
    assert p["btc"] == 0.5
    # 40% of 2,000,000 is 800,000, but min 1,000,000 so deducted 1,000,000
    assert p["money"] == 1000000

    # Try again when not captured
    ok, msg = recover_base_fence(p)
    assert ok is False
    print("✅ Base Recovery Fence Buyout: PASSED")

    # 5. Boss Ambush Mechanics
    print("[TEST 5] Boss Ambush Trigger & Definitions...")
    for loc_k in ["customs", "factory", "woods", "interchange", "reserve", "labs"]:
        assert loc_k in BOSS_AMBUSH_DEFINITIONS
        boss = BOSS_AMBUSH_DEFINITIONS[loc_k]
        assert "boss_name" in boss
        assert "relic_id" in boss

    # Force roll_boss_ambush check
    loc_ambush = roll_boss_ambush("customs", force=True)
    assert loc_ambush is not None
    assert "Решала" in loc_ambush["boss_name"]

    loc_no_ambush = roll_boss_ambush("customs", force=False)
    # Even if probabilistic, can check invalid location
    assert roll_boss_ambush("invalid_loc", force=True) is None
    print("✅ Boss Ambush Trigger: PASSED")

    # 6. Boss Combat Simulation
    print("[TEST 6] Boss Combat Simulation...")
    p = create_new_player(99903, "CombatTester", "usec")
    ambush = BOSS_AMBUSH_DEFINITIONS["customs"]

    res = simulate_boss_combat("customs", ambush, p, 100, 100)
    assert "boss_diff" in res
    assert "win_chance_pct" in res
    assert res["boss_diff"] > 0
    if res["success"]:
        assert len(res["items"]) >= 2
        assert res["rubles"] >= 150000
    else:
        assert res["success"] is False
        assert "boss_info" in res
    print("✅ Boss Combat Simulation: PASSED")

    # 7. Boss Retreat Simulation
    print("[TEST 7] Boss Retreat Simulation...")
    p = create_new_player(99904, "RetreatTester", "bear")
    ambush = BOSS_AMBUSH_DEFINITIONS["factory"]
    res = simulate_boss_retreat("factory", ambush, p)
    assert res["retreat_type"] in ["safe", "rearguard_hit"]
    if res["retreat_type"] == "safe":
        assert "dropped_name" in res
    else:
        assert "injured_fighter_name" in res
    print("✅ Boss Retreat Simulation: PASSED")

    print("==================================================")
    print("   🎉 ALL HARDCORE MECHANICS TESTS PASSED!        ")
    print("==================================================")

if __name__ == "__main__":
    run_tests()
