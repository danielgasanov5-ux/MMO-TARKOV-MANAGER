# -*- coding: utf-8 -*-
import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))
sys.path.insert(0, os.path.dirname(__file__))

from tarkov_engine import (
    create_new_player, SPECIAL_BUSINESSES, get_special_businesses_income,
    add_player_rubles
)
import bot

print("=" * 60)
print("   TEST SUITE: 2 NEW SPECIAL BUSINESS OBJECTS & MECHANICS")
print("=" * 60)

# [TEST 1] Configuration Check
print("\n[TEST 1] Checking SPECIAL_BUSINESSES configuration...")
assert "smugglers_fleet" in SPECIAL_BUSINESSES, "smugglers_fleet must be in SPECIAL_BUSINESSES"
assert "fence_protection" in SPECIAL_BUSINESSES, "fence_protection must be in SPECIAL_BUSINESSES"

fleet = SPECIAL_BUSINESSES["smugglers_fleet"]
fence = SPECIAL_BUSINESSES["fence_protection"]

assert fleet["cost"] == 200_000_000, f"Expected 200M cost for fleet, got {fleet['cost']}"
assert fleet["hourly_income"] == 1_500_000, f"Expected 1.5M/hr for fleet, got {fleet['hourly_income']}"

assert fence["cost"] == 500_000_000, f"Expected 500M cost for fence, got {fence['cost']}"
assert fence["hourly_income"] == 3_500_000, f"Expected 3.5M/hr for fence, got {fence['hourly_income']}"
print("  ✓ Config verification: PASSED!")

# [TEST 2] Buying Special Businesses
print("\n[TEST 2] Testing Business Purchase Logic...")
dummy_db = {"users": {}, "p2p_market": []}
player = create_new_player(998877, "Oligarch", "Viper")
dummy_db["users"]["998877"] = player

# Class mock for Telegram call
class MockCall:
    def __init__(self, user_id):
        self.id = "mock_call_1"
        self.from_user = type("User", (), {"id": user_id, "username": "Oligarch"})()
        self.message = type("Msg", (), {"chat": type("Chat", (), {"id": user_id})(), "message_id": 100})()

# Try buying with 0 money
player["money"] = 100_000_000
bot.handle_buy_special_business(MockCall(998877), player, dummy_db, "smugglers_fleet")
assert not player["special_businesses"].get("smugglers_fleet"), "Should not buy fleet without 200M"
print("  ✓ Insufficient funds check: PASSED!")

# Give enough money and buy fleet
player["money"] = 250_000_000
bot.handle_buy_special_business(MockCall(998877), player, dummy_db, "smugglers_fleet")
assert player["special_businesses"].get("smugglers_fleet") is True, "Fleet should be active"
assert player["money"] == 50_000_000, f"Expected 50M remaining, got {player['money']}"
print("  ✓ Buy Автопарк «Контрабандисты Резерва»: PASSED!")

# Buy fence protection
player["money"] = 600_000_000
bot.handle_buy_special_business(MockCall(998877), player, dummy_db, "fence_protection")
assert player["special_businesses"].get("fence_protection") is True, "Fence protection should be active"
assert player["money"] == 100_000_000, f"Expected 100M remaining, got {player['money']}"
print("  ✓ Buy Доля в бизнесе Скупщика («Крышевание Барахолки»): PASSED!")

# [TEST 3] Passive Income Verification
print("\n[TEST 3] Testing Passive Income Calculation & Claim...")
# Base with both businesses: 1.5M + 3.5M = 5.0M / hr
inc, items = get_special_businesses_income(player)
assert inc >= 5_000_000, f"Expected at least 5M/hr, got {inc}"
print(f"  ✓ Total Special Passive Income: {inc:,} ₽/hr verified!")

# Test claim income
now = int(time.time())
player["last_income_claim"] = now - 3600  # 1 hour accrued
prev_money = player["money"]
bot.handle_claim_income(MockCall(998877), player, dummy_db)
diff = player["money"] - prev_money
assert diff >= 5_000_000, f"Expected at least +5M claimed after 1 hour, got {diff}"
print(f"  ✓ Claimed Income: +{diff:,} ₽ verified!")

# [TEST 4] Contraband Cargo Speed Buff (3x faster)
print("\n[TEST 4] Testing Contraband Cargo 3x Speedup Mechanic...")
# Test order tier 1 (normal: 60s, with 3x: 20s)
player["active_delivery"] = None
player["money"] = 1_000_000
t1_order_call = MockCall(998877)
bot.handle_order_supply(t1_order_call, player, dummy_db, 1)
assert player["active_delivery"] is not None, "Delivery should be active"
del_dur = player["active_delivery"]["finish_time"] - player["active_delivery"]["start_time"]
# Normal 60s // 3 = 20s (or with supply_speed Viper buff 20 * 0.8 = 16s)
assert del_dur <= 20, f"Expected <= 20s delivery duration, got {del_dur}s"
print(f"  ✓ Tier 1 delivery time: {del_dur}s (successfully accelerated 3x)!")

# Test Tier 3 (normal: 360s, with 3x: 120s)
player["active_delivery"] = None
bot.handle_order_supply(t1_order_call, player, dummy_db, 3)
del_dur3 = player["active_delivery"]["finish_time"] - player["active_delivery"]["start_time"]
assert del_dur3 <= 120, f"Expected <= 120s delivery duration, got {del_dur3}s"
print(f"  ✓ Tier 3 delivery time: {del_dur3}s (successfully accelerated 3x)!")

# [TEST 5] 0% Flea Market (P2P) Tax
print("\n[TEST 5] Testing 0% Flea Market P2P Commission Rate...")
tax_rate = bot.get_p2p_tax_rate(player)
assert tax_rate == 0.0, f"Expected 0.0 tax rate for Fence partner, got {tax_rate}"

# Test buyer buying player's lot: seller should receive 100% full payout without tax
buyer = create_new_player(111222, "Buyer", "Bear")
dummy_db["users"]["111222"] = buyer
buyer["money"] = 10_000_000

lot_price = 1_000_000
dummy_db["p2p_market"] = [{
    "lot_id": "test_lot_100",
    "seller_id": player["user_id"],
    "seller_name": player["username"],
    "price": lot_price,
    "item": {"id": "ak74m_common", "name": "AK-74M", "rarity": "common"}
}]

player_prev = player["money"]
buy_call = MockCall(111222)
bot.handle_buy_p2p_lot(buy_call, buyer, dummy_db, "test_lot_100")
received = player["money"] - player_prev
assert received == lot_price, f"Seller should receive 100% ({lot_price}), received {received}"
print(f"  ✓ 0% Tax seller payout: Received exact {received:,} ₽ (100% without deductions)!")

# [TEST 6] Simulated NPC Auto-Buyout Every 3 Hours
print("\n[TEST 6] Testing Simulated NPC Auto-Buyout Every 3 Hours...")
# Put a new lot on market
dummy_db["p2p_market"] = [{
    "lot_id": "test_lot_200",
    "seller_id": player["user_id"],
    "seller_name": player["username"],
    "price": 2_500_000,
    "item": {"id": "m4a1_rare", "name": "M4A1 Assault Rifle", "rarity": "rare"}
}]

# Check when cooldown hasn't passed (e.g. 1 hour ago)
player["last_npc_p2p_buyout"] = now - 3600
res = bot.check_npc_p2p_auto_buyout(player, dummy_db)
assert res is None, "Should not auto-buy before 3 hours have passed"
assert len(dummy_db["p2p_market"]) == 1, "Lot should still be on market"
print("  ✓ Cooldown check (< 3 hours): PASSED (no buyout yet)")

# Now simulate that 3.5 hours passed
player["last_npc_p2p_buyout"] = now - (3 * 3600 + 1800)
prev_money = player["money"]
notif = bot.check_npc_p2p_auto_buyout(player, dummy_db)

assert notif is not None, "Auto-buyout should have triggered!"
assert len(dummy_db["p2p_market"]) == 0, "Lot should be removed by NPC buyout"
payout = player["money"] - prev_money
assert payout == 2_500_000, f"Expected +2,500,000 ₽ payout, got {payout}"
assert len(player.get("notifications", [])) > 0, "Notification must be appended"
print(f"  ✓ Auto-buyout triggered: Lot purchased for full {payout:,} ₽ by wealthy NPC!")
print(f"  ✓ Notification generated: {player['notifications'][-1][:50]}...")

print("\n" + "=" * 60)
print("   ALL TESTS FOR 2 SPECIAL BUSINESSES PASSED PERFECTLY! 🚀")
print("=" * 60)
