import sys
import os
sys.path.insert(0, os.path.abspath('backend'))

from tarkov_engine import ITEMS_LIST, ITEMS_BY_ID, create_new_player, generate_scav_gear
from loot_generator import (
    generate_airdrop_loot, generate_container_loot, roll_strict_tarkov_loot,
    roll_supply_item
)
from coop_system import simulate_coop_raid
from relics_system import ALL_30_RELICS, RELICS_BY_ID

def test_catalog():
    print(f"Total items in clean ITEMS_LIST: {len(ITEMS_LIST)}")
    assert len(ITEMS_LIST) >= 700, f"Expected >= 700 items, got {len(ITEMS_LIST)}"
    
    # Ensure zero relics in ITEMS_LIST
    for itm in ITEMS_LIST:
        assert itm.get("category") != "relic", f"Found relic in ITEMS_LIST: {itm['id']}"
        assert not itm.get("is_relic"), f"Found relic flag in ITEMS_LIST: {itm['id']}"
        assert itm["id"] not in RELICS_BY_ID, f"Boss relic found in ITEMS_LIST: {itm['id']}"
    print("✓ Catalog clean of relics!")

def test_scav_gear():
    items, uids = generate_scav_gear(1)
    assert len(items) == 4, f"Expected 4 scav items, got {len(items)}"
    for itm in items:
        info = ITEMS_BY_ID[itm["item_id"]]
        assert info.get("rarity") == "common", f"Scav item not common: {info}"
    print("✓ Scav starter gear is strictly Common items!")

def test_container_2500k():
    player = create_new_player(12345, "TestUser", "USEC")
    relic_count = 0
    sims = 10000
    for _ in range(sims):
        res = generate_container_loot("terragroup_case_2500k", player)
        if res.get("relic_won"):
            relic_count += 1
            # Verify relic is in RELICS_BY_ID
            assert res["relic_won"]["id"] in RELICS_BY_ID
        # Verify no relics in standard items list
        for itm in res["items"]:
            if itm != res.get("relic_won"):
                assert itm.get("category") != "relic"
    rate = relic_count / sims
    print(f"2.5M Case: {relic_count}/{sims} relics won ({rate*100:.2f}%) - Expected ~1.0%")
    assert 0.005 <= rate <= 0.018, f"Unexpected drop rate: {rate}"
    print("✓ 2.5M Case relic balance passed!")

def test_airdrop():
    relic_count = 0
    sims = 5000
    for _ in range(sims):
        loot = generate_airdrop_loot()
        assert len(loot["items"]) in [5, 6, 7], f"Expected 5, 6 or 7 items, got {len(loot['items'])}"
        has_relic = any(i.get("category") == "relic" or i["id"] in RELICS_BY_ID for i in loot["items"])
        if has_relic:
            relic_count += 1
            # Check only 1 relic max
            relics_in_box = [i for i in loot["items"] if i.get("category") == "relic" or i["id"] in RELICS_BY_ID]
            assert len(relics_in_box) == 1, f"Expected 1 relic max, got {len(relics_in_box)}"
            assert relics_in_box[0]["id"] in RELICS_BY_ID
        for itm in loot["items"]:
            if itm.get("category") != "relic":
                assert itm.get("rarity") in ["rare", "epic", "legendary"], f"Common found in airdrop: {itm}"
    rate = relic_count / sims
    print(f"Airdrop: {relic_count}/{sims} relics won ({rate*100:.2f}%) - Expected ~10.0%")
    assert 0.08 <= rate <= 0.12, f"Unexpected drop rate: {rate}"
    print("✓ Airdrop balance passed!")

def test_coop_raids():
    party = [{"user_id": 1, "username": "p1"}, {"user_id": 2, "username": "p2"}]
    
    # Colossal: 10%
    colossal_relics = 0
    sims = 4000
    for _ in range(sims):
        res = simulate_coop_raid("colossal", party, force_success=True)
        if res.get("relic_dropped"):
            colossal_relics += 1
            assert res["relic_dropped"]["id"] in RELICS_BY_ID
    c_rate = colossal_relics / sims
    print(f"Coop Colossal: {colossal_relics}/{sims} ({c_rate*100:.2f}%) - Expected ~10.0%")
    assert 0.08 <= c_rate <= 0.12

    # Ultra: 4%
    ultra_relics = 0
    for _ in range(sims):
        res = simulate_coop_raid("ultra", party, force_success=True)
        if res.get("relic_dropped"):
            ultra_relics += 1
    u_rate = ultra_relics / sims
    print(f"Coop Ultra: {ultra_relics}/{sims} ({u_rate*100:.2f}%) - Expected ~4.0%")
    assert 0.025 <= u_rate <= 0.055

    # Hard: 1%
    hard_relics = 0
    for _ in range(sims):
        res = simulate_coop_raid("hard", party, force_success=True)
        if res.get("relic_dropped"):
            hard_relics += 1
    h_rate = hard_relics / sims
    print(f"Coop Hard: {hard_relics}/{sims} ({h_rate*100:.2f}%) - Expected ~1.0%")
    assert 0.004 <= h_rate <= 0.020

    # Normal & Easy: 0%
    for diff in ["normal", "easy"]:
        for _ in range(500):
            res = simulate_coop_raid(diff, party, force_success=True)
            assert not res.get("relic_dropped"), f"Relic dropped on {diff}!"
    print("✓ Coop raids balance passed!")

def test_prapor_market():
    common_items = [i for i in ITEMS_LIST if i.get("rarity") == "common"]
    rare_items = [i for i in ITEMS_LIST if i.get("rarity") == "rare"]
    epic_items = [i for i in ITEMS_LIST if i.get("rarity") == "epic"]
    legendary_items = [i for i in ITEMS_LIST if i.get("rarity") == "legendary"]

    print(f"Prapor pool: {len(common_items)} Common + {len(rare_items)} Rare items = {len(common_items) + len(rare_items)} available to buy.")
    assert len(common_items) > 200, f"Expected >200 common items, got {len(common_items)}"
    assert len(rare_items) > 200, f"Expected >200 rare items, got {len(rare_items)}"

    # Check eligibility rule: itm.get('rarity') in ['common', 'rare'] and itm.get('category') != 'relic'
    for itm in common_items + rare_items:
        is_sold = itm.get("rarity") in ["common", "rare"] and itm.get("category") != "relic"
        assert is_sold, f"Item {itm['name']} should be sold by Prapor!"
    
    for itm in epic_items + legendary_items:
        is_sold = itm.get("rarity") in ["common", "rare"] and itm.get("category") != "relic"
        assert not is_sold, f"High tier item {itm['name']} should NOT be sold by Prapor!"
    print("✓ Prapor sells 100% of Common and Rare items from 720 catalog!")

def test_admin_security():
    from tarkov_engine import is_admin
    assert is_admin(1001, "reventus"), "reventus must be admin!"
    assert is_admin(1001, "@reventus"), "@reventus must be admin!"
    assert is_admin(1001, "Reventus"), "Case insensitive Reventus must be admin!"
    assert is_admin(1001, "revenuts"), "revenuts fallback must be admin!"
    assert not is_admin(1001, "some_player"), "Normal player must NOT be admin!"
    assert not is_admin(1001, None), "Empty user must NOT be admin!"
    print("✓ Admin rights strictly locked to @reventus!")

def test_solo_raids_balance():
    from loot_generator import simulate_raid, RAID_LOCATIONS
    player = create_new_player(999, "Tester", "Viper")
    
    factory_rarities = {"legendary": 0, "epic": 0, "rare": 0, "common": 0}
    labs_rarities = {"legendary": 0, "epic": 0, "rare": 0, "common": 0}
    sims = 1000

    for _ in range(sims):
        # Factory with high squad power => 95% win
        res_f = simulate_raid("factory", player, 200, 150)
        if res_f["success"]:
            for itm in res_f["items"]:
                assert itm.get("category") != "relic"
                assert itm["id"] not in RELICS_BY_ID
                factory_rarities[itm.get("rarity", "common")] += 1

        # Labs
        res_l = simulate_raid("labs", player, 300, 250)
        if res_l["success"]:
            for itm in res_l["items"]:
                assert itm.get("category") != "relic"
                assert itm["id"] not in RELICS_BY_ID
                labs_rarities[itm.get("rarity", "common")] += 1

    total_f = sum(factory_rarities.values())
    total_l = sum(labs_rarities.values())
    print(f"Factory loot ({total_f} items): Common {factory_rarities['common']/total_f*100:.1f}%, Rare {factory_rarities['rare']/total_f*100:.1f}%, Epic {factory_rarities['epic']/total_f*100:.1f}%, Leg {factory_rarities['legendary']/total_f*100:.2f}%")
    print(f"Labs loot ({total_l} items): Common {labs_rarities['common']/total_l*100:.1f}%, Rare {labs_rarities['rare']/total_l*100:.1f}%, Epic {labs_rarities['epic']/total_l*100:.1f}%, Leg {labs_rarities['legendary']/total_l*100:.2f}%")

    # Labs must have substantially higher Epic & Legendary proportion than Factory
    assert (labs_rarities["epic"] + labs_rarities["legendary"]) / total_l > (factory_rarities["epic"] + factory_rarities["legendary"]) / total_f
    print("✓ Solo raids loot scaling and isolation passed!")

if __name__ == "__main__":
    test_catalog()
    test_scav_gear()
    test_container_2500k()
    test_airdrop()
    test_coop_raids()
    test_prapor_market()
    test_admin_security()
    test_solo_raids_balance()
    print("\nALL BALANCE TESTS PASSED SUCCESSFULLY!")
