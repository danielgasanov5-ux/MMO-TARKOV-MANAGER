# -*- coding: utf-8 -*-
"""
Signature PMC Solo SpecOps Raid System for Escape from Tarkov MMO Telegram Bot.

Mechanics:
- Only available after reaching MAX profile level (Level 10).
- Cooldown: Strictly once every 6 hours (21,600 seconds).
- 100% Invincibility (Бессмертие): Guaranteed survival, zero injuries, zero gear loss.
- 3x Rewards (3х денег и 3х лута):
  * 3x cash rubles (typically 2,400,000 to 4,800,000 ₽)
  * 3x elite loot items (weapons, armor, valuables, keycards, relics)
  * 350 EXP
"""

import time
import random
from telebot import types
from tarkov_engine import (
    fmt_rub, get_player_level, add_player_rubles, add_player_exp,
    can_store_item, save_db, PMC_DEFINITIONS, ITEMS_BY_ID
)
from relics_system import ALL_30_RELICS

SIGNATURE_RAID_COOLDOWN_SEC = 6 * 3600  # 6 hours
SIGNATURE_RAID_REQUIRED_LEVEL = 10     # Max profile level

def get_elite_loot_pool():
    """Returns all verified Epic and Legendary weapons, armor, gear and valuables from items_data."""
    pool = [
        k for k, v in ITEMS_BY_ID.items()
        if (v.get("rarity") in ("legendary", "epic") or v.get("category") == "valuables")
        and not k.startswith("boss_")
    ]
    return pool if pool else list(ITEMS_BY_ID.keys())

def can_launch_signature_raid(player):
    """
    Returns (can_launch: bool, reason: str, remaining_sec: int)
    """
    p_lvl = get_player_level(player)
    if p_lvl < SIGNATURE_RAID_REQUIRED_LEVEL:
        return False, f"Требуется максимальный уровень профиля (10 уровень). Ваш уровень: {p_lvl}/10.", 0

    now = int(time.time())
    cooldown_until = player.get("signature_raid_cooldown_until", 0)
    if cooldown_until > now:
        rem = cooldown_until - now
        return False, "Снаряжение ЧВК перезаряжается после прошлой спецоперации.", rem

    return True, "Готов к выходу в рейд!", 0

def handle_menu_signature_raid(chat_id, msg_id, player, bot):
    """Displays the Signature PMC Raid briefing view."""
    pmc_key = player.get("pmc_signature", "Viper")
    p_info = PMC_DEFINITIONS.get(pmc_key, {})
    p_lvl = get_player_level(player)
    can_launch, reason, rem = can_launch_signature_raid(player)

    txt = (
        f"⭐ <b>СПЕЦОПЕРАЦИЯ СИГНАТУРНОГО ЧВК</b>\n"
        f"────────────────────────\n"
        f"Личный оператор: {p_info.get('icon', '🎖️')} <b>{pmc_key}</b>\n"
        f"Уровень профиля: <b>{p_lvl}/10</b> {'(МАКСИМАЛЬНЫЙ ✅)' if p_lvl >= 10 else '(Недостаточен ❌)'}\n"
        f"────────────────────────\n"
        f"<b>Элитные условия операции:</b>\n"
        f"• 🛡️ <b>Полное бессмертие:</b> Ваш сигнатурный ЧВК неуязвим! 100% выживаемость, отсутствие ранений и риска гибели.\n"
        f"• 💰 <b>3х Деньги:</b> Тройной куш чистыми рублями со спец-схронов TerraGroup.\n"
        f"• 🎁 <b>3х Лут:</b> Тройное количество элитного вооружения, брони 6 класса, драгоценностей и реликвий.\n"
        f"• ⏱️ <b>Ограничение:</b> Ровно 1 вылазка раз в 6 часов (только для ветеранов 10 уровня).\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)

    if p_lvl < SIGNATURE_RAID_REQUIRED_LEVEL:
        txt += (
            f"🔒 <b>ДОСТУП ЗАБЛОКИРОВАН:</b>\n"
            f"Спецоперация открывается строго на <b>10 уровне профиля</b>!\n"
            f"Прокачивайте убежище, повышайте боевой опыт в обычных и кооперативных рейдах."
        )
        markup.add(types.InlineKeyboardButton("🔙 К Меню Рейдов", callback_data="menu_raids"))
    elif not can_launch:
        hours = rem // 3600
        minutes = (rem % 3600) // 60
        txt += (
            f"⏳ <b>ПЕРЕЗАРЯДКА ОПЕРАТИВНИКА:</b>\n"
            f"Оператор пополняет боекомплект и проводит техобслуживание снаряжения.\n"
            f"Следующая спецоперация будет доступна через: <b>{hours} ч. {minutes} мин.</b>"
        )
        markup.add(types.InlineKeyboardButton("🔄 Обновить статус", callback_data="menu_signature_raid"))
        markup.add(types.InlineKeyboardButton("🔙 К Меню Рейдов", callback_data="menu_raids"))
    else:
        txt += "⚡ <b>Оперативник готов к немедленной зачистке секретного сектора!</b>"
        markup.add(
            types.InlineKeyboardButton(
                f"🚀 ОТПРАВИТЬ {pmc_key.upper()} (3x ЛУТ | БЕССМЕРТИЕ)",
                callback_data="start_signature_raid"
            )
        )
        markup.add(types.InlineKeyboardButton("🔙 К Меню Рейдов", callback_data="menu_raids"))

    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_start_signature_raid(call, player, db, bot):
    """Executes the invincible 3x loot Signature PMC Raid."""
    can_launch, reason, rem = can_launch_signature_raid(player)
    if not can_launch:
        bot.answer_callback_query(call.id, f"❌ {reason}", show_alert=True)
        return

    now = int(time.time())
    pmc_key = player.get("pmc_signature", "Viper")
    p_info = PMC_DEFINITIONS.get(pmc_key, {})

    # Set 6-hour cooldown
    player["signature_raid_cooldown_until"] = now + SIGNATURE_RAID_COOLDOWN_SEC

    # 3x Cash Reward: Base 900k-1.5M * 3 = 2.7M - 4.5M rubles!
    base_money = random.randint(900000, 1500000)
    total_rubles = base_money * 3
    add_player_rubles(player, total_rubles)
    add_player_exp(player, 350)

    # 3x Loot items: 6 to 9 items from elite loot pool + chance of boss relic
    item_count = random.randint(6, 9)
    pool = get_elite_loot_pool()
    chosen_item_ids = random.sample(pool, min(item_count, len(pool)))

    relic_dropped = None
    if ALL_30_RELICS and random.random() < 0.40:
        relic_dropped = random.choice(ALL_30_RELICS)

    stored_items = []
    overflow_count = 0

    for iid in chosen_item_ids:
        info = ITEMS_BY_ID.get(iid)
        if not info:
            continue
        if can_store_item(player, iid):
            u_obj = {
                "uid": f"sig_{now}_{random.randint(1000, 9999)}",
                "item_id": iid,
                "equipped_to": None
            }
            player.setdefault("stash", []).append(u_obj)
            stored_items.append(info.get("name", iid))
        else:
            overflow_count += 1

    if relic_dropped:
        if can_store_item(player, relic_dropped["id"]):
            player.setdefault("stash", []).append({
                "uid": f"sig_relic_{now}_{random.randint(1000, 9999)}",
                "item_id": relic_dropped["id"],
                "equipped_to": None
            })
            stored_items.append(f"🏆 {relic_dropped['name']}")
        else:
            overflow_count += 1

    # Update stats
    st = player.setdefault("stats", {})
    st["signature_raids_count"] = st.get("signature_raids_count", 0) + 1
    st["raids_count"] = st.get("raids_count", 0) + 1

    save_db(db)

    bot.answer_callback_query(call.id, "🎖️ Спецоперация успешно завершена!")

    items_list_str = "\n".join([f"  • {name}" for name in stored_items[:6]])
    if len(stored_items) > 6:
        items_list_str += f"\n  • ...и еще {len(stored_items) - 6} элитных предметов"

    overflow_note = f"\n⚠️ <i>{overflow_count} предметов не поместились на переполненных складах.</i>" if overflow_count > 0 else ""

    txt = (
        f"⭐ <b>ТРИУМФ СПЕЦОПЕРАЦИИ СИГНАТУРНОГО ЧВК!</b> ⭐\n"
        f"────────────────────────\n"
        f"Оператор: {p_info.get('icon', '🎖️')} <b>{pmc_key}</b> — 🛡️ <b>БЕЗУПРЕЧНАЯ ЗАЧИСТКА</b>\n"
        f"Благодаря <b>бессмертию</b> и элитному статусу операция завершилась со 100% успехом без единой царапины!\n\n"
        f"💰 <b>ТРОЙНОЙ КУШ (3x ДЕНЬГИ):</b>\n"
        f"+<b>{fmt_rub(total_rubles)}</b> (База: {fmt_rub(base_money)} × 3)\n"
        f"🎖️ Опыт: +<b>350 EXP</b>\n\n"
        f"🎁 <b>ТРОЙНОЙ ЭЛИТНЫЙ ЛУТ (3x ТРОФЕИ):</b>\n"
        f"{items_list_str}{overflow_note}\n\n"
        f"────────────────────────\n"
        f"⏱️ <i>Следующая спецоперация будет доступна ровно через 6 часов.</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1).add(
        types.InlineKeyboardButton("🔙 К Меню Рейдов", callback_data="menu_raids"),
        types.InlineKeyboardButton("📦 Открыть Схрон", callback_data="menu_stash")
    )

    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)
