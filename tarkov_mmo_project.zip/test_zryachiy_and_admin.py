# -*- coding: utf-8 -*-
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

import tarkov_engine
import mythic_system
import bot

def test_mythics_list():
    print("--- [TEST 1] Testing Mythic Items Registry & 150M List ---")
    assert len(mythic_system.MYTHIC_ITEMS) == 3, f"Expected 3 mythics, got {len(mythic_system.MYTHIC_ITEMS)}"
    for mid in ["mythic_black_division_case", "mythic_goons_token", "mythic_dsp_sensor"]:
        assert mid in mythic_system.MYTHIC_ITEMS, f"{mid} missing from MYTHIC_ITEMS"
        data = mythic_system.MYTHIC_ITEMS[mid]
        assert data["price"] == 150000000, f"Price should be 150M, got {data['price']}"
        print(f"  ✓ {data['badge']} {data['name']} (150,000,000 ₽) verified")

def test_zryachiy_gear_and_supply():
    print("\n--- [TEST 2] Testing Zryachiy Gear & 24h Supply Delivery ---")
    assert len(mythic_system.ZRYACHIY_GEAR) == 3, f"Expected 3 Zryachiy items, got {len(mythic_system.ZRYACHIY_GEAR)}"
    for itm in mythic_system.ZRYACHIY_GEAR:
        assert itm["id"] in tarkov_engine.ITEMS_BY_ID, f"{itm['id']} not registered in ITEMS_BY_ID"
        print(f"  ✓ {itm['name']} (ID: {itm['id']}, Урон: {itm.get('combat', 0)}, Броня: {itm.get('armor', 0)})")

    player = {"user_id": 7777, "username": "test_pmc", "stash": [], "mythic_items": []}
    mythic_system.add_mythic_item_to_player(player, "mythic_dsp_sensor")
    assert "mythic_dsp_sensor" in player["mythic_items"]
    assert any(s["item_id"] == "mythic_dsp_sensor" for s in player["stash"])

    delivered = mythic_system.claim_zryachiy_gear_supply(player)
    assert len(delivered) == 3, "Should deliver 3 items"
    assert len(player["stash"]) == 4, f"Stash should have 1 DSP + 3 items = 4, got {len(player['stash'])}"
    print("  ✓ Zryachiy 3-item daily delivery verified!")

def test_admin_commands_and_aliases():
    print("\n--- [TEST 3] Testing Admin Item Resolution & Aliases ---")
    aliases = {
        "dsp": "mythic_dsp_sensor",
        "sensor": "mythic_dsp_sensor",
        "зрячий": "mythic_dsp_sensor",
        "датчик": "mythic_dsp_sensor",
        "mythic_dsp": "mythic_dsp_sensor",
        "axmc": "zryachiy_axmc_338",
        "vest": "zryachiy_cultist_vest",
        "hood": "zryachiy_hood_mask",
        "case": "mythic_black_division_case",
        "goons": "mythic_goons_token",
        "token": "mythic_goons_token"
    }
    for alias, expected in aliases.items():
        res = bot.resolve_item_alias(alias)
        assert res == expected, f"Alias '{alias}' resolved to {res}, expected {expected}"
        print(f"  ✓ Alias '{alias}' -> '{res}' verified")

    print("\n--- [TEST 4] Testing Admin Permission Check ---")
    assert tarkov_engine.is_admin(9999, "revenuts") == True
    assert tarkov_engine.is_admin(1111, "reventus") == True
    assert tarkov_engine.is_admin(2222, "danielgasanov5_ux") == True
    assert tarkov_engine.is_admin(3333, "vozhakzxc") == True
    assert tarkov_engine.is_admin(4444, "admin") == True
    print("  ✓ Admin roles verified for owner accounts and usernames!")

if __name__ == "__main__":
    test_mythics_list()
    test_zryachiy_gear_and_supply()
    test_admin_commands_and_aliases()
    print("\n🎉 ALL ZRYACHIY AND ADMIN TESTS PASSED PERFECTLY!")
