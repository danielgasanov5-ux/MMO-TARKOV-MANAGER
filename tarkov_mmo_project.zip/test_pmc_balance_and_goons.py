# -*- coding: utf-8 -*-
"""
Verification test for:
1. PMC solo raid balance vs Scav solo raid balance.
2. The Goons (Отступники) drop pool and mechanics with the Goons token.
"""
import time
from loot_generator import calculate_raid_win_chance, RAID_LOCATIONS
from tarkov_engine import create_new_player, calculate_squad_power, ITEMS_BY_ID
from mythic_system import (
    GOONS_GEAR,
    GOONS_GEAR_BY_ID,
    MYTHIC_ITEMS,
    has_mythic_item,
    add_mythic_item_to_player,
    can_claim_goons_supply,
    claim_goons_gear_supply,
    can_launch_goons_raid,
    execute_goons_raid,
)

def test_pmc_vs_scav_balance():
    print("--- [TEST 1] Testing PMC vs Scav Balance Across Maps ---")
    
    # 1. Scav Squad (2 Scavs)
    scav_player = create_new_player(101, "ScavSquad", "BEAR")
    scav_player["squad"] = [
        {"id": 1, "type": "scav", "name": "Дикий 1", "weapon_uid": None, "armor_uid": None, "helmet_uid": None, "headset_uid": None},
        {"id": 2, "type": "scav", "name": "Дикий 2", "weapon_uid": None, "armor_uid": None, "helmet_uid": None, "headset_uid": None}
    ]
    scav_pow, scav_arm = calculate_squad_power(scav_player)
    
    for loc_key in ["factory", "customs", "woods", "reserve", "labs"]:
        chance = calculate_raid_win_chance(loc_key, scav_player, scav_pow, scav_arm)
        print(f"Scav Squad on {loc_key.capitalize()}: {chance*100:.1f}%")
        assert chance <= 0.45, f"Scav chance too high on {loc_key}: {chance}"
        if loc_key == "labs":
            assert chance <= 0.10, f"Scav chance too high on Labs: {chance}"

    # 2. Naked PMC Squad (2 PMCs, no gear)
    naked_pmc_player = create_new_player(102, "NakedPMC", "USEC")
    naked_pmc_player["squad"] = [
        {"id": 1, "type": "pmc", "name": "ЧВК 1", "weapon_uid": None, "armor_uid": None, "helmet_uid": None, "headset_uid": None},
        {"id": 2, "type": "pmc", "name": "ЧВК 2", "weapon_uid": None, "armor_uid": None, "helmet_uid": None, "headset_uid": None}
    ]
    npmc_pow, npmc_arm = calculate_squad_power(naked_pmc_player)
    f_chance = calculate_raid_win_chance("factory", naked_pmc_player, npmc_pow, npmc_arm)
    l_chance = calculate_raid_win_chance("labs", naked_pmc_player, npmc_pow, npmc_arm)
    print(f"Naked PMC on Factory: {f_chance*100:.1f}% | Labs: {l_chance*100:.1f}%")
    # Naked PMC should NOT have 95%! Must be between 35% and 50% on factory, and <15% on labs
    assert 0.30 <= f_chance <= 0.50, f"Naked PMC Factory balance failed: {f_chance}"
    assert l_chance <= 0.15, f"Naked PMC Labs balance failed: {l_chance}"

    # 3. Mid-geared PMC Squad (Power ~ 130, Armor ~ 100)
    mid_f = calculate_raid_win_chance("factory", naked_pmc_player, 130, 100)
    mid_l = calculate_raid_win_chance("labs", naked_pmc_player, 130, 100)
    print(f"Mid-geared PMC on Factory: {mid_f*100:.1f}% | Labs: {mid_l*100:.1f}%")
    assert 0.58 <= mid_f <= 0.75, f"Mid PMC Factory failed: {mid_f}"
    assert 0.18 <= mid_l <= 0.35, f"Mid PMC Labs failed: {mid_l}"

    # 4. Top-tier PMC Squad (Power ~ 250, Armor ~ 250)
    top_f = calculate_raid_win_chance("factory", naked_pmc_player, 250, 250)
    top_l = calculate_raid_win_chance("labs", naked_pmc_player, 250, 250)
    print(f"Top-tier PMC on Factory: {top_f*100:.1f}% | Labs: {top_l*100:.1f}%")
    assert top_f >= 0.72, f"Top PMC Factory failed: {top_f}"
    assert top_l >= 0.35, f"Top PMC Labs failed: {top_l}"

    print("✓ PMC raid balance re-calibrated smoothly! Scav balance strictly preserved!")

def test_goons_token_and_drop_pool():
    print("\n--- [TEST 2] Testing The Goons Token & Drop Pool ---")
    player = create_new_player(201, "GoonsMaster", "USEC")
    
    # Check player does not have token initially
    assert not has_mythic_item(player, "mythic_goons_token")
    can_claim, _ = can_claim_goons_supply(player)
    assert not can_claim
    can_raid, _ = can_launch_goons_raid(player)
    assert not can_raid
    
    # Grant token
    add_mythic_item_to_player(player, "mythic_goons_token")
    assert has_mythic_item(player, "mythic_goons_token")
    
    # Verify pool of Goons items
    print(f"Total Goons signature items in pool: {len(GOONS_GEAR)}")
    assert len(GOONS_GEAR) == 9, f"Expected 9 Goons items, got {len(GOONS_GEAR)}"
    
    expected_ids = {
        "goons_knight_skull_mask",
        "goons_knight_avs_rig",
        "goons_knight_scar_h",
        "goons_bigpipe_m32a1",
        "goons_bigpipe_bandana",
        "goons_bigpipe_rec10",
        "goons_birdeye_dvl10",
        "goons_birdeye_comtac",
        "goons_birdeye_rsass"
    }
    actual_ids = {item["id"] for item in GOONS_GEAR}
    assert expected_ids == actual_ids, f"Mismatch in Goons item IDs: {actual_ids}"
    
    for item in GOONS_GEAR:
        print(f"  - {item['name']}: Combat +{item.get('combat', 0)}, Armor +{item.get('armor', 0)}, Price {item['price']:,} ₽")
        assert item["rarity"] == "mythic"
        assert item["price"] >= 20000000

    # Claim supply drop
    can_claim, _ = can_claim_goons_supply(player)
    assert can_claim
    dropped = claim_goons_gear_supply(player)
    print(f"Claimed 24h Goons Supply: {dropped['name']}")
    assert dropped["id"] in expected_ids
    
    # Cooldown check
    can_claim_again, rem = can_claim_goons_supply(player)
    assert not can_claim_again
    assert rem > 86000

    # Execute Goons 24h Raid
    can_raid, _ = can_launch_goons_raid(player)
    assert can_raid
    raid_res = execute_goons_raid(player)
    print(f"Goons Raid Results:")
    print(f"  - Rubles: {raid_res['rubles']:,} ₽")
    print(f"  - Bitcoin won: {raid_res['btc_won']} BTC")
    print(f"  - EXP: {raid_res['exp']}")
    print(f"  - Elite trophies: {[t['name'] for t in raid_res['trophies']]}")
    assert 7000000 <= raid_res["rubles"] <= 15000000
    assert len(raid_res["trophies"]) in [3, 4]
    
    print("✓ The Goons token and drop pool mechanics tested 100% successfully!")

if __name__ == "__main__":
    test_pmc_vs_scav_balance()
    test_goons_token_and_drop_pool()
    print("\n🎉 ALL TESTS PASSED!")
