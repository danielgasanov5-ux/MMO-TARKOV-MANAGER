# -*- coding: utf-8 -*-
"""
Clothes System for MMO Tarkov Manager
Shop "Шота у Ашота" & Wardrobe Management
Categories: Обувь, Головной убор, Костюм, Аксессуар (50 items each, 200 total)
Rules:
- Can only be bought in "Шота у Ашота" shop (cannot be looted/dropped in raids)
- Cannot be sold to Prapor or on P2P market
- Can be equipped, unequipped, or discarded (thrown away)
- Strict validation: CANNOT discard currently equipped items
"""

import os
import json
import time
import random

_DIR = os.path.dirname(os.path.abspath(__file__))
POSSIBLE_CLOTHES_DATA_FILES = [
    os.path.join(_DIR, "clothes_data.json"),
    os.path.join(os.getcwd(), "clothes_data.json"),
    os.path.join(os.getcwd(), "backend", "clothes_data.json"),
    "clothes_data.json",
    "backend/clothes_data.json",
    "/tmp/bot/backend/clothes_data.json",
    "/tmp/bot/clothes_data.json",
]

_RAW = {}
for _p in POSSIBLE_CLOTHES_DATA_FILES:
    if os.path.exists(_p):
        try:
            with open(_p, "r", encoding="utf-8") as _f:
                _RAW = json.load(_f)
            if _RAW.get("items"):
                break
        except Exception:
            pass

CLOTHES_CATEGORIES = _RAW.get("categories", {
    "shoes": {"name": "Обувь", "icon": "🥾"},
    "headwear": {"name": "Головной убор", "icon": "🧢"},
    "suit": {"name": "Костюм", "icon": "🥋"},
    "accessory": {"name": "Аксессуар", "icon": "⌚"}
})

CLOTHES_BY_ID = _RAW.get("items", {})
CLOTHES_BY_CATEGORY = {k: [] for k in CLOTHES_CATEGORIES}

for itm in CLOTHES_BY_ID.values():
    slot = itm.get("slot")
    if slot in CLOTHES_BY_CATEGORY:
        CLOTHES_BY_CATEGORY[slot].append(itm)

# Ensure sorted by price then index
for k in CLOTHES_BY_CATEGORY:
    CLOTHES_BY_CATEGORY[k].sort(key=lambda x: (x.get("price", 0), x.get("index", 0)))


def _fmt_money(val):
    return f"{int(val):,}".replace(",", " ") + " ₽"


def get_player_clothes_stash(player):
    return player.setdefault("clothes_stash", [])


def get_player_equipped_clothes(player):
    equipped = player.setdefault("equipped_clothes", {})
    for k in CLOTHES_CATEGORIES:
        equipped.setdefault(k, None)
    return equipped


def get_equipped_item_in_slot(player, slot):
    equipped = get_player_equipped_clothes(player)
    uid = equipped.get(slot)
    if not uid:
        return None, None
    stash = get_player_clothes_stash(player)
    for entry in stash:
        if entry.get("uid") == uid:
            item_info = CLOTHES_BY_ID.get(entry.get("item_id"))
            if item_info:
                return item_info, uid
            break
    # In case item was somehow removed or not found, clean slot
    equipped[slot] = None
    return None, None


def player_owns_clothing(player, item_id):
    stash = get_player_clothes_stash(player)
    return any(entry.get("item_id") == item_id for entry in stash)


def buy_clothing_item(player, item_id):
    item_info = CLOTHES_BY_ID.get(item_id)
    if not item_info:
        return False, "❌ Товар не найден в каталоге «Шота у Ашота»!", None
    price = item_info.get("price", 0)
    current_money = player.get("money", 0)
    if current_money < price:
        return False, f"❌ Недостаточно рублей! Цена: {_fmt_money(price)}, у вас: {_fmt_money(current_money)}", None
    if player_owns_clothing(player, item_id):
        return False, f"⚠️ У вас уже есть «{item_info['name']}» в гардеробе!", None

    player["money"] -= price
    uid = f"cloth_{int(time.time())}_{random.randint(1000, 9999)}"
    entry = {
        "uid": uid,
        "item_id": item_id,
        "slot": item_info["slot"],
        "name": item_info["name"],
        "price": price,
        "bought_at": int(time.time())
    }
    get_player_clothes_stash(player).append(entry)
    return True, f"✅ Вы успешно приобрели «{item_info['name']}» за {_fmt_money(price)}!", uid


def equip_clothing_item(player, uid):
    stash = get_player_clothes_stash(player)
    target_entry = None
    for entry in stash:
        if entry.get("uid") == uid:
            target_entry = entry
            break
    if not target_entry:
        return False, "❌ Предмет не найден в вашем гардеробе!"
    slot = target_entry.get("slot")
    if slot not in CLOTHES_CATEGORIES:
        return False, "❌ Недопустимый слот экипировки!"
    equipped = get_player_equipped_clothes(player)
    equipped[slot] = uid
    item_info = CLOTHES_BY_ID.get(target_entry.get("item_id"), {})
    name = item_info.get("name", target_entry.get("name", "Одежда"))
    return True, f"🎽 Вы надели «{name}»!"


def unequip_clothing_item(player, slot):
    if slot not in CLOTHES_CATEGORIES:
        return False, "❌ Недопустимый слот!"
    equipped = get_player_equipped_clothes(player)
    current_uid = equipped.get(slot)
    if not current_uid:
        return False, "⚠️ В этом слоте ничего не экипировано!"
    equipped[slot] = None
    cat_name = CLOTHES_CATEGORIES[slot]["name"]
    return True, f"❎ Слот «{cat_name}» освобожден (предмет снят)."


def discard_clothing_item(player, uid):
    stash = get_player_clothes_stash(player)
    target_idx = None
    target_entry = None
    for idx, entry in enumerate(stash):
        if entry.get("uid") == uid:
            target_idx = idx
            target_entry = entry
            break
    if target_entry is None:
        return False, "❌ Предмет не найден в гардеробе!"
    slot = target_entry.get("slot")
    equipped = get_player_equipped_clothes(player)
    # CRITICAL SECURITY CHECK: Cannot discard equipped items
    if equipped.get(slot) == uid:
        return False, "❌ Нельзя выбросить экипированный предмет! Сначала снимите его."
    stash.pop(target_idx)
    item_info = CLOTHES_BY_ID.get(target_entry.get("item_id"), {})
    name = item_info.get("name", target_entry.get("name", "Одежда"))
    return True, f"🗑️ Предмет «{name}» выброшен из гардероба!"


def is_clothing_item(item_id):
    return item_id in CLOTHES_BY_ID


def is_clothing_uid(player, uid):
    stash = get_player_clothes_stash(player)
    return any(e.get("uid") == uid for e in stash)
