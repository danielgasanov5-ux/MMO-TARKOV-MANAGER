# -*- coding: utf-8 -*-
"""
Boss Summon System (1% chance on Scav hire) for Escape from Tarkov MMO Telegram Bot.

Summons one of 3 unique bosses:
1. Сектанты (Cultists) — «Ночной ритуал и Скрытный токсин»
2. Партизан (Partisan) — «Растяжки и снайперские мины»
3. Коллонтай (Kollontay) — «Милицейский спецназ и подавление»

Mechanics:
- 1% chance upon clicking 'Нанять Дикого' in the squad menu.
- Interactive choice:
  1. Recruit to squad (if slot available) with unique passive buff and boss gear.
  2. Fight the summoned boss with squad for jackpot rubles (1.5M - 3.5M ₽), exclusive weapons/armor, and trophies.
  3. Dismiss safely.
"""

import time
import random
from telebot import types
from tarkov_engine import (
    fmt_rub, calculate_squad_power, add_player_rubles, add_player_exp,
    can_store_item, has_boss_set_bonus, save_db, ITEMS_BY_ID
)

SUMMONED_BOSSES = {
    "cultists": {
        "id": "cultists",
        "name": "Жрец Сектантов",
        "title": "🗡️ ЖРЕЦ СЕКТАНТОВ И АДЕПТЫ ТЬМЫ",
        "icon": "🗡️",
        "badge": "🕯️",
        "difficulty": 180,
        "base_power": 45,
        "base_armor": 25,
        "desc": (
            "Из ночного тумана бесшумно выступили Сектанты во главе с верховным Жрецом! "
            "В руках Жреца блестит ритуальный клинок, смазанный смертоносным токсином."
        ),
        "perk_name": "Ночной ядовитый ритуал",
        "perk_desc": "+15% к скрытности и выживаемости отряда во всех рейдах, полный иммунитет к ночным засадам.",
        "gear": [
            {
                "id": "cultist_poison_blade_legendary",
                "name": "🗡️ Ритуальный ядовитый нож Жреца Сектантов",
                "category": "weapons",
                "subcategory": "knife",
                "rarity": "legendary",
                "price": 8500000,
                "combat": 40,
                "armor": 10,
                "desc": "Легендарный церемониальный клинок сектантов с выемкой под быстродействующий паралитический токсин."
            },
            {
                "id": "cultist_hood_rare",
                "name": "🕯️ Ритуальный балахон Сектанта",
                "category": "armor",
                "subcategory": "body_armor",
                "rarity": "rare",
                "price": 3200000,
                "combat": 15,
                "armor": 30,
                "desc": "Скрывающий силуэт плотный балахон со скрытыми композитными пластинами."
            }
        ],
        "reward_rubles": (1800000, 3200000),
        "reward_item": {
            "id": "cultist_poison_blade_legendary",
            "name": "🗡️ Ритуальный ядовитый нож Жреца Сектантов",
            "category": "weapons",
            "subcategory": "knife",
            "rarity": "legendary",
            "price": 8500000,
            "combat": 40,
            "armor": 10,
            "desc": "Легендарный церемониальный клинок сектантов с выемкой под быстродействующий паралитический токсин."
        }
    },
    "partisan": {
        "id": "partisan",
        "name": "Партизан",
        "title": "🌲 ПАРТИЗАН — ОХОТНИК НОРВИНСКИХ ЛЕСОВ",
        "icon": "🌲",
        "badge": "🎯",
        "difficulty": 200,
        "base_power": 55,
        "base_armor": 30,
        "desc": (
            "Из лесной чащи бесшумно появился Партизан — суровый охотник, карающий мародеров и кемперов. "
            "На его разгрузке закреплены растяжки с гранатами и снайперские мины."
        ),
        "perk_name": "Растяжки и лесные ловушки",
        "perk_desc": "+25 к огневой мощи отряда, +30% к добыче рублей в рейдах и автоматическая защита базы от рейдеров.",
        "gear": [
            {
                "id": "partisan_svd_legendary",
                "name": "🎯 Снайперский карабин Партизана 7.62x54R",
                "category": "weapons",
                "subcategory": "sniper_rifle",
                "rarity": "legendary",
                "price": 9500000,
                "combat": 50,
                "armor": 5,
                "desc": "Модифицированная винтовка Партизана с глушителем и метками зачищенных мародеров."
            },
            {
                "id": "partisan_rig_rare",
                "name": "🌲 Тактическая разгрузка Партизана с минами",
                "category": "gear",
                "subcategory": "rig",
                "rarity": "rare",
                "price": 4000000,
                "combat": 20,
                "armor": 25,
                "desc": "Специальная разгрузка с отсеками под сигнальные мины и растяжки."
            }
        ],
        "reward_rubles": (2000000, 3500000),
        "reward_item": {
            "id": "partisan_svd_legendary",
            "name": "🎯 Снайперский карабин Партизана 7.62x54R",
            "category": "weapons",
            "subcategory": "sniper_rifle",
            "rarity": "legendary",
            "price": 9500000,
            "combat": 50,
            "armor": 5,
            "desc": "Модифицированная винтовка Партизана с глушителем и метками зачищенных мародеров."
        }
    },
    "kollontay": {
        "id": "kollontay",
        "name": "Коллонтай",
        "title": "🛡️ КОЛЛОНТАЙ — БЫВШИЙ НАЧАЛЬНИК ОВД",
        "icon": "🛡️",
        "badge": "⚡",
        "difficulty": 220,
        "base_power": 45,
        "base_armor": 60,
        "desc": (
            "Тяжелым чеканным шагом перед вами предстал Коллонтай — бывший начальник милиции. "
            "В руках у него тяжелая милицейская дубинка, а корпус защищен штурмовым бронежилетом высшего класса."
        ),
        "perk_name": "Милицейский спецназ и подавление",
        "perk_desc": "+40 к броне отряда, подавляет вражеских Диких (сдаются без боя, +15% шанс победы в рейдах).",
        "gear": [
            {
                "id": "kollontay_baton_legendary",
                "name": "⚡ Усиленная милицейская дубинка Коллонтая",
                "category": "weapons",
                "subcategory": "melee",
                "rarity": "legendary",
                "price": 7500000,
                "combat": 30,
                "armor": 20,
                "desc": "Титановая спец-дубинка с шоковым сердечником, внушающая страх уличным бандам."
            },
            {
                "id": "kollontay_armor_6b43_legendary",
                "name": "🛡️ Штурмовой бронежилет 6Б43 Коллонтая (6 класс)",
                "category": "armor",
                "subcategory": "body_armor",
                "rarity": "legendary",
                "price": 11000000,
                "combat": 15,
                "armor": 55,
                "desc": "Тяжелейший общевойсковой бронежилет с керамическими плитами высшего класса защиты."
            }
        ],
        "reward_rubles": (2200000, 3800000),
        "reward_item": {
            "id": "kollontay_armor_6b43_legendary",
            "name": "🛡️ Штурмовой бронежилет 6Б43 Коллонтая (6 класс)",
            "category": "armor",
            "subcategory": "body_armor",
            "rarity": "legendary",
            "price": 11000000,
            "combat": 15,
            "armor": 55,
            "desc": "Тяжелейший общевойсковой бронежилет с керамическими плитами высшего класса защиты."
        }
    }
}

# Register boss items in ITEMS_BY_ID so inventory, power, and stash work seamlessly
for b_key, b_info in SUMMONED_BOSSES.items():
    for g in b_info["gear"]:
        if g["id"] not in ITEMS_BY_ID:
            ITEMS_BY_ID[g["id"]] = g

def is_boss_summon_triggered(player, force=False):
    """
    1% chance (0.01) upon clicking hire scav.
    Supports force=True or player['_force_boss_summon'] for testing/audits.
    """
    if force or player.get("_force_boss_summon"):
        player.pop("_force_boss_summon", None)
        return True
    return random.random() < 0.01

def get_random_summoned_boss():
    """Picks one of Cultists, Partisan, Kollontay."""
    boss_key = random.choice(["cultists", "partisan", "kollontay"])
    return SUMMONED_BOSSES[boss_key]

def render_boss_summon_screen(chat_id, msg_id, player, boss_data, bot):
    """Renders the special boss summon encounter screen."""
    squad = player.get("squad", [])
    max_squad = 6 if has_boss_set_bonus(player, "glukhar") else 5
    can_recruit = len(squad) < max_squad

    txt = (
        f"⚡⚡ <b>СВЕРХРЕДКИЙ ВЫЗОВ БОССА ТАРКОВА! (ШАНС 1%)</b> ⚡⚡\n"
        f"────────────────────────\n"
        f"{boss_data['icon']} <b>{boss_data['title']}</b>\n\n"
        f"{boss_data['desc']}\n\n"
        f"✨ <b>Уникальная механика босса:</b>\n"
        f"<b>«{boss_data['perk_name']}»</b>\n"
        f"<i>{boss_data['perk_desc']}</i>\n"
        f"────────────────────────\n"
        f"🪖 <b>Мест в отряде:</b> {len(squad)}/{max_squad}\n\n"
        f"<b>Что вы предпримете?</b>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if can_recruit:
        markup.add(
            types.InlineKeyboardButton(
                f"🤝 Завербовать в отряд ({boss_data['name']})",
                callback_data=f"recruit_summoned_boss_{boss_data['id']}"
            )
        )
    else:
        markup.add(
            types.InlineKeyboardButton(
                "⚠️ Отряд полон (макс. бойцов) — вербовка недоступна",
                callback_data="none"
            )
        )

    markup.add(
        types.InlineKeyboardButton(
            f"⚔️ Атаковать босса (Трофеи и до {fmt_rub(boss_data['reward_rubles'][1])})",
            callback_data=f"fight_summoned_boss_{boss_data['id']}"
        )
    )
    markup.add(
        types.InlineKeyboardButton("🏃 Отпустить с миром (Назад)", callback_data="dismiss_summoned_boss")
    )

    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_recruit_summoned_boss(call, player, db, boss_key, bot):
    """Recruits the summoned boss into the player's squad."""
    boss_data = SUMMONED_BOSSES.get(boss_key)
    if not boss_data:
        bot.answer_callback_query(call.id, "❌ Босс не найден!")
        return

    squad = player.setdefault("squad", [])
    max_squad = 6 if has_boss_set_bonus(player, "glukhar") else 5
    if len(squad) >= max_squad:
        bot.answer_callback_query(call.id, f"❌ Отряд уже полон (макс. {max_squad} бойцов)!", show_alert=True)
        return

    now = int(time.time())
    new_id = max([f["id"] for f in squad] + [0]) + 1

    # Generate boss equipment into stash
    stash = player.setdefault("stash", [])
    w_uid = f"boss_{boss_key}_w_{now}_{random.randint(100, 999)}"
    a_uid = f"boss_{boss_key}_a_{now}_{random.randint(100, 999)}"

    # Weapon
    g_w = boss_data["gear"][0]
    stash.append({
        "uid": w_uid,
        "item_id": g_w["id"],
        "equipped_to": new_id,
        "is_boss_locked": True
    })

    # Armor
    g_a = boss_data["gear"][1]
    stash.append({
        "uid": a_uid,
        "item_id": g_a["id"],
        "equipped_to": new_id,
        "is_boss_locked": True
    })

    fighter = {
        "id": new_id,
        "type": "boss",
        "boss_key": boss_key,
        "name": f"{boss_data['icon']} {boss_data['name']}",
        "base_power": boss_data["base_power"],
        "base_armor": boss_data["base_armor"],
        "perk_name": boss_data["perk_name"],
        "perk_desc": boss_data["perk_desc"],
        "weapon_uid": w_uid,
        "armor_uid": a_uid,
        "helmet_uid": None,
        "headset_uid": None
    }
    squad.append(fighter)

    # Clean pending boss
    player.pop("pending_boss_summon", None)
    save_db(db)

    bot.answer_callback_query(call.id, f"🎉 {boss_data['name']} вступил в ваш отряд!", show_alert=True)

    txt = (
        f"👑 <b>ЛЕГЕНДАРНЫЙ БОСС ВСТУПИЛ В ВАШ ОТРЯД!</b>\n"
        f"────────────────────────\n"
        f"Боец: {boss_data['icon']} <b>{boss_data['name']}</b>\n"
        f"Роль: <b>Элитный Командир Отряда</b>\n\n"
        f"✨ <b>Активная механика:</b>\n"
        f"«{boss_data['perk_name']}»\n"
        f"<i>{boss_data['perk_desc']}</i>\n\n"
        f"🗡️ Стартовое вооружение: <b>{g_w['name']}</b>\n"
        f"🛡️ Стартовая броня: <b>{g_a['name']}</b>\n"
        f"────────────────────────\n"
        f"Босс не погибает в рейдах как обычный Дикий и приносит колоссальную пользу отряду!"
    )
    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🪖 Перейти в Меню Отряда", callback_data="menu_squad")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)

def handle_fight_summoned_boss(call, player, db, boss_key, bot):
    """Simulates squad combat against the summoned boss."""
    boss_data = SUMMONED_BOSSES.get(boss_key)
    if not boss_data:
        bot.answer_callback_query(call.id, "❌ Босс не найден!")
        return

    pow_val, arm_val = calculate_squad_power(player)
    boss_diff = boss_data["difficulty"]

    # Squad combat balance against summoned boss
    combat_score = (pow_val * 1.4) + (arm_val * 1.0)
    ratio = combat_score / max(1, boss_diff)
    win_chance = min(0.90, max(0.20, (ratio / (ratio + 0.85)) * 1.25))

    is_win = random.random() < win_chance
    now = int(time.time())

    player.pop("pending_boss_summon", None)

    if is_win:
        min_r, max_r = boss_data["reward_rubles"]
        won_rub = random.randint(min_r, max_r)
        add_player_rubles(player, won_rub)
        add_player_exp(player, 250)

        # Trophy item
        trophy = boss_data["reward_item"]
        stored_item = False
        if can_store_item(player, trophy["id"]):
            player.setdefault("stash", []).append({
                "uid": f"trophy_{now}_{random.randint(1000, 9999)}",
                "item_id": trophy["id"],
                "equipped_to": None
            })
            stored_item = True

        save_db(db)
        bot.answer_callback_query(call.id, "🏆 ПОБЕДА НАД БОССОМ!")

        txt = (
            f"🏆 <b>ТРИУМФ НАД БОССОМ ТАРКОВА!</b>\n"
            f"────────────────────────\n"
            f"Ваш отряд сошелся в яростном бою против: {boss_data['icon']} <b>{boss_data['title']}</b>!\n"
            f"Шанс победы отряда составлял: <b>{round(win_chance * 100, 1)}%</b>\n\n"
            f"<b>Ход сражения:</b>\n"
            f"Метким перекрестным огнем и слаженной тактикой ваш отряд подавил сопротивление босса!\n\n"
            f"🎁 <b>ВАШИ ТРОФЕИ:</b>\n"
            f"• 💰 Деньги: +<b>{fmt_rub(won_rub)}</b>\n"
            f"• 🎖️ Опыт: +<b>250 EXP</b>\n"
        )
        if stored_item:
            txt += f"• 🏆 Редчайший трофей: <b>{trophy['name']}</b> (добавлен в схрон!)\n"
        else:
            txt += f"• ⚠️ Трофей <b>{trophy['name']}</b> не поместился на складе оружия/снаряжения!\n"

        txt += "────────────────────────"
    else:
        # Squad suffered defeat
        add_player_exp(player, 50)
        # Wound signature operator / scav casualties
        for f in player.get("squad", []):
            if f.get("type") == "scav":
                f["wounded"] = True

        save_db(db)
        bot.answer_callback_query(call.id, "💀 Отряд отступил с потерями!", show_alert=True)

        txt = (
            f"💀 <b>ОТРЯД ПОТЕРПЕЛ ПОРАЖЕНИЕ!</b>\n"
            f"────────────────────────\n"
            f"Босс {boss_data['icon']} <b>{boss_data['name']}</b> оказался слишком опасен!\n"
            f"Применив механику <i>«{boss_data['perk_name']}»</i>, противник рассек боевые порядки отряда.\n\n"
            f"Бойцы были вынуждены экстренно эвакуироваться на базу.\n"
            f"Получено: +50 EXP за тактический опыт."
        )

    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🔙 Вернуться в Меню Отряда", callback_data="menu_squad")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)
