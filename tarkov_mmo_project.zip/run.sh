#!/usr/bin/env bash
set -e

echo "=== Запуск Python FastAPI Backend для Tarkov Mini App ==="

# Check virtual environment
if [ ! -d "venv" ]; then
    echo "Создание виртуального окружения python3 -m venv venv..."
    python3 -m venv venv || true
fi

# Activate virtualenv if present
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
fi

echo "Установка зависимостей из requirements.txt..."
pip install -r requirements.txt || true

echo "Запуск сервера FastAPI на порту 8000..."
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
