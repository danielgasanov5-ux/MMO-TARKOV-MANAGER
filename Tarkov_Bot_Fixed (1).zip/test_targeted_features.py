import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))

import tarkov_engine as te
import coop_system as cs
import bot as tb

class DummyCall:
    def __init__(self, uid, data):
        self.id = "mock_call_1"
        self.data = data
        self.message = type("msg", (), {"chat": type("c", (), {"id": 12345})(), "message_id": 99})()
        self.from_user = type("u", (), {"id": uid, "username": "revenuts", "first_name": "Test"})()

class DummyBot:
    def __init__(self):
        self.answers = []
        self.messages = []
        self.last_edited_text = ""
        self.last_markup = None
    def answer_callback_query(self, call_id, text=None, show_alert=False):
        self.answers.append((call_id, text, show_alert))
    def send_message(self, chat_id, text, reply_markup=None, *args, **kwargs):
        self.messages.append((chat_id, text))
    def send_photo(self, chat_id, photo, caption=None, reply_markup=None, *args, **kwargs):
        self.last_edited_text = caption or ""
        self.last_markup = reply_markup
        self.messages.append((chat_id, caption))
    def delete_message(self, chat_id, message_id, *args, **kwargs):
        pass
    def edit_message_text(self, text, chat_id, message_id, reply_markup=None, *args, **kwargs):
        self.last_edited_text = text
        self.last_markup = reply_markup
        self.messages.append((chat_id, text))

mock_bot = DummyBot()
tb.bot = mock_bot

print("=== STARTING TARGETED FEATURES TEST SUITE ===")

# Test 1: Admin verification for @revenuts
print("\n[TEST 1] Admin Verification for @revenuts...")
assert te.is_admin(12345, "revenuts") == True, "@revenuts must be recognized as admin"
assert te.is_admin(12345, "@revenuts") == True, "@@revenuts must be recognized as admin"
assert te.is_admin(12345, "REVENUTS") == True, "Uppercase REVENUTS must be recognized as admin"
print("✓ Admin ID @revenuts verified successfully!")

# Test 2: P2P Pagination in handle_p2p_market and handle_p2p_list_menu
print("\n[TEST 2] P2P Market and Stash Listing Pagination...")
test_player = te.create_new_player(888001, "revenuts", "Revenant")
test_db = {"p2p_market": [], "users": {str(test_player["user_id"]): test_player}}

# Populate 15 lots in P2P market
for i in range(15):
    test_db["p2p_market"].append({
        "lot_id": f"lot_test_{i}",
        "seller_id": 99999,
        "seller_name": f"Seller_{i}",
        "price": 10000 + i * 1000,
        "item": te.ITEMS_LIST[i]
    })

# Render page 1
tb.handle_p2p_market(12345, 99, test_player, test_db, page=1)
assert "Стр. 1/3" in mock_bot.last_edited_text
btn_texts = [b.text for row in mock_bot.last_markup.keyboard for b in row]
assert "Вперед ➡️" in btn_texts
assert "⬅️ Назад" not in btn_texts

# Render page 2
tb.handle_p2p_market(12345, 99, test_player, test_db, page=2)
assert "Стр. 2/3" in mock_bot.last_edited_text
btn_texts = [b.text for row in mock_bot.last_markup.keyboard for b in row]
assert "⬅️ Назад" in btn_texts
assert "Вперед ➡️" in btn_texts

# Populate player stash with 14 items for listing
test_player["stash"] = []
for i in range(14):
    test_player["stash"].append({
        "uid": f"item_uid_{i}",
        "item_id": te.ITEMS_LIST[i]["id"],
        "equipped_to": None
    })

# Render page 1 of listing menu
tb.handle_p2p_list_menu(12345, 99, test_player, test_db, page=1)
assert "Стр. 1/3" in mock_bot.last_edited_text
btn_texts = [b.text for row in mock_bot.last_markup.keyboard for b in row]
assert "Вперед ➡️" in btn_texts

# Render page 3 of listing menu
tb.handle_p2p_list_menu(12345, 99, test_player, test_db, page=3)
assert "Стр. 3/3" in mock_bot.last_edited_text
btn_texts = [b.text for row in mock_bot.last_markup.keyboard for b in row]
assert "⬅️ Назад" in btn_texts
assert "Вперед ➡️" not in btn_texts
print("✓ P2P Arrow Pagination verified for both Market Lots and Stash Listings!")

# Test 3: Stash "Sell all" rarity buttons and handle_prapor_sell_rarity
print("\n[TEST 3] Stash Sell All by Rarity...")
test_player["stash"] = [
    {"uid": "c1", "item_id": "bandage_common", "equipped_to": None},
    {"uid": "c2", "item_id": "splint_common", "equipped_to": None},
    {"uid": "r1", "item_id": "ammo_545_bt_rare", "equipped_to": None},
    {"uid": "e1", "item_id": "slick_armor_epic", "equipped_to": None},
    {"uid": "l1", "item_id": "keycard_black_legendary", "equipped_to": None},
    {"uid": "c_eq", "item_id": "gssh_01_common", "equipped_to": 1} # Equipped, must not be sold
]
init_money = test_player.get("money", 0)
init_earned = test_player.get("stats", {}).get("total_earned_rubles", 0)

call_sell = DummyCall(test_player["user_id"], "prapor_sell_rarity_common")
tb.handle_prapor_sell_rarity(call_sell, test_player, test_db, None, "common")

# Verify common items sold, equipped kept
rem_uids = [i["uid"] for i in test_player["stash"]]
assert "c1" not in rem_uids
assert "c2" not in rem_uids
assert "c_eq" in rem_uids # Equipped item preserved!
assert "r1" in rem_uids
assert test_player["money"] > init_money
assert test_player["stats"]["total_earned_rubles"] > init_earned
print("✓ Stash Sell All by Rarity correctly sold free items, preserved equipped gear, and credited total rubles!")

# Test 4: Stash Overflow Checks in handle_buy_p2p_lot and handle_cancel_p2p_lot
print("\n[TEST 4] Stash Overflow Protection in P2P...")
test_player["warehouses"]["weapons"] = 1
w_cap = te.get_warehouse_capacity(test_player, "weapons")
# Fill weapon warehouse to cap
test_player["stash"] = []
for i in range(w_cap):
    test_player["stash"].append({"uid": f"w_{i}", "item_id": "ak74m_common", "equipped_to": None})

# Try to buy another weapon from P2P
test_db["p2p_market"] = [{
    "lot_id": "lot_w_overflow",
    "seller_id": 777,
    "seller_name": "Seller",
    "price": 10000,
    "item": te.ITEMS_BY_ID["ak74m_common"]
}]
test_player["money"] = 50000
mock_bot.answers.clear()
call_buy = DummyCall(test_player["user_id"], "buy_p2p_lot_w_overflow")
tb.handle_buy_p2p_lot(call_buy, test_player, test_db, "lot_w_overflow")
assert any("склад переполнен" in str(a) for a in mock_bot.answers), "P2P buy did not block on warehouse overflow"
assert len(test_player["stash"]) == w_cap, f"Stash should still be {w_cap}"

# Try to cancel a weapon lot with full warehouse
test_db["p2p_market"].append({
    "lot_id": "lot_my_overflow",
    "seller_id": test_player["user_id"],
    "seller_name": "revenuts",
    "price": 10000,
    "item": te.ITEMS_BY_ID["ak74m_common"]
})
mock_bot.answers.clear()
call_cancel = DummyCall(test_player["user_id"], "cancel_p2p_lot_my_overflow")
tb.handle_cancel_p2p_lot(call_cancel, test_player, test_db, "lot_my_overflow")
assert any("склад переполнен" in str(a) for a in mock_bot.answers), "P2P cancel did not block on warehouse overflow"
print("✓ P2P Market correctly prevented stash overflow on both Buy and Cancel operations!")

# Test 5: Scav Death on Raid Failure in handle_start_solo_raid
print("\n[TEST 5] Scav Death on Raid Failure in Solo Raids...")
test_player["squad"] = [
    {"id": 1, "type": "pmc", "name": "Viper", "weapon_uid": "w1", "armor_uid": "a1", "helmet_uid": "h1", "headset_uid": "hs1"},
    {"id": 2, "type": "scav", "name": "Дикий #2", "weapon_uid": "w2", "armor_uid": "a2", "helmet_uid": "h2", "headset_uid": "hs2"}
]
test_player["stash"] = [
    {"uid": "w1", "item_id": "ak74m_common", "equipped_to": 1},
    {"uid": "a1", "item_id": "paca_common", "equipped_to": 1},
    {"uid": "h1", "item_id": "kolpak_common", "equipped_to": 1},
    {"uid": "hs1", "item_id": "gssh_01_common", "equipped_to": 1},
    {"uid": "w2", "item_id": "ak74m_common", "equipped_to": 2},
    {"uid": "a2", "item_id": "paca_common", "equipped_to": 2},
    {"uid": "h2", "item_id": "kolpak_common", "equipped_to": 2},
    {"uid": "hs2", "item_id": "gssh_01_common", "equipped_to": 2}
]

# Simulate a failure by mocking simulate_raid
orig_simulate_raid = tb.simulate_raid
tb.simulate_raid = lambda loc, player, p, a: {
    "location": "Таможня",
    "win_chance": 20,
    "success": False,
    "rubles": 0,
    "items": []
}

call_raid = DummyCall(test_player["user_id"], "start_solo_raid_customs")
tb.handle_start_solo_raid(call_raid, test_player, test_db, "customs")

# Restore simulate_raid
tb.simulate_raid = orig_simulate_raid

# Verify both PMC and Scav died and were removed from squad
assert len(test_player["squad"]) == 0, f"Expected 0 survivors (both PMC and Scav die), got {len(test_player['squad'])}"
assert len(test_player["stash"]) == 0, f"All equipped gear should be lost on death, got {len(test_player['stash'])}"
assert "Все бойцы отряда погибли" in mock_bot.last_edited_text
print("✓ Full squad death (PMC + Scav) and gear stripping on raid failure verified perfectly!")

# Test 6: Dynamic hiring cost
print("\n[TEST 6] Dynamic Hiring Cost based on Player Level and Hideout Module...")
p_temp = te.create_new_player(777111, "HiringTest", "Viper")
# Base cost at level 1
cost_lvl1 = tb.get_fighter_hire_cost(p_temp, "scav")
assert cost_lvl1 == 10000, f"Expected 10000, got {cost_lvl1}"

# Level up player
p_temp["level"] = 3
cost_lvl3 = tb.get_fighter_hire_cost(p_temp, "scav")
assert cost_lvl3 > cost_lvl1, f"Expected cost_lvl3 > cost_lvl1, got {cost_lvl3} vs {cost_lvl1}"

# Water collector module discount
p_temp["modules"]["water_collector"] = 5 # 10% discount
cost_discounted = tb.get_fighter_hire_cost(p_temp, "scav")
assert cost_discounted < cost_lvl3, f"Expected cost_discounted < cost_lvl3, got {cost_discounted} vs {cost_lvl3}"
print(f"✓ Dynamic hiring cost verified: Lvl 1={cost_lvl1} -> Lvl 3={cost_lvl3} -> With Water Module={cost_discounted}")

# Test 7: Profile level and total earned rubles display
print("\n[TEST 7] Profile Level and Total Earned Rubles Display...")
test_player["money"] = 50000
test_player["stats"]["total_earned_rubles"] = 1250000
tb.handle_menu_profile(12345, 99, test_player)
assert "1 250 000 ₽" in mock_bot.last_edited_text, "Profile must show total_earned_rubles (1 250 000), not current money"
assert "Уровень" in mock_bot.last_edited_text
assert "Всего заработано:" in mock_bot.last_edited_text
print("✓ Profile level and total earned rubles confirmed in profile menu!")

# Test 8: Empty squad raid lock
print("\n[TEST 8] Empty Squad Raid Lock (Solo, Coop, Darkzone)...")
test_player["squad"] = []
mock_bot.answers.clear()
call_empty_solo = DummyCall(test_player["user_id"], "start_solo_raid_customs")
tb.handle_start_solo_raid(call_empty_solo, test_player, test_db, "customs")
assert any("В вашем отряде нет бойцов" in str(a) for a in mock_bot.answers), "Solo raid did not block empty squad"

# Test 9: Prapor Market catalog filtering (only Common and Rare items)
print("\n[TEST 9] Prapor Market Catalog filtering...")
tb.handle_market_catalog(12345, 99, test_player, test_db, "Оружие", page=1)
# Ensure no epic or legendary items are displayed
assert "🟪" not in mock_bot.last_edited_text, "Found epic item in Prapor catalog!"
assert "🟨" not in mock_bot.last_edited_text, "Found legendary item in Prapor catalog!"
print("✓ Prapor market strictly contains Common and Rare items only!")

# Test 10: Solo Raid Button Chance consistency
print("\n[TEST 10] Solo Raid Button Chance consistency with loot generator...")
test_player["squad"] = [{"id": 1, "type": "pmc", "name": "Viper", "weapon_uid": None, "armor_uid": None, "helmet_uid": None, "headset_uid": None}]
tb.handle_menu_raids(12345, 99, test_player)
pow_val, arm_val = te.calculate_squad_power(test_player)
expected_win_pct = round(tb.calculate_raid_win_chance("customs", test_player, pow_val, arm_val) * 100, 1)
assert f"(~{expected_win_pct}%)" in [b.text for row in mock_bot.last_markup.keyboard for b in row if "Таможня" in b.text][0]
print("✓ Raid button win chance correctly matches calculate_raid_win_chance!")

print("\n==================================================")
print("   🎉 ALL TARGETED FEATURES TESTS PASSED 100%!    ")
print("==================================================")
