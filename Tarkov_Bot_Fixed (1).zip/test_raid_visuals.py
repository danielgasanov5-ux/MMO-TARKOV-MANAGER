import os
import sys
import unittest
import types

sys.path.insert(0, os.path.dirname(__file__))

import bot
import tarkov_engine
import loot_generator

class TestRaidVisuals(unittest.TestCase):
    def setUp(self):
        self.db = bot.load_db()
        self.admin_id = int(os.getenv("ADMIN_USER_ID", "6021200021"))
        self.player_id = 998877
        self.username = "visual_tester"
        self.player = tarkov_engine.create_new_player(self.player_id, self.username, "Viper")
        self.db["users"][str(self.player_id)] = self.player
        bot.save_db(self.db)

    def test_raids_menu_photo_delivery(self):
        sent_photos = []
        bot.bot.send_photo = lambda chat_id, photo, caption=None, reply_markup=None, parse_mode=None, *args, **kwargs: sent_photos.append((photo, caption, reply_markup))

        bot.handle_menu_raids(self.player_id, 101, self.player)
        self.assertTrue(len(sent_photos) > 0)
        photo_url, caption, markup = sent_photos[-1]
        self.assertIn("РЕЙДЫ В ЗОНУ ТАРКОВА", caption)
        self.assertTrue(photo_url.startswith("http") or "file" in photo_url)
        print("  ✓ Raids menu photo delivered above text successfully!")

    def test_solo_raid_result_location_photo_delivery(self):
        sent_photos = []
        bot.bot.send_photo = lambda chat_id, photo, caption=None, reply_markup=None, parse_mode=None, *args, **kwargs: sent_photos.append((photo, caption, reply_markup))

        class DummyCall:
            def __init__(self, user_id, chat_id, msg_id):
                self.id = "call_test_raid_1"
                self.from_user = types.SimpleNamespace(id=user_id, username="visual_tester")
                self.message = types.SimpleNamespace(chat=types.SimpleNamespace(id=chat_id), message_id=msg_id)
                self.data = "start_solo_raid_factory"

        bot.bot.answer_callback_query = lambda call_id, *args, **kwargs: None

        call = DummyCall(self.player_id, self.player_id, 202)
        db = bot.load_db()
        bot.handle_start_solo_raid(call, self.player, db, "factory")

        self.assertTrue(len(sent_photos) > 0)
        photo_url, caption, markup = sent_photos[-1]
        self.assertIn("Завод", caption)
        self.assertTrue("УСПЕШНАЯ ЭВАКУАЦИЯ" in caption or "погибли" in caption)
        self.assertEqual(photo_url, bot.get_location_photo("factory", db))
        print("  ✓ Solo raid results delivered with location photo above text!")

    def test_admin_custom_raids_and_loc_photo_setting(self):
        class DummyPhotoSize:
            def __init__(self, fid):
                self.file_id = fid
                self.width = 1280
                self.height = 720

        class DummyPhotoMsg:
            def __init__(self, from_id, uname, caption, file_id):
                self.from_user = types.SimpleNamespace(id=from_id, username=uname)
                self.chat = types.SimpleNamespace(id=from_id)
                self.caption = caption
                self.photo = [DummyPhotoSize(file_id)]
                self.reply_to_message = None

        replies = []
        bot.bot.reply_to = lambda msg, txt, parse_mode=None, reply_markup=None: replies.append(txt)

        # 1. Admin sends photo with caption 'рейды'
        raids_fid = "AgACAgIAAxkBAAI_CUSTOM_RAIDS_PHOTO"
        msg_raids = DummyPhotoMsg(self.admin_id, "admin", "рейды", raids_fid)
        bot.handle_admin_photo_upload(msg_raids)

        db = bot.load_db()
        self.assertEqual(db.get("raids_menu_photo"), raids_fid)
        self.assertIn("меню «Рейды в Тарков» успешно привязано", replies[-1])

        # 2. Admin sends photo with caption 'завод'
        factory_fid = "AgACAgIAAxkBAAI_CUSTOM_FACTORY_PHOTO"
        msg_factory = DummyPhotoMsg(self.admin_id, "admin", "завод", factory_fid)
        bot.handle_admin_photo_upload(msg_factory)

        db = bot.load_db()
        self.assertEqual(db.get("location_photos", {}).get("factory"), factory_fid)
        self.assertIn("локации «Завод» успешно привязано", replies[-1])

        # 3. Test /reset_raids_photo
        class DummyCmdMsg:
            def __init__(self, text, from_id, uname):
                self.text = text
                self.from_user = types.SimpleNamespace(id=from_id, username=uname)
                self.chat = types.SimpleNamespace(id=from_id)
                self.reply_to_message = None

        msg_reset_r = DummyCmdMsg("/reset_raids_photo", self.admin_id, "admin")
        bot.cmd_admin_commands(msg_reset_r)
        db = bot.load_db()
        self.assertIsNone(db.get("raids_menu_photo"))

        # 4. Test /reset_loc_photo factory
        msg_reset_l = DummyCmdMsg("/reset_loc_photo factory", self.admin_id, "admin")
        bot.cmd_admin_commands(msg_reset_l)
        db = bot.load_db()
        self.assertNotIn("factory", db.get("location_photos", {}))
        print("  ✓ Admin custom photo setting, caption detection and resets verified!")

if __name__ == "__main__":
    unittest.main()
