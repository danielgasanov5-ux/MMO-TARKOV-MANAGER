import sys
import types
import random
import time

sys.path.insert(0, "/tmp/tarkov-bot")
import tarkov_engine as te
import gd_military_system as gd
import prestige as pr
import mythic_system as ms
import loot_generator as lg
from relics_system import ALL_30_RELICS, get_player_relics
import bot

def run_simulation():
    print("==================================================")
    print("   🎮 FULL ENDGAME SIMULATION TEST RUN          ")
    print("==================================================")
    
    # Setup mock bot callbacks
    sent_messages = []
    bot.bot.answer_callback_query = lambda *a, **kw: None
    bot.bot.edit_message_text = lambda txt, *a, **kw: sent_messages.append(txt)
    bot.bot.send_message = lambda chat_id, txt, *a, **kw: sent_messages.append(txt)
    bot.bot.send_photo = lambda chat_id, photo, caption=None, *a, **kw: sent_messages.append(caption or "")
    bot.bot.delete_message = lambda *a, **kw: None

    class DummyCall:
        def __init__(self, uid=9999, uname="danielgasanov5_ux"):
            self.id = "c_sim"
            self.from_user = types.SimpleNamespace(id=uid, username=uname)
            self.message = types.SimpleNamespace(chat=types.SimpleNamespace(id=123), message_id=456)

    # 1. CREATE FULL ENDGAME ADMIN ACCOUNT
    admin = te.create_new_player(9999, "danielgasanov5_ux", "Revenant")
    admin["money"] = 15_000_000_000
    admin["level"] = 10
    admin["exp"] = 0

    # Prestige 5
    admin["prestige"] = 5
    admin["prestige_mastery"] = {"combat_mastery": 5, "economic_mastery": 5}
    admin["prestige_tokens"] = 5

    # All Businesses (4 regular + 3 special)
    admin["businesses"] = {
        "customs_terminal": 10,
        "bitcoin_farm": 10,
        "arms_factory": 10,
        "pmc_training_center": 10
    }
    admin["special_businesses"] = {
        "smugglers_fleet": True,
        "fence_protection": True,
        "gd_shadow_agent": True
    }

    # Full GD Battle Pass
    bp_state = admin.setdefault("gd_battlepass", {})
    bp_state["level"] = 150
    bp_state["current_exp"] = 0
    bp_state["unlocked_weapons"] = list(gd.GD_WEAPONS_CATALOG.keys())

    # All 10/10 Hideout Modules
    admin["modules"] = {k: 10 for k in te.MODULE_NAMES}
    admin["warehouses"] = {k: 10 for k in te.BASE_WAREHOUSE_CAPS}

    # All 30/30 Boss Relics in stash
    for r in ALL_30_RELICS:
        admin["stash"].append({"uid": f"relic_{r['id']}", "item_id": r["id"], "equipped_to": None})

    # All Mythic items in stash/inventory
    ms.add_mythic_item_to_player(admin, "mythic_dsp_sensor")
    ms.add_mythic_item_to_player(admin, "mythic_goons_token")
    ms.add_mythic_item_to_player(admin, "mythic_diplomatic_case")

    # Top PMC Squad of 7 Fighters (with mythic equipment)
    admin["squad"] = []
    now = int(time.time())
    for i in range(1, 8):
        w_uid = f"m_w_{i}"
        a_uid = f"m_a_{i}"
        h_uid = f"m_h_{i}"
        w_id = "zryachiy_axmc_338" if i % 2 == 1 else "goons_bigpipe_m32a1"
        a_id = "zryachiy_cultist_vest" if i % 2 == 1 else "goons_knight_avs_rig"
        h_id = "zryachiy_hood_mask" if i % 2 == 1 else "goons_knight_skull_mask"
        admin["stash"].extend([
            {"uid": w_uid, "item_id": w_id, "equipped_to": i},
            {"uid": a_uid, "item_id": a_id, "equipped_to": i},
            {"uid": h_uid, "item_id": h_id, "equipped_to": i}
        ])
        admin["squad"].append({
            "id": i,
            "type": "pmc",
            "name": f"Элитный Оператор ЧВК #{i}",
            "power": 120,
            "weapon_uid": w_uid,
            "armor_uid": a_uid,
            "helmet_uid": h_uid,
            "headset_uid": None
        })

    db = {"users": {"9999": admin}}

    print("✔ Status check:")
    print("  - Level:", admin["level"])
    print("  - Prestige:", pr.get_player_prestige(admin), pr.get_prestige_badge(admin))
    print("  - Businesses:", len(admin["businesses"]), "regular +", len(admin["special_businesses"]), "special")
    print("  - Boss Relics:", len(get_player_relics(admin)), "/ 30")
    print("  - Has DSP Sensor:", pr.has_player_dsp_sensor(admin))
    print("  - Squad Size:", len(admin["squad"]), "/ 7")
    print("  - Battle Pass:", admin["gd_battlepass"]["level"], "/ 150")

    # SIMULATION 1: Standard Solo Raid (Factory)
    print("\n[SIM 1] Testing Solo Raid on Factory...")
    sent_messages.clear()
    bot.handle_start_solo_raid(DummyCall(), admin, db, "factory")
    assert len(sent_messages) > 0, "No raid message sent!"
    print("✔ [SIM 1] Factory Raid executed successfully without errors!")

    # SIMULATION 2: High Difficulty Raid (Laboratory) with forced success
    print("\n[SIM 2] Testing Lab Raid (Forced Success with Loot)...")
    sent_messages.clear()
    bot.simulate_raid = lambda loc, p, po, a: {
        "success": True,
        "location": "Лаборатория Terragroup",
        "win_chance": 98.0,
        "rubles": 850000,
        "items": [
            {"id": "ledx_skin_transilluminator", "name": "Медицинский трансиллюминатор LEDX", "rarity": "mythic", "price": 4500000},
            {"id": "graphics_card_gpu", "name": "Видеокарта GeForce RTX", "rarity": "epic", "price": 350000}
        ],
        "btc_won": 1.0,
        "mythic_perks": {"rubles_mult": 1.5, "exp_mult": 2.0}
    }
    init_money = admin["money"]
    bot.handle_start_solo_raid(DummyCall(), admin, db, "lab")
    assert len(sent_messages) > 0
    assert "УСПЕШНАЯ ЭВАКУАЦИЯ" in sent_messages[0]
    assert "МАКСИМАЛЬНЫЙ УРОВЕНЬ" in sent_messages[0]
    assert "Опыт ЧВК" in sent_messages[0]
    assert admin["money"] == init_money + 850000
    print("✔ [SIM 2] Lab Raid Success: rubles, exp, LEDX loot and Max BP message verified!")

    # SIMULATION 3A: Raid Squad Defeat with Tagilla Boss Set protection
    print("\n[SIM 3A] Testing Raid Squad Defeat with Tagilla Set Active...")
    sent_messages.clear()
    bot.simulate_raid = lambda loc, p, po, a: {
        "success": False,
        "location": "Маяк",
        "win_chance": 15.0,
        "rubles": 0,
        "items": [],
        "btc_won": 0.0,
        "mythic_perks": {}
    }
    bot.handle_start_solo_raid(DummyCall(), admin, db, "lighthouse")
    assert len(sent_messages) > 0
    assert "ОТРЯД ПОЛНОСТЬЮ ПОГИБ В БОЮ" in sent_messages[0]
    assert "СЕТ ТАГИЛЛЫ" in sent_messages[0]
    assert len(admin["squad"]) == 7, "Squad should be 100% saved by Tagilla set!"
    print("✔ [SIM 3A] Tagilla set prevented all losses: squad and gear 100% saved!")

    # SIMULATION 3B: Defeat WITHOUT Tagilla set -> Mythic beacon test
    print("\n[SIM 3B] Testing Defeat without Tagilla Set (Satellite Beacon)...")
    tagilla_relics = [it for it in admin["stash"] if "tagilla" in it.get("item_id", "")]
    for it in tagilla_relics:
        admin["stash"].remove(it)

    sent_messages.clear()
    bot.handle_start_solo_raid(DummyCall(), admin, db, "lighthouse")
    assert len(sent_messages) > 0
    assert "МИФИЧЕСКИЙ ЭВАКУАЦИОННЫЙ МАЯЧОК" in sent_messages[0]
    unequipped_mythics = [it for it in admin["stash"] if it.get("item_id", "").startswith(("zryachiy_", "goons_")) and it.get("equipped_to") is None]
    assert len(unequipped_mythics) >= 21, f"Expected saved mythics, found {len(unequipped_mythics)}"
    print(f"✔ [SIM 3B] Mythic satellite beacon safely recovered all {len(unequipped_mythics)} mythic items back to stash!")

    # Restore Tagilla relics & re-equip squad
    admin["stash"].extend(tagilla_relics)
    for i in range(1, 8):
        admin["squad"].append({
            "id": i, "type": "pmc", "name": f"ЧВК #{i}", "power": 120,
            "weapon_uid": f"m_w_{i}", "armor_uid": f"m_a_{i}", "helmet_uid": f"m_h_{i}", "headset_uid": None
        })

    # SIMULATION 4: Boss Combat Ambush (Killa)
    print("\n[SIM 4] Testing Boss Ambush Combat (Killa with Zryachiy Sniper)...")
    sent_messages.clear()
    b_info = lg.BOSS_AMBUSH_DEFINITIONS["interchange"]
    boss_res = lg.simulate_boss_combat("interchange", b_info, admin, 800, 1000)
    print(f"  - Boss combat victory: {boss_res['success']}")
    print(f"  - Calculated win chance: {boss_res['win_chance_pct']}%")
    print(f"  - Sniper AXMC shot active: {'ЗРЯЧЕГО' in boss_res.get('sniper_log', '')}")
    assert "ЗРЯЧЕГО" in boss_res.get("sniper_log", ""), "Expected Zryachiy sniper support to be active!"
    print("✔ [SIM 4] Boss combat with Zryachiy AXMC .338 AP verified!")

    # SIMULATION 5: Prestige 5 Exclusive Black Raid
    print("\n[SIM 5] Testing Prestige 5 Black Raid...")
    can_r, reason, rem = pr.can_launch_prestige_black_raid(admin)
    assert can_r is True, f"Black raid should be available: {reason}"
    ok, b_data = pr.execute_prestige_black_raid(admin)
    assert ok is True
    print(f"  - Earned Rubles: {b_data['rubles']:,} ₽")
    print(f"  - Found Items: {b_data['items_names']}")
    print("✔ [SIM 5] Black Raid executed successfully!")

    print("\n==================================================")
    print("   🎉 ALL 5 ENDGAME SIMULATIONS PASSED 100%!     ")
    print("==================================================")

if __name__ == "__main__":
    run_simulation()
