# -*- coding: utf-8 -*-
"""
GD Military: Shadow Operative & 150-Level Battle Pass System
Private Military Corporation Elite Syndicate Business & Progressive Raid Grind
for Escape from Tarkov MMO Telegram Bot.
"""
import random
import time
from typing import Dict, Any, List, Optional, Tuple

GD_BUSINESS_DEF = {
    "id": "gd_shadow_agent",
    "name": "🛰️ Теневой сотрудник GD Military",
    "icon": "🛰️",
    "cost": 5_000_000_000, # 5 Billion Rubles
    "hourly_income": 25_000_000, # 25 Million Rubles per hour
    "effect": "Боевой Пропуск GD (150 ур.), спутниковый радар рейдов и дроп уникального оружия",
    "desc": (
        "Сверхсекретный контракт синдиката частной военной корпорации GD Military. "
        "Предоставляет доступ к закрытому орбитальному каналу разведки, регулярным траншам "
        "в 25 млн ₽/час и 150-уровневому Боевому Пропуску спецопераций."
    )
}

GD_WEAPONS_CATALOG = {
    "gd_glock19x_phantom": {
        "id": "gd_glock19x_phantom",
        "name": "GD Glock 19X «Phantom»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "rare",
        "price": 180000,
        "combat": 75,
        "armor": 0,
        "desc": "Компактный бесшумный пистолет теневого агента с тритиевым прицелом.",
        "locations": "Завод, Таможня",
        "drop_chance": "4.5%"
    },
    "gd_mp7_spectre": {
        "id": "gd_mp7_spectre",
        "name": "GD MP7A2 «Spectre»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "epic",
        "price": 450000,
        "combat": 115,
        "armor": 0,
        "desc": "Сверхскорострельный PDW в черном матовом карбоне с бронебойными патронами AP SX.",
        "locations": "Таможня, Лес",
        "drop_chance": "3.8%"
    },
    "gd_vector45_cyclone": {
        "id": "gd_vector45_cyclone",
        "name": "GD KRISS Vector .45 «Cyclone»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "epic",
        "price": 620000,
        "combat": 130,
        "armor": 0,
        "desc": "Ураганный пистолет-пулемет .45 ACP с системой Super V и лазером GD-IR.",
        "locations": "Завод, Таможня",
        "drop_chance": "3.5%"
    },
    "gd_sr25_shadow": {
        "id": "gd_sr25_shadow",
        "name": "GD SR-25 «Shadow Mark»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "legendary",
        "price": 950000,
        "combat": 148,
        "armor": 0,
        "desc": "Снайперская полуавтоматическая система 7.62x51 NATO с оптикой Razor HD.",
        "locations": "Лес, Резерв",
        "drop_chance": "2.8%"
    },
    "gd_val_nightstalker": {
        "id": "gd_val_nightstalker",
        "name": "GD АС ВАЛ «Night Stalker»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "legendary",
        "price": 1200000,
        "combat": 158,
        "armor": 0,
        "desc": "Бесшумный штурмовой комплекс с вольфрамовыми спецпатронами СПП.",
        "locations": "Таможня, Резерв",
        "drop_chance": "2.5%"
    },
    "gd_mcx_blackout": {
        "id": "gd_mcx_blackout",
        "name": "GD SIG MCX .300 BLK «Viper»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "legendary",
        "price": 1450000,
        "combat": 168,
        "armor": 0,
        "desc": "Штурмовой карабин .300 Blackout AP для мгновенной ликвидации тяжелобронированных целей.",
        "locations": "Резерв, Лаборатория",
        "drop_chance": "2.4%"
    },
    "gd_saiga12_devastator": {
        "id": "gd_saiga12_devastator",
        "name": "GD Сайга-12К «Devastator»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "legendary",
        "price": 1600000,
        "combat": 175,
        "armor": 0,
        "desc": "Дробовик с барабаном на 20 патронов и бронебойными шрапнельными дротиками AP-20.",
        "locations": "Завод, Таможня",
        "drop_chance": "2.2%"
    },
    "gd_hk416_valkyrie": {
        "id": "gd_hk416_valkyrie",
        "name": "GD HK416A5 «Valkyrie Special»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "legendary",
        "price": 1900000,
        "combat": 182,
        "armor": 0,
        "desc": "Флагманская винтовка штурмовых групп GD со стволом холодной ковки и глушителем Rotex-V.",
        "locations": "Резерв, Лаборатория",
        "drop_chance": "2.0%"
    },
    "gd_ak12_predator": {
        "id": "gd_ak12_predator",
        "name": "GD АК-12 Теневой «Predator»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "legendary",
        "price": 2100000,
        "combat": 188,
        "armor": 0,
        "desc": "Кастомный АК-12 нового поколения с цевьем Zenitco Leader и оптикой 1P87.",
        "locations": "Таможня, Резерв",
        "drop_chance": "1.9%"
    },
    "gd_m4a1_chimera": {
        "id": "gd_m4a1_chimera",
        "name": "GD M4A1 «Chimera SpecOps»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "legendary",
        "price": 2500000,
        "combat": 198,
        "armor": 0,
        "desc": "Ультимативный карабин M4A1 ресивера Vltor MUR-1S с патронами M995 Armor Piercing.",
        "locations": "Лаборатория, Резерв",
        "drop_chance": "1.8%"
    },
    "gd_ash12_behemoth": {
        "id": "gd_ash12_behemoth",
        "name": "GD АШ-12 12.7x55 «Behemoth»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 3200000,
        "combat": 208,
        "armor": 0,
        "desc": "Крупнокалиберный штурмовой монстр 12.7 мм с пулями ПС-12Б, пробивающими 6 класс брони.",
        "locations": "Лаборатория, Резерв",
        "drop_chance": "1.5%"
    },
    "gd_svd_phantom": {
        "id": "gd_svd_phantom",
        "name": "GD СВД-М «Phantom Longshot»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 3600000,
        "combat": 218,
        "armor": 0,
        "desc": "Снайперская винтовка Драгунова в шасси SAG с прицелом Nightforce ATACR 7-35x56.",
        "locations": "Лес, Резерв",
        "drop_chance": "1.4%"
    },
    "gd_m1a_juggernaut": {
        "id": "gd_m1a_juggernaut",
        "name": "GD M1A SOCOM «Juggernaut»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 4100000,
        "combat": 226,
        "armor": 0,
        "desc": "Тяжелая винтовка в ложе SAGE EBR с барабаном на 50 патронов M61.",
        "locations": "Лаборатория, Резерв",
        "drop_chance": "1.3%"
    },
    "gd_pkm_black_division": {
        "id": "gd_pkm_black_division",
        "name": "GD ПКМ «Black Division SpecOps»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 4800000,
        "combat": 235,
        "armor": 0,
        "desc": "Пулемет 7.62x54R с укороченным стволом и коробом на 200 патронов повышенного давления Б-32.",
        "locations": "Резерв, Кооп-рейды",
        "drop_chance": "1.2%"
    },
    "gd_scar_h_titan": {
        "id": "gd_scar_h_titan",
        "name": "GD FN SCAR-H «Titan Vanguard»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 5500000,
        "combat": 245,
        "armor": 0,
        "desc": "Тяжелая боевая штурмовая система 7.62x51 в расцветке Midnight Stealth с HUD-счетчиком.",
        "locations": "Лаборатория, Кооп-рейды",
        "drop_chance": "1.1%"
    },
    "gd_dvl10_eclipse": {
        "id": "gd_dvl10_eclipse",
        "name": "GD DVL-10 «Eclipse Saboteur»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 6200000,
        "combat": 255,
        "armor": 0,
        "desc": "Бесшумная снайперская винтовка Лобаева с тяжелыми дозвуковыми патронами GD Sub-X.",
        "locations": "Лес, Лаборатория",
        "drop_chance": "1.0%"
    },
    "gd_pkp_omega": {
        "id": "gd_pkp_omega",
        "name": "GD ПКП «Печенег-Омега»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 7000000,
        "combat": 265,
        "armor": 0,
        "desc": "Штурмовой пулемет непрерывного охлаждения с лентой бронебойно-зажигательных патронов 7Н13.",
        "locations": "Резерв, Лаборатория",
        "drop_chance": "0.9%"
    },
    "gd_mrad_overkill": {
        "id": "gd_mrad_overkill",
        "name": "GD Barrett MRAD «Overkill .338»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 8000000,
        "combat": 275,
        "armor": 0,
        "desc": "Модульная антиматериальная снайперка .338 Lapua с тепловизором Trijicon REAP-IR.",
        "locations": "Лаборатория, Кооп-рейды",
        "drop_chance": "0.8%"
    },
    "gd_m200_interceptor": {
        "id": "gd_m200_interceptor",
        "name": "GD CheyTac M200 «Interceptor»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 9500000,
        "combat": 285,
        "armor": 0,
        "desc": "Дальнобойная снайперская система .408 CheyTac со спутниковым баллистическим компьютером.",
        "locations": "Лаборатория, Спецоперации",
        "drop_chance": "0.7%"
    },
    "gd_m32a1_apocalypse": {
        "id": "gd_m32a1_apocalypse",
        "name": "GD M32A1 «Apocalypse Multi-Launcher»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 12000000,
        "combat": 298,
        "armor": 0,
        "desc": "Шестизарядный 40-мм револьверный гранатомет с кумулятивно-осколочными выстрелами M433.",
        "locations": "Лаборатория (Ультра/Colossal)",
        "drop_chance": "0.6%"
    },
    "gd_mk18_void": {
        "id": "gd_mk18_void",
        "name": "GD Mk-18 «Mjolnir Void .338»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 15000000,
        "combat": 308,
        "armor": 0,
        "desc": "Полуавтоматический зверь .338 LM, прошивающий бронированные укрытия насквозь.",
        "locations": "Лаборатория, Кооп Colossal",
        "drop_chance": "0.5%"
    },
    "gd_nemesis_prototype": {
        "id": "gd_nemesis_prototype",
        "name": "GD Experimental Assault Unit «Nemesis»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 18500000,
        "combat": 318,
        "armor": 0,
        "desc": "Сверхсекретная штурмовая система Black Division с электромагнитным досылателем пуль.",
        "locations": "Все элитные зоны",
        "drop_chance": "0.4%"
    },
    "gd_arc_valkyrie": {
        "id": "gd_arc_valkyrie",
        "name": "GD Импульсный карабин «Arc Valkyrie»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 22000000,
        "combat": 328,
        "armor": 0,
        "desc": "Опытный прототип с плазменной ионизацией пороховых газов, удваивающей кинетическую энергию.",
        "locations": "Лаборатория, Спецоперации",
        "drop_chance": "0.3%"
    },
    "gd_barrett_doomsday": {
        "id": "gd_barrett_doomsday",
        "name": "GD Barrett .50 BMG «Doomsday»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 26000000,
        "combat": 338,
        "armor": 0,
        "desc": "Антиматериальный разрушитель 12.7x99 NATO с дульным тормозом активного демпфирования.",
        "locations": "Лаборатория, Спецоперации",
        "drop_chance": "0.2%"
    },
    "gd_kinetic_chronos": {
        "id": "gd_kinetic_chronos",
        "name": "GD Кинетический Дисраптор «Chronos»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 30000000,
        "combat": 344,
        "armor": 0,
        "desc": "Квантовое ручное орудие, генерирующее направленные кинетические импульсы сверхвысокой плотности.",
        "locations": "Самые опасные рейды",
        "drop_chance": "0.15%"
    },
    "gd_railgun_exterminator": {
        "id": "gd_railgun_exterminator",
        "name": "GD-Railgun M-150 «Экстерминатор»",
        "category": "weapons",
        "market_cat": "Оружие",
        "rarity": "mythic",
        "price": 50000000,
        "combat": 350,
        "armor": 0,
        "desc": "Венец военно-инженерной мысли GD Military. Портативный рельсовый ускоритель гиперзвуковых вольфрамовых игл (скорость снаряда 3200 м/с). Мгновенное устранение любой цели!",
        "locations": "Все рейды высшей сложности",
        "drop_chance": "0.1%"
    }
}

GD_BATTLEPASS_LEVELS = [
    {
        "level": 1,
        "exp": 520,
        "totalExp": 520,
        "title": "📡 Спутниковый радар GD",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Постоянный мониторинг засад боссов: шанс внезапной засады в соло-рейдах снижен на 35%.",
        "isMilestone": True,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 2,
        "exp": 699,
        "totalExp": 1219,
        "title": "Модификатор: Бонус рейдового золота I",
        "category": "drop_enhancer",
        "rarity": "rare",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+3% к сумме рублей, выносимых со всех локаций.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 3,
        "exp": 883,
        "totalExp": 2102,
        "title": "📦 Контейнеры GD: Схрон +50",
        "category": "mechanic",
        "rarity": "rare",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Вместимость основных складов навсегда увеличена на +50 предметов.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 4,
        "exp": 1071,
        "totalExp": 3173,
        "title": "Экипировка: Кепка Теневого Агента GD",
        "category": "outfit",
        "rarity": "epic",
        "badge": "Гардероб (Головной убор)",
        "stat": "Слот: Головной убор",
        "description": "Темная кевларовая кепка с антибликовым козырьком GD. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 5,
        "exp": 1262,
        "totalExp": 4435,
        "title": "Оружие: GD Glock 19X «Phantom»",
        "category": "weapon",
        "rarity": "rare",
        "badge": "Combat +75",
        "stat": "Мощь: 75 | Дроп: 4.5% (Завод, Таможня)",
        "description": "Компактный бесшумный пистолет теневого агента с тритиевым прицелом. Навсегда добавляется в лут-пул рейдов (Завод, Таможня) с шансом 4.5%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_glock19x_phantom",
            "name": "GD Glock 19X «Phantom»",
            "combat": 75,
            "rarity": "rare",
            "price": 180000,
            "locations": "Завод, Таможня",
            "dropChance": "4.5%",
            "desc": "Компактный бесшумный пистолет теневого агента с тритиевым прицелом."
        },
        "raidDropUnlocked": "Открывает выпадение GD Glock 19X «Phantom» в рейдах (Завод, Таможня) с шансом 4.5%"
    },
    {
        "level": 6,
        "exp": 1455,
        "totalExp": 5890,
        "title": "Модификатор: Спец-досмотр на Заводе",
        "category": "drop_enhancer",
        "rarity": "rare",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "На Заводе гарантированно находится +1 дополнительный ценный предмет.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 7,
        "exp": 1650,
        "totalExp": 7540,
        "title": "⚡ Тактический экспресс-выход",
        "category": "mechanic",
        "rarity": "rare",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Спец-протокол навигации: +5% к базовому шансу выживания на Заводе и Таможне.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 8,
        "exp": 1848,
        "totalExp": 9388,
        "title": "Титул профиля: [Агент Наблюдения GD]",
        "category": "title",
        "rarity": "rare",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Агент Наблюдения GD]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 9,
        "exp": 2047,
        "totalExp": 11435,
        "title": "Экипировка: Тактические ботинки GD Stealth",
        "category": "outfit",
        "rarity": "epic",
        "badge": "Гардероб (Обувь)",
        "stat": "Слот: Обувь",
        "description": "Бесшумная резиновая подошва Vibram и защита голеностопа от осколков. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 10,
        "exp": 2249,
        "totalExp": 13684,
        "title": "Оружие: GD MP7A2 «Spectre»",
        "category": "weapon",
        "rarity": "epic",
        "badge": "Combat +115",
        "stat": "Мощь: 115 | Дроп: 3.8% (Таможня, Лес)",
        "description": "Сверхскорострельный PDW в черном матовом карбоне с бронебойными патронами AP SX. Навсегда добавляется в лут-пул рейдов (Таможня, Лес) с шансом 3.8%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_mp7_spectre",
            "name": "GD MP7A2 «Spectre»",
            "combat": 115,
            "rarity": "epic",
            "price": 450000,
            "locations": "Таможня, Лес",
            "dropChance": "3.8%",
            "desc": "Сверхскорострельный PDW в черном матовом карбоне с бронебойными патронами AP SX."
        },
        "raidDropUnlocked": "Открывает выпадение GD MP7A2 «Spectre» в рейдах (Таможня, Лес) с шансом 3.8%"
    },
    {
        "level": 11,
        "exp": 2451,
        "totalExp": 16135,
        "title": "Модификатор: Элитный лут Таможни",
        "category": "drop_enhancer",
        "rarity": "rare",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+4% к шансу найти предметы Эпической редкости на Таможне.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 12,
        "exp": 2655,
        "totalExp": 18790,
        "title": "💼 Теневая лицензия брокера",
        "category": "mechanic",
        "rarity": "epic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Снижает комиссию при продаже предметов на Барахолке на 3%.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 13,
        "exp": 2861,
        "totalExp": 21651,
        "title": "Кейс: Тактический контейнер GD Tactical I",
        "category": "case",
        "rarity": "epic",
        "badge": "Военный дроп Т1",
        "stat": "Гарантированный топ-хабар",
        "description": "Специальная военная посылка GD Military 1-го тира. Содержит элитную броню 5-6 класса, медикаменты спецназа и компоненты высоких технологий.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 14,
        "exp": 3068,
        "totalExp": 24719,
        "title": "Экипировка: Теневой камуфляж GD Recon",
        "category": "outfit",
        "rarity": "epic",
        "badge": "Гардероб (Костюм)",
        "stat": "Слот: Костюм",
        "description": "Маскировочный костюм в расцветке Midnight Camo с поглощением ИК-излучения. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 15,
        "exp": 3276,
        "totalExp": 27995,
        "title": "Оружие: GD KRISS Vector .45 «Cyclone»",
        "category": "weapon",
        "rarity": "epic",
        "badge": "Combat +130",
        "stat": "Мощь: 130 | Дроп: 3.5% (Завод, Таможня)",
        "description": "Ураганный пистолет-пулемет .45 ACP с системой Super V и лазером GD-IR. Навсегда добавляется в лут-пул рейдов (Завод, Таможня) с шансом 3.5%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_vector45_cyclone",
            "name": "GD KRISS Vector .45 «Cyclone»",
            "combat": 130,
            "rarity": "epic",
            "price": 620000,
            "locations": "Завод, Таможня",
            "dropChance": "3.5%",
            "desc": "Ураганный пистолет-пулемет .45 ACP с системой Super V и лазером GD-IR."
        },
        "raidDropUnlocked": "Открывает выпадение GD KRISS Vector .45 «Cyclone» в рейдах (Завод, Таможня) с шансом 3.5%"
    },
    {
        "level": 16,
        "exp": 3485,
        "totalExp": 31480,
        "title": "Титул профиля: [Младший Оперативник GD]",
        "category": "title",
        "rarity": "rare",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Младший Оперативник GD]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 17,
        "exp": 3695,
        "totalExp": 35175,
        "title": "Модификатор: Бонус рейдового золота II",
        "category": "drop_enhancer",
        "rarity": "rare",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+6% к сумме выносимых рублей из рейдов.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 18,
        "exp": 3906,
        "totalExp": 39081,
        "title": "💉 Тактический био-инжектор GD",
        "category": "mechanic",
        "rarity": "epic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "При гибели отряда 1 боец спасается со 100% здоровьем с вероятностью 35%.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 19,
        "exp": 4119,
        "totalExp": 43200,
        "title": "Финансирование: +11 000 000 ₽",
        "category": "currency",
        "rarity": "rare",
        "badge": "Наличные рубли",
        "stat": "+11 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +11 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 20,
        "exp": 4332,
        "totalExp": 47532,
        "title": "Оружие: GD SR-25 «Shadow Mark»",
        "category": "weapon",
        "rarity": "legendary",
        "badge": "Combat +148",
        "stat": "Мощь: 148 | Дроп: 2.8% (Лес, Резерв)",
        "description": "Снайперская полуавтоматическая система 7.62x51 NATO с оптикой Razor HD. Навсегда добавляется в лут-пул рейдов (Лес, Резерв) с шансом 2.8%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_sr25_shadow",
            "name": "GD SR-25 «Shadow Mark»",
            "combat": 148,
            "rarity": "legendary",
            "price": 950000,
            "locations": "Лес, Резерв",
            "dropChance": "2.8%",
            "desc": "Снайперская полуавтоматическая система 7.62x51 NATO с оптикой Razor HD."
        },
        "raidDropUnlocked": "Открывает выпадение GD SR-25 «Shadow Mark» в рейдах (Лес, Резерв) с шансом 2.8%"
    },
    {
        "level": 21,
        "exp": 8072,
        "totalExp": 55604,
        "title": "Экипировка: Очки ночного видения GD-Quad",
        "category": "outfit",
        "rarity": "epic",
        "badge": "Гардероб (Аксессуар)",
        "stat": "Слот: Аксессуар",
        "description": "Четырехтрубный панорамный прибор ночного видения с термо-контуром. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 22,
        "exp": 9015,
        "totalExp": 64619,
        "title": "Титул профиля: [Теневой Стрелок]",
        "category": "title",
        "rarity": "rare",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Теневой Стрелок]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 23,
        "exp": 9965,
        "totalExp": 74584,
        "title": "Модификатор: Тайники Лесопилки",
        "category": "drop_enhancer",
        "rarity": "rare",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+5% к шансу обнаружить фиолетовые ключ-карты и папки с разведданными в Лесу.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 24,
        "exp": 10923,
        "totalExp": 85507,
        "title": "🤝 Контракт на дешевый наем ЧВК",
        "category": "mechanic",
        "rarity": "legendary",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Стоимость найма Диких и бойцов ЧВК в меню отряда снижена на 20%.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 25,
        "exp": 11888,
        "totalExp": 97395,
        "title": "Оружие: GD АС ВАЛ «Night Stalker»",
        "category": "weapon",
        "rarity": "legendary",
        "badge": "Combat +158",
        "stat": "Мощь: 158 | Дроп: 2.5% (Таможня, Резерв)",
        "description": "Бесшумный штурмовой комплекс с вольфрамовыми спецпатронами СПП. Навсегда добавляется в лут-пул рейдов (Таможня, Резерв) с шансом 2.5%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_val_nightstalker",
            "name": "GD АС ВАЛ «Night Stalker»",
            "combat": 158,
            "rarity": "legendary",
            "price": 1200000,
            "locations": "Таможня, Резерв",
            "dropChance": "2.5%",
            "desc": "Бесшумный штурмовой комплекс с вольфрамовыми спецпатронами СПП."
        },
        "raidDropUnlocked": "Открывает выпадение GD АС ВАЛ «Night Stalker» в рейдах (Таможня, Резерв) с шансом 2.5%"
    },
    {
        "level": 26,
        "exp": 12861,
        "totalExp": 110256,
        "title": "Финансирование: +14 000 000 ₽",
        "category": "currency",
        "rarity": "rare",
        "badge": "Наличные рубли",
        "stat": "+14 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +14 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 27,
        "exp": 13840,
        "totalExp": 124096,
        "title": "Финансирование: +15 000 000 ₽",
        "category": "currency",
        "rarity": "rare",
        "badge": "Наличные рубли",
        "stat": "+15 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +15 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 28,
        "exp": 14825,
        "totalExp": 138921,
        "title": "Титул профиля: [Призрак Таркова]",
        "category": "title",
        "rarity": "rare",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Призрак Таркова]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 29,
        "exp": 15818,
        "totalExp": 154739,
        "title": "Модификатор: Тайный бункер Резерва",
        "category": "drop_enhancer",
        "rarity": "rare",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "На Резерве всегда спавнится дополнительный военный компонент.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 30,
        "exp": 16817,
        "totalExp": 171556,
        "title": "Оружие: GD SIG MCX .300 BLK «Viper»",
        "category": "weapon",
        "rarity": "legendary",
        "badge": "Combat +168",
        "stat": "Мощь: 168 | Дроп: 2.4% (Резерв, Лаборатория)",
        "description": "Штурмовой карабин .300 Blackout AP для мгновенной ликвидации тяжелобронированных целей. Навсегда добавляется в лут-пул рейдов (Резерв, Лаборатория) с шансом 2.4%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_mcx_blackout",
            "name": "GD SIG MCX .300 BLK «Viper»",
            "combat": 168,
            "rarity": "legendary",
            "price": 1450000,
            "locations": "Резерв, Лаборатория",
            "dropChance": "2.4%",
            "desc": "Штурмовой карабин .300 Blackout AP для мгновенной ликвидации тяжелобронированных целей."
        },
        "raidDropUnlocked": "Открывает выпадение GD SIG MCX .300 BLK «Viper» в рейдах (Резерв, Лаборатория) с шансом 2.4%"
    },
    {
        "level": 31,
        "exp": 17822,
        "totalExp": 189378,
        "title": "Финансирование: +17 000 000 ₽",
        "category": "currency",
        "rarity": "rare",
        "badge": "Наличные рубли",
        "stat": "+17 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +17 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 32,
        "exp": 18834,
        "totalExp": 208212,
        "title": "🪙 Квантовый трекер криптокошельков",
        "category": "mechanic",
        "rarity": "legendary",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "+3.0% к шансу обнаружить чистый Биткоин (1.0 BTC) в Лаборатории и на Резерве.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 33,
        "exp": 19852,
        "totalExp": 228064,
        "title": "Кейс: Штурмовой ящик вооружения GD SpecOps II",
        "category": "case",
        "rarity": "epic",
        "badge": "Военный дроп Т2",
        "stat": "Гарантированный топ-хабар",
        "description": "Специальная военная посылка GD Military 2-го тира. Содержит элитную броню 5-6 класса, медикаменты спецназа и компоненты высоких технологий.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 34,
        "exp": 20876,
        "totalExp": 248940,
        "title": "Экипировка: Шлем GD-Vanguard Altyn",
        "category": "outfit",
        "rarity": "epic",
        "badge": "Гардероб (Головной убор)",
        "stat": "Слот: Головной убор",
        "description": "Титановый шлем 6 класса защиты с бронезабралом и радиомодулем. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 35,
        "exp": 21907,
        "totalExp": 270847,
        "title": "Оружие: GD Сайга-12К «Devastator»",
        "category": "weapon",
        "rarity": "legendary",
        "badge": "Combat +175",
        "stat": "Мощь: 175 | Дроп: 2.2% (Завод, Таможня)",
        "description": "Дробовик с барабаном на 20 патронов и бронебойными шрапнельными дротиками AP-20. Навсегда добавляется в лут-пул рейдов (Завод, Таможня) с шансом 2.2%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_saiga12_devastator",
            "name": "GD Сайга-12К «Devastator»",
            "combat": 175,
            "rarity": "legendary",
            "price": 1600000,
            "locations": "Завод, Таможня",
            "dropChance": "2.2%",
            "desc": "Дробовик с барабаном на 20 патронов и бронебойными шрапнельными дротиками AP-20."
        },
        "raidDropUnlocked": "Открывает выпадение GD Сайга-12К «Devastator» в рейдах (Завод, Таможня) с шансом 2.2%"
    },
    {
        "level": 36,
        "exp": 22943,
        "totalExp": 293790,
        "title": "Финансирование: +20 000 000 ₽",
        "category": "currency",
        "rarity": "rare",
        "badge": "Наличные рубли",
        "stat": "+20 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +20 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 37,
        "exp": 23985,
        "totalExp": 317775,
        "title": "Модификатор: Бонус рейдового золота III",
        "category": "drop_enhancer",
        "rarity": "rare",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+8% к сумме рублей за рейд.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 38,
        "exp": 25034,
        "totalExp": 342809,
        "title": "Титул профиля: [Охотник Black Division]",
        "category": "title",
        "rarity": "rare",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Охотник Black Division]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 39,
        "exp": 26088,
        "totalExp": 368897,
        "title": "Финансирование: +22 000 000 ₽",
        "category": "currency",
        "rarity": "rare",
        "badge": "Наличные рубли",
        "stat": "+22 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +22 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 40,
        "exp": 27147,
        "totalExp": 396044,
        "title": "Оружие: GD HK416A5 «Valkyrie Special»",
        "category": "weapon",
        "rarity": "legendary",
        "badge": "Combat +182",
        "stat": "Мощь: 182 | Дроп: 2.0% (Резерв, Лаборатория)",
        "description": "Флагманская винтовка штурмовых групп GD со стволом холодной ковки и глушителем Rotex-V. Навсегда добавляется в лут-пул рейдов (Резерв, Лаборатория) с шансом 2.0%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_hk416_valkyrie",
            "name": "GD HK416A5 «Valkyrie Special»",
            "combat": 182,
            "rarity": "legendary",
            "price": 1900000,
            "locations": "Резерв, Лаборатория",
            "dropChance": "2.0%",
            "desc": "Флагманская винтовка штурмовых групп GD со стволом холодной ковки и глушителем Rotex-V."
        },
        "raidDropUnlocked": "Открывает выпадение GD HK416A5 «Valkyrie Special» в рейдах (Резерв, Лаборатория) с шансом 2.0%"
    },
    {
        "level": 41,
        "exp": 28213,
        "totalExp": 424257,
        "title": "Финансирование: +23 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+23 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +23 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 42,
        "exp": 29284,
        "totalExp": 453541,
        "title": "🏗️ Бункерный модуль: Схрон +100",
        "category": "mechanic",
        "rarity": "legendary",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Вместимость складов увеличивается еще на +100 ячеек.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 43,
        "exp": 30360,
        "totalExp": 483901,
        "title": "Кейс: Штурмовой ящик вооружения GD SpecOps II",
        "category": "case",
        "rarity": "epic",
        "badge": "Военный дроп Т2",
        "stat": "Гарантированный топ-хабар",
        "description": "Специальная военная посылка GD Military 2-го тира. Содержит элитную броню 5-6 класса, медикаменты спецназа и компоненты высоких технологий.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 44,
        "exp": 31442,
        "totalExp": 515343,
        "title": "Экипировка: Бронекостюм GD Black Division",
        "category": "outfit",
        "rarity": "epic",
        "badge": "Гардероб (Костюм)",
        "stat": "Слот: Костюм",
        "description": "Сверхпрочный комбинезон из арамидного волокна с защитой суставов. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 45,
        "exp": 32530,
        "totalExp": 547873,
        "title": "Оружие: GD АК-12 Теневой «Predator»",
        "category": "weapon",
        "rarity": "legendary",
        "badge": "Combat +188",
        "stat": "Мощь: 188 | Дроп: 1.9% (Таможня, Резерв)",
        "description": "Кастомный АК-12 нового поколения с цевьем Zenitco Leader и оптикой 1P87. Навсегда добавляется в лут-пул рейдов (Таможня, Резерв) с шансом 1.9%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_ak12_predator",
            "name": "GD АК-12 Теневой «Predator»",
            "combat": 188,
            "rarity": "legendary",
            "price": 2100000,
            "locations": "Таможня, Резерв",
            "dropChance": "1.9%",
            "desc": "Кастомный АК-12 нового поколения с цевьем Zenitco Leader и оптикой 1P87."
        },
        "raidDropUnlocked": "Открывает выпадение GD АК-12 Теневой «Predator» в рейдах (Таможня, Резерв) с шансом 1.9%"
    },
    {
        "level": 46,
        "exp": 33623,
        "totalExp": 581496,
        "title": "Титул профиля: [Старший Аналитик GD]",
        "category": "title",
        "rarity": "rare",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Старший Аналитик GD]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 47,
        "exp": 34721,
        "totalExp": 616217,
        "title": "Модификатор: Лабораторный крипто-куш",
        "category": "drop_enhancer",
        "rarity": "epic",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "В Лаборатории в 2 раза чаще попадаются видеокарты и процессоры.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 48,
        "exp": 35825,
        "totalExp": 652042,
        "title": "🕵️ Разведданные по Свите Боссов",
        "category": "mechanic",
        "rarity": "legendary",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Шанс выпадения редких Босс-реликвий при победе над Решалой, Тагиллой, Штурманом повышен на +50%.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 49,
        "exp": 36933,
        "totalExp": 688975,
        "title": "Финансирование: +28 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+28 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +28 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 50,
        "exp": 38047,
        "totalExp": 727022,
        "title": "Оружие: GD M4A1 «Chimera SpecOps»",
        "category": "weapon",
        "rarity": "legendary",
        "badge": "Combat +198",
        "stat": "Мощь: 198 | Дроп: 1.8% (Лаборатория, Резерв)",
        "description": "Ультимативный карабин M4A1 ресивера Vltor MUR-1S с патронами M995 Armor Piercing. Навсегда добавляется в лут-пул рейдов (Лаборатория, Резерв) с шансом 1.8%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_m4a1_chimera",
            "name": "GD M4A1 «Chimera SpecOps»",
            "combat": 198,
            "rarity": "legendary",
            "price": 2500000,
            "locations": "Лаборатория, Резерв",
            "dropChance": "1.8%",
            "desc": "Ультимативный карабин M4A1 ресивера Vltor MUR-1S с патронами M995 Armor Piercing."
        },
        "raidDropUnlocked": "Открывает выпадение GD M4A1 «Chimera SpecOps» в рейдах (Лаборатория, Резерв) с шансом 1.8%"
    },
    {
        "level": 51,
        "exp": 39166,
        "totalExp": 766188,
        "title": "Финансирование: +30 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+30 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +30 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 52,
        "exp": 40290,
        "totalExp": 806478,
        "title": "Финансирование: +31 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+31 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +31 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 53,
        "exp": 41420,
        "totalExp": 847898,
        "title": "Модификатор: Экстра-ячейка рейдового лута",
        "category": "drop_enhancer",
        "rarity": "epic",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "Максимальное количество предметов из каждого рейда увеличено на +1.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 54,
        "exp": 42554,
        "totalExp": 890452,
        "title": "Титул профиля: [Каратель Синдиката]",
        "category": "title",
        "rarity": "epic",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Каратель Синдиката]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 55,
        "exp": 43693,
        "totalExp": 934145,
        "title": "Оружие: GD АШ-12 12.7x55 «Behemoth»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +208",
        "stat": "Мощь: 208 | Дроп: 1.5% (Лаборатория, Резерв)",
        "description": "Крупнокалиберный штурмовой монстр 12.7 мм с пулями ПС-12Б, пробивающими 6 класс брони. Навсегда добавляется в лут-пул рейдов (Лаборатория, Резерв) с шансом 1.5%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_ash12_behemoth",
            "name": "GD АШ-12 12.7x55 «Behemoth»",
            "combat": 208,
            "rarity": "mythic",
            "price": 3200000,
            "locations": "Лаборатория, Резерв",
            "dropChance": "1.5%",
            "desc": "Крупнокалиберный штурмовой монстр 12.7 мм с пулями ПС-12Б, пробивающими 6 класс брони."
        },
        "raidDropUnlocked": "Открывает выпадение GD АШ-12 12.7x55 «Behemoth» в рейдах (Лаборатория, Резерв) с шансом 1.5%"
    },
    {
        "level": 56,
        "exp": 44837,
        "totalExp": 978982,
        "title": "Финансирование: +34 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+34 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +34 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 57,
        "exp": 45986,
        "totalExp": 1024968,
        "title": "Финансирование: +34 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+34 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +34 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 58,
        "exp": 47140,
        "totalExp": 1072108,
        "title": "🎖️ Нейро-интерфейс боевого опыта",
        "category": "mechanic",
        "rarity": "legendary",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Рейдовый опыт профиля ЧВК удваивается (+100% EXP за любые рейды).",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 59,
        "exp": 48298,
        "totalExp": 1120406,
        "title": "Экипировка: Берцы GD Heavy Assault",
        "category": "outfit",
        "rarity": "legendary",
        "badge": "Гардероб (Обувь)",
        "stat": "Слот: Обувь",
        "description": "Тяжелые десантные берцы со стальным подноском и кевларовой стелькой. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 60,
        "exp": 49461,
        "totalExp": 1169867,
        "title": "Оружие: GD СВД-М «Phantom Longshot»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +218",
        "stat": "Мощь: 218 | Дроп: 1.4% (Лес, Резерв)",
        "description": "Снайперская винтовка Драгунова в шасси SAG с прицелом Nightforce ATACR 7-35x56. Навсегда добавляется в лут-пул рейдов (Лес, Резерв) с шансом 1.4%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_svd_phantom",
            "name": "GD СВД-М «Phantom Longshot»",
            "combat": 218,
            "rarity": "mythic",
            "price": 3600000,
            "locations": "Лес, Резерв",
            "dropChance": "1.4%",
            "desc": "Снайперская винтовка Драгунова в шасси SAG с прицелом Nightforce ATACR 7-35x56."
        },
        "raidDropUnlocked": "Открывает выпадение GD СВД-М «Phantom Longshot» в рейдах (Лес, Резерв) с шансом 1.4%"
    },
    {
        "level": 61,
        "exp": 77983,
        "totalExp": 1247850,
        "title": "Финансирование: +37 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+37 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +37 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 62,
        "exp": 80550,
        "totalExp": 1328400,
        "title": "Финансирование: +38 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+38 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +38 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 63,
        "exp": 83133,
        "totalExp": 1411533,
        "title": "Модификатор: Охотник за ключ-картами",
        "category": "drop_enhancer",
        "rarity": "epic",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+25% к шансу выпадения цветных Ключ-Карт Лаборатории в любых рейдах.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 64,
        "exp": 85732,
        "totalExp": 1497265,
        "title": "🛩️ Авто-десантирование контейнера GD",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Каждые 4 часа на базу бесплатно доставляется элитный военный контейнер GD с броней и пушками.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 65,
        "exp": 88345,
        "totalExp": 1585610,
        "title": "Оружие: GD M1A SOCOM «Juggernaut»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +226",
        "stat": "Мощь: 226 | Дроп: 1.3% (Лаборатория, Резерв)",
        "description": "Тяжелая винтовка в ложе SAGE EBR с барабаном на 50 патронов M61. Навсегда добавляется в лут-пул рейдов (Лаборатория, Резерв) с шансом 1.3%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_m1a_juggernaut",
            "name": "GD M1A SOCOM «Juggernaut»",
            "combat": 226,
            "rarity": "mythic",
            "price": 4100000,
            "locations": "Лаборатория, Резерв",
            "dropChance": "1.3%",
            "desc": "Тяжелая винтовка в ложе SAGE EBR с барабаном на 50 патронов M61."
        },
        "raidDropUnlocked": "Открывает выпадение GD M1A SOCOM «Juggernaut» в рейдах (Лаборатория, Резерв) с шансом 1.3%"
    },
    {
        "level": 66,
        "exp": 90974,
        "totalExp": 1676584,
        "title": "Финансирование: +41 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+41 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +41 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 67,
        "exp": 93618,
        "totalExp": 1770202,
        "title": "Финансирование: +42 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+42 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +42 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 68,
        "exp": 96278,
        "totalExp": 1866480,
        "title": "Титул профиля: [Командир Спецотряда GD]",
        "category": "title",
        "rarity": "epic",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Командир Спецотряда GD]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 69,
        "exp": 98952,
        "totalExp": 1965432,
        "title": "Финансирование: +44 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+44 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +44 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 70,
        "exp": 101642,
        "totalExp": 2067074,
        "title": "Оружие: GD ПКМ «Black Division SpecOps»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +235",
        "stat": "Мощь: 235 | Дроп: 1.2% (Резерв, Кооп-рейды)",
        "description": "Пулемет 7.62x54R с укороченным стволом и коробом на 200 патронов повышенного давления Б-32. Навсегда добавляется в лут-пул рейдов (Резерв, Кооп-рейды) с шансом 1.2%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_pkm_black_division",
            "name": "GD ПКМ «Black Division SpecOps»",
            "combat": 235,
            "rarity": "mythic",
            "price": 4800000,
            "locations": "Резерв, Кооп-рейды",
            "dropChance": "1.2%",
            "desc": "Пулемет 7.62x54R с укороченным стволом и коробом на 200 патронов повышенного давления Б-32."
        },
        "raidDropUnlocked": "Открывает выпадение GD ПКМ «Black Division SpecOps» в рейдах (Резерв, Кооп-рейды) с шансом 1.2%"
    },
    {
        "level": 71,
        "exp": 104346,
        "totalExp": 2171420,
        "title": "Финансирование: +46 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+46 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +46 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 72,
        "exp": 107066,
        "totalExp": 2278486,
        "title": "🛡️ Дипломатический щит Black Division",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Штраф 2-часового кулдауна за поражение в Кооперативном рейде снижается до 30 минут.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 73,
        "exp": 109800,
        "totalExp": 2388286,
        "title": "Модификатор: Бонус рейдового золота IV",
        "category": "drop_enhancer",
        "rarity": "epic",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+12% к сумме выносимых рублей из рейдов.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 74,
        "exp": 112549,
        "totalExp": 2500835,
        "title": "Экипировка: Золотой шеврон Shadow Operative",
        "category": "outfit",
        "rarity": "legendary",
        "badge": "Гардероб (Аксессуар)",
        "stat": "Слот: Аксессуар",
        "description": "Эксклюзивный наплечный патч из чистого золота 999 пробы. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 75,
        "exp": 115313,
        "totalExp": 2616148,
        "title": "Оружие: GD FN SCAR-H «Titan Vanguard»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +245",
        "stat": "Мощь: 245 | Дроп: 1.1% (Лаборатория, Кооп-рейды)",
        "description": "Тяжелая боевая штурмовая система 7.62x51 в расцветке Midnight Stealth с HUD-счетчиком. Навсегда добавляется в лут-пул рейдов (Лаборатория, Кооп-рейды) с шансом 1.1%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_scar_h_titan",
            "name": "GD FN SCAR-H «Titan Vanguard»",
            "combat": 245,
            "rarity": "mythic",
            "price": 5500000,
            "locations": "Лаборатория, Кооп-рейды",
            "dropChance": "1.1%",
            "desc": "Тяжелая боевая штурмовая система 7.62x51 в расцветке Midnight Stealth с HUD-счетчиком."
        },
        "raidDropUnlocked": "Открывает выпадение GD FN SCAR-H «Titan Vanguard» в рейдах (Лаборатория, Кооп-рейды) с шансом 1.1%"
    },
    {
        "level": 76,
        "exp": 118091,
        "totalExp": 2734239,
        "title": "Финансирование: +50 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+50 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +50 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 77,
        "exp": 120884,
        "totalExp": 2855123,
        "title": "Финансирование: +51 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+51 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +51 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 78,
        "exp": 123692,
        "totalExp": 2978815,
        "title": "Титул профиля: [Владыка Черного Рынка]",
        "category": "title",
        "rarity": "epic",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Владыка Черного Рынка]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 79,
        "exp": 126514,
        "totalExp": 3105329,
        "title": "Финансирование: +52 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+52 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +52 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 80,
        "exp": 129350,
        "totalExp": 3234679,
        "title": "Оружие: GD DVL-10 «Eclipse Saboteur»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +255",
        "stat": "Мощь: 255 | Дроп: 1.0% (Лес, Лаборатория)",
        "description": "Бесшумная снайперская винтовка Лобаева с тяжелыми дозвуковыми патронами GD Sub-X. Навсегда добавляется в лут-пул рейдов (Лес, Лаборатория) с шансом 1.0%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_dvl10_eclipse",
            "name": "GD DVL-10 «Eclipse Saboteur»",
            "combat": 255,
            "rarity": "mythic",
            "price": 6200000,
            "locations": "Лес, Лаборатория",
            "dropChance": "1.0%",
            "desc": "Бесшумная снайперская винтовка Лобаева с тяжелыми дозвуковыми патронами GD Sub-X."
        },
        "raidDropUnlocked": "Открывает выпадение GD DVL-10 «Eclipse Saboteur» в рейдах (Лес, Лаборатория) с шансом 1.0%"
    },
    {
        "level": 81,
        "exp": 132201,
        "totalExp": 3366880,
        "title": "Финансирование: +54 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+54 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +54 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 82,
        "exp": 135067,
        "totalExp": 3501947,
        "title": "🛰️ Спутниковая эвакуация оружия",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "При гибели всего отряда в рейде гарантированно спасается самое дорогое экипированное оружие.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 83,
        "exp": 137946,
        "totalExp": 3639893,
        "title": "Модификатор: Спец-дроп контейнеров",
        "category": "drop_enhancer",
        "rarity": "epic",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "Шанс найти редкие военные кейсы в тайниках Резерва и Лаборатории +4%.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 84,
        "exp": 140840,
        "totalExp": 3780733,
        "title": "Финансирование: +57 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+57 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +57 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 85,
        "exp": 143748,
        "totalExp": 3924481,
        "title": "Оружие: GD ПКП «Печенег-Омега»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +265",
        "stat": "Мощь: 265 | Дроп: 0.9% (Резерв, Лаборатория)",
        "description": "Штурмовой пулемет непрерывного охлаждения с лентой бронебойно-зажигательных патронов 7Н13. Навсегда добавляется в лут-пул рейдов (Резерв, Лаборатория) с шансом 0.9%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_pkp_omega",
            "name": "GD ПКП «Печенег-Омега»",
            "combat": 265,
            "rarity": "mythic",
            "price": 7000000,
            "locations": "Резерв, Лаборатория",
            "dropChance": "0.9%",
            "desc": "Штурмовой пулемет непрерывного охлаждения с лентой бронебойно-зажигательных патронов 7Н13."
        },
        "raidDropUnlocked": "Открывает выпадение GD ПКП «Печенег-Омега» в рейдах (Резерв, Лаборатория) с шансом 0.9%"
    },
    {
        "level": 86,
        "exp": 146670,
        "totalExp": 4071151,
        "title": "Финансирование: +59 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+59 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +59 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 87,
        "exp": 149606,
        "totalExp": 4220757,
        "title": "Финансирование: +60 000 000 ₽",
        "category": "currency",
        "rarity": "epic",
        "badge": "Наличные рубли",
        "stat": "+60 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +60 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 88,
        "exp": 152556,
        "totalExp": 4373313,
        "title": "Титул профиля: [Генерал Теневого Авангарда]",
        "category": "title",
        "rarity": "epic",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Генерал Теневого Авангарда]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 89,
        "exp": 155520,
        "totalExp": 4528833,
        "title": "Экипировка: Экзо-шлем GD Titan Apex",
        "category": "outfit",
        "rarity": "legendary",
        "badge": "Гардероб (Головной убор)",
        "stat": "Слот: Головной убор",
        "description": "Композитный боевой шлем со встроенным тактическим визором дополненной реальности. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 90,
        "exp": 158498,
        "totalExp": 4687331,
        "title": "Оружие: GD Barrett MRAD «Overkill .338»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +275",
        "stat": "Мощь: 275 | Дроп: 0.8% (Лаборатория, Кооп-рейды)",
        "description": "Модульная антиматериальная снайперка .338 Lapua с тепловизором Trijicon REAP-IR. Навсегда добавляется в лут-пул рейдов (Лаборатория, Кооп-рейды) с шансом 0.8%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_mrad_overkill",
            "name": "GD Barrett MRAD «Overkill .338»",
            "combat": 275,
            "rarity": "mythic",
            "price": 8000000,
            "locations": "Лаборатория, Кооп-рейды",
            "dropChance": "0.8%",
            "desc": "Модульная антиматериальная снайперка .338 Lapua с тепловизором Trijicon REAP-IR."
        },
        "raidDropUnlocked": "Открывает выпадение GD Barrett MRAD «Overkill .338» в рейдах (Лаборатория, Кооп-рейды) с шансом 0.8%"
    },
    {
        "level": 91,
        "exp": 161490,
        "totalExp": 4848821,
        "title": "Финансирование: +63 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+63 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +63 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 92,
        "exp": 164496,
        "totalExp": 5013317,
        "title": "📈 Теневой арбитраж Скупщика",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "+15% к цене продажи любых предметов и хабара Прапору и Скупщику.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 93,
        "exp": 167515,
        "totalExp": 5180832,
        "title": "Модификатор: Экстра-ячейка рейдового лута II",
        "category": "drop_enhancer",
        "rarity": "legendary",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "Максимальное количество предметов из каждого рейда увеличено еще на +1.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 94,
        "exp": 170548,
        "totalExp": 5351380,
        "title": "Финансирование: +66 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+66 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +66 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 95,
        "exp": 173595,
        "totalExp": 5524975,
        "title": "Оружие: GD CheyTac M200 «Interceptor»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +285",
        "stat": "Мощь: 285 | Дроп: 0.7% (Лаборатория, Спецоперации)",
        "description": "Дальнобойная снайперская система .408 CheyTac со спутниковым баллистическим компьютером. Навсегда добавляется в лут-пул рейдов (Лаборатория, Спецоперации) с шансом 0.7%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_m200_interceptor",
            "name": "GD CheyTac M200 «Interceptor»",
            "combat": 285,
            "rarity": "mythic",
            "price": 9500000,
            "locations": "Лаборатория, Спецоперации",
            "dropChance": "0.7%",
            "desc": "Дальнобойная снайперская система .408 CheyTac со спутниковым баллистическим компьютером."
        },
        "raidDropUnlocked": "Открывает выпадение GD CheyTac M200 «Interceptor» в рейдах (Лаборатория, Спецоперации) с шансом 0.7%"
    },
    {
        "level": 96,
        "exp": 176656,
        "totalExp": 5701631,
        "title": "Финансирование: +68 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+68 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +68 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 97,
        "exp": 179730,
        "totalExp": 5881361,
        "title": "Финансирование: +69 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+69 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +69 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 98,
        "exp": 182818,
        "totalExp": 6064179,
        "title": "Титул профиля: [Мастер Смерти GD]",
        "category": "title",
        "rarity": "epic",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Мастер Смерти GD]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 99,
        "exp": 185920,
        "totalExp": 6250099,
        "title": "Финансирование: +71 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+71 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +71 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 100,
        "exp": 189034,
        "totalExp": 6439133,
        "title": "Оружие: GD M32A1 «Apocalypse Multi-Launcher»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +298",
        "stat": "Мощь: 298 | Дроп: 0.6% (Лаборатория (Ультра/Colossal))",
        "description": "Шестизарядный 40-мм револьверный гранатомет с кумулятивно-осколочными выстрелами M433. Навсегда добавляется в лут-пул рейдов (Лаборатория (Ультра/Colossal)) с шансом 0.6%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_m32a1_apocalypse",
            "name": "GD M32A1 «Apocalypse Multi-Launcher»",
            "combat": 298,
            "rarity": "mythic",
            "price": 12000000,
            "locations": "Лаборатория (Ультра/Colossal)",
            "dropChance": "0.6%",
            "desc": "Шестизарядный 40-мм револьверный гранатомет с кумулятивно-осколочными выстрелами M433."
        },
        "raidDropUnlocked": "Открывает выпадение GD M32A1 «Apocalypse Multi-Launcher» в рейдах (Лаборатория (Ультра/Colossal)) с шансом 0.6%"
    },
    {
        "level": 101,
        "exp": 363274,
        "totalExp": 6802407,
        "title": "Финансирование: +73 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+73 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +73 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 102,
        "exp": 370938,
        "totalExp": 7173345,
        "title": "Финансирование: +74 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+74 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +74 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 103,
        "exp": 378646,
        "totalExp": 7551991,
        "title": "Модификатор: Золотой слиток в рейде",
        "category": "drop_enhancer",
        "rarity": "legendary",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "10% шанс найти Чистый Золотой Слиток (стоимость 15,000,000 ₽) в Лаборатории.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 104,
        "exp": 386397,
        "totalExp": 7938388,
        "title": "Экипировка: Штурмовой экзокостюм GD-01",
        "category": "outfit",
        "rarity": "mythic",
        "badge": "Гардероб (Костюм)",
        "stat": "Слот: Костюм",
        "description": "Тяжелый композитный силовой костюм с сервоприводами поддержки бойца. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 105,
        "exp": 394191,
        "totalExp": 8332579,
        "title": "🦾 Кибернетические стимуляторы ЧВК",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Все бойцы вашего отряда навсегда получают +25 Combat и +20 Armor.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 106,
        "exp": 402028,
        "totalExp": 8734607,
        "title": "Финансирование: +78 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+78 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +78 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 107,
        "exp": 409908,
        "totalExp": 9144515,
        "title": "Финансирование: +79 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+79 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +79 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 108,
        "exp": 417831,
        "totalExp": 9562346,
        "title": "Титул профиля: [Инквизитор TerraGroup]",
        "category": "title",
        "rarity": "legendary",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Инквизитор TerraGroup]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 109,
        "exp": 425797,
        "totalExp": 9988143,
        "title": "Финансирование: +81 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+81 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +81 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 110,
        "exp": 433805,
        "totalExp": 10421948,
        "title": "Оружие: GD Mk-18 «Mjolnir Void .338»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +308",
        "stat": "Мощь: 308 | Дроп: 0.5% (Лаборатория, Кооп Colossal)",
        "description": "Полуавтоматический зверь .338 LM, прошивающий бронированные укрытия насквозь. Навсегда добавляется в лут-пул рейдов (Лаборатория, Кооп Colossal) с шансом 0.5%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_mk18_void",
            "name": "GD Mk-18 «Mjolnir Void .338»",
            "combat": 308,
            "rarity": "mythic",
            "price": 15000000,
            "locations": "Лаборатория, Кооп Colossal",
            "dropChance": "0.5%",
            "desc": "Полуавтоматический зверь .338 LM, прошивающий бронированные укрытия насквозь."
        },
        "raidDropUnlocked": "Открывает выпадение GD Mk-18 «Mjolnir Void .338» в рейдах (Лаборатория, Кооп Colossal) с шансом 0.5%"
    },
    {
        "level": 111,
        "exp": 441856,
        "totalExp": 10863804,
        "title": "Финансирование: +83 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+83 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +83 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 112,
        "exp": 449950,
        "totalExp": 11313754,
        "title": "Финансирование: +84 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+84 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +84 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 113,
        "exp": 458087,
        "totalExp": 11771841,
        "title": "Модификатор: Бонус рейдового золота V",
        "category": "drop_enhancer",
        "rarity": "legendary",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+15% к сумме выносимых рублей из рейдов.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 114,
        "exp": 466266,
        "totalExp": 12238107,
        "title": "Финансирование: +86 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+86 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +86 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 115,
        "exp": 474488,
        "totalExp": 12712595,
        "title": "⚡ Оверклокинг Биткоин-фермы",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Скорость майнинга фермы видеокарт в убежище навсегда увеличивается на +30%.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 116,
        "exp": 482752,
        "totalExp": 13195347,
        "title": "Финансирование: +88 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+88 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +88 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 117,
        "exp": 491058,
        "totalExp": 13686405,
        "title": "Финансирование: +89 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+89 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +89 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 118,
        "exp": 499407,
        "totalExp": 14185812,
        "title": "Титул профиля: [Архитектор Войны]",
        "category": "title",
        "rarity": "legendary",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Архитектор Войны]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 119,
        "exp": 507798,
        "totalExp": 14693610,
        "title": "Экипировка: Тактические сапоги GD Imperator",
        "category": "outfit",
        "rarity": "mythic",
        "badge": "Гардероб (Обувь)",
        "stat": "Слот: Обувь",
        "description": "Непробиваемая обувь из титановых пластин и графеновой мембраны. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 120,
        "exp": 516231,
        "totalExp": 15209841,
        "title": "Оружие: GD Experimental Assault Unit «Nemesis»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +318",
        "stat": "Мощь: 318 | Дроп: 0.4% (Все элитные зоны)",
        "description": "Сверхсекретная штурмовая система Black Division с электромагнитным досылателем пуль. Навсегда добавляется в лут-пул рейдов (Все элитные зоны) с шансом 0.4%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_nemesis_prototype",
            "name": "GD Experimental Assault Unit «Nemesis»",
            "combat": 318,
            "rarity": "mythic",
            "price": 18500000,
            "locations": "Все элитные зоны",
            "dropChance": "0.4%",
            "desc": "Сверхсекретная штурмовая система Black Division с электромагнитным досылателем пуль."
        },
        "raidDropUnlocked": "Открывает выпадение GD Experimental Assault Unit «Nemesis» в рейдах (Все элитные зоны) с шансом 0.4%"
    },
    {
        "level": 121,
        "exp": 524707,
        "totalExp": 15734548,
        "title": "Финансирование: +94 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+94 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +94 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 122,
        "exp": 533224,
        "totalExp": 16267772,
        "title": "Финансирование: +95 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+95 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +95 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 123,
        "exp": 541784,
        "totalExp": 16809556,
        "title": "Модификатор: Абсолютный оружейный дроп",
        "category": "drop_enhancer",
        "rarity": "legendary",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+50% к шансу выпадения разблокированного оружия GD во всех рейдах.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 124,
        "exp": 550386,
        "totalExp": 17359942,
        "title": "🏛️ Подземный арсенал: Схрон +200",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Колоссальное расширение склада: +200 дополнительных слотов.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 125,
        "exp": 559029,
        "totalExp": 17918971,
        "title": "Транш: 6.5 BTC",
        "category": "currency",
        "rarity": "mythic",
        "badge": "Криптовалюта",
        "stat": "+6.5 BTC",
        "description": "Прямой перевод криптовалюты на ваш криптокошелек в убежище: +6.5 Биткоина (чистая прибыль).",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 126,
        "exp": 567715,
        "totalExp": 18486686,
        "title": "Титул профиля: [Маршал Темного Сектора]",
        "category": "title",
        "rarity": "legendary",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Маршал Темного Сектора]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 127,
        "exp": 576442,
        "totalExp": 19063128,
        "title": "Финансирование: +100 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+100 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +100 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 128,
        "exp": 585212,
        "totalExp": 19648340,
        "title": "🚁 Эвакуационный конвертоплан GD",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Шанс выживания во всех рейдах возрастает на +15% (даже при низкой боевой мощи отряда).",
        "isMilestone": True,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 129,
        "exp": 594023,
        "totalExp": 20242363,
        "title": "Финансирование: +102 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+102 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +102 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 130,
        "exp": 602876,
        "totalExp": 20845239,
        "title": "Оружие: GD Импульсный карабин «Arc Valkyrie»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +328",
        "stat": "Мощь: 328 | Дроп: 0.3% (Лаборатория, Спецоперации)",
        "description": "Опытный прототип с плазменной ионизацией пороховых газов, удваивающей кинетическую энергию. Навсегда добавляется в лут-пул рейдов (Лаборатория, Спецоперации) с шансом 0.3%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_arc_valkyrie",
            "name": "GD Импульсный карабин «Arc Valkyrie»",
            "combat": 328,
            "rarity": "mythic",
            "price": 22000000,
            "locations": "Лаборатория, Спецоперации",
            "dropChance": "0.3%",
            "desc": "Опытный прототип с плазменной ионизацией пороховых газов, удваивающей кинетическую энергию."
        },
        "raidDropUnlocked": "Открывает выпадение GD Импульсный карабин «Arc Valkyrie» в рейдах (Лаборатория, Спецоперации) с шансом 0.3%"
    },
    {
        "level": 131,
        "exp": 611770,
        "totalExp": 21457009,
        "title": "Финансирование: +104 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+104 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +104 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 132,
        "exp": 620706,
        "totalExp": 22077715,
        "title": "Финансирование: +105 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+105 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +105 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 133,
        "exp": 629684,
        "totalExp": 22707399,
        "title": "Модификатор: Крипто-джекпот рейда",
        "category": "drop_enhancer",
        "rarity": "legendary",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+5% шанс вынести из Лаборатории сразу 2 чистых Биткоина (2.0 BTC).",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 134,
        "exp": 638703,
        "totalExp": 23346102,
        "title": "Финансирование: +108 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+108 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +108 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 135,
        "exp": 647764,
        "totalExp": 23993866,
        "title": "👁️ Спутниковое подавление боссов",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Шанс поражения в засадах боссов снижен до абсолютного минимума (-60% к урону боссов).",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 136,
        "exp": 656866,
        "totalExp": 24650732,
        "title": "Титул профиля: [Призрак-Главнокомандующий]",
        "category": "title",
        "rarity": "legendary",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Призрак-Главнокомандующий]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 137,
        "exp": 666009,
        "totalExp": 25316741,
        "title": "Финансирование: +111 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+111 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +111 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 138,
        "exp": 675194,
        "totalExp": 25991935,
        "title": "🚀 Орбитальный удар возмездия GD",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Раз в 12 часов гарантированная победа в любом рейде со 100% выживанием и 3x лутом!",
        "isMilestone": True,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 139,
        "exp": 684420,
        "totalExp": 26676355,
        "title": "Экипировка: Плащ Теневого Командора GD",
        "category": "outfit",
        "rarity": "mythic",
        "badge": "Гардероб (Костюм)",
        "stat": "Слот: Костюм",
        "description": "Легендарный баллистический плащ высшего командования с гербом GD Military. Эксклюзивный предмет гардероба от GD Military. Добавляется в ваш гардероб «Шота у Ашота».",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 140,
        "exp": 693688,
        "totalExp": 27370043,
        "title": "Оружие: GD Barrett .50 BMG «Doomsday»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +338",
        "stat": "Мощь: 338 | Дроп: 0.2% (Лаборатория, Спецоперации)",
        "description": "Антиматериальный разрушитель 12.7x99 NATO с дульным тормозом активного демпфирования. Навсегда добавляется в лут-пул рейдов (Лаборатория, Спецоперации) с шансом 0.2%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_barrett_doomsday",
            "name": "GD Barrett .50 BMG «Doomsday»",
            "combat": 338,
            "rarity": "mythic",
            "price": 26000000,
            "locations": "Лаборатория, Спецоперации",
            "dropChance": "0.2%",
            "desc": "Антиматериальный разрушитель 12.7x99 NATO с дульным тормозом активного демпфирования."
        },
        "raidDropUnlocked": "Открывает выпадение GD Barrett .50 BMG «Doomsday» в рейдах (Лаборатория, Спецоперации) с шансом 0.2%"
    },
    {
        "level": 141,
        "exp": 702996,
        "totalExp": 28073039,
        "title": "Финансирование: +116 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+116 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +116 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 142,
        "exp": 712346,
        "totalExp": 28785385,
        "title": "Финансирование: +117 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+117 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +117 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 143,
        "exp": 721737,
        "totalExp": 29507122,
        "title": "Модификатор: Рейдовый множитель Black Division",
        "category": "drop_enhancer",
        "rarity": "legendary",
        "badge": "Рейдовый бафф",
        "stat": "Постоянное улучшение лута",
        "description": "+25% к денежной награде за эвакуацию из любых локаций.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": "Улучшает лут-генератор во всех будущих рейдах"
    },
    {
        "level": 144,
        "exp": 731169,
        "totalExp": 30238291,
        "title": "⛽ Неиссякаемый генераторный контур",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Генератор убежища больше не потребляет канистры с топливом — вечная бесплатная энергия!",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 145,
        "exp": 740642,
        "totalExp": 30978933,
        "title": "Оружие: GD Кинетический Дисраптор «Chronos»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +344",
        "stat": "Мощь: 344 | Дроп: 0.15% (Самые опасные рейды)",
        "description": "Квантовое ручное орудие, генерирующее направленные кинетические импульсы сверхвысокой плотности. Навсегда добавляется в лут-пул рейдов (Самые опасные рейды) с шансом 0.15%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_kinetic_chronos",
            "name": "GD Кинетический Дисраптор «Chronos»",
            "combat": 344,
            "rarity": "mythic",
            "price": 30000000,
            "locations": "Самые опасные рейды",
            "dropChance": "0.15%",
            "desc": "Квантовое ручное орудие, генерирующее направленные кинетические импульсы сверхвысокой плотности."
        },
        "raidDropUnlocked": "Открывает выпадение GD Кинетический Дисраптор «Chronos» в рейдах (Самые опасные рейды) с шансом 0.15%"
    },
    {
        "level": 146,
        "exp": 750156,
        "totalExp": 31729089,
        "title": "Титул профиля: [Абсолютный Повелитель Таркова]",
        "category": "title",
        "rarity": "legendary",
        "badge": "Престижный титул",
        "stat": "Статус в чате и профиле",
        "description": "Элитный почетный титул частной военной компании GD Military: [Абсолютный Повелитель Таркова]. Отображается перед ником во всех меню и таблице лидеров.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 147,
        "exp": 759711,
        "totalExp": 32488800,
        "title": "Финансирование: +123 000 000 ₽",
        "category": "currency",
        "rarity": "legendary",
        "badge": "Наличные рубли",
        "stat": "+123 000 000 ₽",
        "description": "Секретный военный транш от генерального штаба GD Military на баланс вашего ЧВК: +123 000 000 ₽.",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 148,
        "exp": 769307,
        "totalExp": 33258107,
        "title": "🌌 Квантовый маяк сохранения ЧВК",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Бойцы ЧВК становятся бессмертными: при поражении они не погибают, а восстанавливаются за 5 минут.",
        "isMilestone": True,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 149,
        "exp": 778944,
        "totalExp": 34037051,
        "title": "👑 Право вето в Совете Синдиката",
        "category": "mechanic",
        "rarity": "mythic",
        "badge": "Новая механика",
        "stat": "Перманентный апгрейд",
        "description": "Комиссия барахолки 0%, все экономические кризисы приносят вам исключительно прибыль (+40%).",
        "isMilestone": False,
        "weapon": None,
        "raidDropUnlocked": None
    },
    {
        "level": 150,
        "exp": 788621,
        "totalExp": 34825672,
        "title": "Оружие: GD-Railgun M-150 «Экстерминатор»",
        "category": "weapon",
        "rarity": "mythic",
        "badge": "Combat +350",
        "stat": "Мощь: 350 | Дроп: 0.1% (Все рейды высшей сложности)",
        "description": "Венец военно-инженерной мысли GD Military. Портативный рельсовый ускоритель гиперзвуковых вольфрамовых игл (скорость снаряда 3200 м/с). Мгновенное устранение любой цели! Навсегда добавляется в лут-пул рейдов (Все рейды высшей сложности) с шансом 0.1%!",
        "isMilestone": True,
        "weapon": {
            "id": "gd_railgun_exterminator",
            "name": "GD-Railgun M-150 «Экстерминатор»",
            "combat": 350,
            "rarity": "mythic",
            "price": 50000000,
            "locations": "Все рейды высшей сложности",
            "dropChance": "0.1%",
            "desc": "Венец военно-инженерной мысли GD Military. Портативный рельсовый ускоритель гиперзвуковых вольфрамовых игл (скорость снаряда 3200 м/с). Мгновенное устранение любой цели!"
        },
        "raidDropUnlocked": "Открывает выпадение GD-Railgun M-150 «Экстерминатор» в рейдах (Все рейды высшей сложности) с шансом 0.1%"
    }
]

def has_gd_business(user: Dict[str, Any]) -> bool:
    if not user:
        return False
    return bool(user.get("special_businesses", {}).get("gd_shadow_agent"))

def get_gd_bp_state(user: Dict[str, Any]) -> Dict[str, Any]:
    if "gd_battlepass" not in user:
        user["gd_battlepass"] = {
            "level": 1,
            "current_exp": 0,
            "total_exp": 0,
            "claimed_levels": [],
            "unlocked_weapons": [],
            "perks": {},
            "titles": []
        }
    return user["gd_battlepass"]

def add_gd_bp_exp(user: Dict[str, Any], amount: int) -> Dict[str, Any]:
    if not has_gd_business(user) or amount <= 0:
        return {"leveled_up": False, "levels_gained": 0, "new_level": 1, "exp_added": 0}
    
    state = get_gd_bp_state(user)
    curr_lvl = state.get("level", 1)
    if curr_lvl >= 150:
        return {
            "leveled_up": False,
            "levels_gained": 0,
            "new_level": 150,
            "exp_added": amount,
            "current_exp": state.get("current_exp", 0),
            "need_exp": 0,
            "new_rewards": []
        }
    
    state["current_exp"] = state.get("current_exp", 0) + amount
    state["total_exp"] = state.get("total_exp", 0) + amount
    
    levels_gained = 0
    new_unlocked_rewards = []
    
    while curr_lvl < 150:
        req_exp = GD_BATTLEPASS_LEVELS[curr_lvl - 1]["exp"]
        if state["current_exp"] >= req_exp:
            state["current_exp"] -= req_exp
            curr_lvl += 1
            levels_gained += 1
            reward = GD_BATTLEPASS_LEVELS[curr_lvl - 1]
            new_unlocked_rewards.append(reward)
            _apply_level_reward(user, curr_lvl, reward)
        else:
            break
            
    state["level"] = curr_lvl
    need_exp = GD_BATTLEPASS_LEVELS[curr_lvl - 1]["exp"] if curr_lvl < 150 else 0
    return {
        "leveled_up": levels_gained > 0,
        "levels_gained": levels_gained,
        "new_level": curr_lvl,
        "exp_added": amount,
        "current_exp": state.get("current_exp", 0),
        "need_exp": need_exp,
        "new_rewards": new_unlocked_rewards
    }

def _apply_level_reward(user: Dict[str, Any], level_num: int, reward: Dict[str, Any]):
    state = get_gd_bp_state(user)
    if level_num not in state.get("claimed_levels", []):
        state.setdefault("claimed_levels", []).append(level_num)
        
    cat = reward.get("category")
    if cat == "weapon" and reward.get("weapon"):
        w_id = reward["weapon"]["id"]
        if w_id not in state.setdefault("unlocked_weapons", []):
            state["unlocked_weapons"].append(w_id)
        from tarkov_engine import can_store_item
        if can_store_item(user, w_id):
            now = int(time.time())
            user.setdefault("stash", []).append({
                "uid": f"gdw_{now}_{random.randint(1000, 9999)}",
                "item_id": w_id,
                "equipped_to": None
            })
    elif cat == "title":
        title_name = reward["title"].replace("Титул профиля: ", "")
        if title_name not in state.setdefault("titles", []):
            state["titles"].append(title_name)
            user["active_gd_title"] = title_name
        unlocked = user.setdefault("unlocked_titles", [])
        if title_name not in unlocked:
            unlocked.append(title_name)
        if not user.get("custom_title"):
            user["custom_title"] = title_name
    elif cat == "currency":
        stat = reward.get("stat", "")
        if "BTC" in stat:
            btc_val = float(stat.replace("+", "").replace("BTC", "").strip())
            user["btc"] = round(user.get("btc", 0.0) + btc_val, 2)
        elif "₽" in stat:
            rub_val = int(stat.replace("+", "").replace("₽", "").replace(" ", "").strip())
            from tarkov_engine import add_player_rubles
            add_player_rubles(user, rub_val)
    elif cat == "mechanic":
        state.setdefault("perks", {})[f"lvl_{level_num}"] = reward["title"]
    elif cat == "drop_enhancer":
        state.setdefault("drop_enhancers", []).append(reward["title"])
    elif cat == "case":
        # Military tactical crate reward - adds high-value rubles and components
        from tarkov_engine import add_player_rubles
        add_player_rubles(user, 15_000_000)
    elif cat == "outfit":
        # Military clothing item
        now = int(time.time())
        user.setdefault("clothes_stash", []).append({
            "uid": f"gdo_{now}_{random.randint(1000, 9999)}",
            "item_id": f"gd_outfit_lvl_{level_num}",
            "name": reward["title"],
            "equipped": False
        })

# Mapping of all Battle Pass weapon IDs to their exact unlock levels
BP_WEAPONS_LEVEL_MAP = {}
for _lvl in GD_BATTLEPASS_LEVELS:
    if _lvl.get("category") == "weapon" and _lvl.get("weapon"):
        BP_WEAPONS_LEVEL_MAP[_lvl["weapon"]["id"]] = _lvl["level"]

def roll_gd_raid_weapon(user: Dict[str, Any], location_key: str) -> Optional[Dict[str, Any]]:
    """
    Checks if player has unlocked weapons and rolls raid drop chance (3.5% - 5.5%).
    STRICT ENFORCEMENT: A weapon or piece of gear from the Battle Pass CAN ONLY drop
    if the player has activated the Battle Pass AND has reached its unlock level.
    If the player has not opened the BP or hasn't reached the item's level,
    it CANNOT drop under any circumstances.
    """
    if not has_gd_business(user):
        return None
    state = get_gd_bp_state(user)
    current_bp_level = state.get("level", 1)
    unlocked = state.get("unlocked_weapons", [])
    if not unlocked:
        return None
    
    # Filter strictly to weapons whose unlock level is <= current player's BP level
    eligible = [
        wid for wid in unlocked
        if wid in BP_WEAPONS_LEVEL_MAP and BP_WEAPONS_LEVEL_MAP[wid] <= current_bp_level
    ]
    if not eligible:
        return None
    
    drop_chance = 0.040
    if current_bp_level >= 123:
        drop_chance += 0.020
        
    if random.random() < drop_chance:
        chosen_id = random.choice(eligible)
        return GD_WEAPONS_CATALOG.get(chosen_id)
    return None

# ==================== BATTLE PASS STAGES CONFIG & UI ====================

STAGES_CONFIG = [
    {
        "stage": 1,
        "name": "Этап I: Оперативник Авангарда",
        "icon": "🟢",
        "levels": (1, 25),
        "desc": "Начальный этап службы: освоение спутникового радара, тактические контейнеры и базовое вооружение теневого агента.",
        "highlights": [
            "📡 Спутниковый радар GD (Ур. 1)",
            "🔫 GD Glock 19X, MP7A2, Vector .45, SR-25",
            "🎖️ Финальный титул: [Каратель Синдиката] (Ур. 25)",
            "🔫 GD АС ВАЛ «Night Stalker» (Ур. 25)"
        ]
    },
    {
        "stage": 2,
        "name": "Этап II: Теневой Синдикат",
        "icon": "🔵",
        "levels": (26, 50),
        "desc": "Интеграция в высшие торговые потоки: скорострельные карабины, миллионные транши и Биткоины синдиката.",
        "highlights": [
            "🔫 GD SIG MCX, M4A1 «Executioner», HK416A5, CMMG Mk47",
            "💵 Крупные финансовые транши и чистые BTC",
            "🎖️ Финальный титул: [Командир Спецотряда GD] (Ур. 50)",
            "🔫 GD DSA SA-58 «Titan» (Ур. 50)"
        ]
    },
    {
        "stage": 3,
        "name": "Этап III: Ветеран Спецопераций",
        "icon": "🟣",
        "levels": (51, 75),
        "desc": "Элитные штурмовые и снайперские комплексы для скрытых рейдов в закрытые зоны Резерва и Лаборатории.",
        "highlights": [
            "🔫 GD RD-704, АШ-12 «Behemoth», FN SCAR-H, Remington RSASS",
            "📦 Тактические контейнеры GD Tier II и гардероб агента",
            "🎖️ Финальный титул: [Владыка Черного Рынка] (Ур. 75)",
            "🔫 GD ДВЛ-10 Урбан «Eclipse» (Ур. 75)"
        ]
    },
    {
        "stage": 4,
        "name": "Этап IV: Командир Black Division",
        "icon": "🟡",
        "levels": (76, 100),
        "desc": "Командование тяжелыми ударными группами. Экспериментальные винтовки, пулеметы и тактическое доминирование.",
        "highlights": [
            "🔫 GD ORSIS T-5000, GD «Nemesis», M249 SAW, ПКП «Black Dragon»",
            "⚡ Постоянные перки дропа и защита от засад боссов",
            "🎖️ Финальный титул: [Генерал Теневого Авангарда] (Ур. 100)",
            "🔫 GD M1A EBR «Chimera» (Ур. 100)"
        ]
    },
    {
        "stage": 5,
        "name": "Этап V: Легенда TerraGroup & GD",
        "icon": "🔴",
        "levels": (101, 125),
        "desc": "Сверхсекретные технологии и футуристическое оружие: рельсотроны, ручные гранатометы и калибр .338 Lapua.",
        "highlights": [
            "🔫 GD ВСС «Shadow Lord», AXMC .338 «Oblivion», Milkor M32A1 MGL",
            "⚡ Prototype Coilgun-01 «Abyss» (Электромагнитный рельсотрон)",
            "🎖️ Финальный титул: [Инквизитор TerraGroup] (Ур. 125)",
            "🔫 GD SWORD Mk-18 Mjölnir «Cataclysm» (Ур. 125)"
        ]
    },
    {
        "stage": 6,
        "name": "Этап VI: Абсолютный Повелитель",
        "icon": "👑",
        "levels": (126, 150),
        "desc": "Финальная вершина боевой мощи Таркова. Колоссальные миллиардные транши, пушка Singularity и вечный статус.",
        "highlights": [
            "🔫 GD Ultra-Heavy Anti-Materiel «Singularity» (Мощь: 550)",
            "💎 +250 000 000 ₽ наличными и +25 BTC",
            "🎖️ Титул: [Призрак-Главнокомандующий] (Ур. 145)",
            "👑 АБСОЛЮТНЫЙ ТИТУЛ: [Абсолютный Повелитель Таркова] (Ур. 150)"
        ]
    }
]

def _fmt_rub(val: int) -> str:
    return f"{int(val):,} ₽".replace(",", " ")

def get_bp_stages_summary(user: Dict[str, Any]) -> List[Dict[str, Any]]:
    state = get_gd_bp_state(user)
    curr_lvl = state.get("level", 1)
    claimed = set(state.get("claimed_levels", []))
    
    stages_data = []
    for s in STAGES_CONFIG:
        s_num = s["stage"]
        start_l, end_l = s["levels"]
        
        # calculate completed levels in this stage
        if curr_lvl < start_l:
            completed = 0
            status_text = "🔒 Закрыт"
            badge = "🔒"
        elif curr_lvl >= end_l:
            completed = 25
            status_text = "✅ Завершен"
            badge = "✅"
        else:
            completed = curr_lvl - start_l + 1
            status_text = f"⚡ В процессе ({completed}/25)"
            badge = "⚡"
            
        stage_claimed = sum(1 for l in range(start_l, end_l + 1) if l in claimed)
        stage_available = max(0, min(curr_lvl, end_l) - start_l + 1) - stage_claimed
        
        stages_data.append({
            "stage": s_num,
            "name": s["name"],
            "icon": s["icon"],
            "levels": s["levels"],
            "desc": s["desc"],
            "highlights": s["highlights"],
            "completed": completed,
            "total": 25,
            "pct": int(completed / 25 * 100),
            "status_text": status_text,
            "badge": badge,
            "claimed_count": stage_claimed,
            "unclaimed_count": max(0, stage_available)
        })
    return stages_data

def get_unclaimed_rewards_count(user: Dict[str, Any]) -> int:
    state = get_gd_bp_state(user)
    curr_lvl = state.get("level", 1)
    claimed = set(state.get("claimed_levels", []))
    return sum(1 for lvl in range(1, curr_lvl + 1) if lvl not in claimed)

def claim_all_unclaimed_rewards(user: Dict[str, Any]) -> Tuple[int, List[str]]:
    state = get_gd_bp_state(user)
    curr_lvl = state.get("level", 1)
    claimed = state.setdefault("claimed_levels", [])
    
    claimed_titles = []
    claimed_count = 0
    
    for lvl in range(1, min(curr_lvl + 1, len(GD_BATTLEPASS_LEVELS) + 1)):
        if lvl not in claimed:
            reward = GD_BATTLEPASS_LEVELS[lvl - 1]
            _apply_level_reward(user, lvl, reward)
            claimed_titles.append(f"Ур. {lvl}: {reward['title']}")
            claimed_count += 1
            
    return claimed_count, claimed_titles

# UI Renderers for Telegram Bot
def render_bp_main_menu(user: Dict[str, Any]):
    try:
        from telebot import types
    except ImportError:
        import telebot
        from telebot import types

    state = get_gd_bp_state(user)
    curr_lvl = state.get("level", 1)
    curr_exp = state.get("current_exp", 0)
    total_exp = state.get("total_exp", 0)
    is_active = has_gd_business(user)
    unclaimed = get_unclaimed_rewards_count(user)
    
    req_exp = GD_BATTLEPASS_LEVELS[curr_lvl - 1]["exp"] if curr_lvl <= 150 else 0
    pct = int(min(1.0, curr_exp / max(1, req_exp)) * 100) if curr_lvl < 150 else 100
    
    # Visual Progress Bar (10 segments)
    filled = int(pct / 10)
    bar = "█" * filled + "░" * (10 - filled)
    
    status_str = "🟢 <b>Контракт GD активен (XP начисляется в рейдах)</b>" if is_active else "🔒 <b>Контракт не заключен (Требуется найм в «Элитных бизнесах»)</b>"
    
    # Current stage name
    current_stage_name = "Этап I"
    for s in STAGES_CONFIG:
        if s["levels"][0] <= curr_lvl <= s["levels"][1]:
            current_stage_name = s["name"]
            break
    if curr_lvl >= 150:
        current_stage_name = "👑 Пропуск полностью завершен!"
        
    stages_data = get_bp_stages_summary(user)
    
    txt = (
        f"🎖️ <b>БОЕВОЙ ПРОПУСК GD MILITARY (150 УРОВНЕЙ)</b>\n"
        f"────────────────────────\n"
        f"Статус: {status_str}\n"
        f"Текущий ранг: <b>{current_stage_name}</b>\n\n"
        f"🏆 <b>Уровень: {curr_lvl} / 150</b>\n"
        f"⚡ Опыт уровня: <b>{curr_exp:,} / {req_exp:,} XP</b>\n"
        f"Прогресс: <code>[{bar}] {pct}%</code>\n"
        f"Всего накоплено XP: <b>{total_exp:,}</b>\n"
        f"🎁 Неполученных наград: <b>{unclaimed} шт.</b>\n"
        f"────────────────────────\n"
        f"<b>ПРОГРЕССИЯ ПО ЭТАПАМ:</b>\n"
    )
    
    for s in stages_data:
        txt += f"• {s['icon']} <b>{s['name']}</b> ({s['levels'][0]}-{s['levels'][1]} ур.):\n"
        txt += f"   └ Прогресс: <b>{s['completed']}/25 ({s['pct']}%)</b> — {s['badge']} {s['status_text']}\n"
        
    txt += (
        f"────────────────────────\n"
        f"<i>Участвуйте в рейдах для прокачки пропуска! Награды выдаются автоматически при повышении уровня.</i>"
    )
    
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    if unclaimed > 0:
        markup.add(types.InlineKeyboardButton(f"🎁 Забрать все награды ({unclaimed} шт.)", callback_data="gd_bp_claim_all"))
        
    markup.add(
        types.InlineKeyboardButton("📑 Подробно по этапам", callback_data="gd_bp_stages_view_1"),
        types.InlineKeyboardButton("📜 Список 150 уровней", callback_data="gd_bp_levels_page_1")
    )
    markup.add(
        types.InlineKeyboardButton("🔫 Каталог 26 пушек GD", callback_data="gd_bp_weapons_page_1")
    )
    
    if not is_active:
        markup.add(types.InlineKeyboardButton("🛰️ Нанять Теневого сотрудника (5 млрд ₽)", callback_data="buy_spec_gd_shadow_agent"))
        
    markup.add(
        types.InlineKeyboardButton("🏢 Элитные Бизнесы", callback_data="menu_special_businesses"),
        types.InlineKeyboardButton("🏠 Главное Меню", callback_data="main_menu")
    )
    
    return txt, markup

def render_bp_stage_view(user: Dict[str, Any], stage_num: int):
    try:
        from telebot import types
    except ImportError:
        import telebot
        from telebot import types

    stage_num = max(1, min(6, stage_num))
    stage = STAGES_CONFIG[stage_num - 1]
    state = get_gd_bp_state(user)
    curr_lvl = state.get("level", 1)
    claimed = set(state.get("claimed_levels", []))
    
    start_l, end_l = stage["levels"]
    completed = max(0, min(25, curr_lvl - start_l + 1)) if curr_lvl >= start_l else 0
    pct = int(completed / 25 * 100)
    
    txt = (
        f"{stage['icon']} <b>БОЕВОЙ ПРОПУСК: {stage['name'].upper()}</b>\n"
        f"Диапазон: <b>Уровни {start_l} – {end_l}</b>\n"
        f"────────────────────────\n"
        f"<i>{stage['desc']}</i>\n\n"
        f"📊 Прогресс этапа: <b>{completed} / 25 уровней ({pct}%)</b>\n"
        f"🏆 Ваш текущий уровень БП: <b>{curr_lvl} / 150</b>\n\n"
        f"<b>⭐ Главные награды и трофеи этапа:</b>\n"
    )
    for h in stage["highlights"]:
        txt += f"• {h}\n"
        
    txt += f"\n<b>Список уровней этапа:</b>\n"
    
    for l_idx in range(start_l, end_l + 1):
        reward = GD_BATTLEPASS_LEVELS[l_idx - 1]
        if l_idx in claimed:
            st = "✅ Получено"
        elif l_idx <= curr_lvl:
            st = "🔓 ДОСТУПНО"
        else:
            st = f"🔒 Закрыто ({reward['exp']} XP)"
            
        r_icon = "🔫" if reward.get("category") == "weapon" else ("🎖️" if reward.get("category") == "title" else "🎁")
        txt += f"• <b>Ур. {l_idx}:</b> {r_icon} {reward['title']} — <i>{st}</i>\n"
        
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    # Navigation arrows
    prev_s = stage_num - 1 if stage_num > 1 else 6
    next_s = stage_num + 1 if stage_num < 6 else 1
    markup.add(
        types.InlineKeyboardButton(f"◀ Этап {prev_s}", callback_data=f"gd_bp_stages_view_{prev_s}"),
        types.InlineKeyboardButton(f"Этап {next_s} ▶", callback_data=f"gd_bp_stages_view_{next_s}")
    )
    
    # Quick stage jump row
    jump_btns = [
        types.InlineKeyboardButton(f"{s['icon']} {s['stage']}", callback_data=f"gd_bp_stages_view_{s['stage']}")
        for s in STAGES_CONFIG
    ]
    markup.row(*jump_btns[:3])
    markup.row(*jump_btns[3:])
    
    unclaimed = get_unclaimed_rewards_count(user)
    if unclaimed > 0:
        markup.add(types.InlineKeyboardButton(f"🎁 Забрать все награды ({unclaimed} шт.)", callback_data="gd_bp_claim_all"))
        
    markup.add(
        types.InlineKeyboardButton("🔙 Обзор Пропуска", callback_data="menu_gd_battlepass"),
        types.InlineKeyboardButton("🏠 Главное Меню", callback_data="main_menu")
    )
    return txt, markup

def render_bp_levels_page(user: Dict[str, Any], page: int = 1):
    try:
        from telebot import types
    except ImportError:
        import telebot
        from telebot import types

    total_pages = 15 # 150 levels / 10 per page
    page = max(1, min(total_pages, page))
    state = get_gd_bp_state(user)
    curr_lvl = state.get("level", 1)
    claimed = set(state.get("claimed_levels", []))
    
    start_lvl = (page - 1) * 10 + 1
    end_lvl = min(150, page * 10)
    
    txt = (
        f"📜 <b>СПИСОК УРОВНЕЙ И НАГРАД (Страница {page} / {total_pages})</b>\n"
        f"Уровни {start_lvl} – {end_lvl} из 150\n"
        f"────────────────────────\n"
    )
    
    for l_idx in range(start_lvl, end_lvl + 1):
        reward = GD_BATTLEPASS_LEVELS[l_idx - 1]
        if l_idx in claimed:
            st = "✅ <b>Получено</b>"
        elif l_idx <= curr_lvl:
            st = "🔓 <b>ДОСТУПНО К ПОЛУЧЕНИЮ!</b>"
        else:
            st = f"🔒 Закрыто (Требуется {reward['exp']} XP)"
            
        badge = f"[{reward.get('badge', 'Награда')}]"
        txt += f"• <b>Ур. {l_idx}:</b> {reward['title']}\n"
        txt += f"   └ {badge} {reward.get('stat', '')}\n"
        txt += f"   └ Статус: {st}\n"
        
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    prev_p = page - 1 if page > 1 else total_pages
    next_p = page + 1 if page < total_pages else 1
    markup.add(
        types.InlineKeyboardButton(f"◀ Стр. {prev_p}", callback_data=f"gd_bp_levels_page_{prev_p}"),
        types.InlineKeyboardButton(f"Стр. {next_p} ▶", callback_data=f"gd_bp_levels_page_{next_p}")
    )
    
    unclaimed = get_unclaimed_rewards_count(user)
    if unclaimed > 0:
        markup.add(types.InlineKeyboardButton(f"🎁 Забрать все награды ({unclaimed} шт.)", callback_data="gd_bp_claim_all"))
        
    markup.add(
        types.InlineKeyboardButton("🔙 Обзор Пропуска", callback_data="menu_gd_battlepass"),
        types.InlineKeyboardButton("🏠 Главное Меню", callback_data="main_menu")
    )
    return txt, markup

def render_bp_weapons_page(page: int = 1):
    try:
        from telebot import types
    except ImportError:
        import telebot
        from telebot import types

    w_list = list(GD_WEAPONS_CATALOG.values())
    per_page = 9
    total_pages = (len(w_list) + per_page - 1) // per_page
    page = max(1, min(total_pages, page))
    
    start_i = (page - 1) * per_page
    end_i = min(len(w_list), page * per_page)
    items_slice = w_list[start_i:end_i]
    
    txt = (
        f"🔫 <b>АРСЕНАЛ ОРУЖИЯ GD MILITARY (26 ЕДИНИЦ)</b>\n"
        f"Страница {page} / {total_pages} (Оружие {start_i + 1} – {end_i})\n"
        f"────────────────────────\n"
        f"<i>Все 26 видов оружия добавлены в пул предметов игры и открываются в боевом пропуске, а также падают в рейдах!</i>\n\n"
    )
    
    for w in items_slice:
        rarity_badge = {"mythic": "🔴 Mythic", "legendary": "🟨 Legendary", "epic": "🟪 Epic", "rare": "🟦 Rare"}.get(w["rarity"], "⬜")
        txt += f"• <b>{w['name']}</b> ({rarity_badge})\n"
        txt += f"   ⚔️ Огневая мощь: <b>+{w['combat']}</b> | 💰 Цена: <b>{_fmt_rub(w['price'])}</b>\n"
        txt += f"   🗺️ Локации: {w.get('locations', 'Все зоны')} | Шанс: <b>{w.get('drop_chance', '3.5%')}</b>\n"
        txt += f"   └ <i>{w['desc']}</i>\n\n"
        
    markup = types.InlineKeyboardMarkup(row_width=2)
    prev_p = page - 1 if page > 1 else total_pages
    next_p = page + 1 if page < total_pages else 1
    markup.add(
        types.InlineKeyboardButton(f"◀ Стр. {prev_p}", callback_data=f"gd_bp_weapons_page_{prev_p}"),
        types.InlineKeyboardButton(f"Стр. {next_p} ▶", callback_data=f"gd_bp_weapons_page_{next_p}")
    )
    markup.add(
        types.InlineKeyboardButton("🔙 Обзор Пропуска", callback_data="menu_gd_battlepass"),
        types.InlineKeyboardButton("🏠 Главное Меню", callback_data="main_menu")
    )
    return txt, markup

