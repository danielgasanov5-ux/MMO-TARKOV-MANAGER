import sys
import types
import tarkov_engine as te
import bot
import gd_military_system as gd

def run_tests():
    print("==================================================")
    print("   TESTING ADMIN & GD SHADOW AGENT RAIDS FIX     ")
    print("==================================================")
    
    # Setup mock bot callbacks
    sent_messages = []
    bot.bot.answer_callback_query = lambda *a, **kw: None
    bot.bot.edit_message_text = lambda txt, *a, **kw: sent_messages.append(txt)
    bot.bot.send_message = lambda chat_id, txt, *a, **kw: sent_messages.append(txt)
    bot.bot.send_photo = lambda chat_id, photo, caption=None, *a, **kw: sent_messages.append(caption or "")
    bot.bot.delete_message = lambda *a, **kw: None
    
    class DummyCall:
        def __init__(self, uid=9999, uname="danielgasanov5_ux"):
            self.id = "c_test"
            self.from_user = types.SimpleNamespace(id=uid, username=uname)
            self.message = types.SimpleNamespace(chat=types.SimpleNamespace(id=123), message_id=456)
    
    # 1. Test Admin with Max BP (level 150)
    print("\n[TEST 1] Admin with Max Battle Pass Level 150 (Solo Raid Success)...")
    admin = te.create_new_player(9999, "danielgasanov5_ux", "Revenant")
    admin.setdefault("special_businesses", {})["gd_shadow_agent"] = True
    bp_state = admin.setdefault("gd_battlepass", {})
    bp_state["level"] = 150
    bp_state["current_exp"] = 0
    db = {"users": {"9999": admin}}
    
    bot.simulate_raid = lambda loc, p, po, a: {
        "success": True,
        "location": "Завод",
        "win_chance": 99.0,
        "rubles": 65000,
        "items": [{"id": "ak74m_rifle", "name": "АК-74М", "rarity": "rare", "price": 45000}],
        "btc_won": 0.0,
        "mythic_perks": {}
    }
    
    sent_messages.clear()
    bot.handle_start_solo_raid(DummyCall(9999, "danielgasanov5_ux"), admin, db, "factory")
    assert len(sent_messages) > 0, "No message was sent!"
    assert "МАКСИМАЛЬНЫЙ УРОВЕНЬ" in sent_messages[0], "Max level message missing!"
    assert admin["money"] == 500000 + 65000, f"Money not updated: {admin['money']}"
    assert admin["stats"]["raids_count"] == 1, "Raid count not incremented!"
    print("✅ [TEST 1] Admin Max BP Raid: PASSED! Money, items, and text properly processed without KeyError.")
    
    # 2. Test Player with GD Shadow Agent at Level 1 (Solo Raid Success)
    print("\n[TEST 2] Player with Level 1 GD Shadow Agent (Solo Raid Success)...")
    player = te.create_new_player(1111, "rich_player", "Whale")
    player.setdefault("special_businesses", {})["gd_shadow_agent"] = True
    p_bp = player.setdefault("gd_battlepass", {})
    p_bp["level"] = 1
    p_bp["current_exp"] = 0
    db["users"]["1111"] = player
    
    sent_messages.clear()
    bot.handle_start_solo_raid(DummyCall(1111, "rich_player"), player, db, "factory")
    assert len(sent_messages) > 0, "No message was sent!"
    assert "Прогресс: 450/520 XP" in sent_messages[0], f"Unexpected text: {sent_messages[0]}"
    assert player["gd_battlepass"]["current_exp"] == 450, "EXP not added to battlepass!"
    print("✅ [TEST 2] Level 1 GD BP Raid: PASSED! Progress 450/520 XP cleanly formatted.")
    
    # 3. Test Level Up in GD BP from Raid
    print("\n[TEST 3] Player leveling up in GD BP from raid...")
    sent_messages.clear()
    # Adding another 450 XP should bring it to 900 XP, which is >= 520, leveling up to level 2!
    bot.handle_start_solo_raid(DummyCall(1111, "rich_player"), player, db, "factory")
    assert len(sent_messages) > 0, "No message was sent!"
    assert "Новый уровень: 2 / 150" in sent_messages[0], f"Level up not in text: {sent_messages[0]}"
    assert player["gd_battlepass"]["level"] == 2, "Player level did not increase!"
    print("✅ [TEST 3] Level up in GD BP from raid: PASSED!")
    
    # 4. Test Raid Defeat
    print("\n[TEST 4] Player raid defeat with GD BP...")
    bot.simulate_raid = lambda loc, p, po, a: {
        "success": False,
        "location": "Завод",
        "win_chance": 10.0,
        "rubles": 0,
        "items": [],
        "btc_won": 0.0,
        "mythic_perks": {}
    }
    sent_messages.clear()
    bot.handle_start_solo_raid(DummyCall(1111, "rich_player"), player, db, "factory")
    assert len(sent_messages) > 0, "No message was sent!"
    assert "ОПЕРАТИВНЫЙ ОПЫТ GD" in sent_messages[0], "Defeat GD text missing!"
    print("✅ [TEST 4] Raid Defeat: PASSED!")
    
    print("\n==================================================")
    print("   🎉 ALL ADMIN & GD RAIDS TESTS 100% PASSED!    ")
    print("==================================================")

if __name__ == "__main__":
    run_tests()
