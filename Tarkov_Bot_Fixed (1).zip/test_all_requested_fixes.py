import sys
import os
import json
import time

sys.path.insert(0, os.path.dirname(__file__))

from tarkov_engine import (
    ITEMS_BY_ID, get_warehouse_count, is_item_valuable,
    create_new_player, load_db
)
from prestige import execute_prestige_reset, get_player_prestige
from boss_summon_system import SUMMONED_BOSSES
from signature_raid_system import get_elite_loot_pool
import bot

print("=" * 70)
print("   COMPREHENSIVE AUDIT FIX VERIFICATION SUITE (2.1, 2.2, 2.3, 3.1, 3.2)")
print("=" * 70)

# -------------------------------------------------------------
# 2.1 VERIFICATION: Prestige Item IDs & Zryachiy Sniper Integration
# -------------------------------------------------------------
print("\n[TEST 2.1] Prestige Starter Stash & Item IDs...")
player = create_new_player(999001, "PrestigeHero", "Viper")
player["level"] = 10
player["exp"] = 10_000_000
player["money"] = 100_000_000
player["rubles_spent_total"] = 100_000_000
player["raids_won"] = 200

# Execute Prestige to Tier 5
ok = execute_prestige_reset(player, target_lvl=5)
assert ok, "Prestige 5 reset failed"
starter_stash = player.get("stash", [])
print(f"  ✓ Prestige reset to Tier 5 succeeded.")

# Check every item in starter stash exists in ITEMS_BY_ID
for item in starter_stash:
    iid = item["item_id"]
    assert iid in ITEMS_BY_ID, f"Invalid item_id in prestige starter stash: {iid}"
    assert ITEMS_BY_ID[iid].get("name"), f"Missing name for item {iid}"

# Specifically check Zryachiy rifle
z_item = next((i for i in starter_stash if "zryachiy_axmc" in i["item_id"]), None)
assert z_item is not None, "Zryachiy AXMC rifle not found in Prestige 5 stash!"
assert z_item["item_id"] == "zryachiy_axmc_338", f"Expected zryachiy_axmc_338, got {z_item['item_id']}"
assert "zryachiy_axmc" in ITEMS_BY_ID, "zryachiy_axmc alias missing in ITEMS_BY_ID"
print("  ✓ All starter items verified in ITEMS_BY_ID (including zryachiy_axmc_338).")
print("✅ [2.1] Prestige Item IDs Fix: 100% PASSED!")

# -------------------------------------------------------------
# 2.2 VERIFICATION: Boss Summon Gear & ITEMS_BY_ID Registration
# -------------------------------------------------------------
print("\n[TEST 2.2] Boss Summon System Items in ITEMS_BY_ID...")
boss_item_ids = [
    "cultist_poison_blade_legendary",
    "cultist_hood_rare",
    "partisan_svd_legendary",
    "partisan_rig_rare",
    "kollontay_baton_legendary",
    "kollontay_armor_6b43_legendary"
]

for bid in boss_item_ids:
    assert bid in ITEMS_BY_ID, f"Boss item {bid} not found in ITEMS_BY_ID!"
    item_data = ITEMS_BY_ID[bid]
    assert item_data.get("name"), f"Boss item {bid} has no name!"
    assert item_data.get("price", 0) > 0, f"Boss item {bid} price is 0!"
    print(f"  ✓ Found '{item_data['name']}' (ID: {bid}) in ITEMS_BY_ID")

for boss_key, boss_data in SUMMONED_BOSSES.items():
    for g in boss_data.get("gear", []):
        assert g["id"] in ITEMS_BY_ID, f"Boss gear {g['id']} not registered"
    ri = boss_data.get("reward_item")
    if ri:
        assert ri["id"] in ITEMS_BY_ID, f"Boss reward {ri['id']} not registered"
print("✅ [2.2] Boss Summon System Items: 100% PASSED!")

# -------------------------------------------------------------
# 2.3 VERIFICATION: Elite Loot Pool Valuables Inclusion
# -------------------------------------------------------------
print("\n[TEST 2.3] Signature Raid Elite Loot Pool...")
elite_pool = get_elite_loot_pool()
print(f"  ✓ Elite loot pool total items: {len(elite_pool)}")
assert len(elite_pool) > 50, "Elite loot pool unexpectedly small!"

# Ensure valuables are in the pool
valuables_in_pool = [k for k in elite_pool if is_item_valuable(ITEMS_BY_ID.get(k, {}))]
assert len(valuables_in_pool) > 0, "No valuables found in elite loot pool!"
print(f"  ✓ Valuables present in elite pool: {len(valuables_in_pool)} items")

key_valuables = [
    "physical_bitcoin_legendary",
    "rolex_submariner_epic",
    "graphics_card_gpu_epic",
    "gold_skull_ring_rare",
    "golden_chain_rare"
]
for kv in key_valuables:
    assert kv in elite_pool, f"Expected {kv} in elite loot pool, but was missing!"
    print(f"  ✓ Verified valuable in elite pool: {ITEMS_BY_ID[kv]['name']}")
print("✅ [2.3] Elite Loot Pool Fix: 100% PASSED!")

# -------------------------------------------------------------
# 3.1 VERIFICATION: Warehouse Capacity & Double-Counting Elimination
# -------------------------------------------------------------
print("\n[TEST 3.1] Warehouse Capacity & Valuables Isolation...")
test_user = {
    "stash": [
        {"item_id": "physical_bitcoin_legendary"},
        {"item_id": "graphics_card_gpu_epic"},
        {"item_id": "gold_skull_ring_rare"},
        {"item_id": "comp_circuit_board_epic"},
        {"item_id": "ak74m_common"},
        {"item_id": "armor_paca_common"},
        {"item_id": "ai2_medkit_common"}
    ]
}

categories = ["weapons", "armor", "gear", "components", "valuables"]
cat_counts = {c: get_warehouse_count(test_user, c) for c in categories}
print(f"  ✓ Calculated category counts: {cat_counts}")

assert cat_counts["valuables"] == 3, f"Expected 3 valuables, got {cat_counts['valuables']}"
assert cat_counts["components"] == 1, f"Expected 1 component (not double counted), got {cat_counts['components']}"
assert cat_counts["weapons"] == 1, f"Expected 1 weapon, got {cat_counts['weapons']}"
assert cat_counts["armor"] == 1, f"Expected 1 armor, got {cat_counts['armor']}"
assert cat_counts["gear"] == 1, f"Expected 1 gear, got {cat_counts['gear']}"
assert sum(cat_counts.values()) == len(test_user["stash"]), "Items count mismatch!"
print("  ✓ Zero double-counting verified: Each item strictly belongs to exactly one warehouse.")
print("✅ [3.1] Warehouse Double-Counting Fix: 100% PASSED!")

# -------------------------------------------------------------
# 3.2 VERIFICATION: Flea Market Multi-Underscore & Compact Callbacks
# -------------------------------------------------------------
print("\n[TEST 3.2] Flea Market Callback Parsing & 64-byte Telegram Limit...")
multi_underscore_items = [
    "toz_106_common",
    "saiga_12k_ver_10_rare",
    "cultist_poison_blade_legendary",
    "physical_bitcoin_legendary",
    "kollontay_armor_6b43_legendary",
    "zryachiy_axmc_338"
]

market_cats = ["Оружие", "Экипировка", "Шлемы", "Наушники", "Медицина", "Драгоценности", "Компоненты"]

for mcat in market_cats:
    cat_code = bot.MKT_CAT_TO_CODE[mcat]
    for mid in multi_underscore_items:
        # 1. Check compact callback length
        cb = f"mktbuy:{mid}:{cat_code}:1"
        byte_len = len(cb.encode("utf-8"))
        assert byte_len <= 64, f"Callback {cb} exceeds 64 bytes ({byte_len} bytes)!"
        
        # 2. Test mktbuy decoding
        parts = cb.split(":")
        dec_id = parts[1]
        raw_cat = parts[2]
        dec_cat = bot.MKT_CODE_TO_CAT.get(raw_cat, raw_cat)
        dec_page = int(parts[3])
        assert dec_id == mid, f"Decoded ID mismatch: {dec_id} != {mid}"
        assert dec_cat == mcat, f"Decoded Category mismatch: {dec_cat} != {mcat}"
        assert dec_page == 1

        # 3. Test legacy market_buy_ with rsplit
        legacy_cb = f"market_buy_{mid}_{mcat}_1"
        rest = legacy_cb[len("market_buy_"):]
        l_parts = rest.rsplit("_", 2)
        assert l_parts[0] == mid, f"Legacy ID mismatch: {l_parts[0]} != {mid}"
        assert l_parts[1] == mcat, f"Legacy Cat mismatch: {l_parts[1]} != {mcat}"
        assert int(l_parts[2]) == 1

print("  ✓ All multi-underscore items and categories parsed without truncation.")
print("  ✓ All callback query strings strictly within Telegram 64-byte limit.")

# Test market_page_ and prapor_sell_cat_ rsplit parsing
p_cb = "prapor_sell_cat_components_common"
p_rest = p_cb[len("prapor_sell_cat_"):]
p_cat, p_rarity = p_rest.rsplit("_", 1)
assert p_cat == "components" and p_rarity == "common"

mp_cb = "market_page_Драгоценности_2"
mp_rest = mp_cb[len("market_page_"):]
mp_cat, mp_page = mp_rest.rsplit("_", 1)
assert mp_cat == "Драгоценности" and int(mp_page) == 2
print("  ✓ prapor_sell_cat_ and market_page_ rsplit parsing verified.")

print("✅ [3.2] Flea Market Callback Parsing Fix: 100% PASSED!")

print("\n" + "=" * 70)
print("   🎉 ALL 5 AUDIT FINDINGS (2.1, 2.2, 2.3, 3.1, 3.2) FULLY VERIFIED!")
print("=" * 70)
