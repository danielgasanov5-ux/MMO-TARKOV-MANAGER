import sys
import os
sys.path.insert(0, "/tmp/tarkov-bot")
from boss_summon_system import SUMMONED_BOSSES, handle_recruit_summoned_boss, ensure_boss_gear
from bot import handle_disband_fighter, handle_menu_squad, handle_view_fighter, ITEMS_BY_ID
from tarkov_engine import calculate_squad_power

class MockBot:
    def __init__(self):
        self.texts = []
        self.alerts = []
    def answer_callback_query(self, call_id, text=None, show_alert=False):
        self.alerts.append(text)
    def edit_message_text(self, text, *a, **kw):
        self.texts.append(text)
    def send_message(self, *a, **kw):
        pass

mock_bot = MockBot()
import bot, boss_summon_system
bot.bot = mock_bot
boss_summon_system.bot = mock_bot

player = {"squad": [], "stash": [], "money": 10000000}
db = {"players": {"1": player}}
call = type("C", (), {"id": "1", "message": type("M", (), {"chat": type("Ch", (), {"id": 1})(), "message_id": 1})()})()

print("--- STEP 1: Recruit Partisan, Cultists, and Kollontay ---")
handle_recruit_summoned_boss(call, player, db, "partisan", mock_bot)
handle_recruit_summoned_boss(call, player, db, "cultists", mock_bot)
handle_recruit_summoned_boss(call, player, db, "kollontay", mock_bot)

squad_len = len(player["squad"])
assert squad_len == 3, f"Expected 3 bosses, got {squad_len}"
stash_map = {i["uid"]: i for i in player["stash"]}
for f in player["squad"]:
    assert f["weapon_uid"] in stash_map, f"Weapon missing for {f['name']}"
    assert f["armor_uid"] in stash_map, f"Armor missing for {f['name']}"
    print(f"✓ {f['name']}: weapon & armor intact in stash")

print("\n--- STEP 2: Hire a Scav and then disband the Scav ---")
scav = {"id": 99, "type": "scav", "name": "Дикий Василий", "weapon_uid": None, "armor_uid": None}
player["squad"].append(scav)
handle_disband_fighter(call, player, db, 99)

stash_map = {i["uid"]: i for i in player["stash"]}
for f in player["squad"]:
    assert f["weapon_uid"] in stash_map, f"CRITICAL: Weapon lost for {f['name']} after disbanding scav!"
    assert f["armor_uid"] in stash_map, f"CRITICAL: Armor lost for {f['name']} after disbanding scav!"
    w_name = ITEMS_BY_ID[stash_map[f["weapon_uid"]]["item_id"]]["name"]
    print(f"✓ After disbanding scav: {f['name']} STILL HAS weapon: {w_name}")

print("\n--- STEP 3: Test auto-healing on previously corrupted state ---")
# Simulate user whose Partisan and Cultist had lost their weapons
f_partisan = next(f for f in player["squad"] if f.get("boss_key") == "partisan")
f_cultist = next(f for f in player["squad"] if f.get("boss_key") == "cultists")

# Corrupt their stash items
player["stash"] = [i for i in player["stash"] if i["uid"] not in (f_partisan["weapon_uid"], f_partisan["armor_uid"], f_cultist["weapon_uid"])]
f_cultist["weapon_uid"] = None

print("Simulated corruption: Partisan gear wiped, Cultist weapon_uid set to None")
handle_menu_squad(1, 1, player)

# Verify auto-healing restored them!
stash_map = {i["uid"]: i for i in player["stash"]}
for f in player["squad"]:
    assert f["weapon_uid"] in stash_map, f"Auto-heal failed for {f['name']} weapon"
    assert f["armor_uid"] in stash_map, f"Auto-heal failed for {f['name']} armor"
    w_name = ITEMS_BY_ID[stash_map[f["weapon_uid"]]["item_id"]]["name"]
    a_name = ITEMS_BY_ID[stash_map[f["armor_uid"]]["item_id"]]["name"]
    print(f"✓ Auto-healed: {f['name']} -> 🔫 {w_name} | 🛡️ {a_name}")

print("\n--- STEP 4: Test squad text rendering ---")
mock_bot.texts.clear()
handle_menu_squad(1, 1, player)
last_text = mock_bot.texts[-1]
assert "Снайперский карабин Партизана" in last_text, "Partisan SVD not in squad menu text!"
assert "Ритуальный ядовитый нож" in last_text, "Cultist Blade not in squad menu text!"
assert "Усиленная милицейская дубинка" in last_text, "Kollontay Baton not in squad menu text!"
print("✓ Squad menu correctly displays all 3 boss weapons!")

print("\n--- STEP 5: Disband Partisan and verify only his gear leaves ---")
handle_disband_fighter(call, player, db, f_partisan["id"])
assert len(player["squad"]) == 2, "Partisan should be removed from squad"
stash_map = {i["uid"]: i for i in player["stash"]}
for f in player["squad"]:
    assert f["weapon_uid"] in stash_map, f"{f['name']} gear erroneously deleted!"
    print(f"✓ {f['name']} gear safely retained in stash")

print("\n--- STEP 6: Calculate squad power ---")
pow_val, arm_val = calculate_squad_power(player)
print(f"✓ Squad power: {pow_val}, armor: {arm_val} (both > 0)")
assert pow_val > 50 and arm_val > 50

print("\n🎉 ALL TESTS PASSED SUCCESSFULLY!")
