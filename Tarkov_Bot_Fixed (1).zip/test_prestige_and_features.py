# -*- coding: utf-8 -*-
"""
Verification suite for:
1. Raid responsiveness with Goons / Zryachiy gear.
2. Prestige system mechanics (costs, income, warehouse, EXP, squad size, sniper support, reset).
3. Battle pass drops lock.
4. Admin BP / Prestige commands.
5. Bot stats and titles rendering.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from tarkov_engine import (
    get_warehouse_capacity, get_module_upgrade_cost,
    get_business_hourly_income, add_player_exp, get_max_squad_size
)
from prestige import (
    get_player_prestige, get_prestige_badge, can_advance_prestige,
    execute_prestige_reset, apply_zryachiy_sniper_support,
    render_prestige_menu, render_prestige_confirm
)
from mythic_system import can_launch_goons_raid
from signature_raid_system import can_launch_signature_raid
from gd_military_system import roll_gd_raid_weapon, BP_WEAPONS_LEVEL_MAP, GD_WEAPONS_CATALOG
from bot_stats import render_bot_stats
from titles_system import render_titles_menu

def run_tests():
    print("=== 1. TESTING PRESTIGE MECHANICAL INTEGRATION ===")
    p0 = {"user_id": 1, "level": 10, "prestige": 0, "warehouse_lvl": 1, "squad": []}
    p1 = {"user_id": 2, "level": 10, "prestige": 1, "warehouse_lvl": 1, "squad": []}
    p5 = {"user_id": 3, "level": 10, "prestige": 5, "warehouse_lvl": 1, "squad": []}

    # Squad size: p0 has 5, p5 has 6 (Prestige 5 perk)
    assert get_max_squad_size(p0) == 5, f"Expected 5, got {get_max_squad_size(p0)}"
    assert get_max_squad_size(p5) == 6, f"Expected 6, got {get_max_squad_size(p5)}"
    print("✓ Squad size scaling with Prestige verified.")

    # Warehouse capacity: Prestige 4 gives +50% warehouse capacity
    cap0 = get_warehouse_capacity(p0, "weapons")
    p4 = {"user_id": 4, "level": 10, "prestige": 4, "warehouse_lvl": 1}
    cap4 = get_warehouse_capacity(p4, "weapons")
    assert cap4 == int(cap0 * 1.5), f"Expected {int(cap0 * 1.5)}, got {cap4}"
    print("✓ Warehouse capacity bonus (+50% at Prestige 4) verified.")

    # Module costs: Prestige 1 gives -15%
    cost0 = get_module_upgrade_cost(1, p0)
    cost1 = get_module_upgrade_cost(1, p1)
    assert cost1 < cost0, f"Prestige 1 discount failed: {cost1} vs {cost0}"
    print("✓ Module discount (-15% at Prestige 1) verified.")

    # Business income: Prestige 2 gives +20%
    p2 = {"user_id": 5, "prestige": 2, "businesses": {"moonshine_still": 1}}
    p_nobonus = {"user_id": 6, "prestige": 0, "businesses": {"moonshine_still": 1}}
    inc0 = get_business_hourly_income("moonshine_still", 1, p_nobonus)
    inc2 = get_business_hourly_income("moonshine_still", 1, p2)
    assert inc2 > inc0, f"Prestige 2 income bonus failed: {inc2} vs {inc0}"
    print("✓ Business income multiplier (+20% at Prestige 2) verified.")

    # EXP gain: Prestige 1 gives +20%
    p_exp0 = {"level": 1, "exp": 0, "prestige": 0}
    p_exp1 = {"level": 1, "exp": 0, "prestige": 1}
    add_player_exp(p_exp0, 100)
    add_player_exp(p_exp1, 100)
    assert p_exp1["exp"] > p_exp0["exp"], f"Prestige 1 EXP boost failed: {p_exp1['exp']} vs {p_exp0['exp']}"
    print("✓ EXP acceleration (+20% at Prestige 1) verified.")

    # Prestige 5 Zryachiy Sniper Support
    p5_dsp = {"user_id": 7, "prestige": 5, "mythic_items": ["mythic_dsp_sensor"]}
    support = apply_zryachiy_sniper_support(p5_dsp, "boss")
    assert support["active"] is True, "Zryachiy sniper support should be active"
    assert support["flat_win_bonus"] == 0.20, "Boss flat win bonus should be +20%"
    assert support["boss_debuff"] == 0.30, "Boss debuff should be 30%"
    print("✓ Zryachiy sniper support active for Prestige 5 with DSP sensor.")

    print("\n=== 2. TESTING RAID RESPONSIVENESS (NO STICKINESS) ===")
    # Test player equipped with full Goons set and Zryachiy gear
    p_raid = {
        "user_id": 8,
        "level": 10,
        "prestige": 2,
        "mythic_items": ["mythic_goons_token", "mythic_dsp_sensor"],
        "equipped_clothes": {
            "shoes": "goons_boots",
            "headwear": "zryachiy_hood",
            "suit": "goons_suit",
            "accessory": "dsp_transmitter"
        },
        "squad": [{"id": 1, "weapon": "goons_spear_308", "armor": "goons_plate_carrier", "health": 100}]
    }

    # Goons raid check:
    can_goon, rem = can_launch_goons_raid(p_raid)
    assert can_goon is True, f"Goons raid was blocked (rem: {rem}s)"
    print("✓ Goons raid check succeeds when wearing Goons/Zryachiy gear.")

    # Signature raid check:
    can_sig, s_reason, s_rem = can_launch_signature_raid(p_raid)
    assert can_sig is True, f"Signature raid was blocked: {s_reason}"
    print("✓ Signature raid check succeeds for level 10 PMC.")

    print("\n=== 3. TESTING BATTLE PASS DROP LOCKING ===")
    p_low_bp = {
        "special_businesses": {"gd_shadow_agent": True},
        "gd_battlepass": {"level": 5, "unlocked_weapons": []}
    }
    # At BP level 5, high-level weapons like level 150 GD Minigun CANNOT drop
    high_tier_drops = 0
    for _ in range(100):
        w = roll_gd_raid_weapon(p_low_bp, "lab")
        if w:
            req_lvl = BP_WEAPONS_LEVEL_MAP.get(w["id"], 1)
            assert req_lvl <= 5, f"Item {w['id']} requires BP lvl {req_lvl} but player is lvl 5!"
            if req_lvl > 5:
                high_tier_drops += 1
    assert high_tier_drops == 0
    print("✓ Strict Battle Pass drop locking verified: No locked weapons drop.")

    print("\n=== 4. TESTING BOT STATS & PRESTIGE RENDERING ===")
    fake_db = {
        "users": {
            "1": {"user_id": 1, "username": "Alpha", "money": 50000000, "btc": 1.5, "stats": {"raids_count": 25, "pvp_wins": 10}},
            "2": {"user_id": 2, "username": "Beta", "money": 10000000, "btc": 0.2, "stats": {"raids_count": 5, "pvp_wins": 2}}
        },
        "market": [{"id": 1, "price": 100000}]
    }
    stats_txt, stats_markup = render_bot_stats(p_raid, fake_db)
    assert "СВОДНАЯ СТАТИСТИКА СЕРВЕРА" in stats_txt
    assert "ЛИЧНОЕ БОЕВОЕ ДОСЬЕ" in stats_txt
    assert len(stats_markup.keyboard) >= 2
    print("✓ Bot stats rendered cleanly with global & personal metrics.")

    prest_txt, prest_markup = render_prestige_menu(p_raid)
    assert "СИСТЕМА ПРЕСТИЖА ЧВК" in prest_txt
    print("✓ Prestige menu rendered cleanly with tier requirements and badges.")

    titles_txt, titles_markup = render_titles_menu(p_raid)
    assert "КОЛЛЕКЦИЯ ТИТУЛОВ" in titles_txt
    print("✓ Titles menu rendered cleanly with active titles and slots.")

    print("\n=== 5. TESTING ADMIN COMMANDS (MAX BP & PRESTIGE) ===")
    admin_user = {"user_id": 999, "username": "AdminPMC"}
    # Simulate set_bp_max
    admin_user.setdefault("special_businesses", {})["gd_shadow_agent"] = True
    bp_state = admin_user.setdefault("gd_battlepass", {})
    bp_state["level"] = 150
    bp_state["unlocked_weapons"] = list(GD_WEAPONS_CATALOG.keys())
    assert admin_user["gd_battlepass"]["level"] == 150
    assert len(admin_user["gd_battlepass"]["unlocked_weapons"]) == 26
    assert admin_user["special_businesses"]["gd_shadow_agent"] is True
    print("✓ Admin max BP logic verified (Level 150 + all 26 weapons + shadow agent).")

    # Simulate set_prestige 5
    admin_user["prestige"] = 5
    assert get_player_prestige(admin_user) == 5
    assert get_prestige_badge(admin_user) == "[👑 ЛЕГЕНДА V]"
    print("✓ Admin prestige command verified (Tier 5 badge and perks active).")

    print("\n=== 6. TESTING USER SPECIFIC REQUIREMENTS ===")
    from gd_military_system import GD_BUSINESS_DEF
    from tarkov_engine import SPECIAL_BUSINESSES
    from prestige import (
        check_prestige_requirements, get_goons_token_drop_chance, get_dsp_sensor_drop_chance
    )

    # 6.1 Check 5 Billion Business price & income
    assert GD_BUSINESS_DEF["cost"] == 5_000_000_000, f"GD cost expected 5B, got {GD_BUSINESS_DEF['cost']}"
    assert GD_BUSINESS_DEF["hourly_income"] == 25_000_000, f"GD income expected 25M, got {GD_BUSINESS_DEF['hourly_income']}"
    assert SPECIAL_BUSINESSES["gd_shadow_agent"]["cost"] == 5_000_000_000
    assert SPECIAL_BUSINESSES["gd_shadow_agent"]["hourly_income"] == 25_000_000
    print("✓ 5 Billion Business price (5,000,000,000) and income (25,000,000/h) verified.")

    # 6.2 Check Prestige cap (button disabled at Prestige 5)
    player_p5 = {
        "user_id": 105,
        "level": 70,
        "money": 500_000_000,
        "btc": 10.0,
        "prestige": 5,
        "stats": {"raids_count": 500, "pvp_wins": 100}
    }
    can_p, reason = check_prestige_requirements(player_p5, 6)
    assert can_p is False, f"Prestige beyond 5 should be blocked: {reason}"
    err_msg = reason.get("error", "") if isinstance(reason, dict) else str(reason)
    assert "максимального" in err_msg.lower() or "отключена" in err_msg.lower() or "5" in err_msg

    # Also check can_advance_prestige helper
    can_adv, _ = can_advance_prestige(player_p5)
    assert can_adv is False
    print("✓ Prestige 5 cap verified: transition blocked and button disabled.")

    # 6.3 Check execute_prestige_reset preserves 5B business, relics, and 3 mythics
    test_player = {
        "user_id": 777,
        "level": 70,
        "money": 200_000_000,
        "btc": 5.0,
        "prestige": 2,
        "special_businesses": {
            "smugglers_fleet": True,
            "fence_protection": True,
            "gd_shadow_agent": True
        },
        "gd_military_bp": {"level": 15, "unlocked_weapons": []},
        "mythic_items": [
            "mythic_black_division_case",
            "mythic_goons_token",
            "mythic_dsp_sensor"
        ],
        "stash": [
            {"uid": "rel_1", "item_id": "relic_kaban_custom_rpk", "category": "relic"},
            {"uid": "rel_2", "item_id": "relic_killa_helmet", "category": "relic"},
            {"uid": "m_1", "item_id": "mythic_black_division_case", "rarity": "mythic"},
            {"uid": "m_2", "item_id": "mythic_goons_token", "rarity": "mythic"},
            {"uid": "m_3", "item_id": "mythic_dsp_sensor", "rarity": "mythic"},
            {"uid": "trash_1", "item_id": "bandage_common"}
        ],
        "clothes_stash": ["suit_shadow_1"],
        "equipped_clothes": {"suit": "suit_shadow_1"}
    }

    reset_success = execute_prestige_reset(test_player, 3)
    assert reset_success is True

    # Check GD business preserved
    assert test_player["special_businesses"].get("gd_shadow_agent") is True, "5B GD Business must be preserved!"
    # Check other businesses were reset
    assert test_player["special_businesses"].get("smugglers_fleet") is False
    assert test_player["special_businesses"].get("fence_protection") is False

    # Check all relics preserved in stash
    relic_ids_in_stash = [it["item_id"] for it in test_player["stash"] if str(it.get("item_id", "")).startswith("relic_")]
    assert "relic_kaban_custom_rpk" in relic_ids_in_stash, "Relic 1 must be preserved in stash"
    assert "relic_killa_helmet" in relic_ids_in_stash, "Relic 2 must be preserved in stash"

    # Check all 3 mythic items preserved in stash & mythic_items list
    assert "mythic_black_division_case" in test_player["mythic_items"]
    assert "mythic_goons_token" in test_player["mythic_items"]
    assert "mythic_dsp_sensor" in test_player["mythic_items"]

    stash_item_ids = [it["item_id"] for it in test_player["stash"]]
    assert "mythic_black_division_case" in stash_item_ids, "Black division case must be preserved in stash"
    assert "mythic_goons_token" in stash_item_ids, "Goons token must be preserved in stash"
    assert "mythic_dsp_sensor" in stash_item_ids, "DSP sensor must be preserved in stash"
    assert "bandage_common" not in stash_item_ids, "Regular stash loot must be reset"
    print("✓ execute_prestige_reset preservation verified: GD 5B business, all relics, and 3 mythics intact.")

    # 6.4 Check Drop Rate scaling per Prestige Level
    goons_chances = []
    dsp_chances_t4 = []
    dsp_chances_t3 = []
    for tier in range(6):
        dummy_p = {"prestige": tier}
        g_ch = get_goons_token_drop_chance(dummy_p)
        d_ch4 = get_dsp_sensor_drop_chance(dummy_p, supply_tier=4)
        d_ch3 = get_dsp_sensor_drop_chance(dummy_p, supply_tier=3)
        goons_chances.append(g_ch)
        dsp_chances_t4.append(d_ch4)
        dsp_chances_t3.append(d_ch3)

    # Verify strictly monotonic increases with huge incentive
    for i in range(1, 6):
        assert goons_chances[i] > goons_chances[i-1], f"Goons token chance not scaling at tier {i}: {goons_chances}"
        assert dsp_chances_t4[i] > dsp_chances_t4[i-1], f"DSP chance not scaling at tier {i}: {dsp_chances_t4}"

    assert goons_chances[0] == 0.0001
    assert goons_chances[5] == 0.0150  # 150x boost!
    assert dsp_chances_t4[0] == 0.0010
    assert dsp_chances_t4[5] == 0.0600  # 60x boost!
    assert dsp_chances_t3[5] == 0.0200  # 2% even in Tier 3!
    print(f"✓ Drop rate scaling verified: Goons token {goons_chances[0]*100}% -> {goons_chances[5]*100}% (x150)")
    print(f"✓ Drop rate scaling verified: DSP sensor {dsp_chances_t4[0]*100}% -> {dsp_chances_t4[5]*100}% (x60)")

    print("\nALL 6 VERIFICATION STAGES PASSED CONVINCINGLY! 🎖️")

if __name__ == "__main__":
    run_tests()
