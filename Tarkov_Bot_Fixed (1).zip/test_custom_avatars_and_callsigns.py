import os
import sys
import unittest
import types

sys.path.insert(0, os.path.dirname(__file__))

import bot
import tarkov_engine

class TestCustomAvatarsAndCallsigns(unittest.TestCase):
    def setUp(self):
        self.db = bot.load_db()
        self.admin_id = int(os.getenv("ADMIN_USER_ID", "6021200021"))
        
        # Setup test player
        self.player_id = 881234
        self.username = "elite_sniper"
        self.player = tarkov_engine.create_new_player(self.player_id, self.username, "Viper")
        self.db["users"][str(self.player_id)] = self.player
        bot.save_db(self.db)

    def test_custom_callsign_change_and_buff_preservation(self):
        # Initial state
        self.assertEqual(self.player.get("pmc_signature"), "Viper")
        self.assertIsNone(self.player.get("custom_pmc_callsign"))
        self.assertTrue(tarkov_engine.has_buff(self.player, "cooldown_reduction"))

        # Create dummy message for /set_callsign
        class DummyMsg:
            def __init__(self, text, from_id, uname):
                self.text = text
                self.from_user = types.SimpleNamespace(id=from_id, username=uname)
                self.chat = types.SimpleNamespace(id=from_id)
                self.reply_to_message = None

        replies = []
        bot.bot.reply_to = lambda msg, txt, parse_mode=None: replies.append(txt)

        # Execute /set_callsign @elite_sniper НочнойОхотник
        msg = DummyMsg(f"/set_callsign @{self.username} НочнойОхотник", self.admin_id, "admin")
        bot.cmd_admin_commands(msg)

        # Check DB update
        db = bot.load_db()
        p = bot.find_target_player(db, f"@{self.username}", self.admin_id)
        self.assertIsNotNone(p)
        self.assertEqual(p.get("custom_pmc_callsign"), "НочнойОхотник")
        self.assertEqual(p.get("pmc_signature"), "Viper")  # Underlying class unchanged!
        # Buff is preserved 100%
        self.assertTrue(tarkov_engine.has_buff(p, "cooldown_reduction"))
        self.assertIn("НочнойОхотник", replies[-1])

        # Test /reset_callsign
        msg_reset = DummyMsg(f"/reset_callsign @{self.username}", self.admin_id, "admin")
        bot.cmd_admin_commands(msg_reset)
        db = bot.load_db()
        p = bot.find_target_player(db, f"@{self.username}", self.admin_id)
        self.assertIsNone(p.get("custom_pmc_callsign"))
        self.assertEqual(p.get("pmc_signature"), "Viper")
        print("  ✓ Custom callsign set, preserved buff and reset passed!")

    def test_personal_photo_upload_and_reset(self):
        class DummyPhotoSize:
            def __init__(self, fid):
                self.file_id = fid
                self.width = 1024
                self.height = 768

        class DummyPhotoMsg:
            def __init__(self, from_id, uname, caption, file_id):
                self.from_user = types.SimpleNamespace(id=from_id, username=uname)
                self.chat = types.SimpleNamespace(id=from_id)
                self.caption = caption
                self.photo = [DummyPhotoSize(file_id)]
                self.reply_to_message = None

        replies = []
        bot.bot.reply_to = lambda msg, txt, parse_mode=None, reply_markup=None: replies.append(txt)

        # Admin sends photo with caption @elite_sniper
        photo_fid = "AgACAgIAAxkBAAI_CUSTOM_PHOTO_123"
        msg = DummyPhotoMsg(self.admin_id, "admin", f"@{self.username}", photo_fid)
        bot.handle_admin_photo_upload(msg)

        db = bot.load_db()
        p = bot.find_target_player(db, f"@{self.username}", self.admin_id)
        self.assertIsNotNone(p)
        self.assertEqual(p.get("custom_pmc_avatar"), photo_fid)
        self.assertIn("Персональное фото ЧВК успешно привязано", replies[-1])

        # Verify photo is sent when viewing avatar
        sent_photos = []
        bot.bot.send_photo = lambda chat_id, photo, caption, parse_mode=None, reply_markup=None: sent_photos.append((photo, caption))
        bot.handle_show_pmc_avatar(self.player_id, p, db)
        self.assertEqual(sent_photos[-1][0], photo_fid)

        # Test command /reset_user_photo
        class DummyCmdMsg:
            def __init__(self, text, from_id, uname):
                self.text = text
                self.from_user = types.SimpleNamespace(id=from_id, username=uname)
                self.chat = types.SimpleNamespace(id=from_id)
                self.reply_to_message = None

        msg_del = DummyCmdMsg(f"/reset_user_photo @{self.username}", self.admin_id, "admin")
        bot.cmd_admin_commands(msg_del)
        db = bot.load_db()
        p = bot.find_target_player(db, f"@{self.username}", self.admin_id)
        self.assertIsNone(p.get("custom_pmc_avatar"))
        print("  ✓ Personal PMC avatar upload, retrieval and reset passed!")

if __name__ == "__main__":
    unittest.main()
