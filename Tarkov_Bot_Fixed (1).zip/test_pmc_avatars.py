# -*- coding: utf-8 -*-
import sys
import unittest
import tarkov_engine
import bot
from telebot import types

class TestPMCAvatars(unittest.TestCase):
    def test_pmc_avatars_dictionary(self):
        expected_urls = {
            "Revenant": "https://i.postimg.cc/K8n6RdkQ/IMG-20260915-143105-572.jpg",
            "Spectre": "https://i.postimg.cc/QdxzdHDt/IMG-20260903-232448-147.jpg",
            "Specter": "https://i.postimg.cc/QdxzdHDt/IMG-20260903-232448-147.jpg",
            "Ares": "https://i.postimg.cc/156mr7Vg/IMG-20260915-140321-458.jpg",
            "Ronin": "https://i.postimg.cc/13BZvkmP/IMG-20260914-185619-476.jpg",
            "Zenith": "https://i.postimg.cc/tJZfyfGc/IMG-20260915-210152-858.jpg",
            "Fenrir": "https://i.postimg.cc/ZR2mr6Tg/IMG-20260914-224628-761.jpg",
            "Stalker": "https://i.postimg.cc/SNW4MXH8/IMG-20260914-190336-896.jpg",
            "Nomad": "https://i.postimg.cc/tggGwBJ8/IMG-20260914-185050-296.jpg",
            "Pharaoh": "https://i.postimg.cc/j2w9K9YW/IMG-20260915-213916-054.jpg",
            "Viper": "https://i.postimg.cc/Y9SZD0XJ/IMG-20260914-183339-584.jpg",
        }
        for pmc, url in expected_urls.items():
            self.assertIn(pmc, tarkov_engine.PMC_AVATARS, f"PMC {pmc} missing in PMC_AVATARS")
            self.assertEqual(tarkov_engine.PMC_AVATARS[pmc], url, f"URL mismatch for {pmc}")

    def test_pmc_profile_rendering(self):
        db = tarkov_engine.load_db()
        player = list(db["users"].values())[0]

        for pmc_name, expected_url in tarkov_engine.PMC_AVATARS.items():
            player["pmc_signature"] = pmc_name
            bot.handle_menu_profile(chat_id=777, msg_id=888, player=player)
            last_edit = bot.bot.edited_messages[-1]
            text = last_edit["text"]
            markup = last_edit["reply_markup"]
            self.assertIn("👤 ПРОФИЛЬ ОПЕРАТОРА ЧВК", text)
            
            # Check button exists
            btn_found = False
            for row in markup.keyboard:
                for btn in row:
                    if btn.callback_data == "show_pmc_avatar":
                        btn_found = True
                        break
            self.assertTrue(btn_found, f"Button 'show_pmc_avatar' must exist for {pmc_name}")

            # Test sending the native HD photo
            bot.handle_show_pmc_avatar(chat_id=777, player=player)
            last_sent = bot.bot.sent_messages[-1]
            self.assertEqual(last_sent.get("photo"), expected_url, f"Native photo URL mismatch for {pmc_name}")
            self.assertIn(pmc_name, last_sent.get("caption", ""), f"Caption must include PMC name {pmc_name}")
            print(f"  ✓ {pmc_name}: HD photo button and native photo delivery verified")

    def test_custom_file_id_upload_and_override(self):
        db = tarkov_engine.load_db()
        db.pop("pmc_custom_avatars", None)
        tarkov_engine.save_db(db)
        test_file_id = "AgACAgIAAxkBAAI_TEST_VIPER_TELEGRAM_CDN_FILE_ID_4K"
        
        # Test 1: get_pmc_avatar priority
        avatar_before = tarkov_engine.get_pmc_avatar("Viper", db)
        self.assertTrue(avatar_before.startswith("http"), "Should default to web url when no custom avatar")

        db.setdefault("pmc_custom_avatars", {})["Viper"] = test_file_id
        avatar_after = tarkov_engine.get_pmc_avatar("Viper", db)
        self.assertEqual(avatar_after, test_file_id, "get_pmc_avatar must return custom Telegram file_id")

        # Test 2: Admin photo upload handling
        admin_user = types.User(id=500366657, username="danielgasanov5")
        mock_photo = [types.PhotoSize(file_id=test_file_id, width=1440, height=2560)]
        
        # Simulation with caption "Viper"
        msg = types.Message(message_id=999, chat_id=500366657, from_user=admin_user, caption="Viper", photo=mock_photo)
        bot.handle_admin_photo_upload(msg)
        
        # Check DB was updated
        db_reloaded = tarkov_engine.load_db()
        self.assertEqual(db_reloaded.get("pmc_custom_avatars", {}).get("Viper"), test_file_id)
        print("  ✓ Admin direct upload with caption assigned to Viper correctly via Telegram CDN")

        # Simulation without caption -> pending photo and button click
        test_file_id_2 = "AgACAgIAAxkBAAI_TEST_REVENANT_TELEGRAM_CDN_FILE_ID"
        mock_photo_2 = [types.PhotoSize(file_id=test_file_id_2, width=1440, height=2560)]
        msg_no_cap = types.Message(message_id=1000, chat_id=500366657, from_user=admin_user, caption="", photo=mock_photo_2)
        bot.handle_admin_photo_upload(msg_no_cap)
        self.assertEqual(bot.PENDING_ADMIN_PHOTOS.get(500366657), test_file_id_2)

        # Trigger callback for Revenant
        call = types.CallbackQuery(id="cb_test", from_user=admin_user, message=msg_no_cap, data="set_pmc_art_Revenant")
        # Find callback handler and call it
        for ch in bot.bot.callback_handlers:
            ch["fn"](call)
            
        db_reloaded = tarkov_engine.load_db()
        self.assertEqual(db_reloaded.get("pmc_custom_avatars", {}).get("Revenant"), test_file_id_2)
        print("  ✓ Admin button selection assigned to Revenant correctly via Telegram CDN")

if __name__ == "__main__":
    unittest.main()
