# -*- coding: utf-8 -*-
import sys
import os
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))
sys.path.insert(0, os.path.dirname(__file__))

from clothes_system import (
    CLOTHES_CATEGORIES, CLOTHES_BY_ID, CLOTHES_BY_CATEGORY,
    get_player_clothes_stash, get_player_equipped_clothes,
    get_equipped_item_in_slot, buy_clothing_item,
    equip_clothing_item, unequip_clothing_item, discard_clothing_item,
    is_clothing_item, is_clothing_uid, player_owns_clothing
)
from tarkov_engine import create_new_player, ITEMS_BY_ID
import bot

print("=" * 60)
print("   RUNNING TARKOV BOT CLOTHES & MARKET FIX TEST SUITE")
print("=" * 60)

# [TEST 1] Catalog Validation
print("\n[TEST 1] Checking Clothes Catalog (4 categories x 50 items = 200 items)...")
assert len(CLOTHES_CATEGORIES) == 4, f"Expected 4 categories, got {len(CLOTHES_CATEGORIES)}"
expected_cats = ["shoes", "headwear", "suit", "accessory"]
for c in expected_cats:
    assert c in CLOTHES_CATEGORIES, f"Missing category {c}"
    count = len(CLOTHES_BY_CATEGORY[c])
    assert count == 50, f"Category {c} has {count} items, expected 50"
    print(f"  ✓ Category '{CLOTHES_CATEGORIES[c]['name']}' ({c}): {count} items verified!")

assert len(CLOTHES_BY_ID) == 200, f"Expected 200 items total, got {len(CLOTHES_BY_ID)}"
print("✅ Clothes Catalog: PASSED (All 200 items with unique IDs, names, prices)")

# [TEST 2] Buying clothes in "Шота у Ашота"
print("\n[TEST 2] Testing Buy Action at 'Шота у Ашота'...")
player = create_new_player(123456, "Tester", "Viper")
player["money"] = 100000  # 100k ₽

# Try buying expensive item:
expensive_id = "cloth_suit_50"  # 5,000,000,000 ₽
ok, msg, _ = buy_clothing_item(player, expensive_id)
assert not ok, "Player with 100k should NOT be able to buy 5B suit"
print("  ✓ Insufficient funds check: PASSED")

# Buy affordable shoes
cheap_shoes = "cloth_shoes_1"  # 10,000 ₽
ok, msg, uid1 = buy_clothing_item(player, cheap_shoes)
assert ok, f"Failed to buy affordable shoes: {msg}"
assert player["money"] == 90000, f"Money should be 90000, got {player['money']}"
assert len(player["clothes_stash"]) == 1
print(f"  ✓ Purchase affordable item: PASSED ({msg})")

# Try buying duplicate
ok, msg, _ = buy_clothing_item(player, cheap_shoes)
assert not ok, "Duplicate purchase should be blocked"
print("  ✓ Duplicate prevention check: PASSED")
print("✅ Buy Action: PASSED")

# [TEST 3] Equipping and Unequipping in Profile
print("\n[TEST 3] Testing Equip & Unequip Logic in Profile...")
ok, msg = equip_clothing_item(player, uid1)
assert ok, f"Equip failed: {msg}"
assert player["equipped_clothes"]["shoes"] == uid1
eq_info, eq_uid = get_equipped_item_in_slot(player, "shoes")
assert eq_info is not None and eq_uid == uid1
print(f"  ✓ Equipped successfully: {eq_info['name']}")

# [TEST 4] Inventory Protection: Cannot Discard Equipped Items
print("\n[TEST 4] Testing Strict Discard Protection on Equipped Items...")
ok, msg = discard_clothing_item(player, uid1)
assert not ok, "CRITICAL ERROR: System allowed discarding an equipped item!"
assert "Нельзя выбросить экипированный предмет" in msg
assert len(player["clothes_stash"]) == 1, "Item must remain in stash!"
print(f"  ✓ Discard blocked while equipped: {msg}")

# Unequip and now discard
ok, msg = unequip_clothing_item(player, "shoes")
assert ok, f"Unequip failed: {msg}"
assert player["equipped_clothes"]["shoes"] is None
print(f"  ✓ Unequipped successfully: {msg}")

ok, msg = discard_clothing_item(player, uid1)
assert ok, f"Discard failed after unequip: {msg}"
assert len(player["clothes_stash"]) == 0
print(f"  ✓ Discard succeeded when unequipped: {msg}")
print("✅ Discard Protection: PASSED")

# [TEST 5] Clothes Cannot Be Sold to Prapor or on P2P
print("\n[TEST 5] Testing Anti-Sell Protection for Clothes...")
# Buy a hat
ok, msg, hat_uid = buy_clothing_item(player, "cloth_headwear_1")
assert ok

class MockCall:
    def __init__(self, uid):
        self.id = "mock_call_1"
        self.data = uid
        self.message = type('Msg', (), {'chat': type('Chat', (), {'id': 123456})(), 'message_id': 999})()

db = {"players": {str(player["user_id"]): player}, "p2p_market": []}

# Attempt Prapor sell
call = MockCall(hat_uid)
prapor_answered = False
def mock_answer(cid, text="", show_alert=False):
    global prapor_answered, last_alert
    prapor_answered = True
    last_alert = text

bot.bot.answer_callback_query = mock_answer

bot.handle_prapor_sell(call, player, db, hat_uid)
assert prapor_answered
assert "нельзя продать" in last_alert.lower()
assert len(player["clothes_stash"]) == 1, "Clothes must NOT be sold by Prapor!"
print(f"  ✓ Prapor sell blocked: {last_alert}")

# Attempt P2P listing
p2p_answered = False
bot.handle_p2p_list_action(call, player, db, hat_uid)
assert "нельзя выставить" in last_alert.lower()
assert len(db.get("p2p_market", [])) == 0, "Clothes must NOT be listed on P2P!"
print(f"  ✓ P2P listing blocked: {last_alert}")
print("✅ Anti-Sell Protection: PASSED")

# [TEST 6] Flea Market Buy Bug Fix (Infinite Loading Fix)
print("\n[TEST 6] Testing Flea Market Buy Bug Fix (Multi-underscore Item IDs)...")
# Item ID with underscores: e.g. toz_106_common
test_item_id = "toz_106_common"
assert test_item_id in ITEMS_BY_ID, f"{test_item_id} must be in ITEMS_BY_ID"
player["money"] = 500000

# Simulate callback parsing
callback_data = f"market_buy_{test_item_id}_Оружие_1"
rest = callback_data[len("market_buy_"):]
parts = rest.rsplit("_", 2)
parsed_item_id = parts[0]
parsed_cat = parts[1]
parsed_page = int(parts[2])

assert parsed_item_id == test_item_id, f"Parsed ID '{parsed_item_id}' does not match '{test_item_id}'"
assert parsed_cat == "Оружие"
assert parsed_page == 1
print(f"  ✓ Split parsing parsed ID='{parsed_item_id}', Cat='{parsed_cat}', Page={parsed_page}")

# Test handle_market_buy_action with parsed values
market_buy_answered = False
def mock_market_answer(cid, text="", show_alert=False):
    global market_buy_answered, last_alert
    market_buy_answered = True
    last_alert = text

bot.bot.answer_callback_query = mock_market_answer
stash_count_before = len(player["stash"])

call_mkt = MockCall("market_buy")
bot.handle_market_buy_action(call_mkt, player, db, parsed_item_id, parsed_cat, parsed_page)
assert market_buy_answered, "bot.answer_callback_query was NOT called (infinite loading bug!)"
assert len(player["stash"]) == stash_count_before + 1, "Item was not added to stash"
print(f"  ✓ Flea market buy executed successfully! Alert: {last_alert}")
print("✅ Flea Market Buy Fix: PASSED")

# [TEST 7] UI Menus & Navigation Verification
print("\n[TEST 7] Verifying UI Menus (Ashot Shop, Profile Tabs, Stash 'Шмот' Button)...")

# Verify Profile Menu has 4 category tabs
class CaptureBot:
    def __init__(self):
        self.last_text = ""
        self.last_markup = None
    def edit_message_text(self, text, chat_id, msg_id, reply_markup=None, **kwargs):
        self.last_text = text
        self.last_markup = reply_markup
    def send_message(self, chat_id, text, reply_markup=None, **kwargs):
        self.last_text = text
        self.last_markup = reply_markup
    def send_photo(self, chat_id, photo, caption=None, reply_markup=None, **kwargs):
        self.last_text = caption
        self.last_markup = reply_markup
    def delete_message(self, chat_id, msg_id, **kwargs):
        pass
    def answer_callback_query(self, *args, **kwargs):
        pass

c_bot = CaptureBot()
bot.bot.edit_message_text = c_bot.edit_message_text
bot.bot.send_message = c_bot.send_message
bot.bot.send_photo = c_bot.send_photo
bot.bot.delete_message = c_bot.delete_message

# 1. Profile menu
bot.handle_menu_profile(123456, 999, player)
btn_cbs = [b.callback_data for row in c_bot.last_markup.keyboard for b in row]
assert "prof_cloth_shoes_1" in btn_cbs, "Profile missing Shoes tab!"
assert "prof_cloth_headwear_1" in btn_cbs, "Profile missing Headwear tab!"
assert "prof_cloth_suit_1" in btn_cbs, "Profile missing Suit tab!"
assert "prof_cloth_accessory_1" in btn_cbs, "Profile missing Accessory tab!"
print("  ✓ Profile contains all 4 clothing tabs: Обувь, Головной убор, Костюм, Аксессуар")

# 2. Stash menu has "Шмот" button
bot.handle_menu_stash(123456, 999, player)
stash_btn_cbs = [b.callback_data for row in c_bot.last_markup.keyboard for b in row]
assert "stash_clothes_menu" in stash_btn_cbs, "Stash menu missing 'Шмот' button!"
print("  ✓ Stash menu contains '👔 Шмот (Гардероб)' button!")

# 3. Market menu has "Шота у Ашота" button
bot.handle_menu_market(123456, 999, player, db)
market_btn_cbs = [b.callback_data for row in c_bot.last_markup.keyboard for b in row]
assert "ashot_shop_main" in market_btn_cbs, "Market menu missing 'Шота у Ашота' button!"
print("  ✓ Flea Market contains '👕 Магазин «Шота у Ашота»' button!")

# 4. Ashot Shop menu has 4 categories
bot.handle_ashot_shop(123456, 999, player)
ashot_btn_cbs = [b.callback_data for row in c_bot.last_markup.keyboard for b in row]
assert "ashot_cat_shoes_1" in ashot_btn_cbs
assert "ashot_cat_headwear_1" in ashot_btn_cbs
assert "ashot_cat_suit_1" in ashot_btn_cbs
assert "ashot_cat_accessory_1" in ashot_btn_cbs
print("  ✓ 'Шота у Ашота' shop contains all 4 categories!")

# 5. Ashot Shop pagination
bot.handle_ashot_category(123456, 999, player, db, "shoes", page=1)
page_btn_cbs = [b.callback_data for row in c_bot.last_markup.keyboard for b in row]
assert "ashot_cat_shoes_2" in page_btn_cbs, "Category missing next page button!"
print("  ✓ 'Шота у Ашота' category pagination (page 1 -> page 2) verified!")

print("✅ UI Menus & Navigation: PASSED")

print("\n" + "=" * 60)
print("   🎉 ALL CLOTHES & FLEA MARKET TESTS PASSED WITH 100% SUCCESS!")
print("=" * 60)
