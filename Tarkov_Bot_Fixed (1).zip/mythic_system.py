# -*- coding: utf-8 -*-
"""
Mythic Items System (150,000,000 ₽ each) for Escape from Tarkov MMO Telegram Bot:
1. 💼 «Дипломатический кейс Black Division» (mythic_black_division_case)
   - Drops from Co-op Boss Raids
   - Allows sending elite Black Division squad on a chosen boss every 24h
   - Guarantees a targeted Boss Relic (prioritizing missing relics for 5/5 sets) + 5-12M ₽ + elite trophies

2. 🎖️ «Жетон Отступников (The Goons)» (mythic_goons_token)
   - 0.01% chance (1 in 10,000) from the 2,500,000 ₽ TerraGroup Case
   - Automatic 24h supply drop of unique Goons signature gear:
     * Knight Skull Mask & Crye AVS Rig
     * Big Pipe M32A1 Grenade Launcher & Signature Smoke Pipe
     * Birdeye DVL-10 Saboteur Sniper & ComTac IV Recon Headset
   - 24h special raid: deploy the Goons trio (Knight, Big Pipe, Birdeye) into Tarkov
     for 7-15M ₽, elite loot, and 35% chance for a pure Bitcoin!
"""

import time
import random

MYTHIC_ITEMS = {
    "mythic_black_division_case": {
        "id": "mythic_black_division_case",
        "name": "💼 Дипломатический кейс Black Division",
        "category": "special",
        "market_cat": "Мифические артефакты",
        "rarity": "mythic",
        "price": 150000000,
        "badge": "💼",
        "desc": (
            "Сверхсекретный титановый дипломат TerraGroup. "
            "Дает возможность раз в 24 часа отправлять элитную ЧВК Black Division "
            "на ликвидацию выбранного Босса за гарантированной реликвией и миллионными трофеями."
        )
    },
    "mythic_goons_token": {
        "id": "mythic_goons_token",
        "name": "🎖️ Жетон Отступников (The Goons)",
        "category": "special",
        "market_cat": "Мифические артефакты",
        "rarity": "mythic",
        "price": 150000000,
        "badge": "🎖️",
        "desc": (
            "Мифический жетон признания банды The Goons (шанс 0.01% с кейса за 2.5М). "
            "Каждые 24 часа снабжает схрон уникальной экипировкой Knight, Big Pipe и Birdeye, "
            "а также позволяет раз в 24 часа отправлять троицу Отступников в рейд зачистки."
        )
    },
    "mythic_dsp_sensor": {
        "id": "mythic_dsp_sensor",
        "name": "📟 Закодированный датчик DSP Смотрителя",
        "category": "special",
        "market_cat": "Мифические артефакты",
        "rarity": "mythic",
        "price": 150000000,
        "badge": "📟",
        "desc": (
            "Специальный закодированный радиопередатчик с персональной частотой Зрячего. "
            "Пока датчик находится у вас, легендарный снайпер берет базу и территории ЧВК под личный круглосуточный дозор. "
            "Обеспечивает 100% вечную защиту территорий от мародеров, краж и рейдерских захватов без необходимости продлевать контракты охраны. "
            "Также каждые 24 часа Смотритель Маяка автоматически присылает в ваш схрон 3 персональных предмета экипировки Зрячего."
        )
    }
}

# Unique signature gear of The Goons (given every 24h via mythic_goons_token)
GOONS_GEAR = [
    {
        "id": "goons_knight_skull_mask",
        "name": "💀 Шлем-маска «Knight Skull»",
        "category": "armor",
        "subcategory": "helmet",
        "market_cat": "Шлемы",
        "rarity": "mythic",
        "price": 25000000,
        "armor": 165,
        "combat": 50,
        "desc": "Культовая баллистическая титановая маска со стилизованным черепом командира Knight. Высшая степень рикошета и устрашения (+165 Броня, +50 Урон)."
    },
    {
        "id": "goons_knight_avs_rig",
        "name": "🛡️ Бронежилет Crye Precision CPC plate carrier (Knight Edition)",
        "category": "armor",
        "subcategory": "body_armor",
        "market_cat": "Броня",
        "rarity": "mythic",
        "price": 35000000,
        "armor": 210,
        "combat": 40,
        "desc": "Сверхтяжелый штурмовой плитник Crye Precision CPC командира Knight с композитными бронеплитами 6+ класса защиты (+210 Броня, +40 Урон)."
    },
    {
        "id": "goons_knight_scar_h",
        "name": "⚔️ Штурмовая винтовка FN SCAR-H «Knight’s Wrath» 7.62x51",
        "category": "weapons",
        "subcategory": "assault_rifle",
        "market_cat": "Штурмовые винтовки",
        "rarity": "mythic",
        "price": 42000000,
        "combat": 250,
        "armor": 30,
        "desc": "Кастомизированная штурмовая винтовка FN SCAR-H командира Knight калибра 7.62x51 NATO с оптикой Vudu и глушителем Wave QD. Пробивает любые укрепления (+250 Урон, +30 Защита)."
    },
    {
        "id": "goons_bigpipe_m32a1",
        "name": "🧨 Гранатомет M32A1 «Big Pipe»",
        "category": "weapons",
        "subcategory": "special",
        "market_cat": "Тяжелое оружие",
        "rarity": "mythic",
        "price": 40000000,
        "combat": 260,
        "armor": 15,
        "desc": "Шестизарядный 40-мм револьверный гранатомет Биг Пайпа. Сметает вражеские укрепления и свиту боссов осколочным шквалом (+260 Урон, +15 Защита)."
    },
    {
        "id": "goons_bigpipe_bandana",
        "name": "🪓 Бандана и трубка «Big Pipe Smoke»",
        "category": "armor",
        "subcategory": "helmet",
        "market_cat": "Шлемы",
        "rarity": "mythic",
        "price": 20000000,
        "combat": 55,
        "armor": 135,
        "desc": "Легендарная курительная трубка и пропитанная порохом кевларовая бандана Биг Пайпа. Внушает животный страх врагам (+135 Броня, +55 Урон)."
    },
    {
        "id": "goons_bigpipe_rec10",
        "name": "💥 Карабин Barrett REC10 «Big Pipe Devastator» 7.62x51",
        "category": "weapons",
        "subcategory": "assault_rifle",
        "market_cat": "Штурмовые винтовки",
        "rarity": "mythic",
        "price": 39000000,
        "combat": 240,
        "armor": 25,
        "desc": "Тяжелый полуавтоматический карабин Barrett REC10 Биг Пайпа с дульным тормозом Lantac Dragon и магазином на 25 патронов (+240 Урон, +25 Защита)."
    },
    {
        "id": "goons_birdeye_dvl10",
        "name": "🎯 Снайперская винтовка DVL-10 «Birdeye Saboteur»",
        "category": "weapons",
        "subcategory": "sniper_rifle",
        "market_cat": "Снайперские винтовки",
        "rarity": "mythic",
        "price": 35000000,
        "combat": 230,
        "armor": 15,
        "desc": "Бесшумная снайперская винтовка Бердая с интегрированным глушителем. Безупречная бесшумная ликвидация (+230 Урон, +15 Защита)."
    },
    {
        "id": "goons_birdeye_comtac",
        "name": "🎧 Гарнитура Peltor ComTac IV «Birdeye Recon»",
        "category": "gear",
        "subcategory": "headset",
        "market_cat": "Наушники",
        "rarity": "mythic",
        "price": 20000000,
        "combat": 65,
        "armor": 125,
        "desc": "Активная гарнитура Бердая. Позволяет улавливать малейший шорох шагов противника, упреждая засады (+125 Броня, +65 Урон)."
    },
    {
        "id": "goons_birdeye_rsass",
        "name": "🦅 Снайперская винтовка Remington RSASS «Birdeye Phantom Eye» 7.62x51",
        "category": "weapons",
        "subcategory": "sniper_rifle",
        "market_cat": "Снайперские винтовки",
        "rarity": "mythic",
        "price": 44000000,
        "combat": 265,
        "armor": 20,
        "desc": "Высокоточная марксманская система Бердая с титановым глушителем Ultra 5 и тепловизионным оптическим комплексом (+265 Урон, +20 Защита)."
    }
]

GOONS_GEAR_BY_ID = {item["id"]: item for item in GOONS_GEAR}

# Unique signature gear of Zryachiy (supplied every 24h via mythic_dsp_sensor)
ZRYACHIY_GEAR = [
    {
        "id": "zryachiy_axmc_338",
        "name": "🎯 Снайперская винтовка Accuracy International AXMC «Глаз Зрячего» .338 Lapua",
        "category": "weapons",
        "subcategory": "sniper_rifle",
        "market_cat": "Снайперские винтовки",
        "rarity": "mythic",
        "price": 42000000,
        "combat": 280,
        "armor": 10,
        "desc": "Высокоточная болтовая винтовка Зрячего под патрон .338 Lapua Magnum с оптическим прицелом Schmidt & Bender и титановым глушителем. Абсолютный урон на любой дистанции (+280 Урон, +10 Защита)."
    },
    {
        "id": "zryachiy_cultist_vest",
        "name": "🛡️ Тяжелый плитник Сектантов «Страж Маяка»",
        "category": "armor",
        "subcategory": "body_armor",
        "market_cat": "Броня",
        "rarity": "mythic",
        "price": 38000000,
        "armor": 220,
        "combat": 35,
        "desc": "Модифицированный разгрузочный бронежилет 6+ класса защиты с ритуальными рунами Сектантов. Поглощает попадания даже тяжелых бронебойных пуль (+220 Броня, +35 Урон)."
    },
    {
        "id": "zryachiy_hood_mask",
        "name": "👁️ Балаклава и капюшон «Ослепленный Жнец»",
        "category": "armor",
        "subcategory": "helmet",
        "market_cat": "Шлемы",
        "rarity": "mythic",
        "price": 24000000,
        "combat": 45,
        "armor": 155,
        "desc": "Плотный темный капюшон с маской, скрывающей слепые бельма Зрячего. Обостряет тактический слух и реакцию бойца (+155 Броня, +45 Урон)."
    }
]

ZRYACHIY_GEAR_BY_ID = {item["id"]: item for item in ZRYACHIY_GEAR}

# Cooldowns in seconds (24 hours = 86400s)
COOLDOWN_24H = 86400

def has_mythic_item(player, item_id):
    """Checks if player owns the specific mythic item."""
    if not player:
        return False
    # Check special mythic_items list
    if item_id in player.get("mythic_items", []):
        return True
    # Check stash
    for itm in player.get("stash", []):
        if itm.get("item_id") == item_id:
            return True
    return False

def add_mythic_item_to_player(player, item_id):
    """Safely grants a mythic item to the player."""
    player.setdefault("mythic_items", [])
    if item_id not in player["mythic_items"]:
        player["mythic_items"].append(item_id)
    # Also add to stash for visualization
    now = int(time.time())
    stash_has = any(itm.get("item_id") == item_id for itm in player.get("stash", []))
    if not stash_has:
        player.setdefault("stash", []).append({
            "uid": f"mythic_{item_id}_{now}",
            "item_id": item_id,
            "equipped_to": None
        })

def get_player_mythics(player):
    """Returns list of all mythic items owned by the player."""
    owned = []
    for mid, mdata in MYTHIC_ITEMS.items():
        if has_mythic_item(player, mid):
            owned.append(mdata)
    return owned

# ----------------- BLACK DIVISION SQUAD RAIDS -----------------

def can_launch_black_division(player):
    """Returns (can_launch: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_black_division_case"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_run = player.get("last_black_division_raid", 0)
    elapsed = now - last_run
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def execute_black_division_raid(player, boss_key):
    """
    Executes Black Division operation against chosen boss:
    - reshala, tagilla, killa, shturman, glukhar, sanitar
    - Guarantees a targeted Boss Relic from that boss!
    - Awards 5,000,000 - 12,000,000 ₽ + high-tier loot + 150 EXP
    """
    from relics_system import BOSS_SETS, get_player_relics

    now = int(time.time())
    b_data = BOSS_SETS.get(boss_key)
    if not b_data:
        boss_key = "killa"
        b_data = BOSS_SETS["killa"]

    # Choose relic: prioritize one the player DOES NOT own yet!
    owned_relic_ids = get_player_relics(player)
    missing_relics = [r for r in b_data["relics"] if r["id"] not in owned_relic_ids]
    if missing_relics:
        chosen_relic = random.choice(missing_relics)
        is_new = True
    else:
        chosen_relic = random.choice(b_data["relics"])
        is_new = False

    # Award relic to stash
    player.setdefault("stash", []).append({
        "uid": f"relic_{now}_{random.randint(1000, 9999)}",
        "item_id": chosen_relic["id"],
        "equipped_to": None
    })

    # Award rubles
    rubles = random.randint(5000000, 12000000)
    player["money"] = player.get("money", 0) + rubles

    # Award EXP
    player["exp"] = player.get("exp", 0) + 150

    # Pick 2-3 elite trophy items
    from loot_generator import roll_strict_tarkov_loot
    trophies = []
    for _ in range(random.randint(2, 3)):
        item = roll_strict_tarkov_loot(player)
        trophies.append(item)
        player.setdefault("stash", []).append({
            "uid": f"bd_loot_{now}_{random.randint(1000, 9999)}",
            "item_id": item["id"],
            "equipped_to": None
        })

    # Update cooldown
    player["last_black_division_raid"] = now

    return {
        "boss_name": b_data["boss_name"],
        "boss_icon": b_data["icon"],
        "relic": chosen_relic,
        "is_new_relic": is_new,
        "rubles": rubles,
        "exp": 150,
        "trophies": trophies
    }

# ----------------- THE GOONS MECHANICS -----------------

def can_claim_goons_supply(player):
    """Returns (can_claim: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_goons_token"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_supply = player.get("last_goons_supply", 0)
    elapsed = now - last_supply
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def claim_goons_gear_supply(player):
    """
    Supplies one random unique Goons signature gear piece to player's stash.
    """
    now = int(time.time())
    gear_item = random.choice(GOONS_GEAR)

    player.setdefault("stash", []).append({
        "uid": f"goons_gear_{now}_{random.randint(1000, 9999)}",
        "item_id": gear_item["id"],
        "equipped_to": None
    })

    player["last_goons_supply"] = now
    return gear_item

def can_launch_goons_raid(player):
    """Returns (can_launch: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_goons_token"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_raid = player.get("last_goons_raid", 0)
    elapsed = now - last_raid
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def execute_goons_raid(player):
    """
    Deploys The Goons trio (Knight, Big Pipe, Birdeye) on a 24h sweep raid:
    - 100% victory (they are The Goons)
    - 7,000,000 - 15,000,000 ₽
    - 3-4 elite items
    - 250 EXP
    - 35% chance for 1 pure Bitcoin (BTC)!
    """
    now = int(time.time())

    rubles = random.randint(7000000, 15000000)
    player["money"] = player.get("money", 0) + rubles
    player["exp"] = player.get("exp", 0) + 250

    # Bitcoin roll (35% chance)
    btc_won = 0.0
    if random.random() < 0.35:
        btc_won = 1.0
        player["btc"] = player.get("btc", 0.0) + 1.0

    # 3-4 high tier items
    from loot_generator import roll_strict_tarkov_loot
    trophies = []
    for _ in range(random.randint(3, 4)):
        item = roll_strict_tarkov_loot(player)
        trophies.append(item)
        player.setdefault("stash", []).append({
            "uid": f"goons_raid_{now}_{random.randint(1000, 9999)}",
            "item_id": item["id"],
            "equipped_to": None
        })

    player["last_goons_raid"] = now

    return {
        "rubles": rubles,
        "btc_won": btc_won,
        "exp": 250,
        "trophies": trophies
    }

# ----------------- ZRYACHIY (LIGHTHOUSE) MECHANICS -----------------

def get_zryachiy_supply_status(player):
    """Returns (can_claim: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_dsp_sensor"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_supply = player.get("last_zryachiy_supply", 0)
    if last_supply == 0:
        return True, 0
    elapsed = now - last_supply
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def claim_zryachiy_gear_supply(player):
    """
    Supplies all 3 unique Zryachiy signature gear pieces to player's stash.
    """
    now = int(time.time())
    delivered = []
    stash = player.setdefault("stash", [])
    for itm in ZRYACHIY_GEAR:
        uid = f"zryachiy_gear_{now}_{random.randint(1000, 9999)}"
        stash.append({
            "uid": uid,
            "item_id": itm["id"],
            "equipped_to": None
        })
        delivered.append(itm)

    player["last_zryachiy_supply"] = now
    return delivered

def check_zryachiy_daily_supply(player):
    """
    Automatically checks and delivers the 3 Zryachiy items if 24 hours have passed.
    Returns (delivered: bool, items: list).
    """
    can_claim, _ = get_zryachiy_supply_status(player)
    if not can_claim:
        return False, []

    delivered = claim_zryachiy_gear_supply(player)
    notif = (
        "👁️ <b>ПОСТАВКА СМОТРИТЕЛЯ МАЯКА (Каждые 24 часа):</b>\n"
        "Зрячий автоматически доставил в ваш схрон 3 персональных предмета экипировки:\n"
        "• 🎯 AXMC «Глаз Зрячего» .338 Lapua (Урон: +280, Броня: +10)\n"
        "• 🛡️ Плитник Сектантов «Страж Маяка» (Броня: +220, Урон: +35)\n"
        "• 👁️ Капюшон «Ослепленный Жнец» (Броня: +155, Урон: +45)"
    )
    player.setdefault("notifications", []).append(notif)
    return True, delivered



# ----------------- SQUAD MYTHIC GEAR PERKS & SYNERGIES -----------------
def get_squad_mythic_perks(user):
    """
    Scans player's squad and stash for equipped Mythic gear.
    Calculates combat bonuses, rubles multiplier, EXP multiplier,
    survival chance bonus, Bitcoin drop chance, and boss combat advantages.
    """
    defaults = {
        "goons_pieces": 0,
        "zryachiy_pieces": 0,
        "total_mythics": 0,
        "has_goons_set": False,
        "has_zryachiy_set": False,
        "bonus_power": 0,
        "bonus_armor": 0,
        "rubles_mult": 1.0,
        "exp_mult": 1.0,
        "flat_win_chance": 0.0,
        "boss_combat_win_bonus": 0.0,
        "extra_loot_count": 0,
        "btc_roll_chance": 0.0,
        "has_m32a1": False,
        "has_comtac": False,
        "has_axmc": False,
        "equipped_mythics": []
    }
    if not user:
        return defaults

    squad = user.get("squad", [])
    stash = {itm["uid"]: itm for itm in user.get("stash", [])}

    try:
        from tarkov_engine import ITEMS_BY_ID
    except ImportError:
        ITEMS_BY_ID = {}

    goons_count = 0
    zryachiy_count = 0
    other_mythics_count = 0
    equipped = []
    has_m32a1 = False
    has_comtac = False
    has_axmc = False

    for fighter in squad:
        for slot in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
            uid = fighter.get(slot)
            if uid and uid in stash:
                item_id = stash[uid].get("item_id")
                if item_id in GOONS_GEAR_BY_ID:
                    goons_count += 1
                    equipped.append(GOONS_GEAR_BY_ID[item_id])
                    if item_id == "goons_bigpipe_m32a1":
                        has_m32a1 = True
                    elif item_id == "goons_birdeye_comtac":
                        has_comtac = True
                elif item_id in ZRYACHIY_GEAR_BY_ID:
                    zryachiy_count += 1
                    equipped.append(ZRYACHIY_GEAR_BY_ID[item_id])
                    if item_id == "zryachiy_axmc_338":
                        has_axmc = True
                else:
                    info = ITEMS_BY_ID.get(item_id, {})
                    if info.get("rarity") == "mythic":
                        other_mythics_count += 1
                        equipped.append(info)

    total_mythics = goons_count + zryachiy_count + other_mythics_count
    if total_mythics == 0:
        return defaults

    # Multipliers:
    # Each Goons gear piece gives +25% rubles extracted from raids!
    rubles_bonus = goons_count * 0.25 + other_mythics_count * 0.20

    # Each Zryachiy gear piece gives +35% EXP gained!
    exp_bonus = zryachiy_count * 0.35 + other_mythics_count * 0.20

    # Flat win chance bonus:
    flat_win_chance = goons_count * 0.02
    flat_win_chance += zryachiy_count * 0.06
    flat_win_chance += other_mythics_count * 0.04
    if has_axmc:
        flat_win_chance += 0.04

    # Boss ambush combat bonuses:
    boss_win_bonus = 0.0
    if has_m32a1:
        boss_win_bonus += 0.20  # 40mm grenade launcher obliterates boss cover
    if has_comtac:
        boss_win_bonus += 0.15  # Early acoustic intercept prevents surprise
    if total_mythics >= 2:
        boss_win_bonus += 0.10

    # Set bonuses:
    has_goons_set = (goons_count >= 3)
    has_zryachiy_set = (zryachiy_count >= 3)

    bonus_power = 0
    bonus_armor = 0
    extra_loot = 0
    btc_chance = 0.0

    if has_goons_set:
        bonus_power += 150
        bonus_armor += 100
        rubles_bonus += 0.50  # +50% extra rubles (total +125%+)
        btc_chance = 0.15    # 15% chance for a pure Bitcoin in solo raids!
        boss_win_bonus += 0.15

    if has_zryachiy_set:
        bonus_power += 200
        bonus_armor += 120
        exp_bonus += 0.50    # Total +155%+ EXP
        flat_win_chance += 0.08
        extra_loot += 1      # +1 guaranteed high tier loot
        boss_win_bonus += 0.15

    if other_mythics_count > 0:
        bonus_power += other_mythics_count * 80
        bonus_armor += other_mythics_count * 50
        extra_loot += (other_mythics_count // 2)
        if other_mythics_count >= 2:
            boss_win_bonus += 0.15

    return {
        "goons_pieces": goons_count,
        "zryachiy_pieces": zryachiy_count,
        "total_mythics": total_mythics,
        "has_goons_set": has_goons_set,
        "has_zryachiy_set": has_zryachiy_set,
        "bonus_power": bonus_power,
        "bonus_armor": bonus_armor,
        "rubles_mult": round(1.0 + rubles_bonus, 2),
        "exp_mult": round(1.0 + exp_bonus, 2),
        "flat_win_chance": round(flat_win_chance, 3),
        "boss_combat_win_bonus": round(boss_win_bonus, 2),
        "extra_loot_count": extra_loot,
        "btc_roll_chance": btc_chance,
        "has_m32a1": has_m32a1,
        "has_comtac": has_comtac,
        "has_axmc": has_axmc,
        "equipped_mythics": equipped
    }
