import sys
import types
import bot
import signature_raid_system as srs

print("============================================================")
print("   TESTING PHOTO SUPPORT ACROSS ALL 11 MAIN MENUS & COMMANDS")
print("============================================================")

sent_photos = []
sent_messages = []

bot.bot.answer_callback_query = lambda *a, **kw: None
bot.bot.edit_message_text = lambda txt, *a, **kw: sent_messages.append(txt)
bot.bot.send_message = lambda chat_id, txt, *a, **kw: sent_messages.append(txt)
bot.bot.send_photo = lambda chat_id, photo, caption=None, reply_markup=None, *a, **kw: sent_photos.append({
    "photo": photo,
    "caption": caption,
    "markup": reply_markup
})
bot.bot.delete_message = lambda *a, **kw: None
bot.load_db = lambda: db
bot.save_db = lambda d: None

player = {
    "user_id": 112233,
    "username": "tester",
    "money": 1000000000,
    "squad": [],
    "stash": [],
    "warehouses": {},
    "special_businesses": {},
    "mythic_inventory": ["mythic_goons_token", "mythic_black_division_case", "mythic_dsp_sensor"],
    "stats": {}
}
db = {
    "users": {"112233": player},
    "menu_photos": {},
    "location_photos": {}
}

# 1. Test get_menu_photo defaults
print("[TEST 1] Checking Default Photos for all 11 Menus...")
menus = [
    "supply", "containers", "stash", "market", "ashot",
    "the_goons", "black_division", "zryachiy", "darkzone",
    "base_guard", "signature_raid"
]
for m in menus:
    p = bot.get_menu_photo(m, db)
    assert p and p.startswith("http"), f"Menu {m} default photo invalid: {p}"
    print(f"  ✓ Menu '{m}' -> {p[:45]}...")
print("✅ Default Photos: PASSED")

# 2. Test invoking all 11 menu handlers and verifying send_photo calls
print("\n[TEST 2] Verifying safe photo rendering on all 11 menus...")

test_handlers = [
    ("supply", lambda: bot.handle_menu_supply(112233, 901, player, db)),
    ("containers", lambda: bot.handle_menu_containers(112233, 902, player, db)),
    ("stash", lambda: bot.handle_menu_stash(112233, 903, player, db)),
    ("market", lambda: bot.handle_menu_market(112233, 904, player, db)),
    ("ashot", lambda: bot.handle_ashot_shop(112233, 905, player, db)),
    ("the_goons", lambda: bot.handle_menu_the_goons(112233, 906, player, db)),
    ("black_division", lambda: bot.handle_menu_black_division(112233, 907, player, db)),
    ("zryachiy", lambda: bot.handle_menu_zryachiy(112233, 908, player, db)),
    ("darkzone", lambda: bot.handle_menu_darkzone(112233, 909, player, db)),
    ("base_guard", lambda: bot.handle_menu_base_guard(112233, 910, player, db)),
    ("signature_raid", lambda: srs.handle_menu_signature_raid(112233, 911, player, bot.bot, db)),
]

for menu_name, handler in test_handlers:
    sent_photos.clear()
    handler()
    assert len(sent_photos) > 0, f"Handler for {menu_name} did not send a photo!"
    last_p = sent_photos[-1]
    expected_photo = bot.get_menu_photo(menu_name, db)
    assert last_p["photo"] == expected_photo, f"Handler for {menu_name} sent unexpected photo: {last_p['photo']}"
    assert last_p["caption"] is not None and len(last_p["caption"]) > 0, f"Handler for {menu_name} has empty caption!"
    assert last_p["markup"] is not None, f"Handler for {menu_name} has no markup!"
    print(f"  ✓ Handler for '{menu_name}' sent photo + caption + markup successfully!")

print("✅ All 11 Menu Handlers: PASSED")

# 3. Test Admin Commands for setting and resetting photos
print("\n[TEST 3] Testing Admin Commands for Menu Photos...")

class DummyAdminMsg:
    def __init__(self, text, user_id=9999, uname="reventus"):
        self.text = text
        self.from_user = types.SimpleNamespace(id=user_id, username=uname)
        self.text = text
        self.from_user = types.SimpleNamespace(id=user_id, username="admin_user")
        self.chat = types.SimpleNamespace(id=user_id)
        self.message_id = 999
        self.reply_to_message = None

admin_replies = []
bot.bot.reply_to = lambda msg, text, *a, **kw: admin_replies.append(text)

# Test universal /set_menu_photo
admin_replies.clear()
msg1 = DummyAdminMsg("/set_menu_photo supply https://example.com/custom_supply.jpg")
bot.cmd_admin_commands(msg1)
assert db.get("menu_photos", {}).get("supply") == "https://example.com/custom_supply.jpg"
assert "успешно обновлено" in admin_replies[-1]
print("  ✓ /set_menu_photo supply <url>: PASSED")

# Verify supply menu now uses custom photo
sent_photos.clear()
bot.handle_menu_supply(112233, 901, player, db)
assert sent_photos[-1]["photo"] == "https://example.com/custom_supply.jpg"
print("  ✓ Menu 'supply' correctly rendered custom photo!")

# Test reset
admin_replies.clear()
msg2 = DummyAdminMsg("/reset_menu_photo supply")
bot.cmd_admin_commands(msg2)
assert "supply" not in db.get("menu_photos", {})
assert "сброшено" in admin_replies[-1]
print("  ✓ /reset_menu_photo supply: PASSED")

# Test dedicated shortcut /set_ashot_photo
admin_replies.clear()
msg3 = DummyAdminMsg("/set_ashot_photo https://example.com/ashot_art.jpg")
bot.cmd_admin_commands(msg3)
assert db.get("menu_photos", {}).get("ashot") == "https://example.com/ashot_art.jpg"
print("  ✓ /set_ashot_photo <url>: PASSED")

# Test /list_menu_photos
admin_replies.clear()
msg4 = DummyAdminMsg("/list_menu_photos")
bot.cmd_admin_commands(msg4)
assert "КАТАЛОГ ОБЛОЖЕК МЕНЮ" in admin_replies[-1]
print("  ✓ /list_menu_photos catalog listing: PASSED")

print("\n🎉 ALL 11 MENU PHOTO TESTS PASSED WITH 100% SUCCESS!")
