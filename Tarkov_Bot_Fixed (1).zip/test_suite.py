import sys
import os
import time
import random
import threading

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))

import tarkov_engine as te
import coop_system as cs
import bot as tb

print("==================================================")
print("   RUNNING TARKOV MMO GLOBAL MECHANICS TEST SUITE  ")
print("==================================================")

# 1. Thread safety and DB operations
print("\n[TEST 1] Concurrency & DB Lock Test...")
# Reset test counter
with te.db_transaction() as db:
    db["test_counter"] = 0

def db_worker(worker_id):
    for _ in range(20):
        with te.db_transaction() as db:
            db["test_counter"] += 1

threads = [threading.Thread(target=db_worker, args=(i,)) for i in range(5)]
for t in threads: t.start()
for t in threads: t.join()

final_db = te.load_db()
assert final_db.get("test_counter") == 100, f"Expected 100, got {final_db.get('test_counter')}"
print("✅ Concurrency DB Lock: PASSED (100 atomic increments executed safely)")

# 2. Starter items & Player Creation
print("\n[TEST 2] Player Creation & Starter Stash Validation...")
test_user_id = 999001
player = te.create_new_player(test_user_id, "TestOperator", "Viper")
stash = player.get("stash", [])
assert len(stash) >= 10, f"Stash too small: {len(stash)}"

for item in stash:
    item_id = item["item_id"]
    assert item_id in te.ITEMS_BY_ID, f"Invalid starter item_id found: {item_id}"
print(f"✅ Starter Stash: PASSED (All {len(stash)} items exist in catalog without missing IDs)")

# 3. Squad power calculation & Auto equip
print("\n[TEST 3] Squad Power & Auto-Equip...")
pow_val, arm_val = te.calculate_squad_power(player)
assert pow_val > 0, "Squad power should be > 0"
print(f"✅ Squad Power: PASSED (Power: {pow_val}, Armor: {arm_val})")

# 4. Warehouses Capacity
print("\n[TEST 4] Warehouses Capacity & can_store_item...")
assert te.can_store_item(player, "ak74m_common") == True
cap_w = te.get_warehouse_capacity(player, "weapons")
assert cap_w >= 10, f"Unexpected weapons capacity: {cap_w}"
print(f"✅ Warehouse Capacity: PASSED (Weapon cap: {cap_w})")

# 5. P2P Market listing safety
print("\n[TEST 5] P2P Market Listing Safety...")
mock_db = {"p2p_market": [], "users": {str(test_user_id): player}}
# Add an unknown item to stash to test crash resilience
player["stash"].append({"uid": "corrupt_uid_999", "item_id": "non_existent_item_xyz", "equipped_to": None})

class DummyCall:
    def __init__(self, uid, data):
        self.id = "mock_call_1"
        self.data = data
        self.message = type("msg", (), {"chat": type("c", (), {"id": 12345})(), "message_id": 99})()
        self.from_user = type("u", (), {"id": uid, "username": "TestOperator", "first_name": "Test"})()

class DummyBot:
    def __init__(self):
        self.answers = []
        self.messages = []
    def answer_callback_query(self, call_id, text=None, show_alert=False):
        self.answers.append((call_id, text, show_alert))
    def send_message(self, chat_id, text, reply_markup=None, *args, **kwargs):
        self.messages.append((chat_id, text))
    def send_photo(self, chat_id, photo, caption=None, reply_markup=None, *args, **kwargs):
        self.messages.append((chat_id, caption))
    def delete_message(self, chat_id, message_id, *args, **kwargs):
        pass
    def edit_message_text(self, text, chat_id, message_id, reply_markup=None, *args, **kwargs):
        self.messages.append((chat_id, text))

mock_bot = DummyBot()
tb.bot = mock_bot

# Listing menu shouldn't crash with corrupt item in stash
tb.handle_p2p_list_menu(12345, 99, player, mock_db)
print("✅ P2P Market List Menu: PASSED (Gracefully handled corrupted/unknown stash items)")

# Trying to list the unknown item
call_unknown = DummyCall(test_user_id, "p2p_list_corrupt_uid_999")
tb.handle_p2p_list_action(call_unknown, player, mock_db, "corrupt_uid_999")
assert any("Неизвестный предмет" in str(a) for a in mock_bot.answers), "Unknown item was not rejected safely"
print("✅ P2P Market Unknown Item Listing: PASSED (Safely rejected with alert)")

# Clean up corrupt item
player["stash"] = [i for i in player["stash"] if i["uid"] != "corrupt_uid_999"]

# 6. Squad Hiring & Glukhar Set Bonus
print("\n[TEST 6] Squad Limits & Glukhar Set Bonus...")
# Hire up to 5
player["money"] = 1000000
for _ in range(4): # already has 1 scav
    call_hire = DummyCall(test_user_id, "hire_scav")
    tb.handle_hire_fighter(call_hire, player, mock_db, "scav", 2500)

assert len(player["squad"]) == 5, f"Expected 5 fighters, got {len(player['squad'])}"
# 6th should fail without Glukhar
mock_bot.answers.clear()
tb.handle_hire_fighter(call_hire, player, mock_db, "scav", 2500)
assert any("Отряд уже полон" in str(a) for a in mock_bot.answers), "6th fighter was not blocked"
print("✅ Default Squad Limit: PASSED (Blocked at 5 fighters)")

# Now grant Glukhar 5/5 relics
for r in te.BOSS_SETS["glukhar"]["relics"]:
    player["stash"].append({"uid": f"relic_{r['id']}", "item_id": r["id"], "equipped_to": None})
assert te.has_boss_set_bonus(player, "glukhar") == True, "Glukhar set bonus should be active"

# Now hire 6th fighter
mock_bot.answers.clear()
tb.handle_hire_fighter(call_hire, player, mock_db, "scav", 2500)
assert len(player["squad"]) == 6, f"Expected 6 fighters with Glukhar set, got {len(player['squad'])}"
print("✅ Glukhar Set Bonus: PASSED (Successfully hired 6th fighter)")

# 7. Reshala Business Income Bonus
print("\n[TEST 7] Reshala Business Income & Module Passive Set Bonus...")
pre_reshala = te.get_business_hourly_income("moonshine_still", 3, user=player)

# Grant Reshala relics
for r in te.BOSS_SETS["reshala"]["relics"]:
    player["stash"].append({"uid": f"relic_{r['id']}", "item_id": r["id"], "equipped_to": None})
assert te.has_boss_set_bonus(player, "reshala") == True, "Reshala set bonus should be active"

reshala_inc = te.get_business_hourly_income("moonshine_still", 3, user=player)
assert reshala_inc == int(pre_reshala * 1.50), f"Expected +50%, got {reshala_inc} vs base {pre_reshala}"
print(f"✅ Reshala Business Income: PASSED (Pre: {pre_reshala} -> Bonus: {reshala_inc} [+50%])")

# 8. Darkzone PvP Escrow, Refund & Full Loot
print("\n[TEST 8] Darkzone PvP Escrow, Escrow Refund & Full Loot...")
player2 = te.create_new_player(999002, "ChallengerOperator", "Grizzly")
mock_db["users"][str(player2["user_id"])] = player2
player["money"] = 200000
player2["money"] = 200000

# Create duel
call_create = DummyCall(player["user_id"], "darkzone_create_pvp")
tb.handle_darkzone_create_pvp(call_create, player, mock_db)
assert player["money"] == 100000, f"Creator money should be reduced by stake 100k, got {player['money']}"
duel_id = list(mock_db["active_duels"].keys())[0]

# Cancel duel
call_cancel = DummyCall(player["user_id"], f"cancel_pvp_{duel_id}")
tb.handle_darkzone_cancel_pvp(call_cancel, player, mock_db, duel_id)
assert player["money"] == 200000, f"Creator money should be refunded back to 200k, got {player['money']}"
assert len(mock_db.get("active_duels", {})) == 0, "Duel was not removed upon cancellation"
print("✅ Darkzone Duel Escrow & Cancel Refund: PASSED")

# Create again and accept
tb.handle_darkzone_create_pvp(call_create, player, mock_db)
duel_id = list(mock_db["active_duels"].keys())[0]

call_accept = DummyCall(player2["user_id"], f"accept_pvp_{duel_id}")
tb.handle_darkzone_accept_pvp(call_accept, player2, mock_db, duel_id)
assert len(mock_db.get("active_duels", {})) == 0, "Duel was not resolved"
total_money = player["money"] + player2["money"]
assert total_money == 400000, f"Total money conservation violated! Expected 400k, got {total_money}"
print(f"✅ Darkzone Duel Combat & Payout: PASSED (Money conserved: {total_money} ₽)")

# 9. Co-op Lobby Cancellation & Hijacking Protection
print("\n[TEST 9] Co-op Lobby Leader Rights & Hijacking Protection...")
with te.db_transaction() as real_db:
    real_db.setdefault("coop_lobbies", {})["test_lobby_1"] = {
        "leader_id": player["user_id"],
        "leader_name": "TestOperator",
        "members": [{"user_id": player["user_id"], "username": "TestOperator"}],
        "status": "waiting"
    }

# Non-leader player2 tries to cancel lobby
call_hijack = DummyCall(player2["user_id"], "cancel_coop_test_lobby_1")
call_hijack.from_user.username = "ChallengerOperator"

# Dispatch through tb.callback_handler
tb.callback_handler(call_hijack)
check_db = te.load_db()
assert "test_lobby_1" in check_db.get("coop_lobbies", {}), "Lobby was hijacked by non-leader!"
print("✅ Co-op Lobby Anti-Hijack: PASSED (Non-leader cancellation rejected)")

# Leader cancels lobby
call_leader_cancel = DummyCall(player["user_id"], "cancel_coop_test_lobby_1")
call_leader_cancel.from_user.username = "TestOperator"
tb.callback_handler(call_leader_cancel)
check_db = te.load_db()
assert "test_lobby_1" not in check_db.get("coop_lobbies", {}), "Leader could not cancel own lobby"
print("✅ Co-op Lobby Leader Disband: PASSED")

# 10. Admin Security: Spoofing & Auth check
print("\n[TEST 10] Admin Security Validation...")
# Random player should never be admin
assert te.is_admin(123456789, "random_operator") == False, "Non-admin was granted admin rights!"
# Valid Telegram handle @reventus is recognized
assert te.is_admin(123456789, "reventus") == True, "@reventus handle was not recognized as admin!"
assert te.is_admin(123456789, "@revenuts") == True, "@revenuts handle was not recognized as admin!"
# Real admin user id via ADMIN_USER_IDS
te.ADMIN_USER_IDS.add(777888999)
assert te.is_admin(777888999, "any_name") == True, "Valid admin user_id rejected!"
print("✅ Admin Security Validation: PASSED (Handle & ID authentication verified)")

# 11. Admin Action Item IDs
print("\n[TEST 11] Admin Top Gear Item IDs Validation...")
call_admin = DummyCall(777888999, "admin_action_topgear")
tb.handle_admin_action(call_admin, player, mock_db, "topgear")
topgear_items = [i for i in player["stash"] if i.get("uid", "").startswith("adm_")]
for itm in topgear_items:
    assert itm["item_id"] in te.ITEMS_BY_ID, f"Admin gave invalid item_id: {itm['item_id']}"
print(f"✅ Admin Action Items: PASSED (All {len(topgear_items)} topgear items exist in catalog)")

# 12. Full Inline Button & Callback Dispatch Coverage
print("\n[TEST 12] Full Inline Button & Callback Coverage...")
# Save test user to real db
with te.db_transaction() as real_db:
    real_db["users"][str(test_user_id)] = player

test_callbacks = [
    "main_menu",
    "menu_profile",
    "menu_squad",
    "auto_equip",
    "hire_scav",
    "menu_stash",
    "stash_cat_weapons",
    "stash_cat_gear",
    "stash_cat_headsets",
    "stash_cat_meds",
    "stash_cat_valuables_1",
    "stash_cat_ammo_1",
    "stash_cat_components_1",
    "upgrade_wh_weapons",
    "upgrade_wh_armor",
    "upgrade_wh_gear",
    "upgrade_wh_valuables",
    "menu_market",
    "market_browse_weapons",
    "market_browse_gear",
    "market_browse_headsets",
    "market_browse_meds",
    "market_browse_valuables",
    "market_browse_components",
    "market_p2p",
    "p2p_list_menu",
    "market_supply_channels",
    "buy_delivery",
    "upgrade_supply_channel",
    "market_crypto",
    "sell_btc_all",
    "menu_hideout",
    "upgrade_hideout",
    "claim_income",
    "menu_raids",
    "raid_loc_customs",
    "raid_loc_factory",
    "raid_loc_interchange",
    "raid_loc_reserve",
    "raid_loc_lighthouse",
    "raid_loc_streets",
    "raid_loc_labs",
    "menu_coop",
    "create_coop_streets_coop",
    "menu_darkzone",
    "darkzone_search_bot",
    "menu_containers",
    "open_container_weapon_case",
    "open_container_med_case",
    "open_container_military_case",
    "container_sell_all",
    "menu_airdrop",
    "loot_airdrop_box",
    "menu_relics",
    "menu_admin",
    "admin_action_give1m",
    "admin_action_give10m",
    "admin_action_give10btc",
    "admin_action_givekeycards",
    "admin_action_topgear",
    "admin_action_components",
    "admin_action_airdrop",
    "some_unknown_legacy_callback"
]

passed_buttons = 0
for cb_data in test_callbacks:
    call_btn = DummyCall(test_user_id, cb_data)
    call_btn.from_user.username = "reventus"
    initial_answers = len(mock_bot.answers)
    try:
        tb.callback_handler(call_btn)
        # Verify that answer_callback_query was invoked
        assert len(mock_bot.answers) > initial_answers, f"Button {cb_data} did not call answer_callback_query!"
        passed_buttons += 1
    except Exception as e:
        print(f"❌ Error testing button {cb_data}: {e}")
        raise e

print(f"✅ Inline Buttons Coverage: PASSED (All {passed_buttons}/{len(test_callbacks)} inline buttons handled flawlessly with responsive callback acknowledgements)")

print("\n==================================================")
print("   🎉 ALL 12 TESTS PASSED WITH ZERO ERRORS!       ")
print("==================================================")
