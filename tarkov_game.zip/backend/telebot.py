# Mock telebot for testing and simulation
class types:
    class InlineKeyboardMarkup:
        def __init__(self, row_width=3):
            self.row_width = row_width
            self.keyboard = []
        def add(self, *buttons):
            for i in range(0, len(buttons), self.row_width):
                self.keyboard.append(list(buttons[i:i + self.row_width]))
            return self
        def row(self, *buttons):
            self.keyboard.append(list(buttons))
            return self
    class InlineKeyboardButton:
        def __init__(self, text, callback_data=None, url=None):
            self.text = text
            self.callback_data = callback_data
            self.url = url
    class ReplyKeyboardMarkup:
        def __init__(self, resize_keyboard=True):
            self.keyboard = []
        def add(self, *buttons):
            self.keyboard.append(list(buttons))
            return self
        def row(self, *buttons):
            self.keyboard.append(list(buttons))
            return self
    class KeyboardButton:
        def __init__(self, text):
            self.text = text
    class User:
        def __init__(self, id, username=None, first_name=None):
            self.id = id
            self.username = username
            self.first_name = first_name or str(id)
    class Chat:
        def __init__(self, id, type='private'):
            self.id = id
            self.type = type
    class Message:
        def __init__(self, message_id=1, from_user=None, chat=None, text=''):
            self.message_id = message_id
            self.from_user = from_user or types.User(1)
            self.chat = chat or types.Chat(1)
            self.text = text
    class CallbackQuery:
        def __init__(self, id='1', from_user=None, message=None, data=''):
            self.id = str(id)
            self.from_user = from_user or types.User(1)
            self.message = message or types.Message()
            self.data = data

class TeleBot:
    def __init__(self, token, parse_mode='HTML'):
        self.token = token
        self.parse_mode = parse_mode
        self.message_handlers = []
        self.callback_handlers = []
        self.sent_messages = []
        self.edited_messages = []
        self.answered_callbacks = []
    def message_handler(self, commands=None, func=None, content_types=None):
        def decorator(fn):
            self.message_handlers.append({'commands': commands, 'func': func, 'fn': fn})
            return fn
        return decorator
    def callback_query_handler(self, func=None):
        def decorator(fn):
            self.callback_handlers.append({'func': func, 'fn': fn})
            return fn
        return decorator
    def send_message(self, chat_id, text, reply_markup=None, parse_mode=None):
        msg = types.Message(message_id=len(self.sent_messages)+100, text=text)
        self.sent_messages.append({'chat_id': chat_id, 'text': text, 'reply_markup': reply_markup})
        return msg
    def edit_message_text(self, text, chat_id, message_id, reply_markup=None, parse_mode=None):
        self.edited_messages.append({'chat_id': chat_id, 'message_id': message_id, 'text': text, 'reply_markup': reply_markup})
        return types.Message(message_id=message_id, text=text)
    def answer_callback_query(self, callback_query_id, text=None, show_alert=False):
        self.answered_callbacks.append({'id': callback_query_id, 'text': text, 'show_alert': show_alert})
        return True
    def reply_to(self, message, text, reply_markup=None):
        return self.send_message(message.chat.id, text, reply_markup=reply_markup)
