# -*- coding: utf-8 -*-
"""
Cooperative Raids System for Escape from Tarkov MMO Telegram Bot
Supports up to 6 players across 5 difficulty levels.

CONSTRAINTS & RULES:
1. Up to 6 players per raid lobby.
2. 5 difficulty tiers:
   - 🟢 Easy (Свалка / Промзона)
   - 🟡 Normal (Торговый центр Ультра)
   - 🔴 Hard (Бункер Резерва Глухаря) -> Requires Legendary Keycard
   - 🟣 Ultra (Очистные сооружения / Отступники) -> Requires Legendary Keycard
   - ☠️ Colossal (TerraGroup Labs Underground) -> Requires Legendary Keycard
3. Keycard requirement:
   Leader must possess an item with 'keycard' in id or 'Ключ-карта' in name (Legendary).
   1 keycard is consumed upon launching a Hard, Ultra, or Colossal raid.
4. Only Signature PMCs allowed:
   Players must have selected their signature PMC class.
5. Cooperative failure penalty:
   On failure, ALL participants receive a 2-hour cooldown ('coop_cooldown_until' = now + 7200)
   and LOSE their signature PMC passive buff for 2 full hours!
"""

import time
import random
try:
    from telebot import types
except ImportError:
    types = None
from tarkov_engine import (
    save_db, has_buff, calculate_squad_power, ITEMS_BY_ID, PMC_DEFINITIONS,
    can_store_item, add_player_rubles, add_player_exp
)
try:
    from relics_system import has_boss_set_bonus
except ImportError:
    def has_boss_set_bonus(p, b): return False
from loot_generator import (
    COOP_DIFFICULTIES, simulate_coop_raid
)

def fmt_rub(val):
    return f"{int(val):,} ₽".replace(",", " ")

def get_leader_keycard(player):
    """Finds an unused legendary keycard in player's stash."""
    stash = player.get("stash", [])
    for itm in stash:
        if itm.get("equipped_to") is None:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            iid = info.get("id", "").lower()
            name = info.get("name", "").lower()
            if "keycard" in iid or "ключ-карт" in name:
                return itm, info
    return None, None

def handle_menu_coop(chat_id, msg_id, player, db, bot):
    """Main cooperative raids menu showing active lobbies and difficulty options."""
    lobbies = db.get("coop_lobbies", {})
    active_lobbies = [lob for lob in lobbies.values() if lob.get("status") == "waiting"]

    txt = (
        "<b>👥 КООПЕРАТИВНЫЕ РЕЙДЫ В ТАРКОВ (ДО 6 БОЙЦОВ)</b>\n"
        "────────────────────────\n"
        "Объединяйтесь с другими ЧВК для совместных штурмов охраняемых зон!\n"
        "• <b>Размер группы:</b> до 6 бойцов\n"
        "• <b>Шанс успеха:</b> возрастает с каждым новым участником (+4-8% за бойца)\n"
        "• <b>Условия:</b> Только Сигнатурные ЧВК!\n"
        "• <b>ВНИМАНИЕ:</b> На сложных рейдах требуется Лабораторная ключ-карта у лидера.\n"
        "• ☠️ <b>ПЕНАЛЬТИ ПРИ ПРОВАЛЕ:</b> Все участники получают травму и <b>теряют классовый пассивный бафф на 2 часа</b>!\n"
        "────────────────────────\n"
    )

    if player.get("coop_cooldown_until", 0) > time.time():
        rem = int((player["coop_cooldown_until"] - time.time()) // 60)
        txt += f"⚠️ <b>ВЫ ТРАВМИРОВАНЫ ПОСЛЕ ПРОВАЛА:</b> еще {rem} мин. (Бафф ЧВК отключен!)\n\n"

    txt += "<b>Выберите сложность для создания рейда:</b>"

    markup = types.InlineKeyboardMarkup(row_width=1)
    for k, d in COOP_DIFFICULTIES.items():
        kc_mark = " 🔑 [Нужна Ключ-карта]" if d["requires_keycard"] else ""
        markup.add(
            types.InlineKeyboardButton(f"{d['name']}{kc_mark}", callback_data=f"coop_view_{k}")
        )

    if active_lobbies:
        txt += f"\n\n<b>Активные лобби в поиске бойцов ({len(active_lobbies)}):</b>"
        for lob in active_lobbies[:5]:
            diff = COOP_DIFFICULTIES.get(lob["diff_key"], {})
            m_cnt = len(lob.get("members", []))
            markup.add(
                types.InlineKeyboardButton(
                    f"⚔️ {diff.get('badge', '🛡️')} Лобби #{lob['id'][-4:]} от @{lob['leader_name']} ({m_cnt}/6)",
                    callback_data=f"join_coop_{lob['id']}"
                )
            )

    markup.add(types.InlineKeyboardButton("🔙 К Меню Рейдов", callback_data="menu_raids"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_coop_difficulty_view(chat_id, msg_id, player, diff_key, bot):
    diff = COOP_DIFFICULTIES.get(diff_key)
    if not diff:
        return

    kc_card, _ = get_leader_keycard(player)
    kc_status = "✅ В наличии в схроне" if kc_card else "❌ Отсутствует в схроне"

    txt = (
        f"<b>⚔️ РЕЙД: {diff['name']}</b>\n"
        f"────────────────────────\n"
        f"<i>{diff['desc']}</i>\n\n"
        f"📊 <b>Базовый шанс победы:</b> {diff['base_win_chance']}%\n"
        f"📈 <b>Бонус за каждого ЧВК:</b> +{diff['member_bonus']}% (до +{diff['member_bonus']*6}%)\n"
        f"💰 <b>Награда в рублях каждому:</b> {fmt_rub(diff['rubles_reward'][0])} — {fmt_rub(diff['rubles_reward'][1])}\n"
        f"🎁 <b>Количество предметов:</b> {diff['loot_count'][0]}–{diff['loot_count'][1]} шт.\n"
        f"🔑 <b>Ключ-карта лидера:</b> {'ТРЕБУЕТСЯ (' + kc_status + ')' if diff['requires_keycard'] else 'Не требуется'}\n"
        f"────────────────────────\n"
        f"<i>При провале все участники теряют бафф ЧВК на 2 часа!</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not diff['requires_keycard'] or kc_card:
        markup.add(
            types.InlineKeyboardButton(f"🚀 Создать лобби на 6 бойцов", callback_data=f"create_coop_{diff_key}")
        )
    else:
        markup.add(
            types.InlineKeyboardButton(f"❌ Нет Лабораторной ключ-карты", callback_data="none")
        )
    markup.add(types.InlineKeyboardButton("🔙 К списку трудностей", callback_data="menu_coop_raids"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_create_coop_lobby(call, player, db, diff_key, bot):
    now = int(time.time())
    diff = COOP_DIFFICULTIES.get(diff_key)
    if not diff:
        bot.answer_callback_query(call.id, "❌ Неверный уровень сложности!", show_alert=True)
        return

    # Check if squad has fighters
    if not player.get("squad") or len(player.get("squad", [])) == 0:
        bot.answer_callback_query(call.id, "❌ В вашем отряде нет бойцов! Наймите бойцов перед кооп-рейдом.", show_alert=True)
        return

    # Check keycard if required
    if diff["requires_keycard"]:
        kc_card, _ = get_leader_keycard(player)
        if not kc_card:
            bot.answer_callback_query(call.id, "❌ Требуется Лабораторная ключ-карта (Legendary) в вашем схроне!", show_alert=True)
            return

    lobby_id = f"coop_{now}_{random.randint(100, 999)}"
    pow_val, arm_val = calculate_squad_power(player)

    lobby = {
        "id": lobby_id,
        "leader_id": player["user_id"],
        "leader_name": player.get("username", f"PMC_{player['user_id']}"),
        "diff_key": diff_key,
        "created_at": now,
        "status": "waiting",
        "chat_id": call.message.chat.id,
        "message_id": call.message.message_id,
        "members": [
            {
                "user_id": player["user_id"],
                "username": player.get("username", f"PMC_{player['user_id']}"),
                "pmc_signature": player.get("pmc_signature", "Viper"),
                "power": pow_val,
                "armor": arm_val
            }
        ]
    }

    db.setdefault("coop_lobbies", {})[lobby_id] = lobby
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Лобби рейда создано! Ожидаем до 6 бойцов.")
    render_lobby_ui(call.message.chat.id, call.message.message_id, lobby, player, bot)

def render_lobby_ui(chat_id, msg_id, lobby, viewer_player, bot):
    diff = COOP_DIFFICULTIES.get(lobby["diff_key"], {})
    members = lobby.get("members", [])
    m_count = len(members)
    win_chance = min(90, diff["base_win_chance"] + m_count * diff["member_bonus"])

    txt = (
        f"<b>🛡️ ЛОББИ КООПЕРАТИВНОГО РЕЙДА #{lobby['id'][-4:]}</b>\n"
        f"Локация: <b>{diff['name']}</b>\n"
        f"Лидер рейда: @{lobby['leader_name']}\n"
        f"Шанс зачистки: <b>{win_chance}%</b> (+{diff['member_bonus']}% за каждого бойца)\n"
        f"────────────────────────\n"
        f"<b>Бойцы в отряде ({m_count}/6):</b>\n"
    )

    for idx, m in enumerate(members, start=1):
        p_info = PMC_DEFINITIONS.get(m['pmc_signature'], {})
        txt += f"{idx}. @{m['username']} — ЧВК {p_info.get('icon', '🎖️')} <b>{m['pmc_signature']}</b> (Огневая мощь: {m['power']})\n"

    txt += (
        f"────────────────────────\n"
        f"<i>Лидер может нажать «Выйти в рейд», как только в группе будет хотя бы 1 боец. Максимум — 6 бойцов.</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    is_leader = viewer_player["user_id"] == lobby["leader_id"]
    is_member = any(m["user_id"] == viewer_player["user_id"] for m in members)

    if not is_member and m_count < 6:
        markup.add(types.InlineKeyboardButton("➕ Вступить в рейд", callback_data=f"join_coop_{lobby['id']}"))

    if is_member and not is_leader:
        markup.add(types.InlineKeyboardButton("🚪 Покинуть лобби", callback_data=f"leave_coop_{lobby['id']}"))

    if is_leader:
        markup.add(types.InlineKeyboardButton(f"🚀 ВЫЙТИ В РЕЙД ({m_count}/6)", callback_data=f"start_coop_{lobby['id']}"))
        markup.add(types.InlineKeyboardButton("❌ Распустить лобби", callback_data=f"cancel_coop_{lobby['id']}"))

    markup.add(types.InlineKeyboardButton("🔄 Обновить статус", callback_data=f"refresh_coop_{lobby['id']}"))
    markup.add(types.InlineKeyboardButton("🔙 К списку рейдов", callback_data="menu_coop_raids"))

    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception:
        pass

def handle_join_coop_lobby(call, player, db, lobby_id, bot):
    lobbies = db.get("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "waiting":
        bot.answer_callback_query(call.id, "❌ Лобби уже закрыто или рейд начался!", show_alert=True)
        return

    members = lobby.setdefault("members", [])
    if len(members) >= 6:
        bot.answer_callback_query(call.id, "❌ В лобби уже максимальное число участников (6/6)!", show_alert=True)
        return

    if any(m["user_id"] == player["user_id"] for m in members):
        bot.answer_callback_query(call.id, "⚠️ Вы уже в этом лобби!")
        return

    if not player.get("squad") or len(player.get("squad", [])) == 0:
        bot.answer_callback_query(call.id, "❌ В вашем отряде нет бойцов! Наймите бойцов перед вступлением в рейд.", show_alert=True)
        return

    pow_val, arm_val = calculate_squad_power(player)
    members.append({
        "user_id": player["user_id"],
        "username": player.get("username", f"PMC_{player['user_id']}"),
        "pmc_signature": player.get("pmc_signature", "Viper"),
        "power": pow_val,
        "armor": arm_val
    })
    save_db(db)

    bot.answer_callback_query(call.id, "✅ Вы успешно вступили в отряд рейда!")
    render_lobby_ui(call.message.chat.id, call.message.message_id, lobby, player, bot)

def handle_leave_coop_lobby(call, player, db, lobby_id, bot):
    lobbies = db.get("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "waiting":
        bot.answer_callback_query(call.id, "❌ Лобби не найдено!")
        return

    members = lobby.get("members", [])
    lobby["members"] = [m for m in members if m["user_id"] != player["user_id"]]
    if player["user_id"] == lobby.get("leader_id"):
        if lobby["members"]:
            new_lead = lobby["members"][0]
            lobby["leader_id"] = new_lead["user_id"]
            lobby["leader_name"] = new_lead["username"]
        else:
            lobbies.pop(lobby_id, None)
    save_db(db)

    bot.answer_callback_query(call.id, "🚪 Вы покинули лобби.")
    handle_menu_coop(call.message.chat.id, call.message.message_id, player, db, bot)

def handle_start_coop_lobby(call, player, db, lobby_id, bot):
    lobbies = db.get("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "waiting":
        bot.answer_callback_query(call.id, "❌ Рейд уже запущен или не найден!", show_alert=True)
        return

    if player["user_id"] != lobby["leader_id"]:
        bot.answer_callback_query(call.id, "❌ Только лидер лобби может запустить рейд!", show_alert=True)
        return

    # Check if leader has fighters
    if not player.get("squad") or len(player.get("squad", [])) == 0:
        bot.answer_callback_query(call.id, "❌ В вашем отряде нет бойцов! Наймите бойцов перед запуском рейда.", show_alert=True)
        return

    # Filter out any lobby members whose squad died while waiting
    valid_members = []
    for m in lobby.get("members", []):
        m_user = db["users"].get(str(m["user_id"]))
        if m_user and m_user.get("squad") and len(m_user.get("squad", [])) > 0:
            valid_members.append(m)
    if not valid_members:
        bot.answer_callback_query(call.id, "❌ Ни у кого в лобби нет живых бойцов!", show_alert=True)
        return
    lobby["members"] = valid_members

    diff = COOP_DIFFICULTIES.get(lobby["diff_key"], {})

    # Consume keycard from leader if required
    if diff.get("requires_keycard"):
        kc_card, _ = get_leader_keycard(player)
        if not kc_card:
            bot.answer_callback_query(call.id, "❌ У вас больше нет Лабораторной ключ-карты!", show_alert=True)
            return
        player.get("stash", []).remove(kc_card)

    lobby["status"] = "in_progress"
    save_db(db)

    # Simulate coop raid
    result = simulate_coop_raid(lobby["diff_key"], lobby["members"])
    now = int(time.time())

    txt = (
        f"<b>⚔️ ИТОГИ КООПЕРАТИВНОГО РЕЙДА #{lobby['id'][-4:]}</b>\n"
        f"Локация: <b>{diff['name']}</b>\n"
        f"Бойцов в рейде: <b>{len(lobby['members'])}</b> | Шанс успеха был: <b>{result['win_chance']}%</b>\n"
        f"────────────────────────\n"
    )

    if result["success"]:
        txt += (
            "🎉 <b>ТРИУМФ ОТРЯДА! ЗОНА ПОЛНОСТЬЮ ЗАЧИЩЕНА!</b>\n"
            "Все бойцы успешно эвакуировались на вертолете с богатым лутом!\n\n"
        )
        if result.get("relic_dropped"):
            r_item = result["relic_dropped"]
            txt += f"🌟 <b>ЛЕГЕНДАРНЫЙ ТРОФЕЙ!</b> В рейде выпала реликвия: <b>{r_item.get('name')}</b> (10 000 000 ₽)!\n\n"

        for m in lobby["members"]:
            uid = str(m["user_id"])
            m_player = db["users"].get(uid)
            rew = result["members_rewards"].get(uid, {"rubles": 100000, "items": []})
            stored_count = 0
            dropped_count = 0
            if m_player:
                add_player_rubles(m_player, rew["rubles"])
                add_player_exp(m_player, 75)
                m_player.setdefault("stats", {})["coop_wins"] = m_player.get("stats", {}).get("coop_wins", 0) + 1
                m_player.setdefault("stats", {})["coop_raids_count"] = m_player.get("stats", {}).get("coop_raids_count", 0) + 1
                for itm in rew["items"]:
                    if can_store_item(m_player, itm["id"]):
                        m_player.setdefault("stash", []).append({
                            "uid": f"coop_{now}_{random.randint(1000,9999)}",
                            "item_id": itm["id"],
                            "equipped_to": None
                        })
                        stored_count += 1
                    else:
                        dropped_count += 1
            relic_note = " 🏆 <b>[ПОЛУЧИЛ РЕЛИКВИЮ БОССА]</b>" if rew.get("dropped_relic") else ""
            overflow_note = f" (⚠️ {dropped_count} не влезло в схрон)" if dropped_count > 0 else ""
            txt += f"👤 @{m['username']}: +<b>{fmt_rub(rew['rubles'])}</b> и {stored_count} предметов в схрон!{relic_note}{overflow_note}\n"
    else:
        txt += (
            "💀 <b>РАЗГРОМ ОТРЯДА! ЗАСАДА РЕЙДЕРОВ!</b>\n"
            "Группа попала под перекрестный огонь пулеметов и тяжелой артиллерии.\n\n"
            "⚠️ <b>ЖЕСТКИЙ ШТРАФ:</b> Все участники отправлены в медблок на <b>2 часа</b>.\n"
            "Пассивные способности ЧВК абсолютно у всех бойцов отключены на время восстановления!\n"
            "Все бойцы отряда (ЧВК и Дикие) погибли, а снаряжение потеряно!\n\n"
        )
        for m in lobby["members"]:
            uid = str(m["user_id"])
            m_player = db["users"].get(uid)
            cd_sec = 7200
            cd_text = "2 часа"
            buff_note = "(бафф отключен)"
            scav_loss_note = ""
            if m_player:
                if has_boss_set_bonus(m_player, "sanitar"):
                    cd_sec = 1800 # 30 minutes
                    cd_text = "30 мин (Сет Санитара)"
                elif has_boss_set_bonus(m_player, "killa"):
                    cd_sec = 3600 # 1 hour
                    cd_text = "1 час (Сет Киллы)"
                    buff_note = "(бафф активен - Килла)"

                m_player["coop_cooldown_until"] = now + cd_sec
                m_player.setdefault("stats", {})["coop_losses"] = m_player.get("stats", {}).get("coop_losses", 0) + 1
                m_player.setdefault("stats", {})["coop_raids_count"] = m_player.get("stats", {}).get("coop_raids_count", 0) + 1

                if has_boss_set_bonus(m_player, "tagilla"):
                    scav_loss_note = " [🛡️ Сет Тагиллы спас бойцов]"
                else:
                    squad = m_player.get("squad", [])
                    stash = m_player.get("stash", [])
                    dead_scavs = 0
                    dead_pmcs = 0
                    for f in squad:
                        for s_k in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
                            u = f.get(s_k)
                            if u:
                                m_player["stash"] = [i for i in m_player.get("stash", []) if i.get("uid") != u]
                                f[s_k] = None
                        if f.get("type") == "scav":
                            dead_scavs += 1
                        else:
                            dead_pmcs += 1
                    m_player["squad"] = []
                    loss_parts = []
                    if dead_pmcs > 0:
                        loss_parts.append(f"{dead_pmcs} ЧВК")
                    if dead_scavs > 0:
                        loss_parts.append(f"{dead_scavs} Диких")
                    loss_txt = ", ".join(loss_parts) if loss_parts else "0 бойцов"
                    scav_loss_note = f" [💀 Отряд погиб: {loss_txt}]"

            txt += f"🚑 @{m['username']} — Кулдаун {cd_text} {buff_note}{scav_loss_note}\n"

    # Remove completed lobby
    lobbies.pop(lobby_id, None)
    save_db(db)

    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🔙 Вернуться в Меню Рейдов", callback_data="menu_coop_raids")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)
