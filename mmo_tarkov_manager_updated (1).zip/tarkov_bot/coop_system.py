# -*- coding: utf-8 -*-
"""
Cooperative Raids System for Escape from Tarkov MMO Telegram Bot
Supports up to 6 players across 5 difficulty levels.

CONSTRAINTS & RULES:
1. Up to 6 players per raid lobby.
2. 5 difficulty tiers:
   - 🟢 Easy (Свалка / Промзона)
   - 🟡 Normal (Торговый центр Ультра)
   - 🔴 Hard (Бункер Резерва Глухаря) -> Requires Legendary Keycard
   - 🟣 Ultra (Очистные сооружения / Отступники) -> Requires Legendary Keycard
   - ☠️ Colossal (TerraGroup Labs Underground) -> Requires Legendary Keycard
3. Keycard requirement:
   Leader must possess an item with 'keycard' in id or 'Ключ-карта' in name (Legendary).
   1 keycard is consumed upon launching a Hard, Ultra, or Colossal raid.
4. Only Signature PMCs allowed:
   Players must have selected their signature PMC class.
5. Cooperative failure penalty:
   On failure, ALL participants receive a 2-hour cooldown ('coop_cooldown_until' = now + 7200)
   and LOSE their signature PMC passive buff for 2 full hours!
"""

import time
import random
import html
from mythic_system import add_mythic_item_to_player
try:
    from telebot import types
except ImportError:
    types = None
from tarkov_engine import (
    save_db, has_buff, calculate_squad_power, ITEMS_BY_ID, PMC_DEFINITIONS,
    can_store_item, add_player_rubles, add_player_exp
)
try:
    from relics_system import has_boss_set_bonus
except ImportError:
    def has_boss_set_bonus(p, b): return False
from loot_generator import (
    COOP_DIFFICULTIES, simulate_coop_raid
)
from gd_military_system import has_gd_business, add_gd_bp_exp, roll_gd_raid_weapon

def fmt_rub(val):
    return f"{int(val):,} ₽".replace(",", " ")

def get_leader_keycard(player):
    """Finds an unused legendary keycard in player's stash."""
    stash = player.get("stash", [])
    for itm in stash:
        if itm.get("equipped_to") is None:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            iid = info.get("id", "").lower()
            name = info.get("name", "").lower()
            if "keycard" in iid or "ключ-карт" in name:
                return itm, info
    return None, None

def handle_menu_coop(chat_id, msg_id, player, db, bot):
    """Main cooperative raids menu showing active lobbies and difficulty options."""
    lobbies = db.get("coop_lobbies", {})
    active_lobbies = [lob for lob in lobbies.values() if lob.get("status") == "waiting"]

    txt = (
        "<b>👥 КООПЕРАТИВНЫЕ РЕЙДЫ В ТАРКОВ (ДО 6 БОЙЦОВ)</b>\n"
        "────────────────────────\n"
        "Объединяйтесь с другими ЧВК для совместных штурмов охраняемых зон!\n"
        "• <b>Размер группы:</b> до 6 бойцов\n"
        "• <b>Шанс успеха:</b> возрастает с каждым новым участником (+4-8% за бойца)\n"
        "• <b>Условия:</b> Только Сигнатурные ЧВК!\n"
        "• <b>ВНИМАНИЕ:</b> На сложных рейдах требуется Лабораторная ключ-карта у лидера.\n"
        "• ☠️ <b>ПЕНАЛЬТИ ПРИ ПРОВАЛЕ:</b> Все участники получают травму и <b>теряют классовый пассивный бафф на 2 часа</b>!\n"
        "────────────────────────\n"
    )

    if player.get("coop_cooldown_until", 0) > time.time():
        rem = int((player["coop_cooldown_until"] - time.time()) // 60)
        txt += f"⚠️ <b>ВЫ ТРАВМИРОВАНЫ ПОСЛЕ ПРОВАЛА:</b> еще {rem} мин. (Бафф ЧВК отключен!)\n\n"

    txt += "<b>Выберите сложность для создания рейда:</b>"

    markup = types.InlineKeyboardMarkup(row_width=1)
    for k, d in COOP_DIFFICULTIES.items():
        kc_mark = " 🔑 [Нужна Ключ-карта]" if d["requires_keycard"] else ""
        min_ch = d['base_win_chance']
        max_ch = min(90, d['base_win_chance'] + 6 * d['member_bonus'])
        markup.add(
            types.InlineKeyboardButton(f"{d['name']} (~{min_ch}–{max_ch}%){kc_mark}", callback_data=f"coop_view_{k}")
        )

    if active_lobbies:
        my_lobby = next((lob for lob in active_lobbies if str(lob.get("leader_id")) == str(player["user_id"]) or any(str(m.get("user_id")) == str(player["user_id"]) for m in lob.get("members", []))), None)
        if my_lobby:
            markup.add(
                types.InlineKeyboardButton(f"👉 ВЕРНУТЬСЯ В ВАШЕ ЛОББИ #{my_lobby['id'][-4:]}", callback_data=f"join_coop_{my_lobby['id']}")
            )
        txt += f"\n\n<b>Активные лобби в поиске бойцов ({len(active_lobbies)}):</b>"
        for lob in active_lobbies[:5]:
            diff = COOP_DIFFICULTIES.get(lob.get("diff_key"), COOP_DIFFICULTIES["easy"])
            m_cnt = len(lob.get("members", []))
            markup.add(
                types.InlineKeyboardButton(
                    f"⚔️ {diff.get('badge', '🛡️')} Лобби #{lob['id'][-4:]} от @{lob.get('leader_name', 'Лидер')} ({m_cnt}/6)",
                    callback_data=f"join_coop_{lob['id']}"
                )
            )

    markup.add(types.InlineKeyboardButton("🔙 К Меню Рейдов", callback_data="menu_raids"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_coop_difficulty_view(chat_id, msg_id, player, diff_key, bot):
    diff = COOP_DIFFICULTIES.get(diff_key)
    if not diff:
        return

    kc_card, _ = get_leader_keycard(player)
    kc_status = "✅ В наличии в схроне" if kc_card else "❌ Отсутствует в схроне"

    txt = (
        f"<b>⚔️ РЕЙД: {diff['name']}</b>\n"
        f"────────────────────────\n"
        f"<i>{diff['desc']}</i>\n\n"
        f"📊 <b>Базовый шанс победы:</b> {diff['base_win_chance']}%\n"
        f"📈 <b>Бонус за каждого ЧВК:</b> +{diff['member_bonus']}% (до +{diff['member_bonus']*6}%)\n"
        f"💰 <b>Награда в рублях каждому:</b> {fmt_rub(diff['rubles_reward'][0])} — {fmt_rub(diff['rubles_reward'][1])}\n"
        f"🎁 <b>Количество предметов:</b> {diff['loot_count'][0]}–{diff['loot_count'][1]} шт.\n"
        f"🔑 <b>Ключ-карта лидера:</b> {'ТРЕБУЕТСЯ (' + kc_status + ')' if diff['requires_keycard'] else 'Не требуется'}\n"
        f"────────────────────────\n"
        f"<i>При провале все участники теряют бафф ЧВК на 2 часа!</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not diff['requires_keycard'] or kc_card:
        markup.add(
            types.InlineKeyboardButton(f"🚀 Создать лобби (Базовый шанс: {diff['base_win_chance']}%)", callback_data=f"create_coop_{diff_key}")
        )
    else:
        markup.add(
            types.InlineKeyboardButton(f"❌ Нет Лабораторной ключ-карты", callback_data="none")
        )
    markup.add(types.InlineKeyboardButton("🔙 К списку трудностей", callback_data="menu_coop_raids"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_create_coop_lobby(call, player, db, diff_key, bot):
    now = int(time.time())
    diff = COOP_DIFFICULTIES.get(diff_key)
    if not diff:
        bot.answer_callback_query(call.id, "❌ Неверный уровень сложности!", show_alert=True)
        return

    # In Co-op, player deploys with their signature PMC operator
    if player.get("coop_cooldown_until", 0) > now:
        rem = int((player["coop_cooldown_until"] - now) // 60)
        bot.answer_callback_query(call.id, f"🚑 Ваш сигнатурный ЧВК в медблоке! Восстановление: {rem} мин.", show_alert=True)
        return

    # Check keycard if required
    if diff["requires_keycard"]:
        kc_card, _ = get_leader_keycard(player)
        if not kc_card:
            bot.answer_callback_query(call.id, "❌ Требуется Лабораторная ключ-карта (Legendary) в вашем схроне!", show_alert=True)
            return

    lobby_id = f"coop_{now}_{random.randint(100, 999)}"
    pow_val, arm_val = calculate_squad_power(player)

    lobby = {
        "id": lobby_id,
        "leader_id": player["user_id"],
        "leader_name": player.get("username", f"PMC_{player['user_id']}"),
        "diff_key": diff_key,
        "created_at": now,
        "status": "waiting",
        "chat_id": call.message.chat.id,
        "message_id": call.message.message_id,
        "members": [
            {
                "user_id": player["user_id"],
                "username": player.get("username", f"PMC_{player['user_id']}"),
                "pmc_signature": player.get("pmc_signature", "Viper"),
                "power": pow_val,
                "armor": arm_val
            }
        ]
    }

    db.setdefault("coop_lobbies", {})[lobby_id] = lobby
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Лобби рейда создано! Ожидаем до 6 бойцов.")
    render_lobby_ui(call.message.chat.id, call.message.message_id, lobby, player, bot)

def render_lobby_ui(chat_id, msg_id, lobby, viewer_player, bot):
    diff = COOP_DIFFICULTIES.get(lobby.get("diff_key"), COOP_DIFFICULTIES["easy"])
    members = lobby.get("members", [])
    m_count = len(members)
    win_chance = min(90, diff["base_win_chance"] + m_count * diff["member_bonus"])

    txt = (
        f"<b>🛡️ ЛОББИ КООПЕРАТИВНОГО РЕЙДА #{lobby['id'][-4:]}</b>\n"
        f"Локация: <b>{diff['name']}</b>\n"
        f"Лидер рейда: @{lobby['leader_name']}\n"
        f"Шанс зачистки: <b>{win_chance}%</b> (+{diff['member_bonus']}% за каждого бойца)\n"
        f"────────────────────────\n"
        f"<b>Бойцы в отряде ({m_count}/6):</b>\n"
    )

    for idx, m in enumerate(members, start=1):
        p_info = PMC_DEFINITIONS.get(m['pmc_signature'], {})
        t_badge = f" [🏷️ {m['custom_title']}]" if m.get("custom_title") else ""
        txt += f"{idx}. @{m['username']}{t_badge} — ЧВК {p_info.get('icon', '🎖️')} <b>{m['pmc_signature']}</b> (Огневая мощь: {m['power']})\n"

    txt += (
        f"────────────────────────\n"
        f"<i>Лидер может нажать «Выйти в рейд», как только в группе будет хотя бы 1 боец. Максимум — 6 бойцов.</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    is_leader = str(viewer_player.get("user_id")) == str(lobby.get("leader_id"))
    is_member = any(str(m.get("user_id")) == str(viewer_player.get("user_id")) for m in members)

    if not is_member and m_count < 6:
        markup.add(types.InlineKeyboardButton("➕ Вступить в рейд", callback_data=f"join_coop_{lobby['id']}"))

    if is_member and not is_leader:
        markup.add(types.InlineKeyboardButton("🚪 Покинуть лобби", callback_data=f"leave_coop_{lobby['id']}"))

    if is_leader:
        markup.add(types.InlineKeyboardButton(f"🚀 ВЫЙТИ В РЕЙД ({m_count}/6) — {win_chance}% шанс", callback_data=f"start_coop_{lobby['id']}"))
        markup.add(types.InlineKeyboardButton("❌ Распустить лобби", callback_data=f"cancel_coop_{lobby['id']}"))

    markup.add(types.InlineKeyboardButton("🔄 Обновить статус", callback_data=f"refresh_coop_{lobby['id']}"))
    markup.add(types.InlineKeyboardButton("🔙 К списку рейдов", callback_data="menu_coop_raids"))

    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception:
        pass

def handle_join_coop_lobby(call, player, db, lobby_id, bot):
    lobbies = db.get("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "waiting":
        bot.answer_callback_query(call.id, "❌ Лобби уже закрыто или рейд начался!", show_alert=True)
        return

    members = lobby.setdefault("members", [])
    if len(members) >= 6:
        bot.answer_callback_query(call.id, "❌ В лобби уже максимальное число участников (6/6)!", show_alert=True)
        return

    if any(m["user_id"] == player["user_id"] for m in members):
        bot.answer_callback_query(call.id, "Вход в лобби...")
        render_lobby_ui(call.message.chat.id, call.message.message_id, lobby, player, bot)
        return

    now = int(time.time())
    if player.get("coop_cooldown_until", 0) > now:
        rem = int((player["coop_cooldown_until"] - now) // 60)
        bot.answer_callback_query(call.id, f"🚑 Ваш сигнатурный ЧВК в медблоке! Восстановление: {rem} мин.", show_alert=True)
        return

    pow_val, arm_val = calculate_squad_power(player)
    members.append({
        "user_id": player["user_id"],
        "username": player.get("username", f"PMC_{player['user_id']}"),
        "pmc_signature": player.get("pmc_signature", "Viper"),
        "power": pow_val,
        "armor": arm_val
    })
    save_db(db)

    bot.answer_callback_query(call.id, "✅ Вы успешно вступили в отряд рейда!")
    render_lobby_ui(call.message.chat.id, call.message.message_id, lobby, player, bot)

def handle_leave_coop_lobby(call, player, db, lobby_id, bot):
    lobbies = db.get("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "waiting":
        bot.answer_callback_query(call.id, "❌ Лобби не найдено!")
        return

    members = lobby.get("members", [])
    lobby["members"] = [m for m in members if m["user_id"] != player["user_id"]]
    if player["user_id"] == lobby.get("leader_id"):
        if lobby["members"]:
            new_lead = lobby["members"][0]
            lobby["leader_id"] = new_lead["user_id"]
            lobby["leader_name"] = new_lead["username"]
        else:
            lobbies.pop(lobby_id, None)
    save_db(db)

    bot.answer_callback_query(call.id, "🚪 Вы покинули лобби.")
    handle_menu_coop(call.message.chat.id, call.message.message_id, player, db, bot)

def handle_start_coop_lobby(call, player, db, lobby_id, bot):
    try:
        bot.answer_callback_query(call.id, "🚀 Высадка в рейд...")
    except Exception:
        pass

    lobbies = db.get("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "waiting":
        try:
            bot.answer_callback_query(call.id, "❌ Рейд уже запущен или не найден!", show_alert=True)
        except Exception:
            pass
        return

    if str(player.get("user_id")) != str(lobby.get("leader_id")):
        try:
            bot.answer_callback_query(call.id, "❌ Только лидер лобби может запустить рейд!", show_alert=True)
        except Exception:
            pass
        return

    now_ts = int(time.time())
    if player.get("coop_cooldown_until", 0) > now_ts:
        rem = int((player["coop_cooldown_until"] - now_ts) // 60)
        rem_sec = int((player["coop_cooldown_until"] - now_ts) % 60)
        cd_str = f"{rem} мин {rem_sec} сек" if rem > 0 else f"{rem_sec} сек"
        try:
            bot.answer_callback_query(call.id, f"🚑 Ваш сигнатурный ЧВК в медблоке! Восстановление: {cd_str}.", show_alert=True)
        except Exception:
            pass
        return

    # Filter out any lobby members whose signature PMC is on cooldown
    valid_members = []
    for m in lobby.get("members", []):
        m_user = db.get("users", {}).get(str(m.get("user_id"))) or db.get("users", {}).get(m.get("user_id"))
        if m_user and m_user.get("coop_cooldown_until", 0) > now_ts:
            continue
        valid_members.append(m)

    if not valid_members:
        pow_val, arm_val = calculate_squad_power(player)
        valid_members = [{
            "user_id": player["user_id"],
            "username": player.get("username", f"PMC_{player['user_id']}"),
            "pmc_signature": player.get("pmc_signature", "Viper"),
            "power": max(50, pow_val),
            "armor": max(20, arm_val)
        }]
    lobby["members"] = valid_members

    diff = COOP_DIFFICULTIES.get(lobby.get("diff_key"), COOP_DIFFICULTIES["easy"])

    # Consume keycard from leader if required
    if diff.get("requires_keycard"):
        kc_card, _ = get_leader_keycard(player)
        if not kc_card:
            try:
                bot.answer_callback_query(call.id, "❌ У вас больше нет Лабораторной ключ-карты!", show_alert=True)
            except Exception:
                pass
            return
        kc_uid = kc_card.get("uid")
        player["stash"] = [itm for itm in player.get("stash", []) if itm.get("uid") != kc_uid]

    lobby["status"] = "in_progress"
    save_db(db)

    # Simulate coop raid
    diff_key = lobby.get("diff_key", "easy")
    result = simulate_coop_raid(diff_key, lobby["members"])
    now = int(time.time())

    txt = (
        f"<b>⚔️ ИТОГИ КООПЕРАТИВНОГО РЕЙДА #{lobby['id'][-4:]}</b>\n"
        f"Локация: <b>{diff['name']}</b>\n"
        f"Бойцов в рейде: <b>{len(lobby['members'])}</b> | Шанс успеха был: <b>{result['win_chance']}%</b>\n"
        f"────────────────────────\n"
    )

    if result["success"]:
        txt += (
            "🎉 <b>ТРИУМФ ОТРЯДА! ЗОНА ПОЛНОСТЬЮ ЗАЧИЩЕНА!</b>\n"
            "Все бойцы успешно эвакуировались на вертолете с богатым лутом!\n\n"
        )
        if result.get("relic_dropped"):
            r_item = result["relic_dropped"]
            r_name = html.escape(str(r_item.get('name', 'Реликвия')))
            txt += f"🌟 <b>ЛЕГЕНДАРНЫЙ ТРОФЕЙ!</b> В рейде выпала реликвия: <b>{r_name}</b> (10 000 000 ₽)!\n\n"

        if result.get("mythic_case_dropped"):
            m_case = result["mythic_case_dropped"]
            m_name = html.escape(str(m_case.get('name', 'Кейс Black Division')))
            txt += f"🔥 <b>СВЕРХРЕДКИЙ МИФИЧЕСКИЙ ДРОП!</b> Обнаружен: <b>{m_name}</b> (150 000 000 ₽)!\n\n"

        for m in lobby["members"]:
            uid = str(m["user_id"])
            m_player = db.get("users", {}).get(uid) or db.get("users", {}).get(m["user_id"])
            rew = result["members_rewards"].get(uid, {"rubles": 100000, "items": []})
            stored_count = 0
            dropped_count = 0
            if m_player:
                add_player_rubles(m_player, rew["rubles"])
                add_player_exp(m_player, 75)
                m_player.setdefault("stats", {})["coop_wins"] = m_player.get("stats", {}).get("coop_wins", 0) + 1
                m_player.setdefault("stats", {})["coop_raids_count"] = m_player.get("stats", {}).get("coop_raids_count", 0) + 1
                if has_gd_business(m_player):
                    add_gd_bp_exp(m_player, 650)
                    gd_w = roll_gd_raid_weapon(m_player, "coop")
                    if gd_w and can_store_item(m_player, gd_w["id"]):
                        m_player.setdefault("stash", []).append({
                            "uid": f"gdw_coop_{now}_{random.randint(1000,9999)}",
                            "item_id": gd_w["id"],
                            "equipped_to": None
                        })
                for itm in rew["items"]:
                    if can_store_item(m_player, itm["id"]):
                        m_player.setdefault("stash", []).append({
                            "uid": f"coop_{now}_{random.randint(1000,9999)}",
                            "item_id": itm["id"],
                            "equipped_to": None
                        })
                        stored_count += 1
                        if itm.get("id") == "mythic_black_division_case":
                            add_mythic_item_to_player(m_player, "mythic_black_division_case")
                    else:
                        dropped_count += 1
            if rew.get("dropped_mythic") and m_player:
                add_mythic_item_to_player(m_player, "mythic_black_division_case")
            relic_note = " 🏆 <b>[ПОЛУЧИЛ РЕЛИКВИЮ БОССА]</b>" if rew.get("dropped_relic") else ""
            mythic_note = " 🔥 <b>[ПОЛУЧИЛ КЕЙС BLACK DIVISION]</b>" if rew.get("dropped_mythic") else ""
            overflow_note = f" (⚠️ {dropped_count} не влезло в схрон)" if dropped_count > 0 else ""
            u_name = html.escape(str(m.get("username", "Боец")))
            txt += f"👤 @{u_name}: +<b>{fmt_rub(rew['rubles'])}</b> и {stored_count} предметов в схрон!{relic_note}{mythic_note}{overflow_note}\n"
    else:
        txt += (
            "💀 <b>РАЗГРОМ В КООП-РЕЙДЕ! ЗАСАДА РЕЙДЕРОВ!</b>\n"
            "Группа попала под перекрестный огонь пулеметов и тяжелой артиллерии.\n\n"
            "⚠️ <b>ТРАВМА СИГНАТУРНОГО ЧВК:</b> Сигнатурный оператор каждого участника эвакуирован в медблок.\n"
            "Пассивные способности ЧВК временно отключены на время восстановления!\n"
            "🛡️ <i>Обычный отряд из 5 бойцов и экипировка на складе остались в полной безопасности на базе!</i>\n\n"
        )
        for m in lobby["members"]:
            uid = str(m["user_id"])
            m_player = db.get("users", {}).get(uid) or db.get("users", {}).get(m["user_id"])
            cd_sec = 300  # 5 minutes base recovery
            cd_text = "5 мин"
            buff_note = "(бафф отключен)"
            if m_player:
                if has_boss_set_bonus(m_player, "sanitar"):
                    cd_sec = 60  # 1 minute
                    cd_text = "1 мин (Сет Санитара)"
                elif has_boss_set_bonus(m_player, "killa"):
                    cd_sec = 120  # 2 minutes
                    cd_text = "2 мин (Сет Киллы)"
                    buff_note = "(бафф активен - Килла)"
                else:
                    med_lvl = m_player.get("modules", {}).get("medblock", 0)
                    if med_lvl > 0:
                        cd_sec = max(60, cd_sec - (med_lvl * 20))
                        cd_text = f"{cd_sec // 60} мин {cd_sec % 60} сек (Медблок)"

                m_player["coop_cooldown_until"] = now + cd_sec
                m_player.setdefault("stats", {})["coop_losses"] = m_player.get("stats", {}).get("coop_losses", 0) + 1
                m_player.setdefault("stats", {})["coop_raids_count"] = m_player.get("stats", {}).get("coop_raids_count", 0) + 1
                if has_gd_business(m_player):
                    add_gd_bp_exp(m_player, 200)

            u_name = html.escape(str(m.get("username", "Боец")))
            txt += f"🚑 @{u_name} — Кулдаун {cd_text} {buff_note} [🛡️ Отряд в безопасности]\n"

    # Remove completed lobby
    lobbies.pop(lobby_id, None)
    save_db(db)

    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🔙 Вернуться в Меню Рейдов", callback_data="menu_coop_raids")
    )
    try:
        bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)
    except Exception:
        try:
            bot.send_message(call.message.chat.id, txt, reply_markup=markup)
        except Exception:
            pass

    # Notify all other lobby members
    for m in lobby.get("members", []):
        m_uid = str(m.get("user_id"))
        if m_uid != str(player.get("user_id")):
            try:
                bot.send_message(int(m_uid) if m_uid.isdigit() else m_uid, txt, reply_markup=markup)
            except Exception:
                pass
