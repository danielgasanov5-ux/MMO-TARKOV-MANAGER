#!/usr/bin/env bash
set -e

echo "=== Запуск Tarkov MMO Telegram Bot ==="

# Check virtual environment
if [ ! -d "venv" ]; then
    echo "Создание виртуального окружения python3 -m venv venv..."
    python3 -m venv venv || true
fi

# Activate virtualenv if present
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
fi

echo "Установка зависимостей из requirements.txt..."
pip install -r requirements.txt || true

echo "Запуск бота python3 bot.py..."
python3 bot.py
