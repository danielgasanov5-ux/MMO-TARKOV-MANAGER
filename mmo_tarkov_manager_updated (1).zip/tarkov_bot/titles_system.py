"""
titles_system.py - Система коллекционирования, хранения и выбора титулов игрока в Таркове.
Позволяет зарабатывать титулы в Боевом Пропуске GD (150 ур.), за прогресс Убежища, рейды,
убийство боссов и бизнес, а также переключать активный титул в профиле в любой момент.
"""

from typing import Dict, Any, List, Optional

# Каталог всех доступных титулов в игре с описанием и условиями получения
TITLES_REGISTRY: Dict[str, Dict[str, Any]] = {
    # --- ТИТУЛЫ БОЕВОГО ПРОПУСКА GD MILITARY (16 титулов) ---
    "[Агент Наблюдения GD]": {
        "id": "gd_title_lvl_8",
        "name": "[Агент Наблюдения GD]",
        "icon": "👁️",
        "source": "Боевой Пропуск GD (Уровень 8)",
        "source_type": "bp",
        "required_bp_lvl": 8,
        "desc": "Начальный ранг оператора наблюдения частной военной компании GD Military."
    },
    "[Младший Оперативник GD]": {
        "id": "gd_title_lvl_16",
        "name": "[Младший Оперативник GD]",
        "icon": "🎖️",
        "source": "Боевой Пропуск GD (Уровень 16)",
        "source_type": "bp",
        "required_bp_lvl": 16,
        "desc": "Полноправный штурмовик специального подразделения GD Military."
    },
    "[Теневой Стрелок]": {
        "id": "gd_title_lvl_22",
        "name": "[Теневой Стрелок]",
        "icon": "🎯",
        "source": "Боевой Пропуск GD (Уровень 22)",
        "source_type": "bp",
        "required_bp_lvl": 22,
        "desc": "Мастер бесшумной ликвидации целей на ближней и средней дистанции."
    },
    "[Призрак Таркова]": {
        "id": "gd_title_lvl_28",
        "name": "[Призрак Таркова]",
        "icon": "👻",
        "source": "Боевой Пропуск GD (Уровень 28)",
        "source_type": "bp",
        "required_bp_lvl": 28,
        "desc": "Одиночка, выживший в самых смертоносных рейдах на Заводе и Таможне."
    },
    "[Охотник Black Division]": {
        "id": "gd_title_lvl_38",
        "name": "[Охотник Black Division]",
        "icon": "💼",
        "source": "Боевой Пропуск GD (Уровень 38)",
        "source_type": "bp",
        "required_bp_lvl": 38,
        "desc": "Оперативник, заслуживший признание сверхсекретного отряда TerraGroup."
    },
    "[Старший Аналитик GD]": {
        "id": "gd_title_lvl_46",
        "name": "[Старший Аналитик GD]",
        "icon": "📡",
        "source": "Боевой Пропуск GD (Уровень 46)",
        "source_type": "bp",
        "required_bp_lvl": 46,
        "desc": "Координатор спутниковой разведки и боевых операций в Норвинском Секторе."
    },
    "[Каратель Синдиката]": {
        "id": "gd_title_lvl_54",
        "name": "[Каратель Синдиката]",
        "icon": "💀",
        "source": "Боевой Пропуск GD (Уровень 54)",
        "source_type": "bp",
        "required_bp_lvl": 54,
        "desc": "Беспощадный ликвидатор предателей и враждебных группировок."
    },
    "[Командир Спецотряда GD]": {
        "id": "gd_title_lvl_68",
        "name": "[Командир Спецотряда GD]",
        "icon": "⭐",
        "source": "Боевой Пропуск GD (Уровень 68)",
        "source_type": "bp",
        "required_bp_lvl": 68,
        "desc": "Лидер тактических ударных групп в глубине закрытых военных зон."
    },
    "[Владыка Черного Рынка]": {
        "id": "gd_title_lvl_78",
        "name": "[Владыка Черного Рынка]",
        "icon": "🏪",
        "source": "Боевой Пропуск GD (Уровень 78)",
        "source_type": "bp",
        "required_bp_lvl": 78,
        "desc": "Контролирует теневые финансовые потоки и контрабанду Норвинска."
    },
    "[Генерал Теневого Авангарда]": {
        "id": "gd_title_lvl_88",
        "name": "[Генерал Теневого Авангарда]",
        "icon": "⚔️",
        "source": "Боевой Пропуск GD (Уровень 88)",
        "source_type": "bp",
        "required_bp_lvl": 88,
        "desc": "Высший офицер передовой линии военной корпорации GD Military."
    },
    "[Мастер Смерти GD]": {
        "id": "gd_title_lvl_98",
        "name": "[Мастер Смерти GD]",
        "icon": "☠️",
        "source": "Боевой Пропуск GD (Уровень 98)",
        "source_type": "bp",
        "required_bp_lvl": 98,
        "desc": "Живая легенда Таркова, прошедшая сотни рейдов без единого поражения."
    },
    "[Инквизитор TerraGroup]": {
        "id": "gd_title_lvl_108",
        "name": "[Инквизитор TerraGroup]",
        "icon": "🧬",
        "source": "Боевой Пропуск GD (Уровень 108)",
        "source_type": "bp",
        "required_bp_lvl": 108,
        "desc": "Хранитель секретов экспериментальных лабораторий и прототипов стимуляторов."
    },
    "[Архитектор Войны]": {
        "id": "gd_title_lvl_118",
        "name": "[Архитектор Войны]",
        "icon": "🏛️",
        "source": "Боевой Пропуск GD (Уровень 118)",
        "source_type": "bp",
        "required_bp_lvl": 118,
        "desc": "Стратег, формирующий правила противостояния ЧВК и Боссов региона."
    },
    "[Маршал Темного Сектора]": {
        "id": "gd_title_lvl_126",
        "name": "[Маршал Темного Сектора]",
        "icon": "🎖️",
        "source": "Боевой Пропуск GD (Уровень 126)",
        "source_type": "bp",
        "required_bp_lvl": 126,
        "desc": "Абсолютный авторитет в Даркзоне и на тайных военных объектах."
    },
    "[Призрак-Главнокомандующий]": {
        "id": "gd_title_lvl_136",
        "name": "[Призрак-Главнокомандующий]",
        "icon": "🌌",
        "source": "Боевой Пропуск GD (Уровень 136)",
        "source_type": "bp",
        "required_bp_lvl": 136,
        "desc": "Невидимый куратор масштабных войсковых операций во всем Таркове."
    },
    "[Абсолютный Повелитель Таркова]": {
        "id": "gd_title_lvl_146",
        "name": "[Абсолютный Повелитель Таркова]",
        "icon": "👑",
        "source": "Боевой Пропуск GD (Уровень 146)",
        "source_type": "bp",
        "required_bp_lvl": 146,
        "desc": "Верховный титул: игрок, полностью покоривший Норвинскую область."
    },

    # --- ТИТУЛЫ ЗА ПРОГРЕСС УБЕЖИЩА И ЗВАНИЯ ---
    "[Рядовой ЧВК]": {
        "id": "rank_private",
        "name": "[Рядовой ЧВК]",
        "icon": "🪖",
        "source": "Базовый титул бойца",
        "source_type": "rank",
        "desc": "Стандартное военное звание каждого нового оперативника Таркова."
    },
    "[Опытный Наемник]": {
        "id": "rank_veteran",
        "name": "[Опытный Наемник]",
        "icon": "🥉",
        "source": "Убежище Уровень 3+",
        "source_type": "rank",
        "desc": "Присваивается за обустройство укрепленного бункера и первые успехи."
    },
    "[Командир Синдиката]": {
        "id": "rank_commander",
        "name": "[Командир Синдиката]",
        "icon": "🥈",
        "source": "Убежище Уровень 5+",
        "source_type": "rank",
        "desc": "Звание лидера крупного синдиката с развитой инфраструктурой."
    },
    "[Генерал Норвинского Сектора]": {
        "id": "rank_general",
        "name": "[Генерал Норвинского Сектора]",
        "icon": "🥇",
        "source": "Убежище Уровень 8+",
        "source_type": "rank",
        "desc": "Высшее признание среди всех независимых отрядов ЧВК."
    },

    # --- БОЕВЫЕ И ЭКОНОМИЧЕСКИЕ ТИТУЛЫ ---
    "[Ветеран Таркова]": {
        "id": "achieve_veteran_100",
        "name": "[Ветеран Таркова]",
        "icon": "🎖️",
        "source": "50+ успешных рейдов",
        "source_type": "achievement",
        "desc": "За закалку в десятках смертоносных вылазок за ценным лутом."
    },
    "[Мародер Таркова]": {
        "id": "achieve_pvp_master",
        "name": "[Мародер Таркова]",
        "icon": "⚔️",
        "source": "10+ побед в PvP (Даркзон)",
        "source_type": "achievement",
        "desc": "Гроза других игроков в опаснейших схватках Даркзона."
    },
    "[Покоритель Боссов]": {
        "id": "achieve_boss_slayer",
        "name": "[Покоритель Боссов]",
        "icon": "💥",
        "source": "Победа в Кооперативном рейде на Босса",
        "source_type": "achievement",
        "desc": "За уничтожение опаснейших боссов Таркова вместе с отрядом союзников."
    },
    "[Миллиардер Таркова]": {
        "id": "achieve_billionaire",
        "name": "[Миллиардер Таркова]",
        "icon": "💰",
        "source": "Заработано свыше 1 000 000 000 ₽",
        "source_type": "achievement",
        "desc": "Финансовый магнат Норвинска с колоссальным капиталом."
    },
    "[Теневой Сотрудник GD]": {
        "id": "achieve_gd_business",
        "name": "[Теневой Сотрудник GD]",
        "icon": "🛰️",
        "source": "Покупка бизнеса GD Military (30 Млрд ₽)",
        "source_type": "special",
        "desc": "Владелец сверхсекретного контракта глобальной корпорации GD Military."
    },
    "[Хранитель Мифика]": {
        "id": "achieve_mythic_owner",
        "name": "[Хранитель Мифика]",
        "icon": "✨",
        "source": "Владение хотя бы 1 мификом (150М)",
        "source_type": "mythic",
        "desc": "Обладатель легендарного мифического артефакта Таркова."
    }
}


def sync_player_titles(player: Dict[str, Any]) -> List[str]:
    """
    Сканирует состояние игрока (уровень БП, Убежище, статистику, бизнесы, мифики)
    и гарантированно разблокирует все заслуженные титулы.
    Возвращает список всех разблокированных титулов.
    """
    unlocked = player.setdefault("unlocked_titles", [])
    
    # Всегда доступен базовый титул
    if "[Рядовой ЧВК]" not in unlocked:
        unlocked.append("[Рядовой ЧВК]")
        
    # Если у игрока уже был кастомный титул (от админа или старой версии)
    curr_custom = player.get("custom_title")
    if curr_custom and curr_custom not in unlocked:
        unlocked.append(curr_custom)
        
    # Прогресс убежища
    h_lvl = player.get("hideout_lvl", 1)
    if h_lvl >= 3 and "[Опытный Наемник]" not in unlocked:
        unlocked.append("[Опытный Наемник]")
    if h_lvl >= 5 and "[Командир Синдиката]" not in unlocked:
        unlocked.append("[Командир Синдиката]")
    if h_lvl >= 8 and "[Генерал Норвинского Сектора]" not in unlocked:
        unlocked.append("[Генерал Норвинского Сектора]")
        
    # Статистика
    st = player.get("stats", {})
    if st.get("raids_count", 0) >= 50 and "[Ветеран Таркова]" not in unlocked:
        unlocked.append("[Ветеран Таркова]")
    if st.get("pvp_wins", 0) >= 10 and "[Мародер Таркова]" not in unlocked:
        unlocked.append("[Мародер Таркова]")
    if st.get("coop_wins", 0) >= 1 and "[Покоритель Боссов]" not in unlocked:
        unlocked.append("[Покоритель Боссов]")
    if st.get("total_earned_rubles", 0) >= 1_000_000_000 and "[Миллиардер Таркова]" not in unlocked:
        unlocked.append("[Миллиардер Таркова]")
        
    # Бизнес GD Military
    if player.get("special_businesses", {}).get("gd_shadow_agent"):
        if "[Теневой Сотрудник GD]" not in unlocked:
            unlocked.append("[Теневой Сотрудник GD]")
            
    # Мифики 150М
    from mythic_system import get_player_mythics
    if len(get_player_mythics(player)) > 0:
        if "[Хранитель Мифика]" not in unlocked:
            unlocked.append("[Хранитель Мифика]")
            
    # Боевой Пропуск GD
    bp_state = player.get("gd_battlepass", {})
    bp_lvl = bp_state.get("level", 1) if player.get("special_businesses", {}).get("gd_shadow_agent") else 0
    claimed_levels = bp_state.get("claimed_levels", [])
    bp_titles = bp_state.get("titles", [])
    
    # Также проверяем зарегистрированные титулы в GD_BATTLEPASS_LEVELS
    for title_name, t_info in TITLES_REGISTRY.items():
        if t_info.get("source_type") == "bp":
            req_lvl = t_info.get("required_bp_lvl", 999)
            if (bp_lvl >= req_lvl or req_lvl in claimed_levels or title_name in bp_titles) and title_name not in unlocked:
                unlocked.append(title_name)
                
    return unlocked


def get_equipped_title(player: Dict[str, Any]) -> Optional[str]:
    """Возвращает текущий экипированный титул игрока или None."""
    return player.get("custom_title")


def equip_title(player: Dict[str, Any], title_name: str) -> bool:
    """Надевает выбранный титул на игрока, если он разблокирован."""
    unlocked = sync_player_titles(player)
    if title_name in unlocked:
        player["custom_title"] = title_name
        return True
    return False


def unequip_title(player: Dict[str, Any]) -> None:
    """Снимает выбранный титул, возвращая игроку стандартное звание."""
    player["custom_title"] = None


def render_titles_menu(player: Dict[str, Any], page: int = 1):
    """
    Генерирует текст и инлайн-клавиатуру для меню управления титулами.
    """
    try:
        from telebot import types
    except ImportError:
        import telebot
        from telebot import types
        
    unlocked = sync_player_titles(player)
    equipped = get_equipped_title(player)
    
    ITEMS_PER_PAGE = 6
    total_unlocked = len(unlocked)
    total_pages = max(1, (total_unlocked + ITEMS_PER_PAGE - 1) // ITEMS_PER_PAGE)
    page = max(1, min(page, total_pages))
    
    start_idx = (page - 1) * ITEMS_PER_PAGE
    end_idx = min(start_idx + ITEMS_PER_PAGE, total_unlocked)
    page_items = unlocked[start_idx:end_idx]
    
    equipped_display = f"🏷️ <b>{equipped}</b>" if equipped else "<i>[Не выбран — отображается ранг по Убежищу]</i>"
    
    txt = (
        "<b>🏷️ ГАРДЕРОБ И КОЛЛЕКЦИЯ ТИТУЛОВ ЧВК</b>\n"
        "────────────────────────\n"
        f"Текущий активный титул: {equipped_display}\n"
        f"Всего открыто титулов: <b>{total_unlocked} из {len(TITLES_REGISTRY)}</b>\n\n"
        "<i>Титул отображается перед вашим позывным в профиле, во всех рейдовых сводках, "
        "в PvP дуэлях и в таблицах рекордов Таркова.</i>\n"
        "────────────────────────\n"
        f"<b>📋 Ваши разблокированные титулы (Стр. {page}/{total_pages}):</b>\n"
    )
    
    for idx, t_name in enumerate(page_items, start=start_idx + 1):
        t_data = TITLES_REGISTRY.get(t_name, {})
        is_active = (equipped == t_name)
        status_tag = "✅ <b>[АКТИВЕН]</b>" if is_active else "🔘 [В гардеробе]"
        icon = t_data.get("icon", "🏷️")
        src = t_data.get("source", "Личное достижение")
        desc = t_data.get("desc", "")
        txt += f"{idx}. {icon} <b>{t_name}</b> — {status_tag}\n   📍 <i>{src}</i>\n"
        if desc:
            txt += f"   📜 <i>{desc}</i>\n"
        txt += "\n"
        
    txt += "────────────────────────\n"
    txt += "Нажмите на кнопку ниже, чтобы надеть или снять нужный титул:"

    markup = types.InlineKeyboardMarkup(row_width=1)
    
    # Кнопки для выбора титула
    for t_name in page_items:
        t_data = TITLES_REGISTRY.get(t_name, {})
        icon = t_data.get("icon", "🏷️")
        if equipped == t_name:
            markup.add(types.InlineKeyboardButton(f"✅ Выбран: {icon} {t_name}", callback_data=f"title_unselect"))
        else:
            markup.add(types.InlineKeyboardButton(f"Надеть {icon} {t_name}", callback_data=f"title_select_{t_name}"))
            
    # Кнопка снятия
    if equipped:
        markup.add(types.InlineKeyboardButton("❌ Снять титул (Отображать стандартный ранг)", callback_data="title_unselect"))
        
    # Навигация по страницам
    nav_row = []
    if page > 1:
        nav_row.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"menu_titles_{page-1}"))
    if page < total_pages:
        nav_row.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"menu_titles_{page+1}"))
    if nav_row:
        markup.row(*nav_row)
        
    # Дополнительные кнопки
    markup.add(
        types.InlineKeyboardButton("🔒 Каталог всех титулов Таркова", callback_data="menu_titles_all_1"),
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    
    return txt, markup


def render_all_titles_catalog(player: Dict[str, Any], page: int = 1):
    """
    Показывает полный каталог всех существующих в игре титулов с условиями получения.
    """
    try:
        from telebot import types
    except ImportError:
        import telebot
        from telebot import types

    unlocked = sync_player_titles(player)
    all_titles = list(TITLES_REGISTRY.items())
    
    ITEMS_PER_PAGE = 5
    total_pages = max(1, (len(all_titles) + ITEMS_PER_PAGE - 1) // ITEMS_PER_PAGE)
    page = max(1, min(page, total_pages))
    
    start_idx = (page - 1) * ITEMS_PER_PAGE
    end_idx = min(start_idx + ITEMS_PER_PAGE, len(all_titles))
    page_items = all_titles[start_idx:end_idx]
    
    txt = (
        "<b>📖 ЭНЦИКЛОПЕДИЯ ВСЕХ ТИТУЛОВ ТАРКОВА</b>\n"
        "────────────────────────\n"
        f"Здесь собраны все <b>{len(TITLES_REGISTRY)} титулов</b> игры, включая 16 элитных званий "
        "Боевого Пропуска GD (150 ур.), ранги убежища и редкие достижения.\n\n"
        f"<b>Страница {page}/{total_pages}:</b>\n\n"
    )
    
    for t_name, t_data in page_items:
        is_owned = t_name in unlocked
        tag = "🟢 <b>[ОТКРЫТО]</b>" if is_owned else "🔒 <b>[ЗАБЛОКИРОВАНО]</b>"
        icon = t_data.get("icon", "🏷️")
        src = t_data.get("source", "Спецоперация")
        desc = t_data.get("desc", "")
        txt += (
            f"{icon} <b>{t_name}</b> — {tag}\n"
            f"📍 <b>Условие:</b> {src}\n"
            f"📜 <i>{desc}</i>\n\n"
        )
        
    txt += "────────────────────────"
    
    markup = types.InlineKeyboardMarkup(row_width=2)
    nav_row = []
    if page > 1:
        nav_row.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"menu_titles_all_{page-1}"))
    if page < total_pages:
        nav_row.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"menu_titles_all_{page+1}"))
    if nav_row:
        markup.row(*nav_row)
        
    markup.add(
        types.InlineKeyboardButton("🏷️ Мои Титулы (Гардероб)", callback_data="menu_titles_collection"),
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile")
    )
    
    return txt, markup
