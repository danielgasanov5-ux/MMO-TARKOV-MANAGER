"""
passives_system.py - Система отображения и расчета всех пассивных эффектов игрока в Таркове.
Объединяет:
1. Мифические предметы из раздела "Мифики 150 миллионов" (Дипломат Black Division, Жетон Goons, Датчик DSP Смотрителя)
2. Все пассивные эффекты, механики и рейдовые модификаторы Боевого Пропуска GD Military (150 уровней) - как активные, так и будущие
3. Элитные бизнесы (Теневой сотрудник GD, Флот Контрабандистов, Защита Скупщика)
4. Модули Убежища (Биткоин-ферма, Медблок, Разведцентр, Генератор)
5. Классовые перки Сигнатурного ЧВК и Сеты Босс-реликвий
"""

from typing import Dict, Any, List, Tuple
from mythic_system import MYTHIC_ITEMS, get_player_mythics, has_mythic_item
import gd_military_system


def get_all_player_passives(player: Dict[str, Any], db: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Собирает исчерпывающую информацию обо всех пассивных эффектах игрока:
    - Активные и неактивные мифики 150М
    - Активные и будущие перки Боевого Пропуска GD (1-150 уровни)
    - Элитные бизнесы
    - Убежище
    - Итоговые боевые и финансовые множители
    """
    owned_mythics = get_player_mythics(player)
    owned_mythic_ids = {m["id"] for m in owned_mythics}
    
    # 1. МИФИКИ 150М
    mythics_list = []
    for m_id, m_data in MYTHIC_ITEMS.items():
        is_active = m_id in owned_mythic_ids
        mythics_list.append({
            "id": m_id,
            "name": m_data["name"],
            "badge": m_data["badge"],
            "price": "150 000 000 ₽",
            "is_active": is_active,
            "desc": m_data["desc"],
            "how_to_get": _get_mythic_source(m_id)
        })

    # 2. ПАССИВКИ И МОДИФИКАТОРЫ БОЕВОГО ПРОПУСКА GD (150 УРОВНЕЙ)
    bp_state = player.get("gd_battlepass", {})
    has_gd = bool(player.get("special_businesses", {}).get("gd_shadow_agent"))
    curr_bp_lvl = bp_state.get("level", 1) if has_gd else 0
    claimed_levels = bp_state.get("claimed_levels", [])
    
    bp_passives = []
    active_bp_count = 0
    
    for item in gd_military_system.GD_BATTLEPASS_LEVELS:
        cat = item.get("category")
        if cat in ["mechanic", "drop_enhancer"]:
            lvl = item["level"]
            # Перк активен, если уровень БП достигнут и активирован контракт GD
            is_active = has_gd and (curr_bp_lvl >= lvl or lvl in claimed_levels)
            if is_active:
                active_bp_count += 1
                
            bp_passives.append({
                "level": lvl,
                "title": item["title"],
                "category": cat,
                "cat_label": "Рейдовый модификатор" if cat == "drop_enhancer" else "Тактическая механика",
                "rarity": item.get("rarity", "rare"),
                "badge": item.get("badge", ""),
                "description": item.get("description", ""),
                "is_active": is_active,
                "unlock_requirement": f"Боевой Пропуск GD (Уровень {lvl})"
            })

    # 3. ЭЛИТНЫЕ БИЗНЕСЫ
    businesses_list = []
    spec_biz = player.get("special_businesses", {})
    
    # GD Military
    is_gd = bool(spec_biz.get("gd_shadow_agent"))
    businesses_list.append({
        "id": "gd_shadow_agent",
        "name": "🛰️ Теневой сотрудник GD Military",
        "is_active": is_gd,
        "cost": "30 000 000 000 ₽",
        "income": "+150 000 000 ₽ / час",
        "effects": [
            "🎖️ Постоянный доступ к Боевому Пропуску GD (150 уровней)",
            "🛡️ +15% к шансу выживания во всех рейдах Таркова",
            "👁️ -35% к шансу засады боссов в соло-рейдах",
            "🔫 Разблокировка выпадения 26 эксклюзивных оружий GD"
        ]
    })
    
    # Smugglers Fleet
    is_fleet = bool(spec_biz.get("smugglers_fleet"))
    businesses_list.append({
        "id": "smugglers_fleet",
        "name": "🚢 Флот Контрабандистов",
        "is_active": is_fleet,
        "cost": "500 000 000 ₽",
        "income": "+1 500 000 ₽ / час",
        "effects": [
            "⚡ 3x ускорение поставок Контрабанды",
            "📦 +15 слотов в тайнике контрабанды"
        ]
    })
    
    # Fence Protection
    is_fence = bool(spec_biz.get("fence_protection"))
    businesses_list.append({
        "id": "fence_protection",
        "name": "🤝 Защита Скупщика",
        "is_active": is_fence,
        "cost": "1 500 000 000 ₽",
        "income": "+3 500 000 ₽ / час",
        "effects": [
            "🏪 0% комиссия на Барахолке",
            "🤖 Автовыкуп непроданных лотов каждые 3 часа"
        ]
    })

    # 4. МОДУЛИ УБЕЖИЩА
    hideout_modules = []
    h_lvl = player.get("hideout_lvl", 1)
    
    # Генератор
    has_infinite_fuel = has_gd and curr_bp_lvl >= 144
    hideout_modules.append({
        "name": "⚡ Энергосистема (Генератор)",
        "is_active": True,
        "desc": "Неиссякаемый генераторный контур (вечное питание без канистр)" if has_infinite_fuel else "Стандартное питание убежища топливом"
    })
    
    # Биткоин ферма
    has_gpu = player.get("gpu_count", 0) > 0 or h_lvl >= 5
    hideout_modules.append({
        "name": "🪙 Биткоин-ферма",
        "is_active": has_gpu,
        "desc": "+30% к скорости майнинга (Оверклокинг БП ур.115)" if (has_gd and curr_bp_lvl >= 115) else "Пассивная добыча криптовалюты BTC"
    })
    
    # 5. ИТОГОВЫЕ МНОЖИТЕЛИ И СВОДКА
    calc_survival_bonus = 0.0
    if is_gd:
        calc_survival_bonus += 0.15
    if has_gd and curr_bp_lvl >= 7:
        calc_survival_bonus += 0.05
    if has_gd and curr_bp_lvl >= 128:
        calc_survival_bonus += 0.15
        
    calc_boss_reduction = 0.0
    if is_gd or (has_gd and curr_bp_lvl >= 1):
        calc_boss_reduction += 0.35
    if has_gd and curr_bp_lvl >= 135:
        calc_boss_reduction += 0.25  # суммарно до 60%

    total_hourly_income = 0
    if is_gd:
        total_hourly_income += 150_000_000
    if is_fleet:
        total_hourly_income += 1_500_000
    if is_fence:
        total_hourly_income += 3_500_000
        
    has_dsp_security = "mythic_dsp_sensor" in owned_mythic_ids

    return {
        "mythics": mythics_list,
        "bp_passives": bp_passives,
        "businesses": businesses_list,
        "hideout": hideout_modules,
        "active_mythics_count": len(owned_mythic_ids),
        "total_mythics_count": len(MYTHIC_ITEMS),
        "active_bp_count": active_bp_count,
        "total_bp_count": len(bp_passives),
        "curr_bp_lvl": curr_bp_lvl,
        "has_gd": has_gd,
        "totals": {
            "survival_bonus_pct": round(calc_survival_bonus * 100),
            "boss_ambush_reduction_pct": round(calc_boss_reduction * 100),
            "hourly_passive_income": total_hourly_income,
            "has_dsp_security": has_dsp_security,
            "market_fee_pct": 0 if (is_fence or (has_gd and curr_bp_lvl >= 149)) else (2 if (has_gd and curr_bp_lvl >= 12) else 5)
        }
    }


def _get_mythic_source(mythic_id: str) -> str:
    if mythic_id == "mythic_black_division_case":
        return "Дроп с шансом до 3.0% при победе в Кооп-рейдах на Боссов (Colossal)"
    elif mythic_id == "mythic_goons_token":
        return "Сверхредкий шанс 0.01% из Военного Кейса TerraGroup (2.5М ₽)"
    elif mythic_id == "mythic_dsp_sensor":
        return "Шанс 0.1% из Теневого Каравана высшего тира (Контрабанда Тир 4)"
    return "Секретная спецоперация"


def render_passives_menu(player: Dict[str, Any], db: Dict[str, Any] = None, tab: str = "summary", page: int = 1):
    """
    Генерирует текст и интерфейс для вкладки главного меню «🔮 Пассивки».
    """
    try:
        from telebot import types
    except ImportError:
        import telebot
        from telebot import types
        
    data = get_all_player_passives(player, db)
    t = data["totals"]
    
    markup = types.InlineKeyboardMarkup(row_width=2)
    
    if tab == "summary":
        txt = (
            "<b>🔮 КРАТКАЯ ТАБЛИЦА ПАССИВНЫХ МНОЖИТЕЛЕЙ ЧВК</b>\n"
            "<i>(Эффект — Проценты или плюс столько-то)</i>\n"
            "─────────────────────────────────────\n"
            f"• 🛡️ Выживаемость в рейдах:  <b>+{t['survival_bonus_pct']}%</b>\n"
            f"• 👁️ Защита от засад Боссов: <b>-{t['boss_ambush_reduction_pct']}%</b>\n"
            f"• 💰 Пассивный доход в час:   <b>+{t['hourly_passive_income']:,} ₽ / ч</b>\n"
            f"• 🏪 Комиссия Барахолки:     <b>{t['market_fee_pct']}%</b> " + ("(скидка -5%)" if t['market_fee_pct'] == 0 else f"(скидка -{5 - t['market_fee_pct']}%)") + "\n"
            f"• 🏰 Защита базы от рейдов:   <b>{'🟢 100% Вечная' if t['has_dsp_security'] else '🟡 0% (Базовая)'}</b>\n"
            f"• 💼 Множитель лута (Мифик):  <b>{'🟢 x3 (+300%)' if has_mythic_item(player, 'mythic_black_division_case') else '🔒 x1 (Стандарт)'}</b>\n"
            f"• 🎖️ Боевая мощь бойцов:      <b>{'🟢 +20 к силе' if has_mythic_item(player, 'mythic_goons_token') else '🔒 +0 ед.'}</b>\n"
            f"• 🪙 Майнинг Биткоинов (BTC): <b>{'🟢 +30% к скорости' if (data['has_gd'] and data['curr_bp_lvl'] >= 115) else '🔒 0% (Ур. 115)'}</b>\n"
            f"• ⚡ Топливо генератора:      <b>{'🟢 0 л/ч (Вечно)' if (data['has_gd'] and data['curr_bp_lvl'] >= 144) else '🟡 2 л/ч (Стандарт)'}</b>\n"
            f"• 🚢 Скорость Контрабанды:    <b>{'🟢 x3 быстрее' if player.get('special_businesses', {}).get('smugglers_fleet') else '🔒 1x (Флот 500М)'}</b>\n"
            f"• 🔫 Дроп оружия GD в рейдах: <b>{'🟢 26 моделей' if data['has_gd'] else '🔒 Заблокирован'}</b>\n"
            "─────────────────────────────────────\n"
            f"📊 <b>Статус:</b> БП GD <b>{data['curr_bp_lvl']}/150</b> | Мификов: <b>{data['active_mythics_count']}/3</b>\n\n"
            "<i>Нажмите кнопки ниже, чтобы открыть подробности по разделам:</i>"
        )
        
    elif tab == "mythics":
        txt = (
            "<b>✨ МИФИЧЕСКИЕ АРТЕФАКТЫ (150 000 000 ₽)</b>\n"
            "────────────────────────\n"
            "Мифические предметы открывают уникальные глобальные механики Таркова:\n\n"
        )
        for m in data["mythics"]:
            st = "🟢 <b>[АКТИВЕН В СХРОНЕ]</b>" if m["is_active"] else "🔒 <b>[НЕ НАЙДЕН]</b>"
            txt += (
                f"{m['badge']} <b>{m['name']}</b> — {st}\n"
                f"💰 Стоимость: <b>{m['price']}</b> | Редкость: <b>Мифический</b>\n"
                f"📜 <i>{m['desc']}</i>\n"
                f"📍 <i>Где найти: {m['how_to_get']}</i>\n\n"
            )
        txt += "────────────────────────"
        
    elif tab == "bp":
        ITEMS_PER_PAGE = 5
        bp_list = data["bp_passives"]
        total_pages = max(1, (len(bp_list) + ITEMS_PER_PAGE - 1) // ITEMS_PER_PAGE)
        page = max(1, min(page, total_pages))
        
        start_idx = (page - 1) * ITEMS_PER_PAGE
        end_idx = min(start_idx + ITEMS_PER_PAGE, len(bp_list))
        page_items = bp_list[start_idx:end_idx]
        
        txt = (
            "<b>🎖️ ПАССИВНЫЕ ЭФФЕКТЫ БОЕВОГО ПРОПУСКА GD (150 УРОВНЕЙ)</b>\n"
            "────────────────────────\n"
            f"Текущий прогресс: <b>{data['active_bp_count']} из {data['total_bp_count']} пассивок</b> "
            f"(Уровень БП: {data['curr_bp_lvl']}/150)\n"
            "<i>Отображаются все 41 механика и модификаторы лута: как активные, так и будущие.</i>\n\n"
            f"<b>Страница {page} из {total_pages}:</b>\n\n"
        )
        
        for p_item in page_items:
            st = "🟢 <b>[АКТИВЕН]</b>" if p_item["is_active"] else f"🔒 <b>[БУДЕТ ОТКРЫТ НА УР. {p_item['level']}]</b>"
            txt += (
                f"⭐ <b>Ур. {p_item['level']}: {p_item['title']}</b> — {st}\n"
                f"🏷️ Тип: <code>{p_item['cat_label']}</code> | {p_item['badge']}\n"
                f"📜 <i>{p_item['description']}</i>\n\n"
            )
            
        txt += "────────────────────────"
        
    elif tab == "businesses":
        txt = (
            "<b>💼 ЭЛИТНЫЕ БИЗНЕСЫ И ИНФРАСТРУКТУРА</b>\n"
            "────────────────────────\n"
            "Постоянные источники пассивного дохода и глобальные боевые привилегии:\n\n"
        )
        for b in data["businesses"]:
            st = "🟢 <b>[КУПЛЕН И РАБОТАЕТ]</b>" if b["is_active"] else "🔒 <b>[НЕ ПРИОБРЕТЕН]</b>"
            txt += (
                f"<b>{b['name']}</b> — {st}\n"
                f"💰 Стоимость: <b>{b['cost']}</b> | Доход: <b>{b['income']}</b>\n"
                f"<b>Пассивные привилегии:</b>\n"
            )
            for eff in b["effects"]:
                txt += f"  • {eff}\n"
            txt += "\n"
        txt += "────────────────────────"

    # Строка переключения вкладок
    markup.row(
        types.InlineKeyboardButton("📊 Краткая таблица (%)" if tab != "summary" else "• 📊 Таблица (%) •", callback_data="menu_passives_summary"),
        types.InlineKeyboardButton("✨ Мифики 150М" if tab != "mythics" else "• Мифики 150М •", callback_data="menu_passives_mythics")
    )
    markup.row(
        types.InlineKeyboardButton("🎖️ Пассивки БП (150 ур.)" if tab != "bp" else "• Пассивки БП •", callback_data="menu_passives_bp_1"),
        types.InlineKeyboardButton("💼 Бизнесы" if tab != "businesses" else "• Бизнесы •", callback_data="menu_passives_biz")
    )

    # Навигация внутри вкладки БП
    if tab == "bp":
        total_pages = max(1, (len(data["bp_passives"]) + 5 - 1) // 5)
        nav_row = []
        if page > 1:
            nav_row.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"menu_passives_bp_{page-1}"))
        if page < total_pages:
            nav_row.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"menu_passives_bp_{page+1}"))
        if nav_row:
            markup.row(*nav_row)

    # Быстрые переходы к функционалу
    if tab == "mythics":
        if has_mythic_item(player, "mythic_black_division_case"):
            markup.add(types.InlineKeyboardButton("💼 Спецоперация Black Division", callback_data="menu_black_division"))
        if has_mythic_item(player, "mythic_goons_token"):
            markup.add(types.InlineKeyboardButton("🎖️ Штаб Отступников (The Goons)", callback_data="menu_the_goons"))
        if has_mythic_item(player, "mythic_dsp_sensor"):
            markup.add(types.InlineKeyboardButton("👁️ Дозор Зрячего (Маяк)", callback_data="menu_zryachiy"))
    elif tab == "bp":
        markup.add(types.InlineKeyboardButton("🎖️ Открыть Боевой Пропуск GD", callback_data="menu_gd_battlepass"))
    elif tab == "businesses":
        markup.add(types.InlineKeyboardButton("💼 Магазин Элитных Бизнесов", callback_data="menu_special_businesses"))

    markup.add(
        types.InlineKeyboardButton("👤 Мой Профиль ЧВК", callback_data="menu_profile"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    
    return txt, markup
