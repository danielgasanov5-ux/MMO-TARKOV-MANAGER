# -*- coding: utf-8 -*-
"""
Dedicated unit test suite for the new Prestige Mastery Tree and Black Raid mechanics.
"""

import sys
import os
import time

sys.path.insert(0, os.path.dirname(__file__))

from prestige import (
    get_player_prestige, get_prestige_badge, PRESTIGE_TIERS,
    PRESTIGE_MASTERY_SKILLS, get_prestige_tokens, allocate_prestige_skill,
    reset_prestige_skills, get_player_mastery_level,
    can_launch_prestige_black_raid, execute_prestige_black_raid,
    render_prestige_mastery_menu, render_prestige_black_raid_menu,
    execute_prestige_reset, apply_zryachiy_sniper_support
)
from tarkov_engine import (
    calculate_squad_power, get_business_hourly_income,
    get_mining_hourly_btc, get_warehouse_capacity
)
from loot_generator import simulate_raid, roll_strict_tarkov_loot

def test_mastery_tokens_and_allocation():
    print("Testing Mastery Tokens & Tree Allocation...")
    player = {
        "user_id": 100,
        "prestige": 3,
        "prestige_mastery": {}
    }
    avail, total, spent = get_prestige_tokens(player)
    assert total == 3, f"Expected 3 tokens, got {total}"
    assert avail == 3, f"Expected 3 available, got {avail}"
    assert spent == 0, f"Expected 0 spent, got {spent}"

    # Allocate combat_mastery
    ok, msg = allocate_prestige_skill(player, "combat_mastery")
    assert ok is True, f"Failed to allocate: {msg}"
    assert get_player_mastery_level(player, "combat_mastery") == 1

    avail, total, spent = get_prestige_tokens(player)
    assert avail == 2 and spent == 1

    # Allocate tycoon_mastery
    ok, msg = allocate_prestige_skill(player, "tycoon_mastery")
    assert ok is True
    assert get_player_mastery_level(player, "tycoon_mastery") == 1

    # Allocate loot_mastery
    ok, msg = allocate_prestige_skill(player, "loot_mastery")
    assert ok is True

    # Try allocating when 0 tokens left
    avail, total, spent = get_prestige_tokens(player)
    assert avail == 0 and spent == 3
    ok, msg = allocate_prestige_skill(player, "survival_mastery")
    assert ok is False, "Should not allow allocation without tokens"

    # Reset skills
    ok, msg = reset_prestige_skills(player)
    assert ok is True
    avail, total, spent = get_prestige_tokens(player)
    assert avail == 3 and spent == 0
    assert get_player_mastery_level(player, "combat_mastery") == 0
    print("✓ Mastery tokens, allocations and reset verified.")

def test_mastery_combat_and_economic_impacts():
    print("Testing Mastery bonuses impact on engine calculations...")
    # Combat mastery (+5% per level)
    p_combat_0 = {
        "user_id": 101,
        "prestige": 5,
        "squad": [{"id": 1, "type": "pmc", "base_power": 100, "base_armor": 100}],
        "prestige_mastery": {"combat_mastery": 0}
    }
    p_combat_5 = {
        "user_id": 102,
        "prestige": 5,
        "squad": [{"id": 1, "type": "pmc", "base_power": 100, "base_armor": 100}],
        "prestige_mastery": {"combat_mastery": 5}
    }
    pow0, arm0 = calculate_squad_power(p_combat_0)
    pow5, arm5 = calculate_squad_power(p_combat_5)
    # Lvl 5 gives +25%
    assert pow5 > pow0, f"Combat mastery failed: {pow5} vs {pow0}"
    assert arm5 > arm0, f"Combat mastery failed: {arm5} vs {arm0}"
    print(f"✓ Combat mastery: base power {pow0} -> boosted {pow5} (+25%)")

    # Tycoon mastery (+10% per level)
    p_tycoon_0 = {
        "user_id": 103,
        "prestige": 3,
        "businesses": {"fuel_station": 5},
        "prestige_mastery": {"tycoon_mastery": 0}
    }
    p_tycoon_5 = {
        "user_id": 104,
        "prestige": 3,
        "businesses": {"fuel_station": 5},
        "prestige_mastery": {"tycoon_mastery": 5}
    }
    inc0 = get_business_hourly_income("fuel_station", 5, p_tycoon_0)
    inc5 = get_business_hourly_income("fuel_station", 5, p_tycoon_5)
    assert inc5 > inc0, f"Tycoon mastery failed: {inc5} vs {inc0}"
    print(f"✓ Tycoon mastery: base income {inc0} -> boosted {inc5} (+50%)")

    # Mining Farm with Prestige 5 (+100% BTC)
    p_mine_0 = {"user_id": 105, "prestige": 0, "modules": {"mining_farm": 10, "generator": 10}}
    p_mine_5 = {"user_id": 106, "prestige": 5, "modules": {"mining_farm": 10, "generator": 10}}
    btc0 = get_mining_hourly_btc(10, p_mine_0)
    btc5 = get_mining_hourly_btc(10, p_mine_5)
    assert btc5 == round(btc0 * 2.0, 4), f"Prestige 5 mining bonus failed: {btc5} vs {btc0}"
    print(f"✓ Prestige 5 Terragroup Reactor: {btc0} BTC/h -> {btc5} BTC/h (2x multiplier)")

def test_black_raid_mechanics():
    print("Testing Prestige 5 Black Raid...")
    # Player with Prestige < 5 cannot launch
    p_low = {"user_id": 107, "prestige": 4, "stash": []}
    can_r, reason, rem = can_launch_prestige_black_raid(p_low)
    assert can_r is False
    assert "5" in reason

    # Player with Prestige 5 can launch
    p_high = {
        "user_id": 108,
        "prestige": 5,
        "stash": [],
        "mythic_items": ["mythic_dsp_sensor"],
        "last_prestige_black_raid": 0
    }
    can_r, reason, rem = can_launch_prestige_black_raid(p_high)
    assert can_r is True

    # Execute Black Raid
    success, res = execute_prestige_black_raid(p_high)
    assert success is True
    assert res["rubles"] >= 10_000_000
    assert len(res["items_names"]) >= 3
    assert p_high["money"] >= 10_000_000
    assert p_high.get("level", 1) >= 2 or p_high.get("exp", 0) > 0
    assert p_high["last_prestige_black_raid"] > 0
    print(f"✓ Black Raid executed: won {res['rubles']} ₽, {len(res['items_names'])} items, {res['btc_found']} BTC")

    # Second launch blocked by cooldown
    can_r2, reason2, rem2 = can_launch_prestige_black_raid(p_high)
    assert can_r2 is False
    assert rem2 > 0
    print("✓ Black Raid 20-hour cooldown verified.")

def test_ui_renderers():
    print("Testing UI menu renderers...")
    player = {
        "user_id": 109,
        "prestige": 5,
        "prestige_mastery": {"combat_mastery": 3, "loot_mastery": 2},
        "stash": [],
        "modules": {},
        "warehouses": {},
        "stats": {}
    }
    txt_m, markup_m = render_prestige_mastery_menu(player)
    assert "ДРЕВО МАСТЕРСТВА ПРЕСТИЖА" in txt_m
    assert len(markup_m.keyboard) >= 3

    txt_br, markup_br = render_prestige_black_raid_menu(player)
    assert "ЧЕРНЫЙ РЕЙД СМОТРИТЕЛЯ" in txt_br
    assert len(markup_br.keyboard) >= 1
    print("✓ Mastery and Black Raid menus rendered cleanly.")

def test_scaled_prestige_resets():
    print("Testing Scaled Starter Packages across all 5 Prestige Tiers...")
    for tier in range(1, 6):
        test_p = {
            "user_id": 200 + tier,
            "level": 10,
            "money": 100_000_000,
            "stash": [{"uid": "old_item", "item_id": "toz_106_common", "equipped_to": None}],
            "mythic_items": ["mythic_dsp_sensor"],
            "prestige": tier - 1,
            "clothes_stash": ["goons_suit"],
            "equipped_clothes": {"suit": "goons_suit"}
        }
        ok = execute_prestige_reset(test_p, tier)
        assert ok is True
        assert test_p["prestige"] == tier
        assert test_p["level"] == 1
        assert "goons_suit" in test_p["clothes_stash"]
        assert test_p["equipped_clothes"]["suit"] == "goons_suit"

        # Check starter balance
        if tier == 1:
            assert test_p["money"] == 1_500_000
        elif tier == 2:
            assert test_p["money"] == 3_500_000
        elif tier == 3:
            assert test_p["money"] == 7_500_000
        elif tier == 4:
            assert test_p["money"] == 15_000_000
            assert any(itm.get("item_id") == "mythic_dsp_sensor" for itm in test_p["stash"])
        elif tier == 5:
            assert test_p["money"] == 35_000_000
            assert any(itm.get("item_id") == "zryachiy_axmc" for itm in test_p["stash"])
            assert any(itm.get("item_id") == "mythic_dsp_sensor" for itm in test_p["stash"])
            assert test_p["modules"]["generator"] == 10
        print(f"✓ Prestige {tier} reset verified: {test_p['money']} ₽ starter package.")

if __name__ == "__main__":
    test_mastery_tokens_and_allocation()
    test_mastery_combat_and_economic_impacts()
    test_black_raid_mechanics()
    test_ui_renderers()
    test_scaled_prestige_resets()
    print("\nALL PRESTIGE MASTERY & BLACK RAID TESTS PASSED! 🌟👑")
