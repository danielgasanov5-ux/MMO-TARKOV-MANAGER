# -*- coding: utf-8 -*-
"""
Loot Generator & Raid System for Escape from Tarkov
Real-time deliveries, airdrops with boss items, military crates,
and 6-player cooperative raids across 5 difficulty tiers.

STRICT BALANCE:
- Epic drop chance in raids/crates: 3%
- Legendary drop chance in raids/crates: < 0.5%
- Supply delivery: 1% legendary at lvl 1 to 12% at lvl 10
"""

import random
from tarkov_engine import ITEMS_LIST, ITEMS_BY_ID, has_buff
try:
    from relics_system import BOSS_SETS
except ImportError:
    BOSS_SETS = {}
try:
    from relics_system import ALL_30_RELICS, has_boss_set_bonus
except ImportError:
    ALL_30_RELICS = []
    def has_boss_set_bonus(u, b): return False

# Helper to filter out any restricted items (relics, mythics, BP-locked gear)
def is_restricted_item(item):
    """
    Excludes relics, mythic gear, and BattlePass (BP / GD Military) gear
    from standard raid loot pools.
    BattlePass items ONLY drop if the player unlocked and reached them in the BP!
    """
    if not item:
        return True
    iid = str(item.get("id", "")).lower()
    cat = str(item.get("category", "")).lower()
    rarity = str(item.get("rarity", "")).lower()
    
    # 1. Relics
    if "relic" in cat or iid.startswith("relic_") or "boss" in cat:
        return True
    # 2. Mythics
    if rarity == "mythic" or iid.startswith("mythic_") or iid.startswith("goons_") or iid.startswith("zryachiy_"):
        return True
    # 3. BattlePass items (GD Military weapons, helmets, armor)
    if iid.startswith("gd_") or iid.startswith("bp_"):
        return True
        
    return False

# Backward compatibility alias
def is_relic_item(item):
    return is_restricted_item(item)

# Filter item pools by rarity (strictly from standard game items, NO relics, NO BP items)
POOL_LEGENDARY = [i for i in ITEMS_LIST if not is_restricted_item(i) and (i.get("rarity") == "legendary" or i.get("price", 0) >= 380000)]
POOL_EPIC = [i for i in ITEMS_LIST if not is_restricted_item(i) and i.get("rarity") == "epic" and i not in POOL_LEGENDARY]
POOL_RARE = [i for i in ITEMS_LIST if not is_restricted_item(i) and i.get("rarity") == "rare"]
POOL_COMMON = [i for i in ITEMS_LIST if not is_restricted_item(i) and i.get("rarity") == "common"]

def pick_item_by_rarity(rarity):
    if rarity == "legendary" and POOL_LEGENDARY:
        return random.choice(POOL_LEGENDARY)
    if rarity == "epic" and POOL_EPIC:
        return random.choice(POOL_EPIC)
    if rarity == "rare" and POOL_RARE:
        return random.choice(POOL_RARE)
    if POOL_COMMON:
        return random.choice(POOL_COMMON)
    clean_items = [i for i in ITEMS_LIST if not is_restricted_item(i)]
    return random.choice(clean_items if clean_items else ITEMS_LIST)

def roll_strict_tarkov_loot(user=None):
    """
    Strict balanced Tarkov MMO drop rates:
    Legendary: 0.2%
    Epic: 1.8%
    Rare: 16.0%
    Common: 82.0%
    Draws exclusively from the 720 items catalog. Relics never drop here!
    """
    leg_chance = 0.002
    epic_chance = 0.018
    rare_chance = 0.160

    if user and has_buff(user, "loot_bonus"):
        leg_chance += 0.002
        epic_chance += 0.010
    if user:
        intel_lvl = user.get("modules", {}).get("intel_center", 0)
        leg_chance += intel_lvl * 0.0003
        epic_chance += intel_lvl * 0.0015

    r = random.random()
    if r < leg_chance:
        return pick_item_by_rarity("legendary")
    elif r < leg_chance + epic_chance:
        return pick_item_by_rarity("epic")
    elif r < leg_chance + epic_chance + rare_chance:
        return pick_item_by_rarity("rare")
    else:
        return pick_item_by_rarity("common")

def generate_supply_drop(supply_lvl, user=None, tier=1):
    """
    Buffed & Rebalanced Contraband Cargo System:
    Delivers a full thematic batch cargo rather than a single disappointing junk item!

    Tier 1 (25,000 ₽, 45s):
      - 2-3 Valuable items (Meds, ammo, weapon modules, gear)
      - Bonus Cash: 20,000 - 45,000 ₽ (+5% per channel lvl)

    Tier 2 (75,000 ₽, 120s):
      - 3-4 Military grade items (Armor class 4-5, rifles, optics, grenades, components)
      - Bonus Cash: 70,000 - 150,000 ₽ (+5% per channel lvl)

    Tier 3 (180,000 ₽, 240s):
      - 4-5 Elite items (Class 5-6 armor, meta guns, GPUs, injectors, high-tech components)
      - Bonus Cash: 180,000 - 360,000 ₽ (+5% per channel lvl)
      - 20% Chance for 0.10 - 0.30 BTC

    Tier 4 (450,000 ₽, 360s) - Unlocked at Channel Lvl 5+:
      - 5-6 Top-Tier Syndicate & Black Market items
      - Bonus Cash: 450,000 - 900,000 ₽ (+5% per channel lvl)
      - 45% Chance for 0.25 - 0.60 BTC
      - 15% Chance to unearth a military weapon/item crate!
    """
    lvl = max(1, min(10, int(supply_lvl)))
    tier = max(1, min(4, int(tier)))

    intel_lvl = user.get("modules", {}).get("intel_center", 0) if user else 0
    loot_bonus = 1.15 if (user and has_buff(user, "loot_bonus")) else 1.0

    if tier == 1:
        item_count = random.randint(2, 3)
        base_cash = random.randint(20000, 45000)
        leg_chance = (0.01 + (lvl - 1) * 0.001) * loot_bonus
        epic_chance = (0.09 + (lvl - 1) * 0.005 + intel_lvl * 0.002) * loot_bonus
        rare_chance = (0.45 + (lvl - 1) * 0.02) * loot_bonus
        btc_chance = 0.0
    elif tier == 2:
        item_count = random.randint(3, 4)
        base_cash = random.randint(70000, 150000)
        leg_chance = (0.02 + (lvl - 1) * 0.002) * loot_bonus
        epic_chance = (0.18 + (lvl - 1) * 0.010 + intel_lvl * 0.003) * loot_bonus
        rare_chance = (0.55 + (lvl - 1) * 0.01) * loot_bonus
        btc_chance = 0.05
    elif tier == 3:
        item_count = random.randint(4, 5)
        base_cash = random.randint(180000, 360000)
        leg_chance = (0.08 + (lvl - 1) * 0.007) * loot_bonus
        epic_chance = (0.45 + (lvl - 1) * 0.005 + intel_lvl * 0.005) * loot_bonus
        rare_chance = 0.40
        btc_chance = 0.20
    else:  # Tier 4 (Black Market Syndicate, lvl >= 5)
        item_count = random.randint(5, 6)
        base_cash = random.randint(450000, 900000)
        leg_chance = (0.20 + (lvl - 1) * 0.006) * loot_bonus
        epic_chance = (0.55 + intel_lvl * 0.005) * loot_bonus
        rare_chance = 0.25
        btc_chance = 0.45

    rubles = int(base_cash * (1.0 + (lvl - 1) * 0.05))

    btc = 0.0
    if btc_chance > 0 and random.random() < btc_chance:
        if tier == 2:
            btc = round(random.uniform(0.05, 0.15), 3)
        elif tier == 3:
            btc = round(random.uniform(0.10, 0.30), 3)
        else:
            btc = round(random.uniform(0.25, 0.60), 3)

    items = []
    for _ in range(item_count):
        r = random.random()
        if r < leg_chance:
            items.append(pick_item_by_rarity("legendary"))
        elif r < (leg_chance + epic_chance):
            items.append(pick_item_by_rarity("epic"))
        elif r < (leg_chance + epic_chance + rare_chance):
            items.append(pick_item_by_rarity("rare"))
        else:
            items.append(pick_item_by_rarity("common"))

    bonus_crate = None
    if tier == 4 and random.random() < 0.15:
        crates = ["weapon_case", "items_case", "meds_case", "ammo_case"]
        bonus_crate = random.choice(crates)

    # 0.1% chance (1 in 1000) for Mythic DSP Sensor in Tier 4 contraband (1.0% with Prestige 4+)
    dsp_chance = 0.001
    if user:
        try:
            from prestige import get_player_prestige
            if get_player_prestige(user) >= 4:
                dsp_chance = 0.010
        except Exception:
            pass
    mythic_dsp_won = False
    if tier == 4 and random.random() < dsp_chance:
        mythic_dsp_won = True

    return {
        "tier": tier,
        "items": items,
        "rubles": rubles,
        "btc": btc,
        "bonus_crate": bonus_crate,
        "mythic_dsp_won": mythic_dsp_won
    }

def roll_supply_item(supply_lvl, user=None, tier=1):
    """
    Backwards-compatible wrapper that returns one high-tier item from the generated batch.
    """
    drop = generate_supply_drop(supply_lvl, user=user, tier=tier)
    if drop.get("items"):
        return drop["items"][0]
    return pick_item_by_rarity("rare")

def generate_airdrop_loot():
    """
    Restores full 720-item pool utilization with high-end military cargo:
    - 2-3 Elite technical/medical components (GPUs, Military Cables, Phasemeters, Toolsets, etc.)
    - 2-3 Top Epic and Legendary weapons / armor from the 720 catalog (Slick, Altyn, AXMC, G28, RSASS)
    - Substantial rubles (600,000 - 1,800,000 ₽) and Bitcoin (0.5 - 2.0 BTC)
    - Low 10% chance for ONE random standard Boss Relic (never a SET relic directly!).
      If relic doesn't drop, an extra legendary item from 720 catalog is awarded.
    """
    loot = {
        "items": [],
        "rubles": random.randint(600000, 1800000),
        "btc": round(random.uniform(0.5, 2.0), 3)
    }

    # 1. 2-3 Elite technical & hideout components from 720 items (no common junk!)
    elite_components = [
        it for it in ITEMS_LIST
        if not is_relic_item(it) and it.get("category") in ["components", "valuable"] and (
            it.get("rarity") in ["epic", "legendary"] or
            (it.get("rarity") == "rare" and (
                it.get("is_hideout_component") or
                any(w in it.get("name", "").lower() for w in ["видеокарт", "плата", "инструмент", "процессор", "аккумулятор", "блок питания", "файл", "кабель", "фильтр"])
            ))
        )
    ]
    if not elite_components:
        elite_components = [it for it in ITEMS_LIST if not is_relic_item(it) and it.get("category") in ["components", "valuable"] and it.get("rarity") in ["rare", "epic", "legendary"]]
    if not elite_components:
        elite_components = POOL_EPIC

    for _ in range(random.randint(2, 3)):
        loot["items"].append(random.choice(elite_components))

    # 2. 2-3 Top Epic and Legendary weapons / body armor / helmets from 720 items
    top_gear = [
        it for it in ITEMS_LIST
        if not is_relic_item(it) and it.get("rarity") in ["legendary", "epic"] and it.get("category") in ["weapons", "armor", "gear"]
    ]
    if not top_gear:
        top_gear = POOL_LEGENDARY if POOL_LEGENDARY else POOL_EPIC

    for _ in range(random.randint(2, 3)):
        loot["items"].append(random.choice(top_gear))

    # 3. 10% isolated chance for ONE random standard Boss Relic
    # SET-relics (5/5 bonus) can NEVER drop directly!
    if ALL_30_RELICS and random.random() < 0.10:
        boss_relic = random.choice(ALL_30_RELICS)
        loot["items"].append(boss_relic)
        loot["has_relic"] = True
    else:
        # Extra top legendary item from the 720 catalog instead
        if POOL_LEGENDARY:
            loot["items"].append(random.choice(POOL_LEGENDARY))

    return loot

# Container & Case Definitions with Mathematical Risk vs Reward Balance
CONTAINER_DEFINITIONS = {
    "scav_box_150k": {
        "id": "scav_box_150k",
        "name": "🧰 Контрабандный Ящик Диких",
        "price": 150000,
        "badge": "🧰",
        "desc": "Сбитый из досок ящик с кустарной контрабандой Диких. Высокий риск неокупа.",
        "item_count": (2, 3),
        "loss_range": (45000, 105000),
        "even_range": (125000, 175000),
        "profit_range": (195000, 320000),
        "probabilities": [0.50, 0.35, 0.15]
    },
    "army_container_750k": {
        "id": "army_container_750k",
        "name": "📦 Армейский Спецконтейнер",
        "price": 750000,
        "badge": "📦",
        "desc": "Герметичный военный контейнер ВС РФ / UNTAR. Лут может не окупить затраты!",
        "item_count": (3, 4),
        "loss_range": (220000, 490000),      # ~48% НЕОКУП
        "even_range": (620000, 820000),      # ~34% ОКОЛО НУЛЯ
        "profit_range": (880000, 1250000),   # ~14% ОКУП
        "jackpot_range": (1350000, 2000000), # ~4% ДЖЕКПОТ
        "probabilities": [0.48, 0.34, 0.14, 0.04]
    },
    "terragroup_case_2500k": {
        "id": "terragroup_case_2500k",
        "name": "💼 Секретный Кейс TerraGroup",
        "price": 2500000,
        "badge": "💼",
        "desc": "Титановый сейф-кейс лаборатории. Дорогостоящий риск ради ключ-карт и прототипов.",
        "item_count": (3, 5),
        "loss_range": (1100000, 1850000),    # ~50% НЕОКУП
        "even_range": (2200000, 2750000),    # ~32% ОКОЛО НУЛЯ
        "profit_range": (3100000, 4200000),  # ~15% ОКУП
        "jackpot_range": (5000000, 7500000), # ~3% ДЖЕКПОТ
        "probabilities": [0.50, 0.32, 0.15, 0.03]
    }
}

def generate_container_loot(container_id, user=None):
    """
    Generates balanced container loot where total items value may not pay off.
    Strictly balances the 750k container and others against guaranteed millions.
    """
    cfg = CONTAINER_DEFINITIONS.get(container_id, CONTAINER_DEFINITIONS["army_container_750k"])
    price = cfg["price"]
    probs = list(cfg["probabilities"])

    if user and has_buff(user, "loot_bonus"):
        if len(probs) == 4:
            probs[0] = max(0.35, probs[0] - 0.05)
            probs[2] += 0.05
        else:
            probs[0] = max(0.35, probs[0] - 0.05)
            probs[2] += 0.05

    roll = random.random()
    if len(probs) == 4:
        if roll < probs[0]:
            outcome = "loss"
            target = random.randint(*cfg["loss_range"])
        elif roll < probs[0] + probs[1]:
            outcome = "even"
            target = random.randint(*cfg["even_range"])
        elif roll < probs[0] + probs[1] + probs[2]:
            outcome = "profit"
            target = random.randint(*cfg["profit_range"])
        else:
            outcome = "jackpot"
            target = random.randint(*cfg["jackpot_range"])
    else:
        if roll < probs[0]:
            outcome = "loss"
            target = random.randint(*cfg["loss_range"])
        elif roll < probs[0] + probs[1]:
            outcome = "even"
            target = random.randint(*cfg["even_range"])
        else:
            outcome = "profit"
            target = random.randint(*cfg["profit_range"])

    min_cnt, max_cnt = cfg["item_count"]
    count = random.randint(min_cnt, max_cnt)
    chosen = []
    current_sum = 0
    remaining_target = target

    clean_catalog = [it for it in ITEMS_LIST if not is_relic_item(it)]
    if not clean_catalog:
        clean_catalog = ITEMS_LIST

    for i in range(count - 1):
        budget = max(5000, remaining_target // (count - i))
        min_p = max(5000, int(budget * 0.35))
        max_p = int(budget * 1.65)
        candidates = [it for it in clean_catalog if min_p <= it.get("price", 0) <= max_p]
        if not candidates:
            candidates = [it for it in clean_catalog if it.get("price", 0) <= max_p * 1.5]
        if not candidates:
            candidates = clean_catalog
        it = random.choice(candidates)
        chosen.append(it)
        current_sum += it.get("price", 0)
        remaining_target = max(5000, target - current_sum)

    last_cands = [it for it in clean_catalog if abs(it.get("price", 0) - remaining_target) < remaining_target * 0.5]
    if not last_cands:
        last_cands = [it for it in clean_catalog if it.get("price", 0) <= remaining_target * 1.5]
    if not last_cands:
        last_cands = clean_catalog
    last_it = min(last_cands, key=lambda it: abs(it.get("price", 0) - remaining_target))
    chosen.append(last_it)

    total_val = sum(it.get("price", 0) for it in chosen)

    # 1% chance for ONE random Boss Relic in 2.5m Military Case (terragroup_case_2500k)
    # Strictly 1% chance. When this 1% hits, it awards 1 standard boss relic (never a SET relic directly!).
    relic_won = None
    mythic_won = None
    if cfg["id"] == "terragroup_case_2500k":
        if ALL_30_RELICS and random.random() < 0.01:
            relic_won = random.choice(ALL_30_RELICS)
            chosen.append(relic_won)
            total_val += relic_won.get("price", 10000000)

        # 0.01% chance (1 in 10,000) for Mythic Goons Token
        if random.random() < 0.0001:
            try:
                from mythic_system import MYTHIC_ITEMS
                mythic_won = MYTHIC_ITEMS["mythic_goons_token"]
                chosen.append(mythic_won)
                total_val += mythic_won.get("price", 150000000)
            except Exception:
                pass

    delta = total_val - price

    return {
        "container_id": cfg["id"],
        "name": cfg["name"],
        "price": price,
        "items": chosen,
        "relic_won": relic_won,
        "mythic_won": mythic_won,
        "total_value": total_val,
        "delta": delta,
        "outcome": outcome
    }

# Solo Raid Locations
RAID_LOCATIONS = {
    "factory": {
        "name": "🏭 Завод (Factory)",
        "desc": "Жестокий ближний бой, легкие Дикие и шанс встретить Тагиллу.",
        "difficulty": 35,
        "cooldown": 0, # Без кулдауна
        "scav_fee": 0,
        "loot_count": (1, 2)
    },
    "customs": {
        "name": "🌲 Таможня (Customs)",
        "desc": "Общаги, стройка, заправка. Охрана босса Решалы.",
        "difficulty": 65,
        "cooldown": 0, # Без кулдауна
        "scav_fee": 5000,
        "loot_count": (2, 3)
    },
    "woods": {
        "name": "🏕️ Лес (Woods)",
        "desc": "Снайперские дуэли, лесопилка, снайпер Штурман с СВД.",
        "difficulty": 90,
        "cooldown": 0, # Без кулдауна
        "scav_fee": 10000,
        "loot_count": (2, 4)
    },
    "reserve": {
        "name": "🏢 Военная база 'Резерв'",
        "desc": "Бункеры, бронепоезд, элитная свита Глухаря и военный лут.",
        "difficulty": 130,
        "cooldown": 0, # Без кулдауна
        "scav_fee": 20000,
        "loot_count": (3, 5)
    },
    "labs": {
        "name": "🧪 Лаборатория TerraGroup",
        "desc": "Рейдеры ЧВК, тяжелая броня, электронные ключ-карты и LEDX.",
        "difficulty": 180,
        "cooldown": 0, # Без кулдауна
        "scav_fee": 50000,
        "loot_count": (4, 6)
    }
}

RAID_LOOT_RATES = {
    "factory": {"legendary": 0.0005, "epic": 0.015, "rare": 0.180},
    "customs": {"legendary": 0.002,  "epic": 0.035, "rare": 0.250},
    "woods":   {"legendary": 0.005,  "epic": 0.060, "rare": 0.320},
    "reserve": {"legendary": 0.012,  "epic": 0.095, "rare": 0.380},
    "labs":    {"legendary": 0.025,  "epic": 0.140, "rare": 0.420}
}

COOP_LOOT_RATES = {
    "easy":     {"legendary": 0.001, "epic": 0.025, "rare": 0.200},
    "normal":   {"legendary": 0.003, "epic": 0.050, "rare": 0.280},
    "hard":     {"legendary": 0.008, "epic": 0.085, "rare": 0.350},
    "ultra":    {"legendary": 0.018, "epic": 0.130, "rare": 0.400},
    "colossal": {"legendary": 0.035, "epic": 0.180, "rare": 0.420}
}

def roll_raid_loot(location_key, user=None):
    rates = RAID_LOOT_RATES.get(location_key, RAID_LOOT_RATES["factory"])
    leg_ch = rates["legendary"]
    epic_ch = rates["epic"]
    rare_ch = rates["rare"]

    if user and has_buff(user, "loot_bonus"):
        leg_ch += 0.005
        epic_ch += 0.015
    if user:
        intel_lvl = user.get("modules", {}).get("intel_center", 0)
        leg_ch += intel_lvl * 0.0003
        epic_ch += intel_lvl * 0.0015

    r = random.random()
    if r < leg_ch:
        return pick_item_by_rarity("legendary")
    elif r < leg_ch + epic_ch:
        return pick_item_by_rarity("epic")
    elif r < leg_ch + epic_ch + rare_ch:
        return pick_item_by_rarity("rare")
    else:
        return pick_item_by_rarity("common")

def roll_coop_raid_loot(diff_key, user=None):
    rates = COOP_LOOT_RATES.get(diff_key, COOP_LOOT_RATES["easy"])
    leg_ch = rates["legendary"]
    epic_ch = rates["epic"]
    rare_ch = rates["rare"]

    if user and has_buff(user, "loot_bonus"):
        leg_ch += 0.005
        epic_ch += 0.015
    if user:
        intel_lvl = user.get("modules", {}).get("intel_center", 0)
        leg_ch += intel_lvl * 0.0003
        epic_ch += intel_lvl * 0.0015

    r = random.random()
    if r < leg_ch:
        return pick_item_by_rarity("legendary")
    elif r < leg_ch + epic_ch:
        return pick_item_by_rarity("epic")
    elif r < leg_ch + epic_ch + rare_ch:
        return pick_item_by_rarity("rare")
    else:
        return pick_item_by_rarity("common")

def calculate_raid_win_chance(location_key, user, squad_power, squad_armor):
    squad = user.get("squad", []) if user else []
    total_fighters = len(squad)
    if total_fighters == 0:
        return 0.0

    loc = RAID_LOCATIONS.get(location_key, RAID_LOCATIONS["factory"])
    diff = loc["difficulty"]

    scav_count = sum(1 for f in squad if f.get("type") == "scav")
    pmc_count = sum(1 for f in squad if f.get("type") != "scav")

    # 1. Scav survival logic (untouched, respects original scav rules and caps)
    scav_combined_stat = (squad_power * 1.3) + (squad_armor * 0.9)
    scav_ratio = scav_combined_stat / max(1, diff)
    scav_raw_chance = min(0.95, max(0.12, scav_ratio / (scav_ratio + 0.9) * 1.35))
    scav_loc_cap = max(0.05, min(0.45, 0.45 * (35.0 / max(30, diff))))
    scav_win_chance = min(scav_loc_cap, scav_raw_chance)

    # 2. PMC survival logic (calibrated strictly by map hazard and gear investment)
    # High-tier armor and weapons are required to survive high-threat zones (Reserve, Labs)
    pmc_combined_stat = (squad_power * 1.3) + (squad_armor * 1.1)
    pmc_diff_threshold = (diff * 2.2) + 70
    pmc_ratio = pmc_combined_stat / pmc_diff_threshold
    pmc_floor = max(0.04, min(0.24, 0.24 * (35.0 / max(30, diff))))
    pmc_ceiling = max(0.60, min(0.88, 0.90 - (diff - 30) * 0.0018))
    pmc_gear_progression = pmc_ratio / (pmc_ratio + 0.9)
    pmc_win_chance = pmc_floor + (pmc_ceiling - pmc_floor) * pmc_gear_progression

    # Weighted composite win chance based on squad roster
    if pmc_count == 0:
        win_chance = scav_win_chance
    elif scav_count == 0:
        win_chance = pmc_win_chance
    else:
        win_chance = (scav_win_chance * scav_count + pmc_win_chance * pmc_count) / total_fighters

    # Modifiers and bonuses:
    if user and has_buff(user, "pvp_bonus"):
        win_chance = min(0.98, win_chance + 0.10)
    if user and has_boss_set_bonus(user, "killa"):
        win_chance = min(0.99, win_chance + 0.75)

    # Hideout Nutrition Module bonus: +1% survival rate per level
    if user:
        nutr_lvl = user.get("modules", {}).get("nutrition", 0)
        win_chance += nutr_lvl * 0.01

    # GD Military Satellite Radar perk: +15% survival rate in raids
    if user and user.get("special_businesses", {}).get("gd_shadow_agent"):
        win_chance += 0.15

    # Mythic gear tactical dominance & survival perks:
    m_perks = None
    if user:
        try:
            from mythic_system import get_squad_mythic_perks
            m_perks = get_squad_mythic_perks(user)
        except Exception:
            pass

    has_mythics = bool(m_perks and m_perks.get("total_mythics", 0) > 0)
    if has_mythics and pmc_count > 0:
        # Multi-million ruble mythic loadout breaks the harsh map hazard ceiling on Labs and Reserve!
        mythic_count = m_perks.get("total_mythics", 0)
        boosted_ceiling = min(0.96, pmc_ceiling + (mythic_count * 0.10))
        boosted_pmc_chance = pmc_floor + (boosted_ceiling - pmc_floor) * pmc_gear_progression
        win_chance = boosted_pmc_chance + m_perks.get("flat_win_chance", 0.0)
    elif m_perks:
        win_chance += m_perks.get("flat_win_chance", 0.0)

    max_overall_cap = 0.99 if (user and has_boss_set_bonus(user, "killa")) else (0.98 if has_mythics else 0.95)
    win_chance = min(max_overall_cap, max(0.03, win_chance))

    return round(win_chance, 3)

def simulate_raid(location_key, user, squad_power, squad_armor):
    loc = RAID_LOCATIONS.get(location_key, RAID_LOCATIONS["factory"])
    win_chance = calculate_raid_win_chance(location_key, user, squad_power, squad_armor)
    roll = random.random()
    success = roll < win_chance

    min_l, max_l = loc["loot_count"]
    found_items = []
    earned_rubles = 0

    # Mythic gear perks
    m_perks = None
    if user:
        try:
            from mythic_system import get_squad_mythic_perks
            m_perks = get_squad_mythic_perks(user)
        except Exception:
            pass

    btc_won = 0.0
    if success:
        loot_count = random.randint(min_l, max_l)
        if m_perks:
            loot_count += m_perks.get("extra_loot_count", 0)
        if user and has_boss_set_bonus(user, "shturman"):
            loot_count *= 2
        for _ in range(loot_count):
            found_items.append(roll_raid_loot(location_key, user))

        # Rebalanced rubles rewards for profitable raids that reward high gear:
        # Factory: 35k-65k, Customs: 120k-220k, Woods: 280k-480k, Reserve: 650k-1.1M, Labs: 1.6M-2.8M
        diff = loc["difficulty"]
        if diff <= 35:
            base_rub = random.randint(35000, 65000)
        elif diff <= 65:
            base_rub = random.randint(120000, 220000)
        elif diff <= 95:
            base_rub = random.randint(280000, 480000)
        elif diff <= 140:
            base_rub = random.randint(650000, 1100000)
        else:
            base_rub = random.randint(1600000, 2800000)

        earned_rubles = base_rub
        if user and has_buff(user, "prapor_bonus"):
            earned_rubles = int(earned_rubles * 1.1)
        if user and has_boss_set_bonus(user, "shturman"):
            earned_rubles *= 2

        # Hideout Rest Space Module bonus: +3% rubles per level
        if user:
            rest_lvl = user.get("modules", {}).get("rest_space", 0)
            earned_rubles = int(earned_rubles * (1.0 + rest_lvl * 0.03))

        # Mythic plunder multiplier:
        if m_perks and m_perks.get("rubles_mult", 1.0) > 1.0:
            earned_rubles = int(earned_rubles * m_perks["rubles_mult"])

        # Prestige 5 perk: 1.5x raid rubles multiplier
        if user:
            try:
                from prestige import get_player_prestige
                if get_player_prestige(user) >= 5:
                    earned_rubles = int(earned_rubles * 1.5)
            except Exception:
                pass

        # Roll Bitcoin (BTC) if Goons set bonus is active:
        if m_perks and m_perks.get("btc_roll_chance", 0.0) > 0:
            if random.random() < m_perks["btc_roll_chance"]:
                btc_won = 1.0
                user["btc"] = user.get("btc", 0.0) + 1.0
    else:
        # Check Prestige 5 Zryachiy sniper support (if user failed the raid):
        if user:
            try:
                from prestige import apply_zryachiy_sniper_support, get_player_prestige
                supported, note = apply_zryachiy_sniper_support(user, "raid")
                if supported:
                    success = True
                    # Zryachiy eliminated the threat! Roll rewards:
                    loot_count = random.randint(min_l, max_l)
                    for _ in range(loot_count):
                        found_items.append(roll_raid_loot(location_key, user))
                    diff = loc["difficulty"]
                    base_rub = random.randint(50000, 150000)
                    earned_rubles = base_rub
                    if get_player_prestige(user) >= 5:
                        earned_rubles = int(earned_rubles * 1.5)
            except Exception:
                pass

    return {
        "success": success,
        "location": loc["name"],
        "items": found_items,
        "rubles": earned_rubles,
        "btc_won": btc_won,
        "mythic_perks": m_perks,
        "win_chance": round(win_chance * 100, 1)
    }

# ----------------- COOPERATIVE RAIDS (UP TO 6 PLAYERS) -----------------
COOP_DIFFICULTIES = {
    "easy": {
        "id": "easy",
        "name": "🟢 Легкая (Свалка / Промзона)",
        "badge": "🟢",
        "desc": "Заброшенные склады, патрули Диких и банда мародеров.",
        "requires_keycard": False,
        "base_win_chance": 35, # 35% base
        "member_bonus": 8,     # +8% per PMC (up to +48%)
        "rubles_reward": (120000, 250000),
        "loot_count": (2, 3)
    },
    "normal": {
        "id": "normal",
        "name": "🟡 Нормальная (Торговый центр Ультра)",
        "badge": "🟡",
        "desc": "Запутанные коридоры, магазины техники, засады рейдеров ЧВК.",
        "requires_keycard": False,
        "base_win_chance": 25, # 25% base
        "member_bonus": 7,     # +7% per PMC
        "rubles_reward": (300000, 600000),
        "loot_count": (2, 4)
    },
    "hard": {
        "id": "hard",
        "name": "🔴 Тяжелая (Бункер Резерва Глухаря)",
        "badge": "🔴",
        "desc": "Гермобункеры, элитная охрана с пулеметами и гранатометами. ⚠️ Требуется Лабораторная ключ-карта (Legendary) у лидера!",
        "requires_keycard": True,
        "base_win_chance": 16, # 16% base
        "member_bonus": 6,     # +6% per PMC
        "rubles_reward": (700000, 1400000),
        "loot_count": (3, 5)
    },
    "ultra": {
        "id": "ultra",
        "name": "🟣 Ультра (Очистные сооружения / Отступники)",
        "badge": "🟣",
        "desc": "Снайперские вышки, пулеметчики Rogue на крышах, минные поля. ⚠️ Требуется Лабораторная ключ-карта (Legendary) у лидера!",
        "requires_keycard": True,
        "base_win_chance": 10, # 10% base
        "member_bonus": 5,     # +5% per PMC
        "rubles_reward": (1500000, 3000000),
        "loot_count": (4, 6)
    },
    "colossal": {
        "id": "colossal",
        "name": "☠️ Колоссальная (TerraGroup Labs Underground)",
        "badge": "☠️",
        "desc": "Глубокий засекреченный подземный комплекс. Безжалостные рейдеры в шлемах Вулкан-5 и с Mk-18. ⚠️ Требуется Лабораторная ключ-карта (Legendary) у лидера!",
        "requires_keycard": True,
        "base_win_chance": 5,  # 5% base
        "member_bonus": 4,     # +4% per PMC (max 6 PMCs => 5 + 24 = 29% max!)
        "rubles_reward": (3500000, 7000000),
        "loot_count": (5, 8)
    }
}

def simulate_coop_raid(diff_key, members_list, force_success=False):
    """
    Simulates coop raid outcome for up to 6 players.
    Returns:
    {
        "success": bool,
        "win_chance": float,
        "diff": dict,
        "members_rewards": {user_id: {"rubles": int, "items": list}},
        "relic_dropped": dict or None,
        "lucky_user_id": str or None
    }
    """
    diff = COOP_DIFFICULTIES.get(diff_key, COOP_DIFFICULTIES["easy"])
    member_count = len(members_list)
    win_chance = min(90, diff["base_win_chance"] + member_count * diff["member_bonus"])

    if force_success:
        success = True
    else:
        roll = random.random() * 100.0
        success = roll < win_chance

    members_rewards = {}
    relic_dropped = None
    lucky_user_id = None
    mythic_case_dropped = None

    if success:
        min_r, max_r = diff["rubles_reward"]
        min_l, max_l = diff["loot_count"]
        for m in members_list:
            u_id = str(m["user_id"])
            m_rub = random.randint(min_r, max_r)
            m_items = []
            count = random.randint(min_l, max_l)
            if has_boss_set_bonus(m, "shturman"):
                count *= 2
                m_rub *= 2
            for _ in range(count):
                m_items.append(roll_coop_raid_loot(diff_key, m))
            members_rewards[u_id] = {
                "rubles": m_rub,
                "items": m_items
            }

        # Exact Boss Relic Drop Rates for the whole group:
        # Colossal: 10%, Ultra: 4%, Hard: 1%, Normal: 0%, Easy: 0%
        relic_chance_map = {
            "colossal": 0.10,
            "ultra": 0.04,
            "hard": 0.01,
            "normal": 0.0,
            "easy": 0.0
        }
        relic_chance = relic_chance_map.get(diff_key, 0.0)
        if ALL_30_RELICS and random.random() < relic_chance and members_list:
            relic_dropped = random.choice(ALL_30_RELICS)
            lucky_member = random.choice(members_list)
            lucky_user_id = str(lucky_member["user_id"])
            if lucky_user_id in members_rewards:
                members_rewards[lucky_user_id]["items"].append(relic_dropped)
                members_rewards[lucky_user_id]["dropped_relic"] = relic_dropped

        # Mythic Black Division Case drop chance for the group:
        # Colossal: 3.0%, Ultra: 1.5%, Hard: 0.5%, Normal: 0.1%
        mythic_case_chance_map = {
            "colossal": 0.030,
            "ultra": 0.015,
            "hard": 0.005,
            "normal": 0.001,
            "easy": 0.0
        }
        mythic_case_chance = mythic_case_chance_map.get(diff_key, 0.0)
        mythic_case_dropped = None
        if random.random() < mythic_case_chance and members_list:
            try:
                from mythic_system import MYTHIC_ITEMS
                mythic_case_dropped = MYTHIC_ITEMS["mythic_black_division_case"]
                lucky_case_member = random.choice(members_list)
                lucky_case_uid = str(lucky_case_member["user_id"])
                if lucky_case_uid in members_rewards:
                    members_rewards[lucky_case_uid]["items"].append(mythic_case_dropped)
                    members_rewards[lucky_case_uid]["dropped_mythic"] = mythic_case_dropped
            except Exception:
                pass

    return {
        "success": success,
        "win_chance": round(win_chance, 1),
        "diff": diff,
        "members_rewards": members_rewards,
        "relic_dropped": relic_dropped,
        "lucky_user_id": lucky_user_id,
        "mythic_case_dropped": mythic_case_dropped
    }

# ----------------- SECTION: BOSS ENCOUNTERS IN SOLO RAIDS -----------------

BOSS_AMBUSH_DEFINITIONS = {
    "factory": {
        "boss_id": "tagilla",
        "boss_name": "Тагилла с кувалдой",
        "icon": "🔨",
        "title": "ЗАСАДА БОССА: ТАГИЛЛА С КУВАЛДОЙ!",
        "desc": "Из темноты цеха с глухим ревом вылетает Тагилла в сварочной маске и тяжелом бронежилете Улей, размахивая двухметровой кувалдой!",
        "intro": "Тагилла заблокировал гермоворота! Пути к штатному выходу перерезаны!",
        "relic_id": "relic_tagilla_sledgehammer"
    },
    "customs": {
        "boss_id": "reshala",
        "boss_name": "Решала со свитой Заводских",
        "icon": "🕶️",
        "title": "ЗАСАДА БОССА: РЕШАЛА И ЗАВОДСКИЕ!",
        "desc": "В коридоре трехэтажной общаги отряд попадает под кинжальный перекрестный огонь: Решала с золотым ТТ и четыре тяжеловооруженных охранника в Гжелях зажали вас на лестнице!",
        "intro": "Заводские охранники забрасывают лестничный пролет гранатами Ф-1!",
        "relic_id": "relic_reshala_golden_tt"
    },
    "interchange": {
        "boss_id": "killa",
        "boss_name": "Килла с РПК-16",
        "icon": "🪖",
        "title": "ЗАСАДА БОССА: КИЛЛА С РПК!",
        "desc": "Среди витрин ТЦ Ультра раздается непрерывная пулеметная очередь из 95-патронного бубна! Килла в полосатом шлеме Маска-1Щ несется на ваш отряд в лобовую атаку!",
        "intro": "Килла поливает коридор свинцом и забрасывает гранатами РГД-5!",
        "relic_id": "relic_killa_helmet"
    },
    "woods": {
        "boss_id": "shturman",
        "boss_name": "Снайпер Штурман",
        "icon": "🎯",
        "title": "ЗАСАДА БОССА: СНАЙПЕР ШТУРМАН!",
        "desc": "Хлесткий выстрел 7.62x54R разрывает тишину соснового бора! Снайпер Штурман в камуфляжном полушубке и его охрана взяли периметр лесопилки под перекрестный прицел!",
        "intro": "Снайперы Штурмана прижали отряд к земле плотным огнем из СВД-С!",
        "relic_id": "relic_shturman_svds"
    },
    "reserve": {
        "boss_id": "glukhar",
        "boss_name": "Глухарь со свитой",
        "icon": "⭐",
        "title": "ЗАСАДА БОССА: ГЛУХАРЬ И СПЕЦНАЗ!",
        "desc": "Коридоры гермобункера содрогаются от грохота тяжелого пулемета АШ-12! Глухарь с штурмовой группой в шлемах Алтын идет на таран вашего отряда!",
        "intro": "Свита Глухаря перекрыла герметичные шлюзы и ведет подавляющий огонь крупным калибром!",
        "relic_id": "relic_glukhar_ash12"
    },
    "labs": {
        "boss_id": "sanitar",
        "boss_name": "Санитар и Элитные Рейдеры",
        "icon": "💉",
        "title": "ЗАСАДА БОССА: САНИТАР И РЕЙДЕРЫ!",
        "desc": "В стерильном гермоблоке лаборатории TerraGroup отряд атакуют головорезы Санитара под действием экспериментальных стимуляторов «Оболтус» и «Мельдонин»!",
        "intro": "Рейдеры под стимуляторами не чувствуют боли и яростно контратакуют в упор!",
        "relic_id": "relic_sanitar_bag"
    }
}

def roll_boss_ambush(location_key, force=False):
    """
    Rolls for boss ambush in solo raids (5-8% chance, default ~7%).
    """
    if location_key not in BOSS_AMBUSH_DEFINITIONS:
        return None
    if force or random.random() < 0.07:
        data = dict(BOSS_AMBUSH_DEFINITIONS[location_key])
        data["location_key"] = location_key
        return data
    return None

def simulate_boss_combat(location_key, boss_info, player, squad_power, squad_armor):
    """
    Executes 'Принять бой':
    - Location difficulty is multiplied by 1.8 (balanced challenge instead of unfair 3.0x).
    - In case of triumph: Jackpot rubles, 2-4 Epic/Legendary items, boss relic/trophy chance, 200 exp!
    - In case of defeat: Catastrophic squad losses (Scavs die permanently, PMCs stripped of gear).
    """
    loc = RAID_LOCATIONS.get(location_key, RAID_LOCATIONS["factory"])
    boss_diff = int(loc["difficulty"] * 1.8)
    
    combined_stat = (squad_power * 1.3) + (squad_armor * 0.9)
    ratio = combined_stat / max(1, boss_diff)
    win_chance = min(0.88, max(0.10, (ratio / (ratio + 0.95)) * 1.30))
    
    if has_buff(player, "pvp_bonus"):
        win_chance = min(0.92, win_chance + 0.10)
    if has_boss_set_bonus(player, "killa"):
        win_chance = min(0.96, win_chance + 0.50)
        
    squad = player.get("squad", [])
    scav_count = sum(1 for f in squad if f.get("type") == "scav")
    pmc_count = sum(1 for f in squad if f.get("type") != "scav")
    if pmc_count == 0 and scav_count > 0:
        win_chance = min(0.35, win_chance)

    # Mythic gear boss combat bonus (M32A1 barrage, ComTac early detection):
    m_perks = None
    if player:
        try:
            from mythic_system import get_squad_mythic_perks
            m_perks = get_squad_mythic_perks(player)
            win_chance += m_perks.get("boss_combat_win_bonus", 0.0)
        except Exception:
            pass

    max_boss_cap = 0.98 if (m_perks and m_perks.get("total_mythics", 0) > 0) else 0.92
    win_chance = min(max_boss_cap, win_chance)
    win_chance_pct = round(win_chance * 100, 1)
    success = random.random() < win_chance
    
    if success:
        rubles = random.randint(600000, 1200000) + (loc["difficulty"] * 4000)
        if m_perks and m_perks.get("rubles_mult", 1.0) > 1.0:
            rubles = int(rubles * m_perks["rubles_mult"])
        items = []
        item_count = random.randint(2, 4)
        for _ in range(item_count):
            r_roll = random.random()
            if r_roll < 0.45 and POOL_LEGENDARY:
                items.append(random.choice(POOL_LEGENDARY))
            elif POOL_EPIC:
                items.append(random.choice(POOL_EPIC))
            elif POOL_RARE:
                items.append(random.choice(POOL_RARE))
                
        boss_relic_id = boss_info.get("relic_id")
        if boss_relic_id and boss_relic_id in ITEMS_BY_ID and random.random() < 0.35:
            relic_item = ITEMS_BY_ID[boss_relic_id]
            items.append(relic_item)

        # Bonus 25% chance to roll another true 10M ₽ boss relic piece from relics_system
        b_id = boss_info.get("boss_id")
        if b_id and b_id in BOSS_SETS and random.random() < 0.25:
            true_relic = random.choice(BOSS_SETS[b_id]["relics"])
            if true_relic not in items:
                items.append(true_relic)

        return {
            "success": True,
            "win_chance_pct": win_chance_pct,
            "boss_diff": boss_diff,
            "rubles": rubles,
            "items": items,
            "boss_info": boss_info,
            "exp": 200
        }
    else:
        return {
            "success": False,
            "win_chance_pct": win_chance_pct,
            "boss_diff": boss_diff,
            "boss_info": boss_info
        }

def simulate_boss_retreat(location_key, boss_info, player):
    """
    Executes 'Отступить с боем (Тактический отход)':
    - 60% chance: Safe smoke grenade withdrawal, squad drops 1 random unequipped item from stash (or pays emergency fee).
    - 40% chance: Rearguard heavy fire - 1 fighter from squad loses equipped armor to covering fire.
    """
    roll = random.random()
    stash = player.get("stash", [])
    squad = player.get("squad", [])
    
    if roll < 0.60:
        # Protect mythic items from drop on retreat:
        unequipped = [i for i in stash if not i.get("equipped_to") and not i.get("is_scav_locked") and ITEMS_BY_ID.get(i.get("item_id"), {}).get("rarity") != "mythic"]
        dropped_name = None
        fee_paid = 0
        if unequipped:
            dropped_item = random.choice(unequipped)
            stash.remove(dropped_item)
            dropped_name = ITEMS_BY_ID.get(dropped_item["item_id"], {}).get("name", "Снаряжение")
        else:
            fee_paid = min(player.get("money", 0), 25000)
            player["money"] = player.get("money", 0) - fee_paid
            dropped_name = f"{fee_paid} ₽ проводнику"
        
        return {
            "retreat_type": "safe",
            "dropped_name": dropped_name,
            "fee_paid": fee_paid,
            "boss_info": boss_info
        }
    else:
        injured_fighter_name = "Боец"
        destroyed_gear_names = []
        if squad:
            fighter = random.choice(squad)
            injured_fighter_name = fighter.get("name", "Боец")
            for slot_key in ["armor_uid", "helmet_uid"]:
                uid = fighter.get(slot_key)
                if uid:
                    item_entry = next((i for i in stash if i.get("uid") == uid), None)
                    if item_entry:
                        info = ITEMS_BY_ID.get(item_entry.get("item_id"), {})
                        if info.get("rarity") != "mythic":
                            stash.remove(item_entry)
                            name = info.get("name", "Броня")
                            destroyed_gear_names.append(name)
                        else:
                            item_entry["equipped_to"] = None
                    fighter[slot_key] = None
        
        return {
            "retreat_type": "rearguard_hit",
            "injured_fighter_name": injured_fighter_name,
            "destroyed_gear_names": destroyed_gear_names,
            "boss_info": boss_info
        }
