# -*- coding: utf-8 -*-
"""
Bot & Server Statistics View for Escape from Tarkov MMO Bot.
Generates comprehensive global server metrics and personal PMC dossier.
"""

import time
from telebot import types

def render_bot_stats(player, db):
    """
    Renders the unified Statistics dashboard.
    Returns (text, inline_markup).
    """
    users = db.get("users", {})
    market = db.get("market", [])
    now = int(time.time())

    # 1. Global Server Metrics
    total_players = len(users)
    total_rubles = sum(p.get("money", 0) for p in users.values())
    total_btc = sum(p.get("btc", 0.0) for p in users.values())
    total_raids = sum(p.get("stats", {}).get("raids_count", 0) for p in users.values())
    total_coop = sum(p.get("stats", {}).get("coop_raids_count", 0) for p in users.values())
    total_pvp = sum(p.get("stats", {}).get("pvp_wins", 0) for p in users.values())
    total_airdrops = sum(p.get("stats", {}).get("airdrop_looted", 0) for p in users.values())
    active_lots = len(market)

    # Top Wealthiest PMCs
    sorted_by_wealth = sorted(
        users.values(),
        key=lambda u: u.get("money", 0) + (u.get("btc", 0.0) * 500000),
        reverse=True
    )[:3]
    top_wealth_lines = []
    medals = ["🥇", "🥈", "🥉"]
    for idx, u in enumerate(sorted_by_wealth):
        uname = u.get("username") or f"PMC_{u.get('user_id')}"
        m_val = u.get("money", 0)
        top_wealth_lines.append(f"  {medals[idx]} <b>@{uname}</b>: {m_val:,} ₽".replace(",", " "))

    # 2. Personal PMC Dossier
    st = player.get("stats", {})
    p_lvl = player.get("level", 1)
    
    # Prestige
    from prestige import get_prestige_badge, get_player_prestige
    prestige_badge = get_prestige_badge(player)
    prestige_lvl = get_player_prestige(player)

    # Battle pass
    bp_lvl = player.get("gd_battlepass", {}).get("level", 1)
    has_bp = player.get("special_businesses", {}).get("gd_shadow_agent", False)
    bp_status = f"{bp_lvl}/150 ур. (Активен ✅)" if has_bp else "Не активирован 🔒"

    # Raids winrate
    raids_cnt = st.get("raids_count", 0)
    coop_cnt = st.get("coop_raids_count", 0)
    coop_wins = st.get("coop_wins", 0)
    coop_losses = st.get("coop_losses", 0)
    coop_winrate = round((coop_wins / max(1, coop_wins + coop_losses)) * 100, 1) if (coop_wins + coop_losses) > 0 else 0.0

    # PvP K/D
    pvp_w = st.get("pvp_wins", 0)
    pvp_l = st.get("pvp_losses", 0)
    pvp_kd = round(pvp_w / max(1, pvp_l), 2) if pvp_l > 0 else (float(pvp_w) if pvp_w > 0 else 0.0)

    # Relics and Mythics
    from relics_system import get_player_relics
    relics_cnt = len(get_player_relics(player))
    
    mythics = player.get("mythic_items", [])
    mythics_icons = []
    if "mythic_dsp_sensor" in mythics:
        mythics_icons.append("📟 DSP")
    if "mythic_goons_token" in mythics:
        mythics_icons.append("🎖️ Goons")
    if "mythic_black_division_case" in mythics:
        mythics_icons.append("💼 ЧД")
    mythics_str = ", ".join(mythics_icons) if mythics_icons else "Нет"

    # Squad info
    from tarkov_engine import calculate_squad_power, get_max_squad_size
    squad = player.get("squad", [])
    pow_val, arm_val = calculate_squad_power(player)
    max_sq = get_max_squad_size(player)

    txt = (
        f"📊 <b>СВОДНАЯ СТАТИСТИКА СЕРВЕРА & ДОСЬЕ ЧВК</b>\n"
        f"────────────────────────\n"
        f"🌐 <b>ГЛОБАЛЬНАЯ ЭКОНОМИКА ТАРКОВА:</b>\n"
        f"• Всего зарегистрировано бойцов: <b>{total_players}</b>\n"
        f"• Денежная масса в обороте: <b>{total_rubles:,} ₽</b>\n".replace(",", " ") +
        f"• Общий запас криптовалюты: <b>{total_btc:.4f} BTC</b>\n"
        f"• Всего выходов в рейды: <b>{total_raids}</b> (Кооп: {total_coop})\n"
        f"• PvP-столкновений зафиксировано: <b>{total_pvp}</b>\n"
        f"• Эирдропов сброшено и вскрыто: <b>{total_airdrops}</b>\n"
        f"• Активных предложений на Барахолке: <b>{active_lots}</b>\n\n"
        f"🏆 <b>ТОП-3 ОЛИГАРХА НОРВИНСКОГО СЕКТОРА:</b>\n"
        + "\n".join(top_wealth_lines) + "\n"
        f"────────────────────────\n"
        f"👤 <b>ЛИЧНОЕ БОЕВОЕ ДОСЬЕ: @{player.get('username', 'PMC')}</b>\n"
        f"• Ранг / Уровень: <b>Уровень {p_lvl}</b>\n"
        f"• Статус Престижа: <b>{prestige_badge}</b> (Транш {prestige_lvl}/5)\n"
        f"• Боевой Пропуск GD: <b>{bp_status}</b>\n"
        f"• Боевой Отряд: <b>{len(squad)}/{max_sq} бойцов</b> (Мощь: {pow_val} | Броня: {arm_val})\n\n"
        f"⚔️ <b>БОЕВАЯ ЭФФЕКТИВНОСТЬ:</b>\n"
        f"• Завершено рейдов: <b>{raids_cnt}</b>\n"
        f"• Кооп-рейды: <b>{coop_cnt}</b> (Побед: {coop_wins} | Разгромов: {coop_losses} | ВР: <b>{coop_winrate}%</b>)\n"
        f"• PvP-дуэли: <b>{pvp_w}W / {pvp_l}L</b> (K/D: <b>{pvp_kd}</b>)\n"
        f"• Перехвачено эирдропов: <b>{st.get('airdrop_looted', 0)}</b>\n\n"
        f"💎 <b>КОЛЛЕКЦИИ И АРТЕФАКТЫ:</b>\n"
        f"• Реликвий боссов: <b>{relics_cnt}/30</b>\n"
        f"• Мифические артефакты: <b>{mythics_str}</b>\n"
        f"• Всего заработано за службу: <b>{st.get('total_earned_rubles', 0):,} ₽</b>\n".replace(",", " ") +
        f"────────────────────────\n"
        f"<i>Обновляется в реальном времени при каждом боевом столкновении.</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("🏷️ Титулы и Звания", callback_data="menu_titles_collection"),
        types.InlineKeyboardButton("🎖️ Престиж ЧВК", callback_data="menu_prestige")
    )
    markup.add(
        types.InlineKeyboardButton("🔮 Все Пассивки ЧВК", callback_data="menu_passives"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    return txt, markup
