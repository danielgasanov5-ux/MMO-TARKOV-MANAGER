# -*- coding: utf-8 -*-
"""
5-Tier Prestige System for Escape from Tarkov MMO Telegram Bot:
Tier 1: 🎖️ Ветеран Контракта
Tier 2: 🥈 Теневой Делец
Tier 3: 💀 Охотник за Головами
Tier 4: ⚡ Доверенный Смотрителя
Tier 5: 👑 Легенда Таркова

Mechanics:
- Voluntary personal profile reset for endgame PMC (level 10).
- Permanent bonuses, badges, and multipliers.
- DSP Sensor (mythic_dsp_sensor) contraband drop rate boost (0.1% -> 1.0% at Prestige 4+).
- DSP Sensor permanent retention across resets starting at Prestige 4.
- Zryachiy Sniper Support at Prestige 5 with active DSP sensor.
- Squad capacity expansion: base 6 fighters (7 with Glukhar set).
- Admin command: /set_prestige [1-5] to instantly set admin or player prestige.
"""

import time
import random

PRESTIGE_TIERS = {
    1: {
        "level": 1,
        "name": "Ветеран Контракта",
        "icon": "🎖️",
        "badge": "[🎖️ Ветеран I]",
        "tagline": "Начало пути легенды. Быстрая прокачка и повышенный стартовый резерв.",
        "reqs": {
            "level": 10,
            "rubles": 25_000_000,
            "raids": 50,
            "btc": 0.0,
            "boss_sets": 0,
            "pvp_wins": 0,
            "need_dsp": False
        },
        "perks": [
            "💰 Стартовый капитал: 1 500 000 ₽ + АК-74М с патронами БТ и броней (вместо ТОЗ-106)",
            "⚡ Опыт во всех рейдах: +20% EXP навсегда",
            "🛠️ Стоимость постройки модулей Убежища: -15% навсегда"
        ]
    },
    2: {
        "level": 2,
        "name": "Теневой Делец",
        "icon": "🥈",
        "badge": "[🥈 Делец II]",
        "tagline": "Прямые выходы на Черный Рынок и ускоренная спецоперативная логистика.",
        "reqs": {
            "level": 10,
            "rubles": 60_000_000,
            "raids": 0,
            "btc": 3.0,
            "boss_sets": 1,
            "pvp_wins": 0,
            "need_dsp": False
        },
        "perks": [
            "🏪 Комиссия P2P Барахолки: 0% навсегда (полная сумма без вычетов)",
            "🎩 Автовыкуп лотов богатыми NPC: каждые 1.5 часа (в 2 раза быстрее)",
            "⏳ Спецоперация ЧВК (Solo SpecOps): кулдаун 4.5 часа вместо 6 часов"
        ]
    },
    3: {
        "level": 3,
        "name": "Охотник за Головами",
        "icon": "💀",
        "badge": "[💀 Охотник III]",
        "tagline": "Особое чутье на боссов, защищенный контейнер и синдикат доходов.",
        "reqs": {
            "level": 10,
            "rubles": 150_000_000,
            "raids": 0,
            "btc": 10.0,
            "boss_sets": 0,
            "pvp_wins": 15,
            "need_dsp": False
        },
        "perks": [
            "👁️ Призыв уникального Босса: 3% шанс при найме Дикого (в 3 раза чаще)",
            "📦 Защищенный контейнер: 1 топ-предмет гарантированно спасается при провале рейда",
            "🏢 Доход всех 4 бизнесов: +25% прибыли/час навсегда"
        ]
    },
    4: {
        "level": 4,
        "name": "Доверенный Смотрителя",
        "icon": "⚡",
        "badge": "[⚡ Агент Маяка IV]",
        "tagline": "Личная радиочастота Смотрителя Маяка и расширенная логистика складов.",
        "reqs": {
            "level": 10,
            "rubles": 350_000_000,
            "raids": 0,
            "btc": 25.0,
            "boss_sets": 3,
            "pvp_wins": 0,
            "need_dsp": False
        },
        "perks": [
            "📟 Шанс Датчика DSP в Контрабанде: 1.0% (1 из 100) вместо 0.1% (в 10 раз легче!)",
            "🔒 Вечная защита Датчика DSP: радиочастота Смотрителя не сгорает при сбросе профиля",
            "📦 Поставки снаряжения Зрячего: каждые 16 часов (вместо 24 часов)",
            "🏭 Базовая вместимость всех 5 складов: +50% навсегда"
        ]
    },
    5: {
        "level": 5,
        "name": "Легенда Таркова",
        "icon": "👑",
        "badge": "[👑 ЛЕГЕНДА V]",
        "tagline": "Вершина криминальной и военной мощи. Личная армия и снайперская поддержка Зрячего.",
        "reqs": {
            "level": 10,
            "rubles": 1_000_000_000,
            "raids": 0,
            "btc": 50.0,
            "boss_sets": 6,
            "pvp_wins": 0,
            "need_dsp": True
        },
        "perks": [
            "🪖 Рота ЧВК: базовый размер отряда 6 бойцов (до 7 бойцов с сетом Глухаря!)",
            "🎯 Снайперское прикрытие Зрячего: выстрел AXMC .338 AP на старте боя, +15% винрейт, -30% брони босса",
            "⚡ Реактор Terragroup: Генератор сразу 10-й ур. (+30% доход) и +100% к майнингу BTC",
            "💰 Денежная добыча в рейдах и операциях: x1.5 мультипликатор",
            "🌟 Эксклюзивный статус: золотой титул [👑 ЛЕГЕНДА V] и анонс во все чаты"
        ]
    }
}

def get_player_prestige(player):
    """Returns integer prestige level (0 to 5)."""
    if not player:
        return 0
    p = player.get("prestige", 0)
    if isinstance(p, dict):
        return int(p.get("level", 0))
    try:
        return max(0, min(5, int(p)))
    except (ValueError, TypeError):
        return 0

def get_active_prestige_perks(player):
    """Returns list of active perks accumulated across all unlocked prestige tiers."""
    lvl = get_player_prestige(player)
    perks = []
    for t in range(1, lvl + 1):
        if t in PRESTIGE_TIERS:
            perks.extend(PRESTIGE_TIERS[t].get("perks", []))
    return perks

def get_prestige_badge(player):
    """Returns badge string to prepend/append to player's name."""
    lvl = get_player_prestige(player)
    if lvl in PRESTIGE_TIERS:
        return PRESTIGE_TIERS[lvl]["badge"]
    return ""

def count_player_boss_sets(player):
    """Counts how many 5/5 boss sets player has completed."""
    try:
        from relics_system import BOSS_SETS
        owned_relics = set()
        for itm in player.get("stash", []):
            item_id = itm.get("item_id", "")
            if item_id.startswith("relic_"):
                owned_relics.add(item_id)
        
        completed = 0
        for bkey, bdata in BOSS_SETS.items():
            req_relic_ids = [r["id"] for r in bdata.get("relics", [])]
            if req_relic_ids and all(rid in owned_relics for rid in req_relic_ids):
                completed += 1
        return completed
    except Exception:
        return 0

def has_player_dsp_sensor(player):
    """Checks if player owns mythic_dsp_sensor."""
    try:
        from mythic_system import has_mythic_item
        return has_mythic_item(player, "mythic_dsp_sensor")
    except Exception:
        return "mythic_dsp_sensor" in player.get("mythic_items", [])

def check_prestige_requirements(player, target_lvl):
    """
    Validates if player meets all requirements for target_lvl (1..5).
    Returns (can_upgrade, checklist_dict).
    """
    if target_lvl not in PRESTIGE_TIERS:
        return False, {"error": "Неверный уровень престижа"}
    
    current_lvl = get_player_prestige(player)
    if target_lvl != current_lvl + 1:
        return False, {"error": f"Сначала необходимо получить {current_lvl + 1}-й Престиж"}
    
    cfg = PRESTIGE_TIERS[target_lvl]
    reqs = cfg["reqs"]
    
    p_lvl = player.get("level", 1)
    p_money = player.get("money", 0)
    p_btc = player.get("btc", 0.0)
    p_raids = player.get("stats", {}).get("raids_count", 0)
    p_pvp = player.get("stats", {}).get("pvp_wins", 0)
    p_boss_sets = count_player_boss_sets(player)
    has_dsp = has_player_dsp_sensor(player)
    
    checklist = [
        {
            "name": "Уровень ЧВК",
            "needed": f"{reqs['level']} ур.",
            "current": f"{p_lvl} ур.",
            "met": p_lvl >= reqs["level"]
        },
        {
            "name": "Наличные рубли",
            "needed": f"{reqs['rubles']:,} ₽".replace(",", " "),
            "current": f"{p_money:,} ₽".replace(",", " "),
            "met": p_money >= reqs["rubles"]
        }
    ]
    
    if reqs.get("btc", 0.0) > 0:
        checklist.append({
            "name": "Биткоины (BTC)",
            "needed": f"{reqs['btc']} BTC",
            "current": f"{p_btc:.3f} BTC",
            "met": p_btc >= reqs["btc"]
        })
        
    if reqs.get("raids", 0) > 0:
        checklist.append({
            "name": "Успешных рейдов",
            "needed": f"{reqs['raids']}",
            "current": f"{p_raids}",
            "met": p_raids >= reqs["raids"]
        })
        
    if reqs.get("pvp_wins", 0) > 0:
        checklist.append({
            "name": "Побед в PvP-дуэлях",
            "needed": f"{reqs['pvp_wins']}",
            "current": f"{p_pvp}",
            "met": p_pvp >= reqs["pvp_wins"]
        })
        
    if reqs.get("boss_sets", 0) > 0:
        checklist.append({
            "name": "Собранных сетов реликвий (5/5)",
            "needed": f"{reqs['boss_sets']}",
            "current": f"{p_boss_sets}",
            "met": p_boss_sets >= reqs["boss_sets"]
        })
        
    if reqs.get("need_dsp", False):
        checklist.append({
            "name": "📟 Датчик DSP Смотрителя",
            "needed": "В наличии",
            "current": "Имеется" if has_dsp else "Отсутствует",
            "met": has_dsp
        })
        
    all_met = all(item["met"] for item in checklist)
    return all_met, {"checklist": checklist, "tier": cfg}

can_advance_prestige = check_prestige_requirements

def execute_prestige_reset(player, target_lvl):
    """
    Executes personal voluntary profile reset to target_lvl.
    Applies permanent bonuses, preserves clothing and DSP sensor (at 4+).
    """
    now = int(time.time())
    
    # 1. Determine items to preserve
    keep_dsp = (target_lvl >= 4) and has_player_dsp_sensor(player)
    
    # Keep clothing intact
    clothes_stash = list(player.get("clothes_stash", []))
    equipped_clothes = dict(player.get("equipped_clothes", {
        "shoes": None, "headwear": None, "suit": None, "accessory": None
    }))
    
    # Keep mythic items list (preserving DSP sensor if eligible)
    mythics = list(player.get("mythic_items", []))
    if not keep_dsp and "mythic_dsp_sensor" in mythics:
        mythics.remove("mythic_dsp_sensor")
        
    # Stats preservation
    stats = dict(player.get("stats", {}))
    stats["prestige_resets"] = stats.get("prestige_resets", 0) + 1
    
    # 2. Starter gear & balance based on prestige perks
    if target_lvl >= 1:
        start_money = 1_500_000
        starter_stash = [
            {"uid": f"{now}_1", "item_id": "ak74m_common", "equipped_to": None},
            {"uid": f"{now}_2", "item_id": "ammo_545_bt_rare", "equipped_to": None},
            {"uid": f"{now}_3", "item_id": "armor_6b23_common", "equipped_to": None},
            {"uid": f"{now}_4", "item_id": "helmet_6b47_common", "equipped_to": None},
            {"uid": f"{now}_5", "item_id": "ai2_medkit_common", "equipped_to": None},
            {"uid": f"{now}_6", "item_id": "ai2_medkit_common", "equipped_to": None},
            {"uid": f"{now}_7", "item_id": "bandage_common", "equipped_to": None},
            {"uid": f"{now}_8", "item_id": "splint_common", "equipped_to": None},
            {"uid": f"{now}_9", "item_id": "gssh_01_common", "equipped_to": None}
        ]
    else:
        start_money = 500_000
        starter_stash = [
            {"uid": f"{now}_1", "item_id": "toz_106_common", "equipped_to": None},
            {"uid": f"{now}_2", "item_id": "ak74m_common", "equipped_to": None},
            {"uid": f"{now}_3", "item_id": "ai2_medkit_common", "equipped_to": None},
            {"uid": f"{now}_4", "item_id": "bandage_common", "equipped_to": None},
            {"uid": f"{now}_5", "item_id": "gssh_01_common", "equipped_to": None},
            {"uid": f"{now}_6", "item_id": "kolpak_common", "equipped_to": None}
        ]
        
    if keep_dsp:
        starter_stash.append({"uid": f"dsp_{now}", "item_id": "mythic_dsp_sensor", "equipped_to": None})
        
    # Starter squad: 1 Scav
    starter_squad = [
        {
            "id": 1,
            "type": "scav",
            "name": "Дикий #1",
            "weapon_uid": f"{now}_1",
            "armor_uid": f"{now}_3" if target_lvl >= 1 else None,
            "helmet_uid": f"{now}_4" if target_lvl >= 1 else None,
            "headset_uid": f"{now}_9" if target_lvl >= 1 else None
        }
    ]
    
    # Generator level: if Prestige >= 5, starts at max level 10!
    gen_start = 10 if target_lvl >= 5 else 1
    
    # 3. Apply profile reset
    player["level"] = 1
    player["exp"] = 0
    player["money"] = start_money
    player["btc"] = 0.0
    player["prestige"] = target_lvl
    player["hideout_lvl"] = 1
    player["supply_channel_lvl"] = 1
    
    try:
        from tarkov_engine import MODULE_NAMES, BUSINESS_NAMES, BASE_WAREHOUSE_CAPS
        player["modules"] = {k: (gen_start if k == "generator" else 0) for k in MODULE_NAMES}
        player["businesses"] = {k: 0 for k in BUSINESS_NAMES}
        player["special_businesses"] = {"smugglers_fleet": False, "fence_protection": False}
        player["warehouses"] = {k: 1 for k in BASE_WAREHOUSE_CAPS}
    except Exception:
        pass
    
    player["stash"] = starter_stash
    player["clothes_stash"] = clothes_stash
    player["equipped_clothes"] = equipped_clothes
    player["mythic_items"] = mythics
    player["squad"] = starter_squad
    player["stats"] = stats
    
    # Protection
    if keep_dsp:
        player["guard_until"] = 2147483647
    else:
        player["guard_until"] = now + 10800
        
    player["is_base_captured"] = False
    player["businesses_blocked"] = False
    player["stolen_stash"] = []
    player["stolen_money"] = 0
    player["stolen_btc"] = 0.0
    player["last_income_claim"] = now
    player["last_raid_time"] = 0
    player["coop_cooldown_until"] = 0
    
    return True

def apply_zryachiy_sniper_support(player, target_type="raid"):
    """
    Calculates sniper support of Zryachiy for Prestige 5 players with DSP sensor.
    Returns dict with combat modifiers and cinematic text.
    """
    lvl = get_player_prestige(player)
    has_dsp = has_player_dsp_sensor(player)
    
    if lvl < 5 or not has_dsp:
        return {
            "active": False,
            "flat_win_bonus": 0.0,
            "boss_debuff": 0.0,
            "log_text": ""
        }
        
    if target_type == "boss":
        log_text = (
            "🎯 <b>СНАЙПЕРСКОЕ ПРИКРЫТИЕ ЗРЯЧЕГО:</b>\n"
            "<i>С Маяка на частоте 104.7 МГц раздается щелчок... Выстрел AXMC .338 AP пробивает шлем босса! "
            "Свита босса ликвидирована, броня босса расколота (-30% защиты).</i>\n"
        )
        return {
            "active": True,
            "flat_win_bonus": 0.20,
            "boss_debuff": 0.30,
            "log_text": log_text
        }
    elif target_type == "duel":
        log_text = (
            "🎯 <b>ВЫСТРЕЛ ЗРЯЧЕГО:</b>\n"
            "<i>Зрячий подавляет отряд соперника точным огнем с километровой дистанции (-25% к броне оппонента)!</i>\n"
        )
        return {
            "active": True,
            "flat_win_bonus": 0.15,
            "enemy_armor_mult": 0.75,
            "log_text": log_text
        }
    else:  # standard raid
        log_text = (
            "🎯 <b>СНАЙПЕРСКОЕ ПРИКРЫТИЕ ЗРЯЧЕГО:</b>\n"
            "<i>Зрячий контролирует периметр. Главный снайпер засады ликвидирован до начала перестрелки (+15% к выживанию)!</i>\n"
        )
        return {
            "active": True,
            "flat_win_bonus": 0.15,
            "log_text": log_text
        }


# ==================== TELEGRAM BOT UI RENDERING ====================

def render_prestige_menu(player, view_tier=None):
    """
    Renders the Prestige System dashboard.
    Returns (text, inline_markup).
    """
    from telebot import types
    curr_tier = get_player_prestige(player)
    
    if view_tier is None:
        target_tier = min(5, curr_tier + 1)
    else:
        target_tier = max(1, min(5, view_tier))
        
    cfg = PRESTIGE_TIERS[target_tier]
    can_prestige, details = can_advance_prestige(player, target_tier)
    
    # Active perks text
    active_perks = get_active_prestige_perks(player)
    if active_perks:
        active_perks_str = "\n".join([f"  • {p}" for p in active_perks])
    else:
        active_perks_str = "  <i>У вас пока нет активных перков престижа.</i>"

    # Next tier perks
    next_perks_str = "\n".join([f"  ✨ {p}" for p in cfg["perks"]])

    # Checklist
    checklist_str = ""
    for chk in details["checklist"]:
        icon = "✅" if chk["met"] else "❌"
        checklist_str += f"{icon} <b>{chk['name']}</b>: {chk['current']} / <b>{chk['needed']}</b>\n"

    txt = (
        f"🎖️ <b>СИСТЕМА ПРЕСТИЖА ЧВК</b>\n"
        f"────────────────────────\n"
        f"Ваш текущий ранг: <b>{get_prestige_badge(player)}</b> (Уровень {curr_tier}/5)\n\n"
        f"🔥 <b>ВАШИ АКТИВНЫЕ БОНУСЫ:</b>\n"
        f"{active_perks_str}\n\n"
        f"────────────────────────\n"
        f"🎯 <b>РАНГ {target_tier}: {cfg['icon']} {cfg['name']}</b>\n"
        f"<i>{cfg['tagline']}</i>\n\n"
        f"🎁 <b>Новые перки ранга:</b>\n"
        f"{next_perks_str}\n\n"
        f"📋 <b>Требования для перехода:</b>\n"
        f"{checklist_str}"
        f"────────────────────────\n"
        f"⚠️ <i>Переход на престиж сбрасывает уровень и обычный схрон, но навсегда сохраняет гардероб, "
        f"мифические бонусы, усиливает дроп и дает элитный стартовый комплект!</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=3)
    
    # Tier selector buttons
    tier_btns = []
    for t in range(1, 6):
        label = f"{PRESTIGE_TIERS[t]['icon']} Т-{t}"
        if t == curr_tier:
            label += " (Вы)"
        elif t == target_tier:
            label = f"👉 {label}"
        tier_btns.append(types.InlineKeyboardButton(label, callback_data=f"prestige_view_{t}"))
    markup.row(*tier_btns[:3])
    markup.row(*tier_btns[3:])

    # Action button
    if curr_tier >= 5:
        markup.add(types.InlineKeyboardButton("👑 ВЫ ДОСТИГЛИ МАКСИМАЛЬНОГО ПРЕСТИЖА", callback_data="none"))
    elif can_prestige and target_tier == curr_tier + 1:
        markup.add(types.InlineKeyboardButton(f"🚀 СОВЕРШИТЬ ПЕРЕХОД: {cfg['icon']} ПРЕСТИЖ {target_tier}", callback_data=f"prestige_confirm_{target_tier}"))
    elif target_tier == curr_tier + 1:
        markup.add(types.InlineKeyboardButton("🔒 Требования еще не выполнены", callback_data="none"))

    markup.add(
        types.InlineKeyboardButton("🔮 Все Пассивки", callback_data="menu_passives"),
        types.InlineKeyboardButton("🔙 В Профиль", callback_data="menu_profile")
    )
    return txt, markup


def render_prestige_confirm(player, target_tier):
    """
    Renders confirmation dialog before voluntary prestige reset.
    """
    from telebot import types
    cfg = PRESTIGE_TIERS[target_tier]
    keep_dsp = (target_tier >= 4) and has_player_dsp_sensor(player)
    dsp_note = "\n• 📟 <b>Датчик DSP Смотрителя сохраняется</b> в вашем схроне!" if keep_dsp else ""

    txt = (
        f"⚠️ <b>ПОДТВЕРЖДЕНИЕ ПЕРЕХОДА НА ПРЕСТИЖ {target_tier}</b>\n"
        f"────────────────────────\n"
        f"Вы собираетесь получить статус: {cfg['icon']} <b>{cfg['name']}</b>\n\n"
        f"🛑 <b>ВНИМАНИЕ! ПРОИЗОЙДЕТ СБРОС ПРОФИЛЯ:</b>\n"
        f"• Уровень ЧВК вернется на 1 (прокачка станет быстрее на +20% EXP)\n"
        f"• Баланс рублей и склад обычных предметов будут заменены на элитный стартовый комплект\n"
        f"• Модули Убежища будут сброшены (стоимость их сборки снижена на -15%)\n"
        f"{dsp_note}\n"
        f"• 👔 <b>ВЕСЬ ВАШ ГАРДЕРОБ И ОДЕЖДА ОСТАЮТСЯ ЦЕЛЫМИ И НЕВРЕДИМЫМИ!</b>\n"
        f"• Вы получите постоянный бейдж <b>{cfg['badge']}</b> и статус легенды!\n\n"
        f"Вы уверены, что готовы сбросить профиль ради вечного величия?"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(f"✅ ДА, СБРОСИТЬ ПРОФИЛЬ И СТАТЬ {cfg['name'].upper()}", callback_data=f"prestige_execute_{target_tier}"),
        types.InlineKeyboardButton("❌ Отмена (Вернуться назад)", callback_data=f"prestige_view_{target_tier}")
    )
    return txt, markup

