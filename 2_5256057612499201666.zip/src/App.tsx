import { useState } from "react";
import { Download, CheckCircle2, Terminal, ShieldAlert, FileCode2, Copy, Check, ExternalLink, Sparkles, Server } from "lucide-react";

export default function App() {
  const [copied, setCopied] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const directDownloadUrl = `${window.location.origin}/tarkov_mmo_bot_fixed.zip`;

  const copyUrl = () => {
    navigator.clipboard.writeText(directDownloadUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const copyBash = () => {
    const text = `cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
export BOT_TOKEN="ВАШ_ТОКЕН_БОТА"
python3 bot.py`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-200">
      {/* Top Bar */}
      <header className="border-b border-neutral-800 bg-neutral-900/70 backdrop-blur px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-sm">
            EFT
          </div>
          <div>
            <h1 className="font-semibold tracking-wide text-sm sm:text-base text-neutral-100">
              TARKOV MMO BOT — RELEASE ARCHIVE
            </h1>
            <p className="text-xs text-neutral-400">Версия с исправленными ошибками и тестами</p>
          </div>
        </div>

        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          Все 12 тестов пройдены
        </span>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-6 sm:p-8 space-y-8">
        {/* Hero Card */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>

          <div className="space-y-4 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md text-xs font-medium bg-amber-500/10 text-amber-300 border border-amber-500/20">
              <Sparkles className="w-3.5 h-3.5" />
              Готовый к развертыванию ZIP-пакет
            </div>

            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Скачать Tarkov MMO Bot (.zip)
            </h2>

            <p className="text-sm text-neutral-300 leading-relaxed">
              В архив включены все исходные файлы с устраненными уязвимостями (эскроу дуэлей, лимит отряда Глухаря, бонус Решалы, потокобезопасность транзакций и отклик 100% кнопок).
            </p>

            {/* Actions */}
            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <a
                href="/tarkov_mmo_bot_fixed.zip"
                download="tarkov_mmo_bot_fixed.zip"
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold text-sm transition-colors shadow-lg shadow-amber-500/20 active:scale-[0.98]"
              >
                <Download className="w-4 h-4 stroke-[2.5]" />
                Скачать архив (.ZIP, ~175 КБ)
              </a>

              <button
                onClick={copyUrl}
                className="inline-flex items-center justify-center gap-2 px-4 py-3.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 font-medium text-sm transition-colors"
              >
                {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                {copiedLink ? "Ссылка скопирована!" : "Скопировать прямую ссылку"}
              </button>
            </div>
          </div>
        </div>

        {/* Direct Link Box */}
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-lg p-4 space-y-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Прямой URL для загрузки (curl / wget / браузер):</span>
          </div>
          <div className="flex items-center gap-2 bg-neutral-950 border border-neutral-800 rounded px-3 py-2 font-mono text-xs text-amber-300 break-all">
            <span className="flex-1 select-all">{directDownloadUrl}</span>
            <button
              onClick={copyUrl}
              className="p-1 hover:text-white transition-colors"
              title="Скопировать ссылку"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* What was fixed */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-neutral-400 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Исправленные уязвимости и механики
          </h3>

          <div className="grid sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-neutral-900/40 border border-neutral-800/80 rounded-lg p-4 space-y-1">
              <div className="font-semibold text-neutral-200">1. Лимит отряда Глухаря (6 бойцов)</div>
              <p className="text-neutral-400">Динамический найм 6-го бойца при сборе комплекта реликвий Глухаря вместо жесткого лимита 5.</p>
            </div>

            <div className="bg-neutral-900/40 border border-neutral-800/80 rounded-lg p-4 space-y-1">
              <div className="font-semibold text-neutral-200">2. Доход теневых бизнесов (+50%)</div>
              <p className="text-neutral-400">Бонус сета Решалы теперь передает контекст игрока и корректно увеличивает пассивную прибыль.</p>
            </div>

            <div className="bg-neutral-900/40 border border-neutral-800/80 rounded-lg p-4 space-y-1">
              <div className="font-semibold text-neutral-200">3. Эскроу-пул и отмена дуэлей в PvP</div>
              <p className="text-neutral-400">Ставки блокируются в банке, добавлена кнопка возврата при отмене, исключена утечка рублей.</p>
            </div>

            <div className="bg-neutral-900/40 border border-neutral-800/80 rounded-lg p-4 space-y-1">
              <div className="font-semibold text-neutral-200">4. Отклик всех инлайн-кнопок (63/63)</div>
              <p className="text-neutral-400">Добавлены подтверждения `answer_callback_query` во все меню (кейсы, дуэли, склады, листинги).</p>
            </div>

            <div className="bg-neutral-900/40 border border-neutral-800/80 rounded-lg p-4 space-y-1">
              <div className="font-semibold text-neutral-200">5. Потокобезопасность базы (DB Lock)</div>
              <p className="text-neutral-400">Контекстный менеджер `db_transaction()` защищает от race condition при одновременных запросах.</p>
            </div>

            <div className="bg-neutral-900/40 border border-neutral-800/80 rounded-lg p-4 space-y-1">
              <div className="font-semibold text-neutral-200">6. Защита лобби от угона</div>
              <p className="text-neutral-400">Только лидер или администратор может отменить/начать рейд; авто-передача лидерства при выходе.</p>
            </div>
          </div>
        </div>

        {/* How to run instructions */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-neutral-200 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-amber-400" />
              Инструкция по запуску бота
            </h3>
            <button
              onClick={copyBash}
              className="text-xs text-neutral-400 hover:text-white flex items-center gap-1.5 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "Скопировано!" : "Скопировать команды"}
            </button>
          </div>

          <pre className="bg-neutral-950 border border-neutral-800 rounded-lg p-4 text-xs font-mono text-neutral-300 overflow-x-auto leading-relaxed">
{`# 1. Распакуйте архив и перейдите в папку backend:
cd backend

# 2. Создайте и активируйте виртуальное окружение:
python3 -m venv venv
source venv/bin/activate  # Для Windows: venv\\Scripts\\activate

# 3. Установите зависимости:
pip install -r requirements.txt

# 4. Задайте токен вашего бота Telegram:
export BOT_TOKEN="123456789:ABCdefGHIjklMNOpqrsTUVwxyz"

# 5. Запустите бота:
python3 bot.py`}
          </pre>
        </div>

        {/* Alternative native export */}
        <div className="border border-neutral-800 rounded-xl p-5 bg-neutral-900/40 flex items-start gap-3.5">
          <FileCode2 className="w-5 h-5 text-neutral-400 shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs text-neutral-400">
            <span className="font-semibold text-neutral-200">Альтернативный способ скачивания через Google AI Studio:</span>
            <p>
              Вы также можете в любой момент нажать на меню <b>Settings</b> в правом верхнем углу интерфейса AI Studio, выбрать <b>Export</b> и скачать проект в ZIP либо экспортировать напрямую в ваш GitHub-репозиторий.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-800/80 py-4 px-6 text-center text-xs text-neutral-400">
        Tarkov MMO Bot • Все системы и тесты работают штатно
      </footer>
    </div>
  );
}
