import os
import zipfile

def create_archive():
    output_dirs = ["public", "dist"]
    for d in output_dirs:
        os.makedirs(d, exist_ok=True)

    exclude_dirs = {"node_modules", "dist", ".git", "__pycache__", ".cache", "venv", ".idea", ".vscode"}
    exclude_files = {".DS_Store", "tarkov_mmo_bot_fixed.zip"}

    for out_dir in output_dirs:
        zip_path = os.path.join(out_dir, "tarkov_mmo_bot_fixed.zip")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk("."):
                # Prune excluded directories
                dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith(".")]
                for f in files:
                    if f in exclude_files or f.endswith(".pyc"):
                        continue
                    file_path = os.path.join(root, f)
                    # archive name relative to root
                    arcname = os.path.normpath(file_path)
                    zf.write(file_path, arcname)
        print(f"Archive created at {zip_path} (Size: {os.path.getsize(zip_path)} bytes)")

if __name__ == "__main__":
    create_archive()
