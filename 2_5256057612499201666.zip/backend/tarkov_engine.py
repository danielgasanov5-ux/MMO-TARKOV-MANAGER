# -*- coding: utf-8 -*-
"""
Escape from Tarkov MMO Economic Engine
Logic, balance formulas, PMC buffs, Hideout, Warehouses, Combat & Persistence.
Now extended with:
- 720 Items Catalog integration
- Dynamic Economic Crises (shifts of +/-30-50% per category daily)
- 4 Equipment Slots: Weapon, Body Armor, Helmet, Headsets
- Full Coop Raid Balance & Penalties
- Admin Rank and Overrides for @revenuts
"""

import json
import os
import time
import random
import math
import threading
import contextlib

DB_LOCK = threading.RLock()
DB_FILE = "database.json"

_CURR_DIR = os.path.dirname(os.path.abspath(__file__))
POSSIBLE_ITEM_FILES = [
    os.path.join(_CURR_DIR, "items_data.json"),
    "items_data.json",
    "backend/items_data.json",
    "/tmp/items_data.json",
    os.path.join(os.getcwd(), "items_data.json"),
    os.path.join(os.getcwd(), "backend", "items_data.json"),
]

ITEMS_LIST = []
for p in POSSIBLE_ITEM_FILES:
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
                if len(data) >= 700:
                    ITEMS_LIST = data
                    break
                elif len(data) > len(ITEMS_LIST):
                    ITEMS_LIST = data
        except Exception:
            pass

# Catalog of regular game items (must NOT contain Boss Relics)
ITEMS_BY_ID = {item["id"]: item for item in ITEMS_LIST}

# Register 30 Boss Relics ONLY in ITEMS_BY_ID for metadata lookup
# DO NOT append relics into ITEMS_LIST so they never pollute regular loot drops!
try:
    from relics_system import (
        ALL_30_RELICS, RELICS_BY_ID, BOSS_SETS,
        has_boss_set_bonus, get_player_boss_sets, get_player_relics, get_active_boss_bonuses_list
    )
    for _r in ALL_30_RELICS:
        ITEMS_BY_ID[_r["id"]] = _r
except ImportError:
    pass

# 10 Signature PMCs + 11th "Revenant"
PMC_DEFINITIONS = {
    "Viper": {
        "name": "Viper",
        "icon": "⚡",
        "desc": "Кулдаун после рейдов и кулдаун ЧВК снижен на 15%.",
        "buff": "cooldown_reduction",
        "val": 0.15
    },
    "Nomad": {
        "name": "Nomad",
        "icon": "🏹",
        "desc": "Стоимость отправки Диких в платные рейды снижена на 20%.",
        "buff": "scav_discount",
        "val": 0.20
    },
    "Ronin": {
        "name": "Ronin",
        "icon": "⚔️",
        "desc": "+15% к шансу победить в PvP-зоне 'Даркзон'.",
        "buff": "pvp_bonus",
        "val": 0.15
    },
    "Specter": {
        "name": "Specter",
        "icon": "👁️",
        "desc": "+10% к шансу найти предметы редкости Legendary и Epic в рейдах/поставках.",
        "buff": "loot_bonus",
        "val": 0.10
    },
    "Ares": {
        "name": "Ares",
        "icon": "🛡️",
        "desc": "Вместимость всех специализированных складов увеличена на 20%.",
        "buff": "warehouse_bonus",
        "val": 0.20
    },
    "Zenith": {
        "name": "Zenith",
        "icon": "⚡",
        "desc": "Пассивный майнинг Биткоинов ускорен на 15%.",
        "buff": "btc_bonus",
        "val": 0.15
    },
    "Fenrir": {
        "name": "Fenrir",
        "icon": "🐺",
        "desc": "При моментальной продаже вещей Прапору он платит 40% стоимости вместо 30%.",
        "buff": "prapor_bonus",
        "val": 0.40
    },
    "Stalker": {
        "name": "Stalker",
        "icon": "☢️",
        "desc": "Время ожидания Контрабандных Поставок снижено на 20%.",
        "buff": "supply_speed",
        "val": 0.20
    },
    "Siren": {
        "name": "Siren",
        "icon": "🧜",
        "desc": "Налог на P2P-барахолке снижен с 10% до 5%.",
        "buff": "market_tax",
        "val": 0.05
    },
    "Pharaoh": {
        "name": "Pharaoh",
        "icon": "👑",
        "desc": "Пассивный доход со всех 4 Теневых Бизнесов увеличен на 15%.",
        "buff": "business_income",
        "val": 0.15
    },
    "Revenant": {
        "name": "Revenant",
        "icon": "💀",
        "desc": "Эксклюзив @reventus: Все 10 баффов одновременно! Ранг: 💀 [ADMIN] 💰 REVENANT GD 💰 💀",
        "buff": "all",
        "val": 1.0
    }
}

# Hideout Upgrade Costs (1 -> 10)
HIDEOUT_UPGRADE_COSTS = {
    1: 75000,       # 1 -> 2
    2: 250000,      # 2 -> 3
    3: 750000,      # 3 -> 4
    4: 2000000,     # 4 -> 5
    5: 5500000,     # 5 -> 6
    6: 15000000,    # 6 -> 7
    7: 40000000,    # 7 -> 8
    8: 100000000,   # 8 -> 9
    9: 250000000    # 9 -> 10
}

# 10 Hideout Modules
MODULE_NAMES = {
    "generator": "Генератор",
    "ammo_bench": "Патронный станок",
    "mining_farm": "Майнинг-ферма (BTC)",
    "medblock": "Медблок",
    "workbench": "Верстак",
    "lavatory": "Санузел",
    "nutrition": "Пищеблок",
    "rest_space": "Зона отдыха",
    "water_collector": "Водосборник",
    "intel_center": "Разведцентр"
}

# 4 Shadow Businesses with balanced progression
BUSINESS_CONFIG = {
    "topography": {
        "name": "🖨️ Подпольная Топография",
        "tagline": "Печать карт выходов и поддельных пропусков Terragroup",
        "costs": [25000, 45000, 85000, 160000, 300000, 550000, 950000, 1650000, 2800000, 4800000],
        "income": [0, 3500, 6800, 12500, 22000, 37000, 60000, 95000, 145000, 215000, 310000]
    },
    "buyers_net": {
        "name": "🏪 Сеть Скупщиков",
        "tagline": "Агентура ломбардов и перепродажа редкого армейского хабара",
        "costs": [60000, 110000, 210000, 390000, 720000, 1300000, 2350000, 4200000, 7500000, 13000000],
        "income": [0, 6500, 12800, 23500, 41000, 68000, 110000, 175000, 270000, 405000, 600000]
    },
    "chem_lab": {
        "name": "🧪 Хим-Лаборатория",
        "tagline": "Синтез боевых стимуляторов SJ6, пропитала и спец-морфина",
        "costs": [150000, 290000, 550000, 1050000, 1950000, 3600000, 6600000, 12000000, 21500000, 38000000],
        "income": [0, 14000, 27500, 51000, 92000, 160000, 270000, 440000, 700000, 1080000, 1650000]
    },
    "smuggling": {
        "name": "🚚 Контрабандный Трафик",
        "tagline": "Трансграничный трафик тяжелого вооружения и военных контейнеров",
        "costs": [400000, 800000, 1600000, 3200000, 6400000, 12500000, 24000000, 45000000, 82000000, 150000000],
        "income": [0, 32000, 65000, 125000, 235000, 425000, 740000, 1250000, 2050000, 3300000, 5200000]
    }
}

BUSINESS_NAMES = {k: v["name"] for k, v in BUSINESS_CONFIG.items()}

# Base warehouse capacities (weapons, armor, gear, components)
BASE_WAREHOUSE_CAPS = {
    "weapons": (10, 5),      # base 10, +5 per level
    "armor": (10, 5),        # base 10, +5 per level
    "gear": (15, 5),         # base 15, +5 per level (headsets, meds)
    "components": (20, 10),  # base 20, +10 per level
    "valuables": (50, 25)    # base 50, +25 per level (keycards, documents, relics)
}

WAREHOUSE_NAMES = {
    "weapons": "Оружейный склад",
    "armor": "Броне-ангар",
    "gear": "Вещевой склад (Снаряжение & Наушники)",
    "components": "Склад компонентов",
    "valuables": "Сейф ценностей, документов и реликвий"
}

# 6 Flea Market & Crisis Categories
MARKET_CATEGORIES = [
    "Оружие",
    "Экипировка",
    "Наушники",
    "Медицина",
    "Драгоценности",
    "Компоненты"
]

# Warehouse upgrade cost formula: base 35k, +80% per level (up to 10 tiers)
def get_warehouse_upgrade_cost(current_lvl):
    if current_lvl >= 10:
        return None
    costs = [0, 35000, 80000, 180000, 400000, 900000, 2000000, 4500000, 10000000, 25000000]
    return costs[current_lvl] if current_lvl < len(costs) else 50000000

# Module upgrade cost: 50,000 base, +50% per level
def get_module_upgrade_cost(current_lvl):
    if current_lvl >= 10:
        return None
    cost = 50000 * ((1.5) ** current_lvl)
    return int(round(cost / 250.0) * 250)

# Supply Channel Upgrade costs (1 to 10)
SUPPLY_CHANNEL_COSTS = {
    1: 30000,
    2: 60000,
    3: 120000,
    4: 250000,
    5: 500000,
    6: 1000000,
    7: 2000000,
    8: 4000000,
    9: 8000000
}

# Bitcoin Dynamic Exchange Rate (~500,000 ₽)
def get_current_btc_rate():
    t = time.time()
    # Gentle wave between 470,000 and 535,000 rubles
    variation = math.sin(t / 1800.0) * 32000 + math.cos(t / 4200.0) * 15000
    return int(round((500000 + variation) / 100.0) * 100)

# Business Upgrade Cost by specific business tier (1 to 10)
def get_business_upgrade_cost(biz_key, current_lvl):
    if current_lvl >= 10:
        return None
    b_conf = BUSINESS_CONFIG.get(biz_key)
    if not b_conf:
        return None
    costs = b_conf["costs"]
    if current_lvl < len(costs):
        return costs[current_lvl]
    return None

# Hourly Rubles from Businesses
def get_business_hourly_income(biz_or_level, level=None, user=None):
    if level is None:
        lvl = biz_or_level
        table = [0, 4500, 9500, 18000, 32000, 55000, 90000, 145000, 225000, 340000, 500000]
        base_inc = table[min(lvl, 10)] if lvl > 0 else 0
    else:
        biz_key = biz_or_level
        if level <= 0:
            return 0
        b_conf = BUSINESS_CONFIG.get(biz_key)
        if not b_conf:
            table = [0, 4500, 9500, 18000, 32000, 55000, 90000, 145000, 225000, 340000, 500000]
            base_inc = table[min(level, 10)]
        else:
            base_inc = b_conf["income"][min(level, 10)]

    if user and has_boss_set_bonus(user, "reshala"):
        # Reshala Set (5/5): +50% business income
        base_inc = int(base_inc * 1.5)
    return base_inc

# Hourly BTC from Mining Farm (0.01 to 0.10 BTC/hour)
def get_mining_hourly_btc(level):
    if level <= 0:
        return 0.0
    return round(0.01 + (min(level, 10) - 1) * 0.01, 4)

# Buff check with failure penalty check and @revenuts master rank
def has_buff(user, buff_name):
    # If currently in coop raid failure penalty, signature buffs are lost for 2 hours
    # EXCEPT if player has Killa Set (5/5): class buffs don't turn off!
    if user.get("coop_cooldown_until", 0) > time.time():
        if not has_boss_set_bonus(user, "killa"):
            return False
    uname = (user.get("username") or "").lower().lstrip("@")
    if uname in ["reventus", "revenuts"] or user.get("pmc_signature") == "Revenant":
        return True
    defin = PMC_DEFINITIONS.get(user.get("pmc_signature"), {})
    return defin.get("buff") == buff_name

ADMIN_USER_IDS = {9999}
_env_admin = os.environ.get("ADMIN_USER_ID", "").strip()
if _env_admin.isdigit():
    ADMIN_USER_IDS.add(int(_env_admin))
_env_admins = os.environ.get("ADMIN_USER_IDS", "").strip()
if _env_admins:
    for _aid in _env_admins.split(","):
        if _aid.strip().isdigit():
            ADMIN_USER_IDS.add(int(_aid.strip()))

def is_admin(user_id, username=None):
    try:
        if user_id and int(user_id) in ADMIN_USER_IDS:
            return True
    except (ValueError, TypeError):
        pass
    if username:
        clean = str(username).lower().lstrip("@")
        if clean in ["reventus", "revenuts"]:
            return True
    return False

# Dynamic Economic Crises System
def check_and_update_economic_crisis(db):
    """
    Evaluates or advances the daily economic crisis (random daily category price shift +/-30-50%).
    Returns (is_new, crisis_dict)
    """
    now = int(time.time())
    crisis = db.get("economic_crisis", {})
    if not crisis or now >= crisis.get("expires_at", 0):
        cat = random.choice(MARKET_CATEGORIES)
        direction = random.choice(["surge", "crash"])
        shift_pct = random.randint(30, 50)
        if direction == "surge":
            mult = round(1.0 + shift_pct / 100.0, 2)
            headline = f"📈 ВОЕННЫЙ ДЕФИЦИТ: Всплеск спроса на «{cat}»! Цены взлетели на +{shift_pct}%!"
        else:
            mult = round(1.0 - shift_pct / 100.0, 2)
            headline = f"📉 ОБВАЛ РЫНКА: Перенасыщение складов категорией «{cat}»! Цены упали на -{shift_pct}%!"

        new_crisis = {
            "category": cat,
            "direction": direction,
            "shift_pct": shift_pct,
            "multiplier": mult,
            "started_at": now,
            "expires_at": now + 86400, # 24 hours
            "headline": headline
        }
        db["economic_crisis"] = new_crisis
        return True, new_crisis
    return False, crisis

def get_crisis_price(base_price, item_or_cat, db):
    """Calculates adjusted price based on active economic crisis."""
    if isinstance(item_or_cat, dict):
        cat = item_or_cat.get("market_cat")
    else:
        cat = item_or_cat
    crisis = db.get("economic_crisis")
    if not crisis or crisis.get("expires_at", 0) < time.time():
        return base_price
    if cat == crisis.get("category"):
        return max(500, int(base_price * crisis.get("multiplier", 1.0)))
    return base_price

def get_warehouse_capacity(user, category):
    base, per_lvl = BASE_WAREHOUSE_CAPS.get(category, (15, 5))
    lvl = user.get("warehouses", {}).get(category, 1)
    cap = base + (lvl - 1) * per_lvl
    if has_buff(user, "warehouse_bonus"):
        cap = int(math.ceil(cap * 1.20))
    # Tagilla Set (5/5): +50% warehouse capacity for all 4 warehouses
    if has_boss_set_bonus(user, "tagilla"):
        cap = int(math.ceil(cap * 1.50))
    # Glukhar Set (5/5): Arsenal and Armor hanger capacity x2
    if has_boss_set_bonus(user, "glukhar") and category in ["weapons", "armor"]:
        cap = cap * 2
    return cap

def is_item_valuable(info):
    cat = info.get("category", "")
    mcat = info.get("market_cat", "")
    name = info.get("name", "").lower()
    i_id = info.get("id", "").lower()
    return (
        cat in ["relic", "valuable", "valuables"] or
        mcat == "Драгоценности" or
        "keycard" in i_id or
        "ключ-карт" in name or
        "документ" in name or
        "флешк" in name or
        i_id.startswith("relic_")
    )

def get_warehouse_count(user, category):
    stash = user.get("stash", [])
    count = 0
    for itm in stash:
        info = ITEMS_BY_ID.get(itm.get("item_id"), {})
        if category == "valuables":
            if is_item_valuable(info):
                count += 1
        elif category == "gear":
            if info.get("category") == "gear" and not is_item_valuable(info):
                count += 1
        elif info.get("category") == category:
            count += 1
    return count

def can_store_item(user, item_id):
    info = ITEMS_BY_ID.get(item_id, {})
    if is_item_valuable(info):
        cat = "valuables"
    else:
        cat = info.get("category", "gear")
    cap = get_warehouse_capacity(user, cat)
    cnt = get_warehouse_count(user, cat)
    return cnt < cap

# Database management
def load_db():
    with DB_LOCK:
        if not os.path.exists(DB_FILE):
            init_db = {
                "users": {},
                "p2p_market": [],
                "active_duels": {},
                "coop_lobbies": {},
                "economic_crisis": {},
                "airdrop": {"active": False, "last_spawn": 0, "chat_id": None, "message_id": None}
            }
            save_db(init_db)
            return init_db
        try:
            with open(DB_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                data.setdefault("coop_lobbies", {})
                data.setdefault("economic_crisis", {})
                return data
        except Exception:
            return {"users": {}, "p2p_market": [], "active_duels": {}, "coop_lobbies": {}, "economic_crisis": {}, "airdrop": {}}

def save_db(data):
    with DB_LOCK:
        tmp = DB_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, DB_FILE)

@contextlib.contextmanager
def db_transaction():
    """Thread-safe context manager for atomic read-modify-write operations."""
    with DB_LOCK:
        db = load_db()
        yield db
        save_db(db)

def generate_scav_gear(fighter_id):
    """
    Selects starting 'bomzh-gear' strictly from the pool of Common (rarity == 'common') items.
    Each hired Scav gets their unique, fixed set of low-tier common equipment that cannot be detached.
    """
    now = int(time.time())
    common_weapons = [i for i in ITEMS_LIST if i.get("rarity") == "common" and i.get("category") == "weapons"]
    common_armors = [
        i for i in ITEMS_LIST
        if i.get("rarity") == "common" and (i.get("category") in ["armor", "gear"] or i.get("market_cat") == "Экипировка")
        and i.get("subcategory") != "helmet" and "шлем" not in i.get("name", "").lower() and "каска" not in i.get("name", "").lower()
    ]
    common_helmets = [
        i for i in ITEMS_LIST
        if i.get("rarity") == "common" and (
            i.get("subcategory") == "helmet" or
            any(w in i.get("name", "").lower() for w in ["шлем", "каска", "шапка", "ушанка", "кепка", "колпак"])
        )
    ]
    common_headsets = [
        i for i in ITEMS_LIST
        if i.get("rarity") == "common" and (i.get("subcategory") == "headset" or "наушники" in i.get("name", "").lower())
    ]

    items_to_add = []
    uids = {"weapon_uid": None, "armor_uid": None, "helmet_uid": None, "headset_uid": None}

    if common_weapons:
        w_item = random.choice(common_weapons)
        w_uid = f"scav_{fighter_id}_w_{now}_{random.randint(100,999)}"
        items_to_add.append({"uid": w_uid, "item_id": w_item["id"], "equipped_to": fighter_id, "is_scav_locked": True})
        uids["weapon_uid"] = w_uid

    if common_armors:
        a_item = random.choice(common_armors)
        a_uid = f"scav_{fighter_id}_a_{now}_{random.randint(100,999)}"
        items_to_add.append({"uid": a_uid, "item_id": a_item["id"], "equipped_to": fighter_id, "is_scav_locked": True})
        uids["armor_uid"] = a_uid

    if common_helmets:
        h_item = random.choice(common_helmets)
        h_uid = f"scav_{fighter_id}_h_{now}_{random.randint(100,999)}"
        items_to_add.append({"uid": h_uid, "item_id": h_item["id"], "equipped_to": fighter_id, "is_scav_locked": True})
        uids["helmet_uid"] = h_uid

    if common_headsets:
        hs_item = random.choice(common_headsets)
        hs_uid = f"scav_{fighter_id}_hs_{now}_{random.randint(100,999)}"
        items_to_add.append({"uid": hs_uid, "item_id": hs_item["id"], "equipped_to": fighter_id, "is_scav_locked": True})
        uids["headset_uid"] = hs_uid

    return items_to_add, uids

# Starter profile builder
def create_new_player(user_id, username, pmc_signature):
    now = int(time.time())
    is_rev = (username or "").lower().lstrip("@") in ["reventus", "revenuts"]
    if is_rev:
        pmc_signature = "Revenant"
    
    starter_scav_items, starter_scav_uids = generate_scav_gear(1)

    stash_items = [
        {"uid": f"{now}_1", "item_id": "toz_106_common", "equipped_to": None},
        {"uid": f"{now}_2", "item_id": "ak74m_common", "equipped_to": None},
        {"uid": f"{now}_3", "item_id": "ai2_medkit_common", "equipped_to": None},
        {"uid": f"{now}_4", "item_id": "ai2_medkit_common", "equipped_to": None},
        {"uid": f"{now}_5", "item_id": "bandage_common", "equipped_to": None},
        {"uid": f"{now}_6", "item_id": "splint_common", "equipped_to": None},
        {"uid": f"{now}_7", "item_id": "ammo_545_bt_rare", "equipped_to": None},
        {"uid": f"{now}_8", "item_id": "gssh_01_common", "equipped_to": None},
        {"uid": f"{now}_9", "item_id": "kolpak_common", "equipped_to": None}
    ]
    stash_items.extend(starter_scav_items)

    player = {
        "user_id": user_id,
        "username": username or f"PMC_{user_id}",
        "pmc_signature": pmc_signature,
        "registered_at": now,
        "money": 50000,
        "btc": 0.0,
        "hideout_lvl": 1,
        "supply_channel_lvl": 1,
        "modules": {k: (1 if k == "generator" else 0) for k in MODULE_NAMES},
        "businesses": {k: 0 for k in BUSINESS_NAMES},
        "warehouses": {k: 1 for k in BASE_WAREHOUSE_CAPS},
        "stash": stash_items,
        "squad": [
            {
                "id": 1,
                "type": "scav",
                "name": "Дикий #1",
                "weapon_uid": starter_scav_uids["weapon_uid"],
                "armor_uid": starter_scav_uids["armor_uid"],
                "helmet_uid": starter_scav_uids["helmet_uid"],
                "headset_uid": starter_scav_uids["headset_uid"]
            }
        ],
        "active_delivery": None,
        "last_income_claim": now,
        "last_raid_time": 0,
        "coop_cooldown_until": 0,
        "stats": {
            "raids_count": 0,
            "coop_raids_count": 0,
            "coop_wins": 0,
            "coop_losses": 0,
            "pvp_wins": 0,
            "pvp_losses": 0,
            "airdrop_looted": 0
        }
    }
    return player

# Squad power & armor calculation with all 4 slots (Weapon, Body Armor, Helmet, Headset)
def calculate_squad_power(user):
    squad = user.get("squad", [])
    stash = {itm["uid"]: itm for itm in user.get("stash", [])}
    total_power = 0
    total_armor = 0

    for fighter in squad:
        base_power = 10 if fighter.get("type") == "scav" else 25
        base_armor = 5

        # 1. Weapon
        w_uid = fighter.get("weapon_uid")
        if w_uid and w_uid in stash:
            item_id = stash[w_uid].get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            base_power += info.get("combat", 0)

        # 2. Body Armor
        a_uid = fighter.get("armor_uid")
        if a_uid and a_uid in stash:
            item_id = stash[a_uid].get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            base_armor += info.get("armor", 0)

        # 3. Helmet
        h_uid = fighter.get("helmet_uid")
        if h_uid and h_uid in stash:
            item_id = stash[h_uid].get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            base_armor += info.get("armor", 0)

        # 4. Active Headset (sound perception grants combat power & survival defense)
        hs_uid = fighter.get("headset_uid")
        if hs_uid and hs_uid in stash:
            item_id = stash[hs_uid].get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            base_power += info.get("combat", 0)
            base_armor += info.get("armor", 0)

        total_power += base_power
        total_armor += base_armor

    # Boss relics bonuses from stash
    for itm in user.get("stash", []):
        iid = itm.get("item_id")
        if iid == "tagilla_sledgehammer_legendary":
            total_power += 20
        elif iid == "killa_helmet_legendary":
            total_armor += 30
        elif iid == "glukhar_cap_legendary":
            total_power += 15
            total_armor += 25

    return total_power, total_armor
