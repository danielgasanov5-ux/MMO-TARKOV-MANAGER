# -*- coding: utf-8 -*-
"""
Dynamic 4-Phase Tactical Raid Engine for Escape from Tarkov MMO Telegram Bot.

Features:
- 4 Multi-stage tactical phases:
    Phase 1: Инфильтрация (Периметр)
    Phase 2: Разведка (Точки интереса / Схроны)
    Phase 3: Кульминация (Горячая точка / Босс / Патрули)
    Phase 4: Эвакуация (Выбор выхода / Экстракция)
- Power and Armor determinism:
    Every tactical choice evaluates total squad power and total squad armor.
    No arbitrary dice-roll win chances.
- Zero pure rubles rewards:
    Pure cash rewards removed. Survival rewards authentic item loot,
    weapons, armor, barter items, BTC, exp and BattlePass progress.
- Nutrition & Rest Space integration:
    Nutrition Unit (+5 max HP per level to squad HP pool).
    Rest Space (+5% PMC EXP per level and -2% initial raid noise).
- Signature PMC Specter nerf:
    Strictly doubles base legendary & epic drop rates.
- Extreme variety:
    Procedural environmental mutators, modular encounter templates,
    consequence propagation, and push-your-luck early extraction dilemma.
"""

import random
import time
import html
from typing import Dict, Any, List, Optional, Tuple

from tarkov_engine import (
    ITEMS_BY_ID,
    ITEMS_LIST,
    has_buff,
    add_player_exp,
    get_player_level,
    can_store_item,
    fmt_rub
)

try:
    from relics_system import has_boss_set_bonus
except ImportError:
    def has_boss_set_bonus(u, b): return False

try:
    from prestige import get_player_prestige
except ImportError:
    def get_player_prestige(u): return 0

try:
    from gd_military_system import has_gd_business, add_gd_bp_exp, roll_gd_raid_weapon
except ImportError:
    def has_gd_business(u): return False
    def add_gd_bp_exp(u, xp): return {"leveled_up": False, "new_level": 1, "new_rewards": []}
    def roll_gd_raid_weapon(u, loc): return None

from loot_generator import (
    RAID_LOCATIONS,
    roll_raid_loot,
    is_restricted_item,
    pick_item_by_rarity
)

# 8 Dynamic Weather & Environmental Mutators
WEATHER_MODIFIERS = [
    {
        "id": "clear",
        "name": "☀️ Ясный день",
        "desc": "Идеальная видимость. Дистанции боя стандартные.",
        "noise_mod": 1.0,
        "power_mod": 1.0,
        "armor_mod": 1.0,
        "loot_tier": "standard"
    },
    {
        "id": "rain",
        "name": "🌧️ Проливной дождь",
        "desc": "Шум ливня глушит звуки шагов (-25% шума).",
        "noise_mod": 0.75,
        "power_mod": 1.0,
        "armor_mod": 1.0,
        "loot_tier": "standard"
    },
    {
        "id": "fog",
        "name": "🌫️ Плотный туман",
        "desc": "Снижена дистанция обзора. Упор на контактный бой и броню.",
        "noise_mod": 0.9,
        "power_mod": 0.9,
        "armor_mod": 1.15,
        "loot_tier": "standard"
    },
    {
        "id": "night",
        "name": "🌙 Глубокая ночь",
        "desc": "Тьма скрывает маневры (+15% скрытности), но враги бьют внезапнее.",
        "noise_mod": 0.8,
        "power_mod": 1.1,
        "armor_mod": 1.1,
        "loot_tier": "valuable"
    },
    {
        "id": "storm",
        "name": "⚡ Грозовой шторм",
        "desc": "Раскаты грома полностью маскируют выстрелы (-40% шума).",
        "noise_mod": 0.6,
        "power_mod": 1.0,
        "armor_mod": 1.0,
        "loot_tier": "standard"
    },
    {
        "id": "pmc_hot",
        "name": "💀 Высокая активность ЧВК",
        "desc": "Локация наводнена опытными ЧВК (+25% сложности), но ценность хабара удвоена!",
        "noise_mod": 1.25,
        "power_mod": 1.2,
        "armor_mod": 1.2,
        "loot_tier": "elite"
    },
    {
        "id": "airdrop_zone",
        "name": "📦 Зона падения AirDrop",
        "desc": "В небе слышен гул самолета. В глубине локации сброшен военный контейнер!",
        "noise_mod": 1.1,
        "power_mod": 1.05,
        "armor_mod": 1.05,
        "loot_tier": "airdrop"
    },
    {
        "id": "gang_war",
        "name": "🔥 Война группировок",
        "desc": "Дикие и ЧВК ожесточенно делят территорию. Полно брошенного снаряжения.",
        "noise_mod": 1.15,
        "power_mod": 1.0,
        "armor_mod": 1.0,
        "loot_tier": "valuable"
    }
]

# Phase titles
PHASE_INFO = {
    1: {"name": "Инфильтрация", "icon": "📍", "desc": "Проникновение через внешний периметр"},
    2: {"name": "Разведка", "icon": "🔍", "desc": "Поиск ценных схронов и объектов"},
    3: {"name": "Кульминация", "icon": "🔥", "desc": "Эпицентр боевого контакта"},
    4: {"name": "Эвакуация", "icon": "🏁", "desc": "Выбор маршрута экстракции"}
}

# Rich procedural encounter pool for each location and phase
ENCOUNTERS_DB = {
    # ------------------ 1. FACTORY ------------------
    "factory": {
        1: [
            {
                "title": "Душевые цеха",
                "desc": "Отряд проникает через разбитые окна душевых. ComTac улавливает возню у шкафчиков: двое мародеров Диких перезаряжают дробовики.",
                "choices": [
                    {
                        "id": "assault_breach",
                        "title": "💥 Штурм на опережение",
                        "type": "power",
                        "power_factor": 0.85,
                        "noise_add": 20,
                        "loot_rolls": 1,
                        "success_msg": "Отряд мгновенно заливает помещение огнем. Дикие нейтрализованы без единого выстрела в ответ!"
                    },
                    {
                        "id": "armor_push",
                        "title": "🛡️ Прорыв со щитом брони",
                        "type": "armor",
                        "armor_factor": 0.8,
                        "absorb": 20,
                        "noise_add": 10,
                        "loot_rolls": 1,
                        "success_msg": "Боец в тяжелой броне принимает картечь в нагрудник. Дробь отскакивает без вреда телу!"
                    },
                    {
                        "id": "stealth_pipes",
                        "title": "👣 Обойти по трубам под потолком",
                        "type": "tactical",
                        "tactical_factor": 0.7,
                        "noise_add": -5,
                        "loot_rolls": 0,
                        "success_msg": "Отряд бесшумно проскальзывает над мародерами, сэкономив ресурсы и сохранив скрытность."
                    }
                ]
            },
            {
                "title": "Подземный тоннель",
                "desc": "Сырые бетонные коридоры под заводом. В темноте блестит проволока самодельной растяжки с гранатой Ф-1.",
                "choices": [
                    {
                        "id": "disarm_trap",
                        "title": "✂️ Обезвредить растяжку и снять гранату",
                        "type": "tactical",
                        "tactical_factor": 0.75,
                        "noise_add": 0,
                        "loot_rolls": 1,
                        "success_msg": "Проволока аккуратно перекушена. В арсенал отряда добавлена боевая граната!"
                    },
                    {
                        "id": "armor_detonate",
                        "title": "🛡️ Закрыть взрыв бронепластиной",
                        "type": "armor",
                        "armor_factor": 0.9,
                        "absorb": 35,
                        "noise_add": 25,
                        "loot_rolls": 0,
                        "success_msg": "Взрыв сотрясает туннель, но мощный бронежилет гасит все осколки!"
                    },
                    {
                        "id": "backtrack",
                        "title": "🏃‍♂️ Обойти через насосную станцию",
                        "type": "tactical",
                        "tactical_factor": 0.6,
                        "noise_add": 5,
                        "loot_rolls": 0,
                        "success_msg": "Отряд делает безопасный крюк, минуя опасный заминированный проход."
                    }
                ]
            }
        ],
        2: [
            {
                "title": "Запертая диспетчерская",
                "desc": "Кабинет мастера на втором этаже. Стальная бронедверь заперта на ригельный замок. Внутри виднеются приборные стойки и сейф.",
                "choices": [
                    {
                        "id": "kick_door",
                        "title": "💥 Выбить дверь штурмовым тараном",
                        "type": "power",
                        "power_factor": 1.0,
                        "noise_add": 30,
                        "loot_rolls": 2,
                        "success_msg": "Дверь с грохотом слетает с петель! Внутри найден закрытый контейнер с деталями и платами!"
                    },
                    {
                        "id": "loot_lockers",
                        "title": "🔍 Осмотреть только шкафчики в коридоре",
                        "type": "tactical",
                        "tactical_factor": 0.7,
                        "noise_add": 5,
                        "loot_rolls": 1,
                        "success_msg": "Без лишнего шума отряд обыскивает металлические шкафы и забирает ценные медикаменты."
                    }
                ]
            },
            {
                "title": "Погрузочная эстакада",
                "desc": "У грузового вагона отряд натыкается на схрон снабжения заводской охраны, но сектор простреливается с переходного мостика.",
                "choices": [
                    {
                        "id": "suppress_sniper",
                        "title": "💥 Подавить стрелка плотным огнем",
                        "type": "power",
                        "power_factor": 1.1,
                        "noise_add": 25,
                        "loot_rolls": 2,
                        "success_msg": "Плотный шквал огня сносит стрелка с мостика. Схрон полностью в распоряжении отряда!"
                    },
                    {
                        "id": "armor_crate_grab",
                        "title": "🛡️ Прорваться к ящику под градом пуль",
                        "type": "armor",
                        "armor_factor": 1.0,
                        "absorb": 30,
                        "noise_add": 15,
                        "loot_rolls": 2,
                        "success_msg": "Броня звенит под пулями, но выдерживает обстрел. Отряд вытягивает тяжелый ящик с патронами!"
                    }
                ]
            }
        ],
        3: [
            {
                "title": "Главный цех: Гнев Тагиллы",
                "desc": "В воздухе вспыхивает сигнальная ракета. Из-за контейнеров с тяжелым ревом вылетает Босс Тагилла с титановой кувалдой и автоматом!",
                "choices": [
                    {
                        "id": "boss_firefight",
                        "title": "💥 Сконцентрировать всю огневую мощь на боссе",
                        "type": "power",
                        "power_factor": 1.4,
                        "noise_add": 40,
                        "loot_rolls": 3,
                        "success_msg": "Отряд выпускает магазины бронебойных патронов прямо в босса! Тагилла повержен, его элитные трофеи ваши!"
                    },
                    {
                        "id": "boss_tank",
                        "title": "🛡️ Принять удар кувалды на титановую броню",
                        "type": "armor",
                        "armor_factor": 1.3,
                        "absorb": 55,
                        "noise_add": 25,
                        "loot_rolls": 2,
                        "success_msg": "Глухой сокрушительный удар сотрясает бронеплиты, но отряд выдерживает и контратакует в упор!"
                    },
                    {
                        "id": "tactical_extract_now",
                        "title": "🏃‍♂️ Бросить дым и запросить досрочный отход",
                        "type": "extract_early",
                        "noise_add": 10,
                        "loot_rolls": 0,
                        "success_msg": "Густая завеса ослепляет преследователей. Отряд организованно отходит к аварийному выходу!"
                    }
                ]
            },
            {
                "title": "Окружение в насосной",
                "desc": "Группа тяжелых наемников ЧВК блокирует выходы из цеха, забрасывая сектор светошумовыми гранатами.",
                "choices": [
                    {
                        "id": "counter_assault",
                        "title": "💥 Прорыв встречным штурмом через дым",
                        "type": "power",
                        "power_factor": 1.25,
                        "noise_add": 35,
                        "loot_rolls": 2,
                        "success_msg": "Отряд перехватывает инициативу и разносит заслон наемников в ближнем огневом контакте!"
                    },
                    {
                        "id": "turtle_defense",
                        "title": "🛡️ Круговая оборона за бетонным блоком",
                        "type": "armor",
                        "armor_factor": 1.15,
                        "absorb": 40,
                        "noise_add": 15,
                        "loot_rolls": 1,
                        "success_msg": "Броня и бетонные укрытия поглощают шрапнель. Наемники вынуждены отступить!"
                    }
                ]
            }
        ],
        4: [
            {
                "title": "Эвакуация с Завода",
                "desc": "Сирены затихают. Отряд подошел к финальной точке эвакуации. Пора решать, как покинуть зону.",
                "choices": [
                    {
                        "id": "gate_0",
                        "title": "🚪 Главные ворота №0 (Быстрый силовой прорыв)",
                        "type": "power",
                        "power_factor": 0.9,
                        "noise_add": 20,
                        "loot_rolls": 1,
                        "success_msg": "Шквальным огнем сбиты последние дозорные. Ворота открыты, выход свободен!"
                    },
                    {
                        "id": "cellar_exit",
                        "title": "🗝️ Гермодверь подвалов (Тихий контролируемый выход)",
                        "type": "tactical",
                        "tactical_factor": 0.8,
                        "noise_add": 0,
                        "loot_rolls": 0,
                        "success_msg": "Отряд бесшумно проворачивает вентиль гермолюка и выходит в безопасную зону."
                    },
                    {
                        "id": "armor_cross",
                        "title": "🛡️ Прикрыть эвакуацию замыкающим бойцом",
                        "type": "armor",
                        "armor_factor": 0.85,
                        "absorb": 15,
                        "noise_add": 10,
                        "loot_rolls": 1,
                        "success_msg": "Тяжелая броня замыкающего защищает всю группу от шальных очередей в спину."
                    }
                ]
            }
        ]
    },

    # ------------------ 2. CUSTOMS (ТАМОЖНЯ) ------------------
    "customs": {
        1: [
            {
                "title": "Железнодорожный мост",
                "desc": "Насыпь у железнодорожного моста. На вышке сидит снайпер Диких с винтовкой Мосина, простреливая единственный переход.",
                "choices": [
                    {
                        "id": "sniper_suppress",
                        "title": "💥 Залповый огонь по вышке на подавление",
                        "type": "power",
                        "power_factor": 0.95,
                        "noise_add": 25,
                        "loot_rolls": 1,
                        "success_msg": "Точный пулеметный залп срезает снайпера! Проход через пути свободен."
                    },
                    {
                        "id": "sprint_under_fire",
                        "title": "🛡️ Пробежать под огнем, прикрываясь броней",
                        "type": "armor",
                        "armor_factor": 0.9,
                        "absorb": 25,
                        "noise_add": 15,
                        "loot_rolls": 0,
                        "success_msg": "Пуля снайпера выбивает искры из бронеплиты, но отряд успешно пересекает насыпь!"
                    },
                    {
                        "id": "culvert_crawl",
                        "title": "👣 Проползти через дренажную трубу под мостом",
                        "type": "tactical",
                        "tactical_factor": 0.75,
                        "noise_add": -5,
                        "loot_rolls": 1,
                        "success_msg": "В дренажной трубе отряд не только избежал выстрелов, но и нашел брошенный вещмешок!"
                    }
                ]
            },
            {
                "title": "Развилка у КПП Таможни",
                "desc": "Посреди шоссе стоит брошенный военный броневик 'Тигр'. Внутри кабины мерцает армейская радиостанция.",
                "choices": [
                    {
                        "id": "search_armored_car",
                        "title": "🔍 Вскрыть люк броневика и забрать оборудование",
                        "type": "power",
                        "power_factor": 0.9,
                        "noise_add": 15,
                        "loot_rolls": 2,
                        "success_msg": "Люк сорван монтировкой! Внутри найден армейский прибор ночного видения и патроны."
                    },
                    {
                        "id": "bypas_highway",
                        "title": "👣 Обойти через лесополосу вдоль забора",
                        "type": "tactical",
                        "tactical_factor": 0.7,
                        "noise_add": 0,
                        "loot_rolls": 0,
                        "success_msg": "Отряд безопасно обходит открытый участок шоссе под прикрытием деревьев."
                    }
                ]
            }
        ],
        2: [
            {
                "title": "Трехэтажное общежитие",
                "desc": "Темные коридоры общаг. В комнате 214 приоткрыта дверь, внутри слышен шорох вскрываемого оружейного ящика.",
                "choices": [
                    {
                        "id": "breach_dorm_room",
                        "title": "💥 Выбить дверь с ноги и зачистить комнату",
                        "type": "power",
                        "power_factor": 1.1,
                        "noise_add": 30,
                        "loot_rolls": 2,
                        "success_msg": "Вражеский мародер ликвидирован в упор. Оружейный ящик переходит вашему отряду!"
                    },
                    {
                        "id": "armor_hallway_hold",
                        "title": "🛡️ Занять коридор щитом тяжелой брони",
                        "type": "armor",
                        "armor_factor": 1.05,
                        "absorb": 35,
                        "noise_add": 15,
                        "loot_rolls": 2,
                        "success_msg": "Отряд формирует непробиваемый рубеж в коридоре, методично зачищая сектор."
                    },
                    {
                        "id": "rooftop_flank",
                        "title": "🧗 Обойти через пожарную лестницу на крышу",
                        "type": "tactical",
                        "tactical_factor": 0.85,
                        "noise_add": 5,
                        "loot_rolls": 1,
                        "success_msg": "С крыши отряд находит безопасный спуск и забирает ценные компоненты из тайника вентиляции."
                    }
                ]
            },
            {
                "title": "Новая стройка",
                "desc": "Скелет недостроенного здания. На третьем ярусе засела двойка ЧВК USEC с автоматическими винтовками M4A1.",
                "choices": [
                    {
                        "id": "storm_construction",
                        "title": "💥 Синхронный штурм лестничного пролета",
                        "type": "power",
                        "power_factor": 1.2,
                        "noise_add": 35,
                        "loot_rolls": 2,
                        "success_msg": "Мощный напор отряда сметает наемников USEC! С их тел сняты натовские модификации оружия."
                    },
                    {
                        "id": "hold_ground_floor",
                        "title": "🛡️ Принять гранаты на бронежилеты за бетонными плитами",
                        "type": "armor",
                        "armor_factor": 1.1,
                        "absorb": 30,
                        "noise_add": 20,
                        "loot_rolls": 1,
                        "success_msg": "Осколки гранат секут бетон и броню, но не причиняют вреда бойцам."
                    }
                ]
            }
        ],
        3: [
            {
                "title": "Заправка: Свита Решалы",
                "desc": "У бензоколонки горит костер. Четверо тяжело бронированных телохранителей Босса Решалы блокируют дорогу!",
                "choices": [
                    {
                        "id": "crush_reshala_guards",
                        "title": "💥 Разнести охрану концентрированным огнем всего отряда",
                        "type": "power",
                        "power_factor": 1.45,
                        "noise_add": 45,
                        "loot_rolls": 3,
                        "success_msg": "Охрана Решалы разбита наголову! Найден легендарный золотой ТТ и пачки редких патронов!"
                    },
                    {
                        "id": "heavy_armor_duel",
                        "title": "🛡️ Продавить позиции в лобовом танковом контакте",
                        "type": "armor",
                        "armor_factor": 1.35,
                        "absorb": 50,
                        "noise_add": 30,
                        "loot_rolls": 2,
                        "success_msg": "Броня отряда принимает град очередей, позволяя в упор расстрелять боевиков!"
                    },
                    {
                        "id": "extract_through_forest",
                        "title": "🏃‍♂️ Уйти через овраг к досрочной эвакуации",
                        "type": "extract_early",
                        "noise_add": 10,
                        "loot_rolls": 0,
                        "success_msg": "Отряд благоразумно уходит в лесную низину, сохраняя весь уже найденный хабар!"
                    }
                ]
            }
        ],
        4: [
            {
                "title": "Выход с Таможни",
                "desc": "Отряд добрался до периметра эвакуации. На горизонте видны развилки блокпостов.",
                "choices": [
                    {
                        "id": "crossroads_assault",
                        "title": "🚪 Перекресток (Прямой силовой прорыв сквозь заслон)",
                        "type": "power",
                        "power_factor": 1.0,
                        "noise_add": 25,
                        "loot_rolls": 1,
                        "success_msg": "Огневая мощь отряда сокрушает заслон на перекрестке. Путь чист!"
                    },
                    {
                        "id": "smuggler_boat",
                        "title": "🚣 Лодка контрабандиста у костра (Скрытный отход)",
                        "type": "tactical",
                        "tactical_factor": 0.85,
                        "noise_add": 0,
                        "loot_rolls": 0,
                        "success_msg": "Костер горит, мотор заведен. Контрабандист без лишних слов переправляет отряд через реку."
                    },
                    {
                        "id": "zb_bunker",
                        "title": "🛡️ Бункер ЗБ-1011 (Прорыв через укрепленную гермодверь)",
                        "type": "armor",
                        "armor_factor": 0.95,
                        "absorb": 20,
                        "noise_add": 10,
                        "loot_rolls": 1,
                        "success_msg": "Броня защитила отряд на лестнице в бункер. Гермозатвор запечатан изнутри!"
                    }
                ]
            }
        ]
    },

    # ------------------ 3. WOODS (ЛЕС) ------------------
    "woods": {
        1: [
            {
                "title": "Снайперская засада на опушке",
                "desc": "Сосновый бор Приозерного заказника. С высоты Снайперской скалы бьет меткий стрелок с тепловизором.",
                "choices": [
                    {
                        "id": "counter_snipe",
                        "title": "💥 Подавить позицию снайпера ураганным огнем",
                        "type": "power",
                        "power_factor": 1.05,
                        "noise_add": 25,
                        "loot_rolls": 1,
                        "success_msg": "Массированный огонь по скале заставляет снайпера замолчать навсегда!"
                    },
                    {
                        "id": "armor_tree_hop",
                        "title": "🛡️ Перебежки от дерева к дереву под броней",
                        "type": "armor",
                        "armor_factor": 1.0,
                        "absorb": 30,
                        "noise_add": 10,
                        "loot_rolls": 0,
                        "success_msg": "Бронепластины отражают рикошеты от древесных стволов. Отряд выходит из сектора обстрела!"
                    },
                    {
                        "id": "ravine_flank",
                        "title": "👣 Спуститься в глубокий лесной овраг",
                        "type": "tactical",
                        "tactical_factor": 0.8,
                        "noise_add": -5,
                        "loot_rolls": 1,
                        "success_msg": "В овраге отряд скрывается от оптики и находит замаскированный армейский схрон!"
                    }
                ]
            }
        ],
        2: [
            {
                "title": "Лагерь МЧС / Временная база",
                "desc": "Брошенные медицинские палатки. В центральном контейнере виднеются нетронутые хирургические наборы и кейсы Meds.",
                "choices": [
                    {
                        "id": "loot_med_tents",
                        "title": "💉 Вскрыть полевые аптечки и контейнеры МЧС",
                        "type": "tactical",
                        "tactical_factor": 0.85,
                        "noise_add": 5,
                        "loot_rolls": 2,
                        "success_msg": "Получены первоклассные армейские аптечки, инъекторы и стимуляторы!"
                    },
                    {
                        "id": "ambush_scav_patrol",
                        "title": "💥 Устроить засаду на приближающийся патруль",
                        "type": "power",
                        "power_factor": 1.15,
                        "noise_add": 30,
                        "loot_rolls": 2,
                        "success_msg": "Патруль лесных мародеров уничтожен в первые секунды огневого контакта!"
                    }
                ]
            }
        ],
        3: [
            {
                "title": "Лесопилка: Снайпер Штурман",
                "desc": "В центре лесопилки эхо разносит сухие выстрелы СВД. Босс Штурман и двое его свирепых охранников держат сектор на прицеле!",
                "choices": [
                    {
                        "id": "storm_shturman",
                        "title": "💥 Сокрушить логово Штурмана мощной штурмовой атакой",
                        "type": "power",
                        "power_factor": 1.5,
                        "noise_add": 45,
                        "loot_rolls": 3,
                        "success_msg": "Штурман и его свита ликвидированы! Отряду достался легендарный схрон Штурмана и элитная снайперская винтовка!"
                    },
                    {
                        "id": "armor_wood_huts",
                        "title": "🛡️ Прорыв сквозь деревянные бараки под броней",
                        "type": "armor",
                        "armor_factor": 1.4,
                        "absorb": 55,
                        "noise_add": 25,
                        "loot_rolls": 2,
                        "success_msg": "Тяжелая броня держит бронебойные пули 7.62x54R. Охрана босса повержена в ближнем бою!"
                    },
                    {
                        "id": "woods_extract_early",
                        "title": "🏃‍♂️ Отступить в чащу и запросить досрочный выход",
                        "type": "extract_early",
                        "noise_add": 10,
                        "loot_rolls": 0,
                        "success_msg": "Отряд растворяется в лесной глуши, успешно унося все собранные трофеи!"
                    }
                ]
            }
        ],
        4: [
            {
                "title": "Эвакуация из Леса",
                "desc": "Сумерки сгущаются над чащей. Впереди — финальные точки эвакуации.",
                "choices": [
                    {
                        "id": "outskirts_gate",
                        "title": "🚪 Окраины (Выход через шлагбаум с боем)",
                        "type": "power",
                        "power_factor": 1.05,
                        "noise_add": 20,
                        "loot_rolls": 1,
                        "success_msg": "Отряд сметает заслон на окраине и выходит к точке эвакуации!"
                    },
                    {
                        "id": "zb_014_exit",
                        "title": "🗝️ Бункер ЗБ-014 (Укрепленный подземный выход)",
                        "type": "armor",
                        "armor_factor": 1.0,
                        "absorb": 20,
                        "noise_add": 10,
                        "loot_rolls": 1,
                        "success_msg": "Броня защищает бойцов на спуске в бункер. Выход успешно завершен!"
                    },
                    {
                        "id": "northern_un_checkpoint",
                        "title": "🇺🇳 Северный блокпост ООН (Дипломатический/скрытный проход)",
                        "type": "tactical",
                        "tactical_factor": 0.9,
                        "noise_add": 0,
                        "loot_rolls": 0,
                        "success_msg": "Отряд незаметно преодолевает контрольную полосу блокпоста."
                    }
                ]
            }
        ]
    },

    # ------------------ 4. RESERVE (РЕЗЕРВ) ------------------
    "reserve": {
        1: [
            {
                "title": "Гермозатвор бункера Резерва",
                "desc": "Массивные стальные двери у железнодорожной рампы. Воет сирена аварийной тревоги, на рампу выбегает тяжелый патруль военных рейдеров.",
                "choices": [
                    {
                        "id": "assault_raiders",
                        "title": "💥 Атаковать рейдеров шквалом тяжелого калибра",
                        "type": "power",
                        "power_factor": 1.25,
                        "noise_add": 35,
                        "loot_rolls": 2,
                        "success_msg": "Рейдеры сметены концентрированным огнем! В их разгрузках найдены редкие магазины и гранаты."
                    },
                    {
                        "id": "armor_wall_push",
                        "title": "🛡️ Выставить бронированный клин против очередей",
                        "type": "armor",
                        "armor_factor": 1.2,
                        "absorb": 40,
                        "noise_add": 20,
                        "loot_rolls": 1,
                        "success_msg": "Броня 5-6 класса держит очереди M855A1. Рейдеры рассеяны!"
                    }
                ]
            }
        ],
        2: [
            {
                "title": "Командный штаб и казармы",
                "desc": "Разграбленные офисы штаба гарнизона. За взломанной решеткой обнаружен опечатанный армейский сейф генералов.",
                "choices": [
                    {
                        "id": "blow_safe",
                        "title": "💥 Подорвать замок сейфа кумулятивным зарядом",
                        "type": "power",
                        "power_factor": 1.3,
                        "noise_add": 40,
                        "loot_rolls": 2,
                        "success_msg": "Дверца сейфа выбита взрывом! Извлечены секретные военные схемы и высокотехнологичные платы!"
                    },
                    {
                        "id": "loot_barracks",
                        "title": "🔍 Обыскать оружейные комнаты казарм без лишнего шума",
                        "type": "tactical",
                        "tactical_factor": 1.0,
                        "noise_add": 10,
                        "loot_rolls": 2,
                        "success_msg": "В оружейных пирамидах обнаружены отличные стволы и ящики с бронебойными патронами!"
                    }
                ]
            }
        ],
        3: [
            {
                "title": "Вокзал: Свита Глухаря и Бронепоезд",
                "desc": "К перрону подходит гудящий Бронепоезд. Из депо выходит Босс Глухарь с пулеметом и шестью бронированными штурмовиками в Алтынах!",
                "choices": [
                    {
                        "id": "defeat_glukhar",
                        "title": "💥 Дать генеральное сражение свите Глухаря",
                        "type": "power",
                        "power_factor": 1.65,
                        "noise_add": 50,
                        "loot_rolls": 3,
                        "success_msg": "Невероятный триумф! Свита Глухаря повержена, захвачен тяжелый пулемет и армейские кейсы!"
                    },
                    {
                        "id": "armor_train_breach",
                        "title": "🛡️ Пробить брешь к броневагону под градом свинца",
                        "type": "armor",
                        "armor_factor": 1.55,
                        "absorb": 65,
                        "noise_add": 35,
                        "loot_rolls": 2,
                        "success_msg": "Сверхпрочная броня спасает от верной гибели. Отряд зачищает вагон и занимает круговую оборону!"
                    },
                    {
                        "id": "reserve_early_out",
                        "title": "🏃‍♂️ Отступить в подземный коллектор (Досрочный отход)",
                        "type": "extract_early",
                        "noise_add": 15,
                        "loot_rolls": 0,
                        "success_msg": "Отряд ныряет в шахту кабельного коллектора, спасая уже добытые военные трофеи!"
                    }
                ]
            }
        ],
        4: [
            {
                "title": "Эвакуация с Резерва",
                "desc": "Финальный рубеж военной базы. Доступны различные протоколы экстракции.",
                "choices": [
                    {
                        "id": "d2_bunker_exit",
                        "title": "🚪 Бункер Д-2 (Спуск через темные коридоры под броню)",
                        "type": "armor",
                        "armor_factor": 1.15,
                        "absorb": 25,
                        "noise_add": 15,
                        "loot_rolls": 1,
                        "success_msg": "Гермодверь Д-2 захлопывается за спиной. Эвакуация успешна!"
                    },
                    {
                        "id": "cliff_descent",
                        "title": "🧗 Спуск со скалы у РЛС (Тактический контролируемый выход)",
                        "type": "tactical",
                        "tactical_factor": 1.05,
                        "noise_add": 0,
                        "loot_rolls": 0,
                        "success_msg": "По альпинистским тросам отряд бесшумно спускается к подножию скалы."
                    },
                    {
                        "id": "armored_train_ride",
                        "title": "🚂 Отбыть на бронепоезде (Штурмовое прикрытие)",
                        "type": "power",
                        "power_factor": 1.25,
                        "noise_add": 30,
                        "loot_rolls": 1,
                        "success_msg": "Пулеметы бронепоезда сметают преследователей. Отряд победоносно покидает базу!"
                    }
                ]
            }
        ]
    },

    # ------------------ 5. LABS (ЛАБОРАТОРИЯ TERRAGROUP) ------------------
    "labs": {
        1: [
            {
                "title": "Гермошлюз Лаборатории",
                "desc": "Стерильные белые коридоры TerraGroup Labs. Впереди автоматическая турель и элитный патруль наемников Black Division.",
                "choices": [
                    {
                        "id": "emp_breach",
                        "title": "💥 Снести охранный рубеж залпом бронебойных патронов",
                        "type": "power",
                        "power_factor": 1.45,
                        "noise_add": 40,
                        "loot_rolls": 2,
                        "success_msg": "Наемники Black Division уничтожены молниеносным скоординированным ударом!"
                    },
                    {
                        "id": "titanium_shield",
                        "title": "🛡️ Проломить рубеж под прикрытием монолитной брони",
                        "type": "armor",
                        "armor_factor": 1.4,
                        "absorb": 45,
                        "noise_add": 25,
                        "loot_rolls": 2,
                        "success_msg": "Элитная броня выдерживает бронебойные пули. Сектор лаборатории разблокирован!"
                    }
                ]
            }
        ],
        2: [
            {
                "title": "Медицинский блок G22 и Серверная",
                "desc": "За герметичным стеклом видны стеллажи с прототипами инъекторов, чипами TerraGroup и контейнерами LEDX.",
                "choices": [
                    {
                        "id": "hack_secure_lab",
                        "title": "💻 Взломать электронный терминал и выгрузить базы данных",
                        "type": "tactical",
                        "tactical_factor": 1.2,
                        "noise_add": 15,
                        "loot_rolls": 3,
                        "success_msg": "Терминал взломан! Извлечены засекреченные прототипы и ценнейшие электронные компоненты!"
                    },
                    {
                        "id": "blast_door",
                        "title": "💥 Вскрыть титановый сейф мощным направленным зарядом",
                        "type": "power",
                        "power_factor": 1.5,
                        "noise_add": 45,
                        "loot_rolls": 3,
                        "success_msg": "Взрыв разносит сейф! Добыты прототипы медоборудования высочайшей стоимости!"
                    }
                ]
            }
        ],
        3: [
            {
                "title": "Атриум: Ударная группа Рейдеров",
                "desc": "В главном зале звучит сирена биологической тревоги. Со всех сторон выдвигаются тяжело экипированные Рейдеры в броне 6 класса!",
                "choices": [
                    {
                        "id": "apex_labs_clash",
                        "title": "💥 Генеральное сражение: полное огневое превосходство",
                        "type": "power",
                        "power_factor": 1.8,
                        "noise_add": 55,
                        "loot_rolls": 4,
                        "success_msg": "Легендарная победа в сердце Лаборатории! Все рейдеры ликвидированы, их топовый хабар ваш!"
                    },
                    {
                        "id": "turtle_quarantine",
                        "title": "🛡️ Забаррикадироваться в карантинном шлюзе на броне",
                        "type": "armor",
                        "armor_factor": 1.7,
                        "absorb": 70,
                        "noise_add": 30,
                        "loot_rolls": 3,
                        "success_msg": "Штурм рейдеров разбит о несокрушимую защиту отряда! Выжившие рейдеры отступают!"
                    },
                    {
                        "id": "labs_early_elevator",
                        "title": "🏃‍♂️ Пробиться к грузовому лифту и уйти досрочно",
                        "type": "extract_early",
                        "noise_add": 20,
                        "loot_rolls": 0,
                        "success_msg": "Грузовой лифт захлопывается перед носом врага. Все сокровища Лаборатории спасены!"
                    }
                ]
            }
        ],
        4: [
            {
                "title": "Финальная экстракция из Лаборатории",
                "desc": "Осталось активировать эвакуационный шлюз и покинуть подземный комплекс.",
                "choices": [
                    {
                        "id": "hangar_gate",
                        "title": "🚪 Ангарные ворота (Огневой заслон на эвакуации)",
                        "type": "power",
                        "power_factor": 1.35,
                        "noise_add": 35,
                        "loot_rolls": 1,
                        "success_msg": "Отряд отбивает последнюю волну охраны и успешно уходит через грузовые ворота!"
                    },
                    {
                        "id": "sewage_canal",
                        "title": "🌊 Канализационный коллектор (Скрытный контролируемый отход)",
                        "type": "tactical",
                        "tactical_factor": 1.15,
                        "noise_add": 0,
                        "loot_rolls": 0,
                        "success_msg": "Вода скрывает следы отряда. Безупречный и чистый выход из лаборатории!"
                    },
                    {
                        "id": "medical_elevator",
                        "title": "🛡️ Медицинский лифт (Прикрыть кнопку вызова броней)",
                        "type": "armor",
                        "armor_factor": 1.25,
                        "absorb": 25,
                        "noise_add": 15,
                        "loot_rolls": 1,
                        "success_msg": "Двери лифта закрываются под градом пуль. Выход успешен!"
                    }
                ]
            }
        ]
    }
}


def init_dynamic_raid(player: Dict[str, Any], location_key: str) -> Dict[str, Any]:
    """
    Initializes a new 4-stage dynamic raid session for the player.
    Takes into account Nutrition module (HP pool) and Rest Space (noise reduction & exp).
    """
    loc = RAID_LOCATIONS.get(location_key, RAID_LOCATIONS["factory"])
    now = int(time.time())

    from tarkov_engine import calculate_squad_power
    pow_val, arm_val = calculate_squad_power(player)

    # Reworked Nutrition Module: +5 max HP to squad pool per level (100 -> up to 150 HP)
    nutr_lvl = player.get("modules", {}).get("nutrition", 0)
    squad_max_hp = 100 + (nutr_lvl * 5)

    # Reworked Rest Space Module: reduces initial raid noise by 2% per level (down to 0%)
    rest_lvl = player.get("modules", {}).get("rest_space", 0)
    init_noise = max(0, 10 - (rest_lvl * 2))

    weather = random.choice(WEATHER_MODIFIERS)

    # Pick initial Phase 1 encounter
    enc_list = ENCOUNTERS_DB.get(location_key, ENCOUNTERS_DB["factory"]).get(1, [])
    curr_enc = random.choice(enc_list) if enc_list else ENCOUNTERS_DB["factory"][1][0]

    raid_session = {
        "location_key": location_key,
        "location_name": loc["name"],
        "difficulty": loc["difficulty"],
        "stage": 1,
        "max_stages": 4,
        "squad_hp": squad_max_hp,
        "squad_max_hp": squad_max_hp,
        "squad_armor": arm_val,
        "squad_max_armor": max(1, arm_val),
        "squad_power": pow_val,
        "noise_level": init_noise,
        "weather": weather,
        "backpack": [],
        "earned_exp": 0,
        "history": [f"🚀 Высадка в секторе {loc['name']}. Погода: {weather['name']}."],
        "current_encounter": curr_enc,
        "started_at": now
    }

    player["active_dynamic_raid"] = raid_session
    return raid_session


def resolve_raid_action(player: Dict[str, Any], choice_id: str) -> Dict[str, Any]:
    """
    Resolves the player's tactical choice in the current phase.
    Purely evaluates squad power and armor against the encounter requirements.
    Zero pure rubles rewards.
    """
    raid = player.get("active_dynamic_raid")
    if not raid:
        return {"error": "Нет активного рейда!"}

    loc_key = raid["location_key"]
    loc = RAID_LOCATIONS.get(loc_key, RAID_LOCATIONS["factory"])
    diff = loc["difficulty"]
    weather = raid.get("weather", WEATHER_MODIFIERS[0])

    curr_enc = raid.get("current_encounter", {})
    choices = curr_enc.get("choices", [])
    chosen_opt = next((c for c in choices if c.get("id") == choice_id), None)
    if not chosen_opt and choices:
        chosen_opt = choices[0]

    action_type = chosen_opt.get("type", "tactical")
    res_text = ""
    hp_loss = 0
    armor_loss = 0
    noise_change = chosen_opt.get("noise_add", 10)

    # Handle Early Extraction choice (Push-your-luck dilemma)
    if action_type == "extract_early" or choice_id == "extract_early":
        raid["stage"] = 4 # jump to extraction completion
        succ_text = chosen_opt.get("success_msg", "Отряд совершил досрочный тактический отход с хабаром.") if chosen_opt else "Отряд совершил досрочный тактический отход с хабаром."
        raid["history"].append("🏃‍♂️ " + succ_text)
        return finish_dynamic_raid(player, success=True, early_extract=True)

    # Deterministic power & armor checks based on map difficulty and weather
    diff_power_baseline = int(diff * weather.get("power_mod", 1.0))
    diff_armor_baseline = int(diff * weather.get("armor_mod", 1.0))

    if action_type == "power":
        req_power = int(diff_power_baseline * chosen_opt.get("power_factor", 1.0))
        cur_power = raid["squad_power"]

        if cur_power >= req_power:
            res_text = f"⚔️ <b>Огневое превосходство!</b> {chosen_opt.get('success_msg', '')}"
            # Clean success, no HP loss
        else:
            deficit = req_power - cur_power
            # Damage from retaliation proportional to deficit
            armor_dmg = min(raid["squad_armor"], int(deficit * 0.5))
            raw_hp_dmg = max(10, int(deficit * 0.4) - (raid["squad_armor"] // 8))
            armor_loss = armor_dmg
            hp_loss = max(5, raw_hp_dmg)
            res_text = (
                f"⚠️ <b>Тяжелый огневой контакт!</b> Требовалось {req_power} Мощи (у отряда: {cur_power}).\n"
                f"Враг оказал яростное сопротивление: Броня: -{armor_loss} | Здоровье: -{hp_loss} HP."
            )

    elif action_type == "armor":
        req_armor = int(diff_armor_baseline * chosen_opt.get("armor_factor", 1.0))
        cur_armor = raid["squad_armor"]
        base_absorb = chosen_opt.get("absorb", 25)

        if cur_armor >= req_armor:
            armor_loss = min(raid["squad_armor"], base_absorb)
            res_text = f"🛡️ <b>Броня спасает жизни!</b> {chosen_opt.get('success_msg', '')} (Прочность брони: -{armor_loss})"
        else:
            # Armor broke, remaining impact damages health
            armor_loss = raid["squad_armor"]
            hp_loss = max(15, base_absorb - (cur_armor // 2))
            res_text = (
                f"💥 <b>Броня пробита!</b> Требовалось {req_armor} Брони (у отряда: {cur_armor}).\n"
                f"Бронежилеты разбиты в щепки (-{armor_loss}), осколки ранили бойцов (-{hp_loss} HP)!"
            )

    else:  # tactical / balance
        req_tactical = int((diff_power_baseline + diff_armor_baseline) * 0.5 * chosen_opt.get("tactical_factor", 0.8))
        cur_tactical = int(raid["squad_power"] * 0.6 + raid["squad_armor"] * 0.4)

        if cur_tactical >= req_tactical:
            res_text = f"🎯 <b>Тактический маневр успешен!</b> {chosen_opt.get('success_msg', '')}"
        else:
            armor_loss = min(raid["squad_armor"], 15)
            hp_loss = 15
            res_text = f"⚠️ <b>Маневр сорвался!</b> Отряд попал под перекрестный огонь: Броня: -{armor_loss} | HP: -{hp_loss}."

    # Apply damage
    raid["squad_armor"] = max(0, raid["squad_armor"] - armor_loss)
    raid["squad_hp"] = max(0, raid["squad_hp"] - hp_loss)
    raid["noise_level"] = max(0, min(100, raid["noise_level"] + int(noise_change * weather.get("noise_mod", 1.0))))

    # Roll authentic item loot (ZERO clean rubles!)
    loot_rolls = chosen_opt.get("loot_rolls", 0)
    found_items = []
    for _ in range(loot_rolls):
        itm = roll_raid_loot(loc_key, player)
        if itm:
            found_items.append(itm)
            raid["backpack"].append(itm)

    # GD BattlePass weapon drop chance on stage 2 or 3
    if has_gd_business(player) and raid["stage"] in [2, 3] and random.random() < 0.12:
        gdw = roll_gd_raid_weapon(player, loc_key)
        if gdw:
            raid["backpack"].append(gdw)
            found_items.append(gdw)

    # Add to history
    raid["history"].append(res_text)

    # Check for squad wipeout
    if raid["squad_hp"] <= 0:
        return finish_dynamic_raid(player, success=False, death_reason=res_text)

    # Advance stage
    curr_stage = raid["stage"]
    if curr_stage >= 4:
        # Completed all 4 phases!
        return finish_dynamic_raid(player, success=True, early_extract=False)

    # Move to next phase
    next_stage = curr_stage + 1
    raid["stage"] = next_stage

    enc_list = ENCOUNTERS_DB.get(loc_key, ENCOUNTERS_DB["factory"]).get(next_stage, [])
    if enc_list:
        raid["current_encounter"] = random.choice(enc_list)
    else:
        raid["current_encounter"] = ENCOUNTERS_DB["factory"][next_stage][0]

    return {
        "status": "in_progress",
        "stage": next_stage,
        "res_text": res_text,
        "found_items": found_items,
        "raid": raid
    }


def finish_dynamic_raid(player: Dict[str, Any], success: bool, early_extract: bool = False, death_reason: str = "") -> Dict[str, Any]:
    """
    Finalizes the raid session.
    Awards backpack loot, exp, BP XP.
    Pure rubles = 0!
    """
    raid = player.pop("active_dynamic_raid", None)
    if not raid:
        return {"error": "Нет активного рейда!"}

    now = int(time.time())
    player["last_raid_time"] = now
    player.setdefault("stats", {})["raids_count"] = player.get("stats", {}).get("raids_count", 0) + 1

    squad = player.get("squad", [])
    backpack = raid.get("backpack", [])

    # Reworked Rest Space bonus: +5% PMC EXP per level
    rest_lvl = player.get("modules", {}).get("rest_space", 0)
    exp_mult = 1.0 + (rest_lvl * 0.05)

    result = {
        "success": success,
        "early_extract": early_extract,
        "location": raid["location_name"],
        "weather": raid["weather"]["name"],
        "history": raid["history"],
        "items": backpack,
        "saved_items_count": 0,
        "dropped_items_count": 0,
        "exp_earned": 0,
        "bp_res": None,
        "squad_lost": False,
        "saved_mythics": []
    }

    if success:
        # Base EXP: 60 for full extraction, 40 for early extraction
        base_exp = 60 if not early_extract else 40
        exp_awarded = int(base_exp * exp_mult)
        add_player_exp(player, exp_awarded)
        result["exp_earned"] = exp_awarded

        # Store backpack items into player's stash
        stored_cnt = 0
        dropped_cnt = 0
        for itm in backpack:
            if can_store_item(player, itm["id"]):
                player.setdefault("stash", []).append({
                    "uid": f"raid_{now}_{random.randint(1000, 9999)}",
                    "item_id": itm["id"],
                    "equipped_to": None
                })
                stored_cnt += 1
            else:
                dropped_cnt += 1

        result["saved_items_count"] = stored_cnt
        result["dropped_items_count"] = dropped_cnt

        # GD BattlePass EXP
        if has_gd_business(player):
            bp_pts = 450 if not early_extract else 250
            result["bp_res"] = add_gd_bp_exp(player, bp_pts)

    else:
        # Squad wiped out!
        result["squad_lost"] = True
        # Tagilla set protection check:
        if has_boss_set_bonus(player, "tagilla"):
            result["tagilla_saved"] = True
        else:
            stash = player.get("stash", [])
            saved_mythics = []
            for f in squad:
                for slot_key in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
                    uid = f.get(slot_key)
                    if uid:
                        item_entry = next((i for i in stash if i.get("uid") == uid), None)
                        if item_entry:
                            item_id = item_entry.get("item_id")
                            info = ITEMS_BY_ID.get(item_id, {})
                            if info.get("rarity") == "mythic" or str(item_id).startswith(("mythic_", "zryachiy_", "goons_")) or info.get("mythic", False):
                                item_entry["equipped_to"] = None
                                saved_mythics.append(info.get("name", item_id))
                            else:
                                if item_entry in stash:
                                    stash.remove(item_entry)
                        f[slot_key] = None

            # Also strip any items marked as equipped in stash
            for item_entry in list(stash):
                if item_entry.get("equipped_to") is not None:
                    item_id = item_entry.get("item_id")
                    info = ITEMS_BY_ID.get(item_id, {})
                    if info.get("rarity") == "mythic" or str(item_id).startswith(("mythic_", "zryachiy_", "goons_")) or info.get("mythic", False):
                        item_entry["equipped_to"] = None
                        if info.get("name", item_id) not in saved_mythics:
                            saved_mythics.append(info.get("name", item_id))
                    else:
                        if item_entry in stash:
                            stash.remove(item_entry)

            player["squad"] = []
            result["saved_mythics"] = saved_mythics

        if has_gd_business(player):
            result["bp_res"] = add_gd_bp_exp(player, 120)

    return result
