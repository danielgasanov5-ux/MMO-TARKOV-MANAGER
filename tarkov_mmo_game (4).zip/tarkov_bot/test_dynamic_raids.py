# -*- coding: utf-8 -*-
"""
Comprehensive Test Suite for Dynamic Raids (4 Phases), Deterministic Combat,
Spectre Nerf, Contraband Money Removal, and Hideout Modules (Nutrition & Rest Space).
"""

import sys
import os
import time

sys.path.insert(0, os.path.dirname(__file__))

import tarkov_engine as te
import loot_generator as lg
import dynamic_raid_engine as dre
import bot as tb

def run_all_tests():
    print("==================================================")
    print("   TEST SUITE: DYNAMIC 4-PHASE RAIDS & REBALANCING")
    print("==================================================")

    # TEST 1: Spectre Signature PMC Nerf
    print("\n[TEST 1] Spectre PMC Nerf: 2.0x legendary/epic drop rate, no flat win rate...")
    spectre_def = te.PMC_DEFINITIONS.get("Specter")
    assert spectre_def is not None, "Specter PMC not found in PMC_DEFINITIONS!"
    assert "2x" in spectre_def.get("desc", "") or "удваивает" in spectre_def.get("desc", "").lower(), \
        f"Spectre buff_desc not updated: {spectre_def.get('desc')}"
    
    # Verify roll_raid_loot with Spectre
    p_spectre = te.create_new_player(1001, "SpectreUser", "Specter")
    assert p_spectre.get("signature_pmc") == "Specter" or p_spectre.get("pmc_signature") == "Specter"
    assert te.has_buff(p_spectre, "loot_bonus") == True
    
    # Roll 200 items with and without Spectre to ensure no exceptions and loot generation works
    loot_spectre = [lg.roll_raid_loot("factory", p_spectre) for _ in range(50)]
    assert len(loot_spectre) == 50
    assert all("id" in item and "price" in item for item in loot_spectre)
    print("✓ Spectre PMC signature buff and roll_raid_loot verified successfully!")

    # TEST 2: Pure Rubles Removal in Raids
    print("\n[TEST 2] Verify pure rubles removal from raids (0 ₽ reward)...")
    sim_res = lg.simulate_raid("lab", p_spectre, 500, 300)
    assert sim_res.get("rubles") == 0, f"Expected 0 rubles from simulate_raid, got {sim_res.get('rubles')}"
    print("✓ simulate_raid returns 0 rubles as expected!")

    # TEST 3: Pure Rubles Removal in Contraband (Supply Drops)
    print("\n[TEST 3] Verify pure rubles removal from contraband supply drops...")
    p_supply = te.create_new_player(1002, "SupplyUser", "Viper")
    for tier in [1, 2, 3, 4]:
        cargo = lg.generate_supply_drop(tier, p_supply)
        assert cargo.get("rubles") == 0, f"Expected 0 rubles in tier {tier} supply drop, got {cargo.get('rubles')}"
        assert len(cargo.get("items", [])) > 0, "Cargo items list should not be empty!"
    print("✓ All 4 tiers of contraband supply drops yield 0 pure rubles!")

    # TEST 4: Hideout Modules (Nutrition and Rest Space)
    print("\n[TEST 4] Hideout Modules: Nutrition Unit (HP Pool) and Rest Space (Noise/EXP)...")
    p_hideout = te.create_new_player(1003, "HideoutTester", "Bear")
    p_hideout.setdefault("modules", {})["nutrition"] = 4 # +20 HP
    p_hideout.setdefault("modules", {})["rest_space"] = 3    # -6% noise, +15% EXP

    raid_init = dre.init_dynamic_raid(p_hideout, "customs")
    assert raid_init["squad_hp"] == 120, f"Expected 120 HP (100 + 4*5), got {raid_init['squad_hp']}"
    assert raid_init["squad_max_hp"] == 120
    assert raid_init["noise_level"] == 4, f"Initial noise level should be 4 (10 - 3*2), got {raid_init['noise_level']}"
    print(f"✓ Nutrition Unit correctly granted +20 max HP ({raid_init['squad_hp']}/{raid_init['squad_max_hp']})!")

    # TEST 5: Dynamic 4-Phase Tactical Progression
    print("\n[TEST 5] Dynamic 4-Phase Progression and Branching Choices...")
    # Give player strong gear
    p_squad = te.create_new_player(1004, "TacticalUser", "USEC")
    p_squad["stash"].append({"uid": "g1", "item_id": "m4a1_rifle", "equipped_to": 1})
    p_squad["stash"].append({"uid": "g2", "item_id": "hexgrid_plate_carrier", "equipped_to": 1})
    p_squad["stash"].append({"uid": "g3", "item_id": "altyn_helmet", "equipped_to": 1})
    p_squad["stash"].append({"uid": "g4", "item_id": "comtac2_headset", "equipped_to": 1})

    raid = dre.init_dynamic_raid(p_squad, "factory")
    assert raid["stage"] == 1, f"Expected stage 1, got {raid['stage']}"
    assert p_squad.get("active_dynamic_raid") is not None, "active_dynamic_raid should be set on player"

    # Step through choices until raid completes
    step_count = 0
    while p_squad.get("active_dynamic_raid") and step_count < 10:
        step_count += 1
        curr_stage = p_squad["active_dynamic_raid"]["stage"]
        choices = p_squad["active_dynamic_raid"]["current_encounter"]["choices"]
        assert len(choices) >= 2, f"Encounter at stage {curr_stage} has fewer than 2 choices!"
        
        # Pick the first available choice
        choice_id = choices[0]["id"]
        res = dre.resolve_raid_action(p_squad, choice_id)
        if res.get("status") != "in_progress":
            break

    assert p_squad.get("active_dynamic_raid") is None, "active_dynamic_raid should be cleared on completion"
    assert "history" in res, "Raid result must include history log"
    assert len(res["history"]) >= 1, "Raid history must not be empty"
    print(f"✓ Completed dynamic raid in {step_count} phases! Outcome: success={res.get('success')}, items={len(res.get('items', []))}")

    # TEST 6: Early Extraction Mechanic (Push-Your-Luck)
    print("\n[TEST 6] Testing Early Extraction / Tactical Retreat Choice...")
    p_early = te.create_new_player(1005, "EarlyExtractor", "Bear")
    dre.init_dynamic_raid(p_early, "customs")
    # Simulate advancing to stage 3 where an exfil choice exists or trigger early extract
    p_early["active_dynamic_raid"]["stage"] = 3
    p_early["active_dynamic_raid"]["backpack"].append({"id": "ak74m_rifle", "name": "АК-74М", "rarity": "rare", "price": 45000})
    res_early = dre.resolve_raid_action(p_early, "extract_early")
    assert res_early.get("success") == True, "Early extract should count as success"
    assert res_early.get("early_extract") == True, "early_extract flag should be True"
    assert any(i.get("item_id") == "ak74m_rifle" for i in p_early["stash"]), "Loot from backpack should be moved to stash"
    print("✓ Early extraction successfully preserved backpack loot and marked raid as survived!")

    # TEST 7: Full Squad Wipeout and Mythic Relic Protection
    print("\n[TEST 7] Squad Defeat and Mythic Relic Protection...")
    p_wipe = te.create_new_player(1006, "WipeoutTester", "USEC")
    # Add a mythic relic item and a standard item
    p_wipe["stash"].append({"uid": "m_uid", "item_id": "mythic_dsp_sensor", "equipped_to": 1})
    p_wipe["stash"].append({"uid": "std_uid", "item_id": "ak74m_rifle", "equipped_to": 1})
    dre.init_dynamic_raid(p_wipe, "lab")
    # Force squad HP to 0 and resolve
    p_wipe["active_dynamic_raid"]["squad_hp"] = 0
    res_wipe = dre.finish_dynamic_raid(p_wipe, False)
    assert res_wipe.get("success") == False, "Raid outcome should be defeat"
    assert len(p_wipe["squad"]) == 0, "Squad must be wiped on defeat"
    # Verify standard item removed from stash, mythic preserved
    std_exists = any(i.get("uid") == "std_uid" for i in p_wipe["stash"])
    mythic_exists = any(i.get("uid") == "m_uid" for i in p_wipe["stash"])
    assert not std_exists, "Standard gear should be lost on squad wipe"
    assert mythic_exists, "Mythic gear must be saved by satellite beacon!"
    print("✓ Squad wipe correctly removed mortal fighters & normal gear while preserving mythics!")

    # TEST 8: UI Menu Integration in bot.py
    print("\n[TEST 8] bot.py Menu Raids displays difficulty and threat rating (no win %)...")
    class MockCall:
        def __init__(self, uid):
            self.id = "mock_call"
            self.message = type("msg", (), {"chat": type("c", (), {"id": 123})(), "message_id": 456})()
            self.from_user = type("u", (), {"id": uid, "username": "Tester"})()

    class MockBot:
        def __init__(self):
            self.last_text = ""
            self.last_markup = None
        def answer_callback_query(self, *args, **kwargs):
            pass
        def edit_message_text(self, text, chat_id, message_id, reply_markup=None, **kwargs):
            self.last_text = text
            self.last_markup = reply_markup
        def send_message(self, chat_id, text, reply_markup=None, **kwargs):
            self.last_text = text
            self.last_markup = reply_markup

    m_bot = MockBot()
    tb.bot = m_bot
    tb.handle_menu_raids(123, 456, p_squad)
    assert "%" not in [b.text for row in m_bot.last_markup.keyboard for b in row if "Сложн." in b.text][0], \
        "Win chance percentage must NOT be displayed on raid location buttons!"
    assert "Сложн." in [b.text for row in m_bot.last_markup.keyboard for b in row if "В рейд:" in b.text][0], \
        "Location button must display sector difficulty!"
    print("✓ Raid menu correctly displays sector difficulty and power assessment without percentages!")

    print("\n==================================================")
    print("   🎉 ALL 8 DYNAMIC RAIDS & REBALANCE TESTS PASSED! ")
    print("==================================================")

if __name__ == "__main__":
    run_all_tests()
