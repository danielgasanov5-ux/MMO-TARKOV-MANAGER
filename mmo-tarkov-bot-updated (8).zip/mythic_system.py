# -*- coding: utf-8 -*-
"""
Mythic Items System (150,000,000 ₽ each) for Escape from Tarkov MMO Telegram Bot:
1. 💼 «Дипломатический кейс Black Division» (mythic_black_division_case)
   - Drops from Co-op Boss Raids
   - Allows sending elite Black Division squad on a chosen boss every 24h
   - Guarantees a targeted Boss Relic (prioritizing missing relics for 5/5 sets) + 5-12M ₽ + elite trophies

2. 🎖️ «Жетон Отступников (The Goons)» (mythic_goons_token)
   - 0.01% chance (1 in 10,000) from the 2,500,000 ₽ TerraGroup Case
   - Automatic 24h supply drop of unique Goons signature gear:
     * Knight Skull Mask & Crye AVS Rig
     * Big Pipe M32A1 Grenade Launcher & Signature Smoke Pipe
     * Birdeye DVL-10 Saboteur Sniper & ComTac IV Recon Headset
   - 24h special raid: deploy the Goons trio (Knight, Big Pipe, Birdeye) into Tarkov
     for 7-15M ₽, elite loot, and 35% chance for a pure Bitcoin!
"""

import time
import random

MYTHIC_ITEMS = {
    "mythic_black_division_case": {
        "id": "mythic_black_division_case",
        "name": "💼 Дипломатический кейс Black Division",
        "category": "special",
        "market_cat": "Мифические артефакты",
        "rarity": "mythic",
        "price": 150000000,
        "badge": "💼",
        "desc": (
            "Сверхсекретный титановый дипломат TerraGroup. "
            "Дает возможность раз в 24 часа отправлять элитную ЧВК Black Division "
            "на ликвидацию выбранного Босса за гарантированной реликвией и миллионными трофеями."
        )
    },
    "mythic_goons_token": {
        "id": "mythic_goons_token",
        "name": "🎖️ Жетон Отступников (The Goons)",
        "category": "special",
        "market_cat": "Мифические артефакты",
        "rarity": "mythic",
        "price": 150000000,
        "badge": "🎖️",
        "desc": (
            "Мифический жетон признания банды The Goons (шанс 0.01% с кейса за 2.5М). "
            "Каждые 24 часа снабжает схрон уникальной экипировкой Knight, Big Pipe и Birdeye, "
            "а также позволяет раз в 24 часа отправлять троицу Отступников в рейд зачистки."
        )
    }
}

# Unique signature gear of The Goons (given every 24h via mythic_goons_token)
GOONS_GEAR = [
    {
        "id": "goons_knight_skull_mask",
        "name": "💀 Шлем-маска «Knight Skull»",
        "category": "armor",
        "subcategory": "helmet",
        "market_cat": "Шлемы",
        "rarity": "mythic",
        "price": 25000000,
        "armor": 35,
        "combat": 12,
        "desc": "Культовая баллистическая маска со стилизованным черепом командира Отступников Knight. Высшая степень защиты головы."
    },
    {
        "id": "goons_knight_avs_rig",
        "name": "🛡️ Бронежилет Crye Precision CPC plate carrier (Knight Edition)",
        "category": "armor",
        "subcategory": "body_armor",
        "market_cat": "Броня",
        "rarity": "mythic",
        "price": 35000000,
        "armor": 50,
        "combat": 8,
        "desc": "Сверхтяжелый штурмовой плитник Crye Precision CPC командира Knight с композитными бронеплитами 6 класса защиты."
    },
    {
        "id": "goons_knight_scar_h",
        "name": "⚔️ Штурмовая винтовка FN SCAR-H «Knight’s Wrath» 7.62x51",
        "category": "weapons",
        "subcategory": "assault_rifle",
        "market_cat": "Штурмовые винтовки",
        "rarity": "mythic",
        "price": 42000000,
        "combat": 62,
        "armor": 4,
        "desc": "Кастомизированная штурмовая винтовка FN SCAR-H командира Knight калибра 7.62x51 NATO с оптикой Vudu и глушителем Wave QD. Пробивает любые укрепления."
    },
    {
        "id": "goons_bigpipe_m32a1",
        "name": "🧨 Гранатомет M32A1 «Big Pipe»",
        "category": "weapons",
        "subcategory": "special",
        "market_cat": "Тяжелое оружие",
        "rarity": "mythic",
        "price": 40000000,
        "combat": 60,
        "armor": 0,
        "desc": "Шестизарядный 40-мм револьверный гранатомет Биг Пайпа. Сметает вражеские укрепления и свиту боссов."
    },
    {
        "id": "goons_bigpipe_bandana",
        "name": "🪓 Бандана и трубка «Big Pipe Smoke»",
        "category": "armor",
        "subcategory": "helmet",
        "market_cat": "Шлемы",
        "rarity": "mythic",
        "price": 20000000,
        "combat": 18,
        "armor": 15,
        "desc": "Легендарная курительная трубка и пропитанная порохом бандана Биг Пайпа. Внушает животный страх врагам."
    },
    {
        "id": "goons_bigpipe_rec10",
        "name": "💥 Карабин Barrett REC10 «Big Pipe Devastator» 7.62x51",
        "category": "weapons",
        "subcategory": "assault_rifle",
        "market_cat": "Штурмовые винтовки",
        "rarity": "mythic",
        "price": 39000000,
        "combat": 58,
        "armor": 6,
        "desc": "Тяжелый полуавтоматический карабин Barrett REC10 Биг Пайпа с дульным тормозом Lantac Dragon и 25-зарядным магазином. Сеет чистый хаос на средней дистанции."
    },
    {
        "id": "goons_birdeye_dvl10",
        "name": "🎯 Снайперская винтовка DVL-10 «Birdeye Saboteur»",
        "category": "weapons",
        "subcategory": "sniper_rifle",
        "market_cat": "Снайперские винтовки",
        "rarity": "mythic",
        "price": 35000000,
        "combat": 55,
        "armor": 0,
        "desc": "Бесшумная снайперская винтовка Бердая с интегрированным глушителем. Стрельба без звука и вспышки."
    },
    {
        "id": "goons_birdeye_comtac",
        "name": "🎧 Гарнитура Peltor ComTac IV «Birdeye Recon»",
        "category": "gear",
        "subcategory": "headset",
        "market_cat": "Наушники",
        "rarity": "mythic",
        "price": 20000000,
        "combat": 15,
        "armor": 15,
        "desc": "Активная гарнитура Бердая. Позволяет улавливать малейший шорох шагов противника на километры вокруг."
    },
    {
        "id": "goons_birdeye_rsass",
        "name": "🦅 Снайперская винтовка Remington RSASS «Birdeye Phantom Eye» 7.62x51",
        "category": "weapons",
        "subcategory": "sniper_rifle",
        "market_cat": "Снайперские винтовки",
        "rarity": "mythic",
        "price": 44000000,
        "combat": 64,
        "armor": 0,
        "desc": "Высокоточная марксманская система Бердая с титановым глушителем Ultra 5 и тепловизионным оптическим комплексом. Ликвидирует цели сквозь дым и кусты без звука."
    }
]

GOONS_GEAR_BY_ID = {item["id"]: item for item in GOONS_GEAR}

# Cooldowns in seconds (24 hours = 86400s)
COOLDOWN_24H = 86400

def has_mythic_item(player, item_id):
    """Checks if player owns the specific mythic item."""
    if not player:
        return False
    # Check special mythic_items list
    if item_id in player.get("mythic_items", []):
        return True
    # Check stash
    for itm in player.get("stash", []):
        if itm.get("item_id") == item_id:
            return True
    return False

def add_mythic_item_to_player(player, item_id):
    """Safely grants a mythic item to the player."""
    player.setdefault("mythic_items", [])
    if item_id not in player["mythic_items"]:
        player["mythic_items"].append(item_id)
    # Also add to stash for visualization
    now = int(time.time())
    stash_has = any(itm.get("item_id") == item_id for itm in player.get("stash", []))
    if not stash_has:
        player.setdefault("stash", []).append({
            "uid": f"mythic_{item_id}_{now}",
            "item_id": item_id,
            "equipped_to": None
        })

def get_player_mythics(player):
    """Returns list of all mythic items owned by the player."""
    owned = []
    for mid, mdata in MYTHIC_ITEMS.items():
        if has_mythic_item(player, mid):
            owned.append(mdata)
    return owned

# ----------------- BLACK DIVISION SQUAD RAIDS -----------------

def can_launch_black_division(player):
    """Returns (can_launch: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_black_division_case"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_run = player.get("last_black_division_raid", 0)
    elapsed = now - last_run
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def execute_black_division_raid(player, boss_key):
    """
    Executes Black Division operation against chosen boss:
    - reshala, tagilla, killa, shturman, glukhar, sanitar
    - Guarantees a targeted Boss Relic from that boss!
    - Awards 5,000,000 - 12,000,000 ₽ + high-tier loot + 150 EXP
    """
    from relics_system import BOSS_SETS, get_player_relics

    now = int(time.time())
    b_data = BOSS_SETS.get(boss_key)
    if not b_data:
        boss_key = "killa"
        b_data = BOSS_SETS["killa"]

    # Choose relic: prioritize one the player DOES NOT own yet!
    owned_relic_ids = get_player_relics(player)
    missing_relics = [r for r in b_data["relics"] if r["id"] not in owned_relic_ids]
    if missing_relics:
        chosen_relic = random.choice(missing_relics)
        is_new = True
    else:
        chosen_relic = random.choice(b_data["relics"])
        is_new = False

    # Award relic to stash
    player.setdefault("stash", []).append({
        "uid": f"relic_{now}_{random.randint(1000, 9999)}",
        "item_id": chosen_relic["id"],
        "equipped_to": None
    })

    # Award rubles
    rubles = random.randint(5000000, 12000000)
    player["money"] = player.get("money", 0) + rubles

    # Award EXP
    player["exp"] = player.get("exp", 0) + 150

    # Pick 2-3 elite trophy items
    from loot_generator import roll_strict_tarkov_loot
    trophies = []
    for _ in range(random.randint(2, 3)):
        item = roll_strict_tarkov_loot(player)
        trophies.append(item)
        player.setdefault("stash", []).append({
            "uid": f"bd_loot_{now}_{random.randint(1000, 9999)}",
            "item_id": item["id"],
            "equipped_to": None
        })

    # Update cooldown
    player["last_black_division_raid"] = now

    return {
        "boss_name": b_data["boss_name"],
        "boss_icon": b_data["icon"],
        "relic": chosen_relic,
        "is_new_relic": is_new,
        "rubles": rubles,
        "exp": 150,
        "trophies": trophies
    }

# ----------------- THE GOONS MECHANICS -----------------

def can_claim_goons_supply(player):
    """Returns (can_claim: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_goons_token"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_supply = player.get("last_goons_supply", 0)
    elapsed = now - last_supply
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def claim_goons_gear_supply(player):
    """
    Supplies one random unique Goons signature gear piece to player's stash.
    """
    now = int(time.time())
    gear_item = random.choice(GOONS_GEAR)

    player.setdefault("stash", []).append({
        "uid": f"goons_gear_{now}_{random.randint(1000, 9999)}",
        "item_id": gear_item["id"],
        "equipped_to": None
    })

    player["last_goons_supply"] = now
    return gear_item

def can_launch_goons_raid(player):
    """Returns (can_launch: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_goons_token"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_raid = player.get("last_goons_raid", 0)
    elapsed = now - last_raid
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def execute_goons_raid(player):
    """
    Deploys The Goons trio (Knight, Big Pipe, Birdeye) on a 24h sweep raid:
    - 100% victory (they are The Goons)
    - 7,000,000 - 15,000,000 ₽
    - 3-4 elite items
    - 250 EXP
    - 35% chance for 1 pure Bitcoin (BTC)!
    """
    now = int(time.time())

    rubles = random.randint(7000000, 15000000)
    player["money"] = player.get("money", 0) + rubles
    player["exp"] = player.get("exp", 0) + 250

    # Bitcoin roll (35% chance)
    btc_won = 0.0
    if random.random() < 0.35:
        btc_won = 1.0
        player["btc"] = player.get("btc", 0.0) + 1.0

    # 3-4 high tier items
    from loot_generator import roll_strict_tarkov_loot
    trophies = []
    for _ in range(random.randint(3, 4)):
        item = roll_strict_tarkov_loot(player)
        trophies.append(item)
        player.setdefault("stash", []).append({
            "uid": f"goons_raid_{now}_{random.randint(1000, 9999)}",
            "item_id": item["id"],
            "equipped_to": None
        })

    player["last_goons_raid"] = now

    return {
        "rubles": rubles,
        "btc_won": btc_won,
        "exp": 250,
        "trophies": trophies
    }
