# -*- coding: utf-8 -*-
"""
Boss Summon System (1% chance on Scav hire) for Escape from Tarkov MMO Telegram Bot.

Summons one of 3 unique bosses:
1. Сектанты (Cultists) — «Ночной ритуал и Скрытный токсин»
2. Партизан (Partisan) — «Растяжки и снайперские мины»
3. Коллонтай (Kollontay) — «Милицейский спецназ и подавление»

Mechanics:
- 1% chance upon clicking 'Нанять Дикого' in the squad menu.
- Interactive choice:
  1. Recruit to squad (if slot available) with unique passive buff and boss gear.
  2. Fight the summoned boss with squad for jackpot rubles (1.5M - 3.5M ₽), exclusive weapons/armor, and trophies.
  3. Dismiss safely.
"""

import time
import random
from telebot import types
from tarkov_engine import (
    fmt_rub, calculate_squad_power, add_player_rubles, add_player_exp,
    can_store_item, has_boss_set_bonus, get_max_squad_size, save_db, ITEMS_BY_ID
)

SUMMONED_BOSSES = {
    "cultists": {
        "id": "cultists",
        "name": "Жрец Сектантов",
        "title": "🗡️ ЖРЕЦ СЕКТАНТОВ И АДЕПТЫ ТЬМЫ",
        "icon": "🗡️",
        "badge": "🕯️",
        "difficulty": 180,
        "base_power": 45,
        "base_armor": 25,
        "desc": (
            "Из ночного тумана бесшумно выступили Сектанты во главе с верховным Жрецом! "
            "В руках Жреца блестит ритуальный клинок, смазанный смертоносным токсином."
        ),
        "perk_name": "Ночной ядовитый ритуал",
        "perk_desc": "+15% к скрытности и выживаемости отряда во всех рейдах, полный иммунитет к ночным засадам.",
        "gear": [
            {
                "id": "cultist_poison_blade_legendary",
                "name": "🗡️ Ритуальный ядовитый нож Жреца Сектантов",
                "category": "weapons",
                "subcategory": "knife",
                "rarity": "legendary",
                "price": 8500000,
                "combat": 40,
                "armor": 10,
                "desc": "Легендарный церемониальный клинок сектантов с выемкой под быстродействующий паралитический токсин."
            },
            {
                "id": "cultist_hood_rare",
                "name": "🕯️ Ритуальный балахон Сектанта",
                "category": "armor",
                "subcategory": "body_armor",
                "rarity": "rare",
                "price": 3200000,
                "combat": 15,
                "armor": 30,
                "desc": "Скрывающий силуэт плотный балахон со скрытыми композитными пластинами."
            }
        ],
        "reward_rubles": (1800000, 3200000),
        "reward_item": {
            "id": "cultist_poison_blade_legendary",
            "name": "🗡️ Ритуальный ядовитый нож Жреца Сектантов",
            "category": "weapons",
            "subcategory": "knife",
            "rarity": "legendary",
            "price": 8500000,
            "combat": 40,
            "armor": 10,
            "desc": "Легендарный церемониальный клинок сектантов с выемкой под быстродействующий паралитический токсин."
        }
    },
    "partisan": {
        "id": "partisan",
        "name": "Партизан",
        "title": "🌲 ПАРТИЗАН — ОХОТНИК НОРВИНСКИХ ЛЕСОВ",
        "icon": "🌲",
        "badge": "🎯",
        "difficulty": 200,
        "base_power": 55,
        "base_armor": 30,
        "desc": (
            "Из лесной чащи бесшумно появился Партизан — суровый охотник, карающий мародеров и кемперов. "
            "На его разгрузке закреплены растяжки с гранатами и снайперские мины."
        ),
        "perk_name": "Растяжки и лесные ловушки",
        "perk_desc": "+25 к огневой мощи отряда, +30% к добыче рублей в рейдах и автоматическая защита базы от рейдеров.",
        "gear": [
            {
                "id": "partisan_svd_legendary",
                "name": "🎯 Снайперский карабин Партизана 7.62x54R",
                "category": "weapons",
                "subcategory": "sniper_rifle",
                "rarity": "legendary",
                "price": 9500000,
                "combat": 50,
                "armor": 5,
                "desc": "Модифицированная винтовка Партизана с глушителем и метками зачищенных мародеров."
            },
            {
                "id": "partisan_rig_rare",
                "name": "🌲 Тактическая разгрузка Партизана с минами",
                "category": "gear",
                "subcategory": "rig",
                "rarity": "rare",
                "price": 4000000,
                "combat": 20,
                "armor": 25,
                "desc": "Специальная разгрузка с отсеками под сигнальные мины и растяжки."
            }
        ],
        "reward_rubles": (2000000, 3500000),
        "reward_item": {
            "id": "partisan_svd_legendary",
            "name": "🎯 Снайперский карабин Партизана 7.62x54R",
            "category": "weapons",
            "subcategory": "sniper_rifle",
            "rarity": "legendary",
            "price": 9500000,
            "combat": 50,
            "armor": 5,
            "desc": "Модифицированная винтовка Партизана с глушителем и метками зачищенных мародеров."
        }
    },
    "kollontay": {
        "id": "kollontay",
        "name": "Коллонтай",
        "title": "🛡️ КОЛЛОНТАЙ — БЫВШИЙ НАЧАЛЬНИК ОВД",
        "icon": "🛡️",
        "badge": "⚡",
        "difficulty": 220,
        "base_power": 45,
        "base_armor": 60,
        "desc": (
            "Тяжелым чеканным шагом перед вами предстал Коллонтай — бывший начальник милиции. "
            "В руках у него тяжелая милицейская дубинка, а корпус защищен штурмовым бронежилетом высшего класса."
        ),
        "perk_name": "Милицейский спецназ и подавление",
        "perk_desc": "+40 к броне отряда, подавляет вражеских Диких (сдаются без боя, +15% шанс победы в рейдах).",
        "gear": [
            {
                "id": "kollontay_baton_legendary",
                "name": "⚡ Усиленная милицейская дубинка Коллонтая",
                "category": "weapons",
                "subcategory": "melee",
                "rarity": "legendary",
                "price": 7500000,
                "combat": 30,
                "armor": 20,
                "desc": "Титановая спец-дубинка с шоковым сердечником, внушающая страх уличным бандам."
            },
            {
                "id": "kollontay_armor_6b43_legendary",
                "name": "🛡️ Штурмовой бронежилет 6Б43 Коллонтая (6 класс)",
                "category": "armor",
                "subcategory": "body_armor",
                "rarity": "legendary",
                "price": 11000000,
                "combat": 15,
                "armor": 55,
                "desc": "Тяжелейший общевойсковой бронежилет с керамическими плитами высшего класса защиты."
            }
        ],
        "reward_rubles": (2200000, 3800000),
        "reward_item": {
            "id": "kollontay_armor_6b43_legendary",
            "name": "🛡️ Штурмовой бронежилет 6Б43 Коллонтая (6 класс)",
            "category": "armor",
            "subcategory": "body_armor",
            "rarity": "legendary",
            "price": 11000000,
            "combat": 15,
            "armor": 55,
            "desc": "Тяжелейший общевойсковой бронежилет с керамическими плитами высшего класса защиты."
        }
    }
}

# Register boss items in ITEMS_BY_ID so inventory, power, and stash work seamlessly
for b_key, b_info in SUMMONED_BOSSES.items():
    for g in b_info.get("gear", []):
        if g["id"] not in ITEMS_BY_ID:
            ITEMS_BY_ID[g["id"]] = g
    ri = b_info.get("reward_item")
    if ri and ri["id"] not in ITEMS_BY_ID:
        ITEMS_BY_ID[ri["id"]] = ri

def ensure_boss_gear(player):
    """
    Auto-repairs and safeguards Boss gear for any summoned boss in the squad.
    If weapon_uid or armor_uid was lost, unequipped, or missing from stash,
    it restores the authentic signature boss weapon and armor immediately.
    Returns True if any repairs were made, False otherwise.
    """
    squad = player.get("squad", [])
    stash = player.setdefault("stash", [])
    stash_by_uid = {itm.get("uid"): itm for itm in stash if itm.get("uid")}
    now = int(time.time())
    repaired = False

    for f in squad:
        if f.get("type") != "boss":
            continue

        b_key = f.get("boss_key")
        if not b_key:
            name_low = f.get("name", "").lower()
            if "сектант" in name_low or "жрец" in name_low:
                b_key = "cultists"
            elif "партизан" in name_low:
                b_key = "partisan"
            elif "коллонтай" in name_low:
                b_key = "kollontay"
            if b_key:
                f["boss_key"] = b_key

        boss_data = SUMMONED_BOSSES.get(b_key)
        if not boss_data:
            continue

        gear = boss_data.get("gear", [])
        if len(gear) >= 1:
            g_w = gear[0]
            w_uid = f.get("weapon_uid")
            w_item = stash_by_uid.get(w_uid) if w_uid else None
            if not w_item or w_item.get("item_id") != g_w["id"]:
                new_w_uid = f"boss_{b_key}_w_{now}_{random.randint(1000, 9999)}"
                new_w_item = {
                    "uid": new_w_uid,
                    "item_id": g_w["id"],
                    "equipped_to": f["id"],
                    "is_boss_locked": True
                }
                stash.append(new_w_item)
                stash_by_uid[new_w_uid] = new_w_item
                f["weapon_uid"] = new_w_uid
                repaired = True
            else:
                w_item["is_boss_locked"] = True
                w_item["equipped_to"] = f["id"]

        if len(gear) >= 2:
            g_a = gear[1]
            a_uid = f.get("armor_uid")
            a_item = stash_by_uid.get(a_uid) if a_uid else None
            if not a_item or a_item.get("item_id") != g_a["id"]:
                new_a_uid = f"boss_{b_key}_a_{now}_{random.randint(1000, 9999)}"
                new_a_item = {
                    "uid": new_a_uid,
                    "item_id": g_a["id"],
                    "equipped_to": f["id"],
                    "is_boss_locked": True
                }
                stash.append(new_a_item)
                stash_by_uid[new_a_uid] = new_a_item
                f["armor_uid"] = new_a_uid
                repaired = True
            else:
                a_item["is_boss_locked"] = True
                a_item["equipped_to"] = f["id"]

    return repaired


def is_boss_summon_triggered(player, force=False):
    """
    1% chance (0.01) upon clicking hire scav.
    Tripled to 3% (0.03) for players with Prestige >= 3 (Syndicate Contacts).
    Supports force=True or player['_force_boss_summon'] for testing/audits.
    """
    if force or player.get("_force_boss_summon"):
        player.pop("_force_boss_summon", None)
        return True
    base_chance = 0.01
    try:
        from prestige import get_player_prestige
        if get_player_prestige(player) >= 3:
            base_chance = 0.03
    except Exception:
        pass
    return random.random() < base_chance

def get_random_summoned_boss():
    """Picks one of Cultists, Partisan, Kollontay."""
    boss_key = random.choice(["cultists", "partisan", "kollontay"])
    return SUMMONED_BOSSES[boss_key]

def render_boss_summon_screen(chat_id, msg_id, player, boss_data, bot):
    """Renders the special boss summon encounter screen."""
    squad = player.get("squad", [])
    max_squad = get_max_squad_size(player)
    can_recruit = len(squad) < max_squad

    txt = (
        f"⚡⚡ <b>СВЕРХРЕДКИЙ ВЫЗОВ БОССА ТАРКОВА! (ШАНС 1%)</b> ⚡⚡\n"
        f"────────────────────────\n"
        f"{boss_data['icon']} <b>{boss_data['title']}</b>\n\n"
        f"{boss_data['desc']}\n\n"
        f"✨ <b>Уникальная механика босса:</b>\n"
        f"<b>«{boss_data['perk_name']}»</b>\n"
        f"<i>{boss_data['perk_desc']}</i>\n"
        f"────────────────────────\n"
        f"🪖 <b>Мест в отряде:</b> {len(squad)}/{max_squad}\n\n"
        f"<b>Что вы предпримете?</b>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if can_recruit:
        markup.add(
            types.InlineKeyboardButton(
                f"🤝 Завербовать в отряд ({boss_data['name']})",
                callback_data=f"recruit_summoned_boss_{boss_data['id']}"
            )
        )
    else:
        markup.add(
            types.InlineKeyboardButton(
                "⚠️ Отряд полон (макс. бойцов) — вербовка недоступна",
                callback_data="none"
            )
        )

    markup.add(
        types.InlineKeyboardButton(
            f"⚔️ Атаковать босса (Трофеи и до {fmt_rub(boss_data['reward_rubles'][1])})",
            callback_data=f"fight_summoned_boss_{boss_data['id']}"
        )
    )
    markup.add(
        types.InlineKeyboardButton("🏃 Отпустить с миром (Назад)", callback_data="dismiss_summoned_boss")
    )

    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_recruit_summoned_boss(call, player, db, boss_key, bot):
    """Recruits the summoned boss into the player's squad."""
    boss_data = SUMMONED_BOSSES.get(boss_key)
    if not boss_data:
        bot.answer_callback_query(call.id, "❌ Босс не найден!")
        return

    squad = player.setdefault("squad", [])
    max_squad = get_max_squad_size(player)
    if len(squad) >= max_squad:
        bot.answer_callback_query(call.id, f"❌ Отряд уже полон (макс. {max_squad} бойцов)!", show_alert=True)
        return

    now = int(time.time())
    new_id = max([f["id"] for f in squad] + [0]) + 1

    # Generate boss equipment into stash
    stash = player.setdefault("stash", [])
    w_uid = f"boss_{boss_key}_w_{now}_{random.randint(100, 999)}"
    a_uid = f"boss_{boss_key}_a_{now}_{random.randint(100, 999)}"

    # Weapon
    g_w = boss_data["gear"][0]
    stash.append({
        "uid": w_uid,
        "item_id": g_w["id"],
        "equipped_to": new_id,
        "is_boss_locked": True
    })

    # Armor
    g_a = boss_data["gear"][1]
    stash.append({
        "uid": a_uid,
        "item_id": g_a["id"],
        "equipped_to": new_id,
        "is_boss_locked": True
    })

    fighter = {
        "id": new_id,
        "type": "boss",
        "boss_key": boss_key,
        "name": f"{boss_data['icon']} {boss_data['name']}",
        "base_power": boss_data["base_power"],
        "base_armor": boss_data["base_armor"],
        "perk_name": boss_data["perk_name"],
        "perk_desc": boss_data["perk_desc"],
        "weapon_uid": w_uid,
        "armor_uid": a_uid,
        "helmet_uid": None,
        "headset_uid": None
    }
    squad.append(fighter)

    # Clean pending boss
    player.pop("pending_boss_summon", None)
    save_db(db)

    bot.answer_callback_query(call.id, f"🎉 {boss_data['name']} вступил в ваш отряд!", show_alert=True)

    txt = (
        f"👑 <b>ЛЕГЕНДАРНЫЙ БОСС ВСТУПИЛ В ВАШ ОТРЯД!</b>\n"
        f"────────────────────────\n"
        f"Боец: {boss_data['icon']} <b>{boss_data['name']}</b>\n"
        f"Роль: <b>Элитный Командир Отряда</b>\n\n"
        f"✨ <b>Активная механика:</b>\n"
        f"«{boss_data['perk_name']}»\n"
        f"<i>{boss_data['perk_desc']}</i>\n\n"
        f"🗡️ Стартовое вооружение: <b>{g_w['name']}</b>\n"
        f"🛡️ Стартовая броня: <b>{g_a['name']}</b>\n"
        f"────────────────────────\n"
        f"Босс не погибает в рейдах как обычный Дикий и приносит колоссальную пользу отряду!"
    )
    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🪖 Перейти в Меню Отряда", callback_data="menu_squad")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)

def handle_fight_summoned_boss(call, player, db, boss_key, bot):
    """Simulates squad combat against the summoned boss."""
    boss_data = SUMMONED_BOSSES.get(boss_key)
    if not boss_data:
        bot.answer_callback_query(call.id, "❌ Босс не найден!")
        return

    pow_val, arm_val = calculate_squad_power(player)
    boss_diff = boss_data["difficulty"]

    # Sniper support check for Prestige 5 players with DSP sensor
    sniper_log = ""
    try:
        from prestige import apply_zryachiy_sniper_support
        sniper_res = apply_zryachiy_sniper_support(player, "boss")
        if sniper_res.get("active"):
            boss_diff = max(50, int(boss_diff * (1.0 - sniper_res.get("boss_debuff", 0.0))))
            sniper_log = sniper_res.get("log_text", "")
    except Exception:
        pass

    # Squad combat balance against summoned boss
    combat_score = (pow_val * 1.4) + (arm_val * 1.0)
    try:
        from signature_skills_system import get_signature_skill_bonus
        pmc_k = player.get("pmc_signature", "Viper")
        b_dmg = get_signature_skill_bonus(player, pmc_k, "boss_damage_pct")
        if b_dmg > 0:
            combat_score *= (1.0 + b_dmg)
    except Exception:
        pass
    ratio = combat_score / max(1, boss_diff)
    win_chance = min(0.95, max(0.20, (ratio / (ratio + 0.85)) * 1.25))

    is_win = random.random() < win_chance
    now = int(time.time())

    player.pop("pending_boss_summon", None)

    if is_win:
        min_r, max_r = boss_data["reward_rubles"]
        won_rub = random.randint(min_r, max_r)
        pts_earned_msg = ""
        try:
            from signature_skills_system import get_signature_skill_bonus, award_signature_pmc_points
            pmc_k = player.get("pmc_signature", "Viper")
            l_mult = get_signature_skill_bonus(player, pmc_k, "boss_loot_mult")
            if l_mult > 0:
                won_rub = int(won_rub * (1.0 + l_mult))
            new_pts = award_signature_pmc_points(player, pmc_k, 1, f"Ликвидация Босса {boss_data['name']}")
            pts_earned_msg = f"• ⭐ Очки ЧВК {pmc_k}: <b>+1 очко навыков</b> (Всего: {new_pts})\n"
        except Exception:
            pass
        add_player_rubles(player, won_rub)
        add_player_exp(player, 250)

        # Trophy item
        trophy = boss_data["reward_item"]
        stored_item = False
        if can_store_item(player, trophy["id"]):
            player.setdefault("stash", []).append({
                "uid": f"trophy_{now}_{random.randint(1000, 9999)}",
                "item_id": trophy["id"],
                "equipped_to": None
            })
            stored_item = True

        save_db(db)
        bot.answer_callback_query(call.id, "🏆 ПОБЕДА НАД БОССОМ!")

        txt = (
            f"🏆 <b>ТРИУМФ НАД БОССОМ ТАРКОВА!</b>\n"
            f"────────────────────────\n"
            f"{sniper_log}"
            f"Ваш отряд сошелся в яростном бою против: {boss_data['icon']} <b>{boss_data['title']}</b>!\n"
            f"Шанс победы отряда составлял: <b>{round(win_chance * 100, 1)}%</b>\n\n"
            f"<b>Ход сражения:</b>\n"
            f"Метким перекрестным огнем и слаженной тактикой ваш отряд подавил сопротивление босса!\n\n"
            f"🎁 <b>ВАШИ ТРОФЕИ:</b>\n"
            f"• 💰 Деньги: +<b>{fmt_rub(won_rub)}</b>\n"
         f"• 🎖️ Опыт: +<b>250 EXP</b>\n" + pts_earned_msg

        )
        if stored_item:
            txt += f"• 🏆 Редчайший трофей: <b>{trophy['name']}</b> (добавлен в схрон!)\n"
        else:
            txt += f"• ⚠️ Трофей <b>{trophy['name']}</b> не поместился на складе оружия/снаряжения!\n"

        txt += "────────────────────────"
    else:
        # Squad suffered defeat
        add_player_exp(player, 50)
        # Wound signature operator / scav casualties
        for f in player.get("squad", []):
            if f.get("type") == "scav":
                f["wounded"] = True

        save_db(db)
        bot.answer_callback_query(call.id, "💀 Отряд отступил с потерями!", show_alert=True)

        txt = (
            f"💀 <b>ОТРЯД ПОТЕРПЕЛ ПОРАЖЕНИЕ!</b>\n"
            f"────────────────────────\n"
            f"Босс {boss_data['icon']} <b>{boss_data['name']}</b> оказался слишком опасен!\n"
            f"Применив механику <i>«{boss_data['perk_name']}»</i>, противник рассек боевые порядки отряда.\n\n"
            f"Бойцы были вынуждены экстренно эвакуироваться на базу.\n"
            f"Получено: +50 EXP за тактический опыт."
        )

    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🔙 Вернуться в Меню Отряда", callback_data="menu_squad")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)
