# -*- coding: utf-8 -*-
"""
Escape from Tarkov MMO Economic Engine
Logic, balance formulas, PMC buffs, Hideout, Warehouses, Combat & Persistence.
Now extended with:
- 720 Items Catalog integration
- Dynamic Economic Crises (shifts of +/-30-50% per category daily)
- 4 Equipment Slots: Weapon, Body Armor, Helmet, Headsets
- Full Coop Raid Balance & Penalties
- Admin Rank and Overrides for @revenuts
"""

import json
import os
import time
import random
import math
import threading
import contextlib

DB_LOCK = threading.RLock()
_CURR_DIR = os.path.dirname(os.path.abspath(__file__))
POSSIBLE_DB_FILES = [
    os.environ.get("DB_FILE", ""),
    os.path.join(os.getcwd(), "database.json"),
    os.path.join(_CURR_DIR, "database.json"),
    "database.json",
    "backend/database.json",
    "/tmp/bot/database.json",
]
DB_FILE = next((f for f in POSSIBLE_DB_FILES if f and os.path.exists(f)), os.path.join(_CURR_DIR, "database.json"))
POSSIBLE_ITEM_FILES = [
    os.path.join(_CURR_DIR, "items_data.json"),
    "items_data.json",
    "backend/items_data.json",
    "/tmp/items_data.json",
    os.path.join(os.getcwd(), "items_data.json"),
    os.path.join(os.getcwd(), "backend", "items_data.json"),
]

ITEMS_LIST = []
for p in POSSIBLE_ITEM_FILES:
    if os.path.exists(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
                if len(data) >= 700:
                    ITEMS_LIST = data
                    break
                elif len(data) > len(ITEMS_LIST):
                    ITEMS_LIST = data
        except Exception:
            pass

# Catalog of regular game items (must NOT contain Boss Relics)
ITEMS_BY_ID = {item["id"]: item for item in ITEMS_LIST}

# Register 30 Boss Relics ONLY in ITEMS_BY_ID for metadata lookup
# DO NOT append relics into ITEMS_LIST so they never pollute regular loot drops!
try:
    from relics_system import (
        ALL_30_RELICS, RELICS_BY_ID, BOSS_SETS,
        has_boss_set_bonus, get_player_boss_sets, get_player_relics, get_active_boss_bonuses_list
    )
    for _r in ALL_30_RELICS:
        ITEMS_BY_ID[_r["id"]] = _r
except ImportError:
    pass

# Register Mythic Items and The Goons Gear into ITEMS_BY_ID
try:
    from mythic_system import (
        MYTHIC_ITEMS, GOONS_GEAR, ZRYACHIY_GEAR, has_mythic_item, get_player_mythics, get_squad_mythic_perks
    )
    for _m in MYTHIC_ITEMS.values():
        ITEMS_BY_ID[_m["id"]] = _m
    for _g in GOONS_GEAR:
        ITEMS_BY_ID[_g["id"]] = _g
    for _z in ZRYACHIY_GEAR:
        ITEMS_BY_ID[_z["id"]] = _z
except ImportError:
    pass

# 10 Signature PMCs + 11th "Revenant"
PMC_DEFINITIONS = {
    "Viper": {
        "name": "Viper",
        "icon": "⚡",
        "desc": "Кулдаун после рейдов и кулдаун ЧВК снижен на 15%.",
        "buff": "cooldown_reduction",
        "val": 0.15
    },
    "Nomad": {
        "name": "Nomad",
        "icon": "🏹",
        "desc": "Стоимость отправки Диких в платные рейды снижена на 20%.",
        "buff": "scav_discount",
        "val": 0.20
    },
    "Ronin": {
        "name": "Ronin",
        "icon": "⚔️",
        "desc": "+15% к шансу победить в PvP-зоне 'Даркзон'.",
        "buff": "pvp_bonus",
        "val": 0.15
    },
    "Specter": {
        "name": "Specter",
        "icon": "👁️",
        "desc": "+10% к шансу найти предметы редкости Legendary и Epic в рейдах/поставках.",
        "buff": "loot_bonus",
        "val": 0.10
    },
    "Ares": {
        "name": "Ares",
        "icon": "🛡️",
        "desc": "Вместимость всех специализированных складов увеличена на 20%.",
        "buff": "warehouse_bonus",
        "val": 0.20
    },
    "Zenith": {
        "name": "Zenith",
        "icon": "⚡",
        "desc": "Пассивный майнинг Биткоинов ускорен на 15%.",
        "buff": "btc_bonus",
        "val": 0.15
    },
    "Fenrir": {
        "name": "Fenrir",
        "icon": "🐺",
        "desc": "При моментальной продаже вещей Прапору он платит 40% стоимости вместо 30%.",
        "buff": "prapor_bonus",
        "val": 0.40
    },
    "Stalker": {
        "name": "Stalker",
        "icon": "☢️",
        "desc": "Время ожидания Контрабандных Поставок снижено на 20%.",
        "buff": "supply_speed",
        "val": 0.20
    },
    "Siren": {
        "name": "Siren",
        "icon": "🧜",
        "desc": "Налог на P2P-барахолке снижен с 10% до 5%.",
        "buff": "market_tax",
        "val": 0.05
    },
    "Pharaoh": {
        "name": "Pharaoh",
        "icon": "👑",
        "desc": "Пассивный доход со всех 4 Теневых Бизнесов увеличен на 15%.",
        "buff": "business_income",
        "val": 0.15
    },
    "Revenant": {
        "name": "Revenant",
        "icon": "💀",
        "desc": "Эксклюзив @revenuts: Все 10 баффов одновременно! Ранг: 💀 [ADMIN] 💰 REVENANT GD 💰 💀",
        "buff": "all",
        "val": 1.0
    }
}

# Hideout Upgrade Costs (1 -> 10)
HIDEOUT_UPGRADE_COSTS = {
    1: 75000,       # 1 -> 2
    2: 250000,      # 2 -> 3
    3: 750000,      # 3 -> 4
    4: 2000000,     # 4 -> 5
    5: 5500000,     # 5 -> 6
    6: 15000000,    # 6 -> 7
    7: 40000000,    # 7 -> 8
    8: 100000000,   # 8 -> 9
    9: 250000000    # 9 -> 10
}

# 10 Hideout Modules
MODULE_NAMES = {
    "generator": "Генератор",
    "ammo_bench": "Патронный станок",
    "mining_farm": "Майнинг-ферма (BTC)",
    "medblock": "Медблок",
    "workbench": "Верстак",
    "lavatory": "Санузел",
    "nutrition": "Пищеблок",
    "rest_space": "Зона отдыха",
    "water_collector": "Водосборник",
    "intel_center": "Разведцентр"
}

MODULE_EFFECTS = {
    "generator": "⚡ Доход теневых бизнесов и фермы: +3% за ур. (до +30%)",
    "ammo_bench": "⚙️ Огневая мощь отряда: +3 за ур. (до +30)",
    "mining_farm": "⛏️ Пассивная добыча Bitcoin в час (усиливается генератором)",
    "medblock": "🏥 Лазарет: -5 мин кулдауна травм за ур. и +2 брони отряда",
    "workbench": "🛠️ Модификация брони: +3 к общей защите отряда за ур. (до +30)",
    "lavatory": "🚿 Склад компонентов: +2 слота за ур. и +1% к выкупу Прапора",
    "nutrition": "🥪 Выносливость в рейдах: +1% к шансу выживания за ур. (до +10%)",
    "rest_space": "🛋️ Зона отдыха: +3% рублей за успешные рейды за ур. (до +30%)",
    "water_collector": "💧 Фильтрация воды: -2% к стоимости найма бойцов и +2% к доходу бизнесов",
    "intel_center": "📡 Разведцентр: -0.5% комиссии P2P барахолки и удача в рейдах"
}

# 4 Shadow Businesses with balanced progression
BUSINESS_CONFIG = {
    "topography": {
        "name": "🖨️ Подпольная Топография",
        "tagline": "Печать карт выходов и поддельных пропусков Terragroup",
        "costs": [35000, 75000, 150000, 300000, 580000, 1100000, 2100000, 3800000, 6800000, 12000000],
        "income": [0, 1200, 2400, 4800, 9200, 16500, 28000, 45000, 68000, 92000, 120000]
    },
    "buyers_net": {
        "name": "🏪 Сеть Скупщиков",
        "tagline": "Агентура ломбардов и перепродажа редкого армейского хабара",
        "costs": [90000, 180000, 360000, 700000, 1350000, 2500000, 4600000, 8200000, 14500000, 25000000],
        "income": [0, 2800, 5600, 11000, 21000, 38000, 65000, 105000, 155000, 205000, 260000]
    },
    "chem_lab": {
        "name": "🧪 Хим-Лаборатория",
        "tagline": "Синтез боевых стимуляторов SJ6, пропитала и спец-морфина",
        "costs": [250000, 500000, 1000000, 1950000, 3700000, 6800000, 12500000, 22000000, 38000000, 65000000],
        "income": [0, 7000, 14000, 27000, 50000, 90000, 150000, 240000, 350000, 460000, 580000]
    },
    "smuggling": {
        "name": "🚚 Контрабандный Трафик",
        "tagline": "Трансграничный трафик тяжелого вооружения и военных контейнеров",
        "costs": [750000, 1500000, 3000000, 5800000, 11000000, 20000000, 36000000, 62000000, 105000000, 175000000],
        "income": [0, 18000, 36000, 70000, 130000, 230000, 380000, 580000, 820000, 1100000, 1450000]
    }
}

BUSINESS_NAMES = {k: v["name"] for k, v in BUSINESS_CONFIG.items()}

# 2 High-Tier Syndicate Business Objects
SPECIAL_BUSINESSES = {
    "smugglers_fleet": {
        "id": "smugglers_fleet",
        "name": "Автопарк «Контрабандисты Резерва»",
        "icon": "🚚",
        "cost": 200_000_000,
        "hourly_income": 1_500_000,
        "effect": "Контрабандный груз едет втрое быстрее (3x)",
        "desc": "Собственный парк тяжелых военных тягачей и бронегрузовиков на закрытой базе Резерва. Обеспечивает мгновенный транзит контрабанды в обход любых патрулей."
    },
    "fence_protection": {
        "id": "fence_protection",
        "name": "Доля в бизнесе Скупщика («Крышевание Барахолки»)",
        "icon": "💼",
        "cost": 500_000_000,
        "hourly_income": 3_500_000,
        "effect": "0% налог на P2P + автовыкуп 1 лота NPC раз в 3 часа",
        "desc": "Прямое теневое партнерство со Скупщиком и полный контроль над торговыми потоками Таркова. Полное освобождение от налогов Барахолки и гарантированный автовыкуп товаров теневыми инвесторами."
    }
}

# Base warehouse capacities (weapons, armor, gear, components)
BASE_WAREHOUSE_CAPS = {
    "weapons": (10, 5),      # base 10, +5 per level
    "armor": (10, 5),        # base 10, +5 per level
    "gear": (15, 5),         # base 15, +5 per level (headsets, meds)
    "components": (20, 10),  # base 20, +10 per level
    "valuables": (50, 25)    # base 50, +25 per level (keycards, documents, relics)
}

WAREHOUSE_NAMES = {
    "weapons": "Оружейный склад",
    "armor": "Броне-ангар",
    "gear": "Вещевой склад (Снаряжение & Наушники)",
    "components": "Склад компонентов",
    "valuables": "Сейф ценностей, документов и реликвий"
}

# 6 Flea Market & Crisis Categories
MARKET_CATEGORIES = [
    "Оружие",
    "Экипировка",
    "Наушники",
    "Медицина",
    "Драгоценности",
    "Компоненты"
]

def fmt_rub(val):
    return f"{int(val):,} ₽".replace(",", " ")

# Base Guard Contracts configuration
BASE_GUARD_CONTRACTS = {
    "scav_watchman": {
        "id": "scav_watchman",
        "name": "Сторож-Дикий (с ружьем ТОЗ)",
        "cost": 15000,
        "duration": 3 * 3600,  # 3 hours
        "icon": "🤠",
        "desc": "Для активной сессии: пока играешь и перебираешь лут. Забыл продлить перед выходом — пеняй на себя."
    },
    "pmc_patrol": {
        "id": "pmc_patrol",
        "name": "Патруль наемников (2 ЧВК)",
        "cost": 75000,
        "duration": 8 * 3600,  # 8 hours
        "icon": "👮‍♂️",
        "desc": "Стандартный контракт на ночь или рабочий день."
    },
    "elite_pmc": {
        "id": "elite_pmc",
        "name": "Элитная ЧВК «Спецгруппа Охраны»",
        "cost": 250000,
        "duration": 20 * 3600,  # 20 hours
        "icon": "🛡️",
        "desc": "Максимальный контракт (20 часов — меньше суток!). Игрок ОБЯЗАН заходить в игру хотя бы раз в день, чтобы продлить договор."
    }
}

# Warehouse upgrade cost formula: base 35k, +80% per level (up to 10 tiers)
def get_warehouse_upgrade_cost(current_lvl):
    if current_lvl >= 10:
        return None
    costs = [0, 35000, 80000, 180000, 400000, 900000, 2000000, 4500000, 10000000, 25000000]
    return costs[current_lvl] if current_lvl < len(costs) else 50000000

# Module upgrade cost: 50,000 base, +50% per level
def get_module_upgrade_cost(current_lvl):
    if current_lvl >= 10:
        return None
    cost = 50000 * ((1.5) ** current_lvl)
    return int(round(cost / 250.0) * 250)

# Supply Channel Upgrade costs (1 to 10)
SUPPLY_CHANNEL_COSTS = {
    1: 30000,
    2: 60000,
    3: 120000,
    4: 250000,
    5: 500000,
    6: 1000000,
    7: 2000000,
    8: 4000000,
    9: 8000000
}

# Bitcoin Dynamic Exchange Rate (~500,000 ₽)
def get_current_btc_rate():
    t = time.time()
    # Gentle wave between 470,000 and 535,000 rubles
    variation = math.sin(t / 1800.0) * 32000 + math.cos(t / 4200.0) * 15000
    return int(round((500000 + variation) / 100.0) * 100)

# Business Upgrade Cost by specific business tier (1 to 10)
def get_business_upgrade_cost(biz_key, current_lvl):
    if current_lvl >= 10:
        return None
    b_conf = BUSINESS_CONFIG.get(biz_key)
    if not b_conf:
        return None
    costs = b_conf["costs"]
    if current_lvl < len(costs):
        return costs[current_lvl]
    return None

# Hourly Rubles from Businesses
def get_business_hourly_income(biz_or_level, level=None, user=None):
    if level is None:
        lvl = biz_or_level
        table = [0, 4500, 9500, 18000, 32000, 55000, 90000, 145000, 225000, 340000, 500000]
        base_inc = table[min(lvl, 10)] if lvl > 0 else 0
    else:
        biz_key = biz_or_level
        if level <= 0:
            return 0
        b_conf = BUSINESS_CONFIG.get(biz_key)
        if not b_conf:
            table = [0, 4500, 9500, 18000, 32000, 55000, 90000, 145000, 225000, 340000, 500000]
            base_inc = table[min(level, 10)]
        else:
            base_inc = b_conf["income"][min(level, 10)]

    if user:
        # Generator (+3% per level) and Water Collector (+2% per level)
        mods = user.get("modules", {})
        gen_bonus = mods.get("generator", 0) * 0.03
        water_bonus = mods.get("water_collector", 0) * 0.02
        base_inc = int(base_inc * (1.0 + gen_bonus + water_bonus))

        if has_boss_set_bonus(user, "reshala"):
            # Reshala Set (5/5): +50% business income
            base_inc = int(base_inc * 1.5)
    return base_inc

# Hourly Rubles from Special Syndicate Businesses
def get_special_businesses_income(user):
    if not user:
        return 0, []
    if user.get("businesses_blocked") or user.get("is_base_captured"):
        return 0, []
    spec = user.get("special_businesses", {})
    mods = user.get("modules", {})
    gen_bonus = mods.get("generator", 0) * 0.03
    water_bonus = mods.get("water_collector", 0) * 0.02
    mult = 1.0 + gen_bonus + water_bonus
    if has_boss_set_bonus(user, "reshala"):
        mult *= 1.5
    if has_buff(user, "business_income"):
        mult *= 1.15

    total = 0
    items = []
    if spec.get("smugglers_fleet"):
        inc = int(SPECIAL_BUSINESSES["smugglers_fleet"]["hourly_income"] * mult)
        total += inc
        items.append((SPECIAL_BUSINESSES["smugglers_fleet"]["name"], inc))
    if spec.get("fence_protection"):
        inc = int(SPECIAL_BUSINESSES["fence_protection"]["hourly_income"] * mult)
        total += inc
        items.append((SPECIAL_BUSINESSES["fence_protection"]["name"], inc))
    return total, items

# Hourly BTC from Mining Farm (0.01 to 0.10 BTC/hour)
def get_mining_hourly_btc(level, user=None):
    if isinstance(level, dict):
        user = level
        level = user.get("modules", {}).get("mining_farm", 0)
    if not isinstance(level, (int, float)) or level <= 0:
        return 0.0
    # Balanced mining curve: Lvl 1 = 0.05 BTC/h (~25k ₽/h), Lvl 10 = 0.95 BTC/h (~475k ₽/h)
    lvl_int = min(int(level), 10)
    base_btc = 0.05 + (lvl_int - 1) * 0.10
    if user:
        gen_lvl = user.get("modules", {}).get("generator", 0)
        base_btc *= (1.0 + gen_lvl * 0.03)
    return round(base_btc, 4)

# Buff check with failure penalty check and @revenuts master rank
def has_buff(user, buff_name):
    # If currently in coop raid failure penalty, signature buffs are lost for 2 hours
    # EXCEPT if player has Killa Set (5/5): class buffs don't turn off!
    if user.get("coop_cooldown_until", 0) > time.time():
        if not has_boss_set_bonus(user, "killa"):
            return False
    uname = (user.get("username") or "").lower().lstrip("@")
    if uname in ["reventus", "revenuts"] or user.get("pmc_signature") == "Revenant":
        return True
    defin = PMC_DEFINITIONS.get(user.get("pmc_signature"), {})
    return defin.get("buff") == buff_name

ADMIN_USER_IDS = {9999}
_env_admin = os.environ.get("ADMIN_USER_ID", "").strip()
if _env_admin.isdigit():
    ADMIN_USER_IDS.add(int(_env_admin))
_env_admins = os.environ.get("ADMIN_USER_IDS", "").strip()
if _env_admins:
    for _aid in _env_admins.split(","):
        if _aid.strip().isdigit():
            ADMIN_USER_IDS.add(int(_aid.strip()))

def is_admin(user_id, username=None):
    try:
        if user_id and int(user_id) in ADMIN_USER_IDS:
            return True
    except (ValueError, TypeError):
        pass
    if username:
        clean = str(username).lower().lstrip("@")
        if clean in ["reventus", "revenuts", "danielgasanov5", "danielgasanov", "danielgasanov5_ux", "vozhakzxc", "vozhak", "admin", "owner", "root"]:
            return True
    return False

# Dynamic Economic Crises System
def check_and_update_economic_crisis(db):
    """
    Evaluates or advances the daily economic crisis (random daily category price shift +/-30-50%).
    Returns (is_new, crisis_dict)
    """
    now = int(time.time())
    crisis = db.get("economic_crisis", {})
    if not crisis or now >= crisis.get("expires_at", 0):
        cat = random.choice(MARKET_CATEGORIES)
        direction = random.choice(["surge", "crash"])
        shift_pct = random.randint(30, 50)
        if direction == "surge":
            mult = round(1.0 + shift_pct / 100.0, 2)
            headline = f"📈 ВОЕННЫЙ ДЕФИЦИТ: Всплеск спроса на «{cat}»! Цены взлетели на +{shift_pct}%!"
        else:
            mult = round(1.0 - shift_pct / 100.0, 2)
            headline = f"📉 ОБВАЛ РЫНКА: Перенасыщение складов категорией «{cat}»! Цены упали на -{shift_pct}%!"

        new_crisis = {
            "category": cat,
            "direction": direction,
            "shift_pct": shift_pct,
            "multiplier": mult,
            "started_at": now,
            "expires_at": now + 86400, # 24 hours
            "headline": headline
        }
        db["economic_crisis"] = new_crisis
        return True, new_crisis
    return False, crisis

def get_crisis_price(base_price, item_or_cat, db):
    """Calculates adjusted price based on active economic crisis."""
    if isinstance(item_or_cat, dict):
        cat = item_or_cat.get("market_cat")
    else:
        cat = item_or_cat
    crisis = db.get("economic_crisis")
    if not crisis or crisis.get("expires_at", 0) < time.time():
        return base_price
    if cat == crisis.get("category"):
        return max(500, int(base_price * crisis.get("multiplier", 1.0)))
    return base_price

def get_warehouse_capacity(user, category):
    base, per_lvl = BASE_WAREHOUSE_CAPS.get(category, (15, 5))
    lvl = user.get("warehouses", {}).get(category, 1)
    cap = base + (lvl - 1) * per_lvl
    # Lavatory Module: +2 components capacity per level
    if category == "components" and user:
        lav_lvl = user.get("modules", {}).get("lavatory", 0)
        cap += lav_lvl * 2
    if has_buff(user, "warehouse_bonus"):
        cap = int(math.ceil(cap * 1.20))
    # Tagilla Set (5/5): +50% warehouse capacity for all 4 warehouses
    if has_boss_set_bonus(user, "tagilla"):
        cap = int(math.ceil(cap * 1.50))
    # Glukhar Set (5/5): Arsenal and Armor hanger capacity x2
    if has_boss_set_bonus(user, "glukhar") and category in ["weapons", "armor"]:
        cap = cap * 2
    return cap

def is_item_valuable(info):
    cat = info.get("category", "")
    mcat = info.get("market_cat", "")
    name = info.get("name", "").lower()
    i_id = info.get("id", "").lower()
    return (
        cat in ["relic", "valuable", "valuables"] or
        mcat == "Драгоценности" or
        "keycard" in i_id or
        "ключ-карт" in name or
        "документ" in name or
        "флешк" in name or
        i_id.startswith("relic_")
    )

def get_warehouse_count(user, category):
    stash = user.get("stash", [])
    count = 0
    for itm in stash:
        info = ITEMS_BY_ID.get(itm.get("item_id"), {})
        if category == "valuables":
            if is_item_valuable(info):
                count += 1
        elif category == "gear":
            if info.get("category") == "gear" and not is_item_valuable(info):
                count += 1
        elif info.get("category") == category:
            count += 1
    return count

def can_store_item(user, item_id):
    info = ITEMS_BY_ID.get(item_id, {})
    if is_item_valuable(info):
        cat = "valuables"
    else:
        cat = info.get("category", "gear")
    cap = get_warehouse_capacity(user, cat)
    cnt = get_warehouse_count(user, cat)
    return cnt < cap

# Database management
def load_db():
    with DB_LOCK:
        if not os.path.exists(DB_FILE):
            init_db = {
                "users": {},
                "p2p_market": [],
                "active_duels": {},
                "coop_lobbies": {},
                "economic_crisis": {},
                "airdrop": {"active": False, "last_spawn": 0, "chat_id": None, "message_id": None}
            }
            save_db(init_db)
            return init_db
        try:
            with open(DB_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                data.setdefault("coop_lobbies", {})
                data.setdefault("economic_crisis", {})
                return data
        except Exception:
            return {"users": {}, "p2p_market": [], "active_duels": {}, "coop_lobbies": {}, "economic_crisis": {}, "airdrop": {}}

def save_db(data):
    with DB_LOCK:
        tmp = DB_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, DB_FILE)

@contextlib.contextmanager
def db_transaction():
    """Thread-safe context manager for atomic read-modify-write operations."""
    with DB_LOCK:
        db = load_db()
        yield db
        save_db(db)

def generate_scav_gear(fighter_id):
    """
    Selects starting 'bomzh-gear' strictly from the pool of Common (rarity == 'common') items.
    Each hired Scav gets their unique, fixed set of low-tier common equipment that cannot be detached.
    """
    now = int(time.time())
    common_weapons = [i for i in ITEMS_LIST if i.get("rarity") == "common" and i.get("category") == "weapons"]
    common_armors = [
        i for i in ITEMS_LIST
        if i.get("rarity") == "common" and (i.get("category") in ["armor", "gear"] or i.get("market_cat") == "Экипировка")
        and i.get("subcategory") != "helmet" and "шлем" not in i.get("name", "").lower() and "каска" not in i.get("name", "").lower()
    ]
    common_helmets = [
        i for i in ITEMS_LIST
        if i.get("rarity") == "common" and (
            i.get("subcategory") == "helmet" or
            any(w in i.get("name", "").lower() for w in ["шлем", "каска", "шапка", "ушанка", "кепка", "колпак"])
        )
    ]
    common_headsets = [
        i for i in ITEMS_LIST
        if i.get("rarity") == "common" and (i.get("subcategory") == "headset" or "наушники" in i.get("name", "").lower())
    ]

    items_to_add = []
    uids = {"weapon_uid": None, "armor_uid": None, "helmet_uid": None, "headset_uid": None}

    if common_weapons:
        w_item = random.choice(common_weapons)
        w_uid = f"scav_{fighter_id}_w_{now}_{random.randint(100,999)}"
        items_to_add.append({"uid": w_uid, "item_id": w_item["id"], "equipped_to": fighter_id, "is_scav_locked": True})
        uids["weapon_uid"] = w_uid

    if common_armors:
        a_item = random.choice(common_armors)
        a_uid = f"scav_{fighter_id}_a_{now}_{random.randint(100,999)}"
        items_to_add.append({"uid": a_uid, "item_id": a_item["id"], "equipped_to": fighter_id, "is_scav_locked": True})
        uids["armor_uid"] = a_uid

    if common_helmets:
        h_item = random.choice(common_helmets)
        h_uid = f"scav_{fighter_id}_h_{now}_{random.randint(100,999)}"
        items_to_add.append({"uid": h_uid, "item_id": h_item["id"], "equipped_to": fighter_id, "is_scav_locked": True})
        uids["helmet_uid"] = h_uid

    if common_headsets:
        hs_item = random.choice(common_headsets)
        hs_uid = f"scav_{fighter_id}_hs_{now}_{random.randint(100,999)}"
        items_to_add.append({"uid": hs_uid, "item_id": hs_item["id"], "equipped_to": fighter_id, "is_scav_locked": True})
        uids["headset_uid"] = hs_uid

    return items_to_add, uids

# Starter profile builder
def create_new_player(user_id, username, pmc_signature):
    now = int(time.time())
    is_rev = (username or "").lower().lstrip("@") in ["reventus", "revenuts"]
    if is_rev:
        pmc_signature = "Revenant"
    
    starter_scav_items, starter_scav_uids = generate_scav_gear(1)

    stash_items = [
        {"uid": f"{now}_1", "item_id": "toz_106_common", "equipped_to": None},
        {"uid": f"{now}_2", "item_id": "ak74m_common", "equipped_to": None},
        {"uid": f"{now}_3", "item_id": "ai2_medkit_common", "equipped_to": None},
        {"uid": f"{now}_4", "item_id": "ai2_medkit_common", "equipped_to": None},
        {"uid": f"{now}_5", "item_id": "bandage_common", "equipped_to": None},
        {"uid": f"{now}_6", "item_id": "splint_common", "equipped_to": None},
        {"uid": f"{now}_7", "item_id": "ammo_545_bt_rare", "equipped_to": None},
        {"uid": f"{now}_8", "item_id": "gssh_01_common", "equipped_to": None},
        {"uid": f"{now}_9", "item_id": "kolpak_common", "equipped_to": None}
    ]
    stash_items.extend(starter_scav_items)

    player = {
        "user_id": user_id,
        "username": username or f"PMC_{user_id}",
        "pmc_signature": pmc_signature,
        "registered_at": now,
        "level": 1,
        "exp": 0,
        "money": 500000,
        "btc": 0.0,
        "hideout_lvl": 1,
        "supply_channel_lvl": 1,
        "modules": {k: (1 if k == "generator" else 0) for k in MODULE_NAMES},
        "businesses": {k: 0 for k in BUSINESS_NAMES},
        "special_businesses": {"smugglers_fleet": False, "fence_protection": False},
        "last_npc_p2p_buyout": 0,
        "warehouses": {k: 1 for k in BASE_WAREHOUSE_CAPS},
        "stash": stash_items,
        "clothes_stash": [],
        "equipped_clothes": {"shoes": None, "headwear": None, "suit": None, "accessory": None},
        "squad": [
            {
                "id": 1,
                "type": "scav",
                "name": "Дикий #1",
                "weapon_uid": starter_scav_uids["weapon_uid"],
                "armor_uid": starter_scav_uids["armor_uid"],
                "helmet_uid": starter_scav_uids["helmet_uid"],
                "headset_uid": starter_scav_uids["headset_uid"]
            }
        ],
        "active_delivery": None,
        "last_income_claim": now,
        "last_raid_time": 0,
        "coop_cooldown_until": 0,
        "guard_until": now + 10800,  # 3 hours starter watchman protection
        "last_security_check": now,
        "is_base_captured": False,
        "businesses_blocked": False,
        "stolen_stash": [],
        "stolen_money": 0,
        "stolen_btc": 0.0,
        "security_incidents": [],
        "security_ticks_done": 0,
        "phase3_triggered": False,
        "stats": {
            "raids_count": 0,
            "coop_raids_count": 0,
            "coop_wins": 0,
            "coop_losses": 0,
            "pvp_wins": 0,
            "pvp_losses": 0,
            "airdrop_looted": 0,
            "total_earned_rubles": 0
        }
    }
    return player

# Squad power & armor calculation with all 4 slots (Weapon, Body Armor, Helmet, Headset)
def calculate_squad_power(user):
    squad = user.get("squad", [])
    stash = {itm["uid"]: itm for itm in user.get("stash", [])}
    total_power = 0
    total_armor = 0

    for fighter in squad:
        if fighter.get("type") == "boss":
            base_power = fighter.get("base_power", 50)
            base_armor = fighter.get("base_armor", 30)
        elif fighter.get("type") == "scav":
            base_power = 10
            base_armor = 5
        else:
            base_power = 25
            base_armor = 5

        # 1. Weapon
        w_uid = fighter.get("weapon_uid")
        if w_uid and w_uid in stash:
            item_id = stash[w_uid].get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            base_power += info.get("combat", 0)
            base_armor += info.get("armor", 0)

        # 2. Body Armor
        a_uid = fighter.get("armor_uid")
        if a_uid and a_uid in stash:
            item_id = stash[a_uid].get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            base_armor += info.get("armor", 0)
            base_power += info.get("combat", 0)

        # 3. Helmet
        h_uid = fighter.get("helmet_uid")
        if h_uid and h_uid in stash:
            item_id = stash[h_uid].get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            base_armor += info.get("armor", 0)
            base_power += info.get("combat", 0)

        # 4. Active Headset (sound perception grants combat power & survival defense)
        hs_uid = fighter.get("headset_uid")
        if hs_uid and hs_uid in stash:
            item_id = stash[hs_uid].get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            base_power += info.get("combat", 0)
            base_armor += info.get("armor", 0)

        total_power += base_power
        total_armor += base_armor

    # Hideout modules bonuses:
    mods = user.get("modules", {})
    ammo_lvl = mods.get("ammo_bench", 0)
    wb_lvl = mods.get("workbench", 0)
    med_lvl = mods.get("medblock", 0)
    total_power += ammo_lvl * 3
    total_armor += (wb_lvl * 3) + (med_lvl * 2)

    # Boss relics bonuses from stash
    for itm in user.get("stash", []):
        iid = itm.get("item_id")
        if iid == "tagilla_sledgehammer_legendary":
            total_power += 20
        elif iid == "killa_helmet_legendary":
            total_armor += 30
        elif iid == "glukhar_cap_legendary":
            total_power += 15
            total_armor += 25

    # Mythic gear squad synergies and set bonuses (Goons & Zryachiy sets)
    try:
        from mythic_system import get_squad_mythic_perks
        m_perks = get_squad_mythic_perks(user)
        total_power += m_perks.get("bonus_power", 0)
        total_armor += m_perks.get("bonus_armor", 0)
    except Exception:
        pass

    return total_power, total_armor

def get_player_level(player):
    if not player:
        return 1
    if "level" in player and isinstance(player["level"], (int, float)):
        return max(1, int(player["level"]))
    raids_count = player.get("stats", {}).get("raids_count", 0)
    hideout_lvl = player.get("hideout_lvl", 1)
    lvl = max(1, hideout_lvl + (raids_count // 5))
    player["level"] = lvl
    return lvl

def add_player_exp(player, amount):
    if not player or amount <= 0:
        return False
    current_lvl = get_player_level(player)
    exp = player.get("exp", 0) + amount
    needed = current_lvl * 250
    leveled_up = False
    while exp >= needed:
        exp -= needed
        current_lvl += 1
        needed = current_lvl * 250
        leveled_up = True
    player["level"] = current_lvl
    player["exp"] = exp
    return leveled_up

def get_fighter_hire_cost(player, f_type):
    lvl = get_player_level(player)
    mods = player.get("modules", {})
    water_lvl = mods.get("water_collector", 0)
    water_discount = max(0.60, 1.0 - (water_lvl * 0.02))

    if f_type == "scav":
        base_cost = 10000 + (lvl - 1) * 2500
        if has_buff(player, "scav_discount"):
            base_cost = int(base_cost * 0.80)
        cost = int(base_cost * water_discount)
        return max(5000, cost)
    else: # pmc
        base_cost = 35000 + (lvl - 1) * 10000
        cost = int(base_cost * water_discount)
        return max(20000, cost)

def add_player_rubles(player, amount):
    if not player or amount <= 0:
        return
    player["money"] = player.get("money", 0) + int(amount)
    st = player.setdefault("stats", {})
    st["total_earned_rubles"] = st.get("total_earned_rubles", 0) + int(amount)

# ----------------- BASE GUARD & SECURITY SYSTEMS -----------------

def get_guard_status(player, now=None):
    if now is None:
        now = int(time.time())
    
    # Mythic item check: 📟 Закодированный датчик DSP Смотрителя provides 100% permanent defense
    try:
        from mythic_system import has_mythic_item
        if has_mythic_item(player, "mythic_dsp_sensor"):
            return {
                "status": "active",
                "active": True,
                "badge": "👁️",
                "title": "ДОЗОР ЗРЯЧЕГО (100% Защита / Бессрочно)",
                "unprotected_time": 0,
                "time_left": 86400 * 365,
                "phase": 0,
                "desc": "База и территории ЧВК находятся под круглосуточным снайперским дозором Зрячего. 100% вечная защита от мародеров и захвата!"
            }
    except Exception:
        pass

    if player.get("is_base_captured"):
        unprot = max(0, now - player.get("guard_until", now))
        h = unprot // 3600
        m = (unprot % 3600) // 60
        return {
            "status": "captured",
            "badge": "🚨",
            "title": f"БАЗА ЗАХВАЧЕНА ОТСТУПНИКАМИ! ({h}ч {m}м)",
            "unprotected_time": unprot,
            "time_left": 0,
            "phase": 3,
            "desc": "Все 4 бизнеса заблокированы бандитами. Склады сожжены. Требуется Штурм или Откуп у Скупщика!"
        }
    
    guard_until = player.get("guard_until", 0)
    if guard_until > now:
        time_left = guard_until - now
        hours = time_left // 3600
        mins = (time_left % 3600) // 60
        badge = "🟢" if time_left > 7200 else "🟡"
        return {
            "status": "active",
            "active": True,
            "badge": badge,
            "title": f"Охрана активна ({hours}ч {mins}м)",
            "unprotected_time": 0,
            "time_left": time_left,
            "phase": 0,
            "desc": "Периметр базы надежно защищен от мародеров и рейдерских атак."
        }
    else:
        unprotected = now - guard_until
        hours = unprotected // 3600
        mins = (unprotected % 3600) // 60
        if unprotected < 7200:
            phase = 1
            badge = "🔴"
            title = f"ПРОРЫВ ПЕРИМЕТРА! ({hours}ч {mins}м без охраны)"
            desc = "Фаза 1: Мародеры вскрывают внешние склады. Каждые 40-60 мин исчезает ценное снаряжение!"
        elif unprotected < 21600:
            phase = 2
            badge = "🚨"
            title = f"РАЗГРАБЛЕНИЕ СЕЙФА! ({hours}ч {mins}м без охраны)"
            desc = "Фаза 2: Грабители подогнали грузовик! Исчезают по 2-3 предмета, воруют Bitcoin и наличные из сейфа базы!"
        else:
            phase = 3
            badge = "🔥"
            title = f"ПОДЖОГ И РЕЙДЕРСКИЙ ЗАХВАТ! ({hours}ч {mins}м без охраны)"
            desc = "Фаза 3: База потеряна! Склады сгорели на 1-2 ур., бизнесы захвачены бандитами Отступников!"
        
        return {
            "status": "expired",
            "active": False,
            "badge": badge,
            "title": title,
            "unprotected_time": unprotected,
            "time_left": 0,
            "phase": phase,
            "desc": desc
        }

def _steal_items_from_warehouses(player, categories, count=1):
    stash = player.get("stash", [])
    candidates = []
    for it in stash:
        if it.get("equipped_to") or it.get("is_scav_locked"):
            continue
        info = ITEMS_BY_ID.get(it.get("item_id"), {})
        cat = info.get("category")
        if "valuables" in categories and is_item_valuable(info):
            candidates.append((it, info))
        elif "gear" in categories and cat == "gear" and not is_item_valuable(info):
            candidates.append((it, info))
        elif cat in categories:
            candidates.append((it, info))
    
    if not candidates:
        return []
    
    rarity_scores = {"legendary": 4, "epic": 3, "rare": 2, "common": 1}
    candidates.sort(key=lambda x: (rarity_scores.get(x[1].get("rarity"), 1), x[1].get("price", 0)), reverse=True)
    
    stolen = []
    for i in range(min(count, len(candidates))):
        item_entry, info = candidates[i]
        if item_entry in stash:
            stash.remove(item_entry)
            stolen.append(item_entry)
            player.setdefault("stolen_stash", []).append(item_entry)
            
    return stolen

def evaluate_base_security(player, now=None):
    """
    Evaluates base defense status, calculates chronological consequences if guard expired:
    - Phase 1 (0 - 2 hours without guard): Looters breach external perimeter.
      Every 40-60 min, 1 item stolen from Weapons, Armor, Gear warehouses (prioritizes high rarity/price).
    - Phase 2 (2 - 6 hours without guard): Robbers bring truck.
      Every 45-60 min, 2-3 items stolen from any warehouse. Safe breached: BTC & cash stolen.
    - Phase 3 (> 6 hours without guard): Fire and Rogue Raid Capture!
      Warehouses burned: levels decreased by 1-2 tiers. Excess items over new reduced capacity burned.
      All 4 businesses captured by Rogues: blocked from generating income.
    Returns list of incident alert messages.
    """
    if now is None:
        now = int(time.time())

    # Mythic item check: 📟 Закодированный датчик DSP Смотрителя provides 100% permanent defense
    try:
        from mythic_system import has_mythic_item
        if has_mythic_item(player, "mythic_dsp_sensor"):
            player["guard_until"] = now + 86400 * 365
            player["is_base_captured"] = False
            player["last_security_check"] = now
            return []
    except Exception:
        pass
    
    if "guard_until" not in player:
        player["guard_until"] = now + 10800
        player["last_security_check"] = now
        return []

    guard_until = player.get("guard_until", 0)
    if now <= guard_until:
        player["last_security_check"] = now
        return []

    unprotected = now - guard_until
    incidents = []

    # Milestone intervals:
    # Phase 1 (0 to 7200s): ticks at 3000s (~50 min) and 6000s (~100 min)
    # Phase 2 (7200s to 21600s): ticks at 10800s (3h), 14400s (4h), 18000s (5h), 21600s (6h)
    ticks_milestones = [
        (1, 3000, 1),
        (2, 6000, 1),
        (3, 10800, 2),
        (4, 14400, 2),
        (5, 18000, 2),
        (6, 21600, 2),
    ]

    current_ticks_done = player.get("security_ticks_done", 0)

    for tick_id, threshold, phase in ticks_milestones:
        if unprotected >= threshold and current_ticks_done < tick_id:
            if phase == 1:
                stolen_items = _steal_items_from_warehouses(player, categories=["weapons", "armor", "gear"], count=1)
                if stolen_items:
                    item_info = ITEMS_BY_ID.get(stolen_items[0]["item_id"], {})
                    r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(item_info.get("rarity"), "⬜")
                    incidents.append(f"⚠️ [Фаза 1: Взлом складов] Мародеры унесли со склада: {r_b} {item_info.get('name', 'Оружие/снаряжение')}!")
            elif phase == 2:
                cnt_to_steal = random.randint(2, 3)
                stolen_items = _steal_items_from_warehouses(player, categories=["weapons", "armor", "gear", "components", "valuables"], count=cnt_to_steal)
                
                stolen_money = 0
                if player.get("money", 0) > 0:
                    max_steal = max(25000, int(player.get("money", 0) * 0.12))
                    stolen_money = min(player["money"], random.randint(25000, max(25000, max_steal)))
                    player["money"] -= stolen_money
                    player["stolen_money"] = player.get("stolen_money", 0) + stolen_money
                
                stolen_btc = 0.0
                if player.get("btc", 0.0) > 0:
                    stolen_btc = min(player["btc"], round(random.uniform(0.04, 0.15), 4))
                    player["btc"] = round(player["btc"] - stolen_btc, 4)
                    player["stolen_btc"] = round(player.get("stolen_btc", 0.0) + stolen_btc, 4)
                
                msg_parts = []
                if stolen_items:
                    msg_parts.append(f"{len(stolen_items)} ценных предметов")
                if stolen_money > 0:
                    msg_parts.append(fmt_rub(stolen_money))
                if stolen_btc > 0:
                    msg_parts.append(f"{stolen_btc:.4f} BTC")
                loot_str = ", ".join(msg_parts) if msg_parts else "часть припасов"
                incidents.append(f"🚨 [Фаза 2: Разграбление сейфа] Грабители на грузовике вскрыли сейф и похитили: {loot_str}!")

            player["security_ticks_done"] = tick_id

    # Phase 3: > 6 hours (21600 seconds)
    if unprotected >= 21600 and not player.get("phase3_triggered", False):
        player["phase3_triggered"] = True
        player["is_base_captured"] = True
        player["businesses_blocked"] = True

        burned_items_count = 0
        stash = player.get("stash", [])
        for cat in ["weapons", "armor", "gear", "components", "valuables"]:
            lvl = player.get("warehouses", {}).get(cat, 1)
            loss = random.choice([1, 2]) if lvl >= 3 else (1 if lvl == 2 else 0)
            new_lvl = max(1, lvl - loss)
            player["warehouses"][cat] = new_lvl

            cap = get_warehouse_capacity(player, cat)
            matching_unequipped = []
            for it in stash:
                if it.get("equipped_to") or it.get("is_scav_locked"):
                    continue
                info = ITEMS_BY_ID.get(it.get("item_id"), {})
                if cat == "valuables" and is_item_valuable(info):
                    matching_unequipped.append(it)
                elif cat == "gear" and info.get("category") == "gear" and not is_item_valuable(info):
                    matching_unequipped.append(it)
                elif info.get("category") == cat:
                    matching_unequipped.append(it)

            if len(matching_unequipped) > cap:
                excess = len(matching_unequipped) - cap
                burned = matching_unequipped[:excess]
                for b in burned:
                    if b in stash:
                        stash.remove(b)
                burned_items_count += len(burned)

        incidents.append(
            f"🔥 [Фаза 3: ПОДЖОГ И РЕЙДЕРСКИЙ ЗАХВАТ] База захвачена Отступниками (Rogues)! "
            f"Склады понижены в уровнях, сгорело в пепел {burned_items_count} предметов! "
            f"Все бизнесы заблокированы бандитами. Доход перехвачен рейдерами!"
        )

    player["last_security_check"] = now
    if incidents:
        player.setdefault("security_incidents", []).extend(incidents)
        player["security_incidents"] = player["security_incidents"][-10:]
    return incidents

def buy_guard_contract(player, contract_id, now=None):
    if now is None:
        now = int(time.time())

    if player.get("is_base_captured"):
        return False, "❌ Ваша база захвачена Отступниками! Охрану нанимать некуда. Сначала освободите базу через Штурм или Откуп у Скупщика!"

    cfg = BASE_GUARD_CONTRACTS.get(contract_id)
    if not cfg:
        return False, "❌ Неизвестный тип контракта охраны."

    cost = cfg["cost"]
    if player.get("money", 0) < cost:
        return False, f"❌ Недостаточно рублей! Стоимость контракта: {fmt_rub(cost)}."

    duration = cfg["duration"]
    cur_guard = player.get("guard_until", 0)

    if cur_guard > now:
        new_until = cur_guard + duration
    else:
        new_until = now + duration

    # Enforce maximum 24h guard cap:
    # "Максимальный контракт (20 часов — меньше суток!). Игрок ОБЯЗАН заходить в игру хотя бы раз в день, чтобы продлить договор."
    max_cap = now + 86400
    if new_until > max_cap:
        new_until = max_cap

    player["money"] -= cost
    player["guard_until"] = new_until
    player["security_ticks_done"] = 0
    player["phase3_triggered"] = False
    player["last_security_check"] = now

    hours_total = (new_until - now) // 3600
    mins_total = ((new_until - now) % 3600) // 60
    return True, f"✅ Контракт «{cfg['name']}» успешно оформлен!\n🛡️ База под надежной охраной еще {hours_total}ч {mins_total}м."

def recover_base_assault(player, now=None):
    if now is None:
        now = int(time.time())

    squad = player.get("squad", [])
    if not squad or len(squad) == 0:
        return False, {
            "success": False,
            "msg": "❌ В вашем отряде нет бойцов! Штурмовать захваченную базу некому. Наймите бойцов в меню Отряда."
        }

    pow_val, arm_val = calculate_squad_power(player)
    # Extreme difficulty: Rogue Boss with elite bodyguards (Difficulty 240)
    combined_stat = (pow_val * 1.2) + (arm_val * 0.8)
    win_chance = min(0.85, max(0.12, (combined_stat / (combined_stat + 240)) * 1.30))
    if has_buff(player, "pvp_bonus"):
        win_chance = min(0.92, win_chance + 0.10)
    if has_boss_set_bonus(player, "killa"):
        win_chance = min(0.95, win_chance + 0.50)

    win_roll = random.random() < win_chance

    if win_roll:
        player["is_base_captured"] = False
        player["businesses_blocked"] = False
        player["phase3_triggered"] = False
        player["security_ticks_done"] = 0
        player["guard_until"] = now + 10800  # 3 hours emergency guard
        player["last_security_check"] = now

        # Recover stolen items
        stolen = player.get("stolen_stash", [])
        recovered_items = []
        stash = player.setdefault("stash", [])
        for itm in stolen:
            stash.append(itm)
            recovered_items.append(itm)
        player["stolen_stash"] = []

        rec_rubles = max(350000, player.get("stolen_money", 0) // 2)
        rec_btc = max(0.2, round(player.get("stolen_btc", 0.0) * 0.5, 4))
        add_player_rubles(player, rec_rubles)
        player["btc"] = round(player.get("btc", 0.0) + rec_btc, 4)
        player["stolen_money"] = 0
        player["stolen_btc"] = 0.0

        boss_trophy = None
        clean_legendary = [it for it in ITEMS_LIST if it.get("rarity") == "legendary"]
        if clean_legendary:
            boss_trophy = random.choice(clean_legendary)
            stash.append({
                "uid": f"assault_trophy_{now}_{random.randint(100,999)}",
                "item_id": boss_trophy["id"],
                "equipped_to": None
            })

        add_player_exp(player, 250)

        return True, {
            "success": True,
            "recovered_items_count": len(recovered_items),
            "recovered_rubles": rec_rubles,
            "recovered_btc": rec_btc,
            "boss_trophy": boss_trophy,
            "win_chance_pct": round(win_chance * 100, 1)
        }
    else:
        # Defeat losses
        stash = player.get("stash", [])
        dead_scavs = 0
        injured_pmcs = 0
        stripped_items_count = 0

        surviving_squad = []
        for fighter in squad:
            for slot_key in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
                uid = fighter.get(slot_key)
                if uid:
                    item_entry = next((i for i in stash if i.get("uid") == uid), None)
                    if item_entry:
                        stash.remove(item_entry)
                        stripped_items_count += 1
                    fighter[slot_key] = None

            if fighter.get("type") == "scav":
                dead_scavs += 1
            else:
                injured_pmcs += 1
                surviving_squad.append(fighter)

        player["squad"] = surviving_squad
        player["is_base_captured"] = True
        player["businesses_blocked"] = True

        return False, {
            "success": False,
            "dead_scavs": dead_scavs,
            "injured_pmcs": injured_pmcs,
            "stripped_items_count": stripped_items_count,
            "win_chance_pct": round(win_chance * 100, 1)
        }

def recover_base_fence(player, now=None):
    if now is None:
        now = int(time.time())

    if not player.get("is_base_captured"):
        return False, "⚠️ Ваша база не находится под контролем рейдеров."

    cost_rubles = max(1000000, int(player.get("money", 0) * 0.40))
    cost_btc = 1.0

    cur_money = player.get("money", 0)
    cur_btc = player.get("btc", 0.0)

    if cur_money < cost_rubles or cur_btc < cost_btc:
        needed_msg = (
            f"❌ <b>Скупщик усмехается и качает головой:</b>\n\n"
            f"<i>«Ты меня за кого держишь? Моя такса: 40% твоих денег (но не менее 1 000 000 ₽) и ровно 1 Bitcoin!</i>\n\n"
            f"• Требуется: <b>{fmt_rub(cost_rubles)}</b> и <b>1.0 BTC</b>\n"
            f"• У вас на руках: <b>{fmt_rub(cur_money)}</b> и <b>{cur_btc:.4f} BTC</b>\n\n"
            f"Приходи, когда соберешь нужную сумму, или собирай отряд на кровавый штурм!»"
        )
        return False, needed_msg

    player["money"] -= cost_rubles
    player["btc"] = round(cur_btc - cost_btc, 4)

    player["is_base_captured"] = False
    player["businesses_blocked"] = False
    player["phase3_triggered"] = False
    player["security_ticks_done"] = 0
    player["guard_until"] = now + 10800  # 3 hours emergency guard
    player["last_security_check"] = now

    msg = (
        f"🤝 <b>СДЕЛКА СО СКУПЩИКОМ ЗАКЛЮЧЕНА!</b>\n\n"
        f"Скупщик передал взятку авторитетам Отступников. Бандиты покинули ваши предприятия.\n"
        f"• Уплачено: -<b>{fmt_rub(cost_rubles)}</b> и -<b>1.0 BTC</b>\n"
        f"• Бизнесы: <b>Разблокированы</b> (пассивный доход снова начисляется вам)\n"
        f"• Склады: <i>Остаются поврежденными пожаром (уровни понижены)</i>\n"
        f"• Охрана: Скупщик выставил временный караул на <b>3 часа</b>."
    )
    return True, msg
