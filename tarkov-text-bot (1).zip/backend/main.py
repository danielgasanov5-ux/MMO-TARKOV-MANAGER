import os
import json
import uuid
from typing import Optional, List
from fastapi import FastAPI, Depends, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from database import engine, Base, get_db
from models import Player, StashCellModel, EquippedGearModel, RaidSessionModel
from schemas import (
    StashResponse, StashCellSchema, EquippedGearSchema,
    MarketResponse, MarketItemSchema, BuyItemRequest, BuyItemResponse,
    SellItemRequest, SellItemResponse, SellAllResponse,
    EquipItemRequest, UnequipItemRequest,
    ReturnFriendGearRequest, ReturnFriendGearResponse,
    RaidStartRequest, RaidActionRequest, RaidStageStateSchema, RaidActionResultSchema,
    PlayerProfileResponse, TarkovItemSchema
)
from telegram_auth import get_current_user, TelegramUser
from data_seed import STARTER_EQUIPMENT, STARTER_STASH_ITEMS, PRAPOR_MARKET_CATALOG
from raid_engine import generate_stage_state, resolve_raid_choice

# Initialize database schema tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Tarkov Mini App - Fullstack Backend",
    description="Python FastAPI backend for Escape from Tarkov Telegram Mini App with Story-Branching Matrix",
    version="2.0.0"
)

# CORS configuration
origins = os.getenv("CORS_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins if origins != ["*"] else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_or_create_player(db: Session, tg_user: TelegramUser) -> Player:
    player = db.query(Player).filter(Player.telegram_id == tg_user.id).first()
    if not player:
        player = Player(
            telegram_id=tg_user.id,
            username=tg_user.username or f"PMC_{tg_user.id}",
            callsign="Гроза",
            faction="BEAR",
            level=1,
            exp=0,
            next_level_exp=1000,
            rubles=350000,
            prapor_rep=0.20,
            prapor_spent=120000
        )
        db.add(player)
        db.commit()
        db.refresh(player)

        # Create 100 stash cells
        stash_map = {item["index"]: item["item"] for item in STARTER_STASH_ITEMS}
        for i in range(100):
            item_data = stash_map.get(i, None)
            cell = StashCellModel(
                player_id=player.id,
                cell_index=i,
                item_json=json.dumps(item_data) if item_data else None
            )
            db.add(cell)

        # Create starter equipment
        equip = EquippedGearModel(
            player_id=player.id,
            weapon_json=json.dumps(STARTER_EQUIPMENT.get("weapon")),
            armor_json=json.dumps(STARTER_EQUIPMENT.get("armor")),
            helmet_json=json.dumps(STARTER_EQUIPMENT.get("helmet")),
            rig_json=json.dumps(STARTER_EQUIPMENT.get("rig")),
            headset_json=json.dumps(STARTER_EQUIPMENT.get("headset")),
            secure_container_json=json.dumps(STARTER_EQUIPMENT.get("secureContainer"))
        )
        db.add(equip)
        db.commit()
        db.refresh(player)

    return player

@app.get("/api/health")
def health_check():
    return {"status": "ok", "service": "tarkov-miniapp-backend", "engine": "FastAPI+SQLite"}

@app.get("/api/profile", response_model=PlayerProfileResponse)
def get_profile(
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    return PlayerProfileResponse(
        id=player.id,
        telegramId=player.telegram_id,
        username=player.username,
        callsign=player.callsign,
        faction=player.faction,
        level=player.level,
        exp=player.exp,
        nextLevelExp=player.next_level_exp,
        rubles=player.rubles,
        dollars=player.dollars,
        euros=player.euros,
        praporRep=player.prapor_rep,
        praporSpent=player.prapor_spent,
        raidsCount=player.raids_count,
        survivedCount=player.survived_count,
        killsCount=player.kills_count
    )

# 1. Stash: 10x10 Grid & Equipped Gear
@app.get("/api/stash", response_model=StashResponse)
def get_stash(
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    cells_db = db.query(StashCellModel).filter(StashCellModel.player_id == player.id).order_by(StashCellModel.cell_index).all()
    
    cell_schemas = []
    total_value = 0
    free_slots = 0
    
    for c in cells_db:
        item_obj = json.loads(c.item_json) if c.item_json else None
        if item_obj:
            total_value += item_obj.get("price", 0)
            cell_schemas.append(StashCellSchema(index=c.cell_index, item=TarkovItemSchema(**item_obj)))
        else:
            free_slots += 1
            cell_schemas.append(StashCellSchema(index=c.cell_index, item=None))

    equip_db = db.query(EquippedGearModel).filter(EquippedGearModel.player_id == player.id).first()
    equipped_schema = EquippedGearSchema(
        weapon=TarkovItemSchema(**json.loads(equip_db.weapon_json)) if equip_db and equip_db.weapon_json else None,
        armor=TarkovItemSchema(**json.loads(equip_db.armor_json)) if equip_db and equip_db.armor_json else None,
        helmet=TarkovItemSchema(**json.loads(equip_db.helmet_json)) if equip_db and equip_db.helmet_json else None,
        rig=TarkovItemSchema(**json.loads(equip_db.rig_json)) if equip_db and equip_db.rig_json else None,
        headset=TarkovItemSchema(**json.loads(equip_db.headset_json)) if equip_db and equip_db.headset_json else None,
        secureContainer=TarkovItemSchema(**json.loads(equip_db.secure_container_json)) if equip_db and equip_db.secure_container_json else None
    )

    return StashResponse(
        cells=cell_schemas,
        equipped=equipped_schema,
        freeSlots=free_slots,
        totalSlots=100,
        stashValue=total_value,
        rubles=player.rubles
    )

@app.post("/api/stash/equip", response_model=StashResponse)
def equip_item(
    req: EquipItemRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    cell = db.query(StashCellModel).filter(
        StashCellModel.player_id == player.id,
        StashCellModel.cell_index == req.cellIndex
    ).first()
    if not cell or not cell.item_json:
        raise HTTPException(status_code=400, detail="Ячейка схрона пуста")

    item_to_equip = json.loads(cell.item_json)
    equip_db = db.query(EquippedGearModel).filter(EquippedGearModel.player_id == player.id).first()
    if not equip_db:
        raise HTTPException(status_code=404, detail="Экипировка не найдена")

    slot_field = f"{req.slotType}_json"
    if not hasattr(equip_db, slot_field):
        raise HTTPException(status_code=400, detail=f"Неизвестный слот снаряжения: {req.slotType}")

    # Swap item currently in slot back to cell
    current_in_slot = getattr(equip_db, slot_field)
    cell.item_json = current_in_slot
    setattr(equip_db, slot_field, json.dumps(item_to_equip))

    db.commit()
    return get_stash(db=db, user=user)

@app.post("/api/stash/unequip", response_model=StashResponse)
def unequip_item(
    req: UnequipItemRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    equip_db = db.query(EquippedGearModel).filter(EquippedGearModel.player_id == player.id).first()
    if not equip_db:
        raise HTTPException(status_code=404, detail="Экипировка не найдена")

    slot_field = f"{req.slotType}_json"
    if not hasattr(equip_db, slot_field) or not getattr(equip_db, slot_field):
        raise HTTPException(status_code=400, detail="Слот уже пуст")

    empty_cell = db.query(StashCellModel).filter(
        StashCellModel.player_id == player.id,
        StashCellModel.item_json == None
    ).order_by(StashCellModel.cell_index).first()

    if not empty_cell:
        raise HTTPException(status_code=400, detail="Схрон полон, нет свободной ячейки")

    item_json = getattr(equip_db, slot_field)
    empty_cell.item_json = item_json
    setattr(equip_db, slot_field, None)

    db.commit()
    return get_stash(db=db, user=user)

# 2. Market with Prapor bundles & Pagination
@app.get("/api/market", response_model=MarketResponse)
def get_market(
    page: int = Query(1, ge=1),
    limit: int = Query(6, ge=1, le=20),
    category: Optional[str] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    
    items = PRAPOR_MARKET_CATALOG
    if category and category != "all":
        items = [x for x in items if x["item"]["category"] == category]
    if search:
        s = search.lower()
        items = [x for x in items if s in x["item"]["name"].lower() or s in x["item"]["shortName"].lower()]
        
    total = len(items)
    total_pages = max(1, (total + limit - 1) // limit)
    start_idx = (page - 1) * limit
    paged = items[start_idx : start_idx + limit]
    
    # Calculate loyalty level: LL1 default, LL2 >= 750k & 0.20 rep, LL3 >= 1.6M & 0.35, LL4 >= 2.8M & 0.60
    current_ll = 1
    if player.prapor_spent >= 2800000 and player.prapor_rep >= 0.60:
        current_ll = 4
    elif player.prapor_spent >= 1600000 and player.prapor_rep >= 0.35:
        current_ll = 3
    elif player.prapor_spent >= 750000 and player.prapor_rep >= 0.20:
        current_ll = 2
        
    return MarketResponse(
        items=[MarketItemSchema(**x) for x in paged],
        page=page,
        limit=limit,
        total=total,
        totalPages=total_pages,
        praporRep=player.prapor_rep,
        praporSpent=player.prapor_spent,
        playerRubles=player.rubles,
        currentLoyaltyLevel=current_ll
    )

@app.post("/api/market/buy", response_model=BuyItemResponse)
def buy_market_item(
    req: BuyItemRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    catalog_item = next((x for x in PRAPOR_MARKET_CATALOG if x["id"] == req.marketItemId), None)
    if not catalog_item:
        raise HTTPException(status_code=404, detail="Товар не найден на Барахолке Прапора")
        
    price = catalog_item["price"] * req.quantity
    if player.rubles < price:
        raise HTTPException(status_code=400, detail="Недостаточно рублей у бойца")
        
    # Find free stash cell
    empty_cell = db.query(StashCellModel).filter(
        StashCellModel.player_id == player.id,
        StashCellModel.item_json == None
    ).order_by(StashCellModel.cell_index).first()
    
    if not empty_cell:
        raise HTTPException(status_code=400, detail="Схрон заполнен (0 свободных ячеек из 100)")
        
    # Deduct rubles and update Prapor stats
    player.rubles -= price
    player.prapor_spent += price
    player.prapor_rep = round(player.prapor_rep + 0.02, 2)
    
    bought_item = catalog_item["item"].copy()
    bought_item["id"] = f"{bought_item['id']}-{uuid.uuid4().hex[:6]}"
    empty_cell.item_json = json.dumps(bought_item)
    
    db.commit()
    db.refresh(player)
    
    return BuyItemResponse(
        success=True,
        message=f"Приобретено: {bought_item['name']} за {price:,} ₽",
        boughtItem=TarkovItemSchema(**bought_item),
        newRubles=player.rubles,
        praporRep=player.prapor_rep,
        praporSpent=player.prapor_spent,
        placedIndex=empty_cell.cell_index
    )

# 3. Sell All: One-button sell of junk/barter/damaged loot with dynamic durability scaling
@app.post("/api/sell_all", response_model=SellAllResponse)
def sell_all_junk(
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    cells = db.query(StashCellModel).filter(
        StashCellModel.player_id == player.id,
        StashCellModel.item_json != None
    ).all()
    
    total_rubles = 0
    sold_count = 0
    
    for c in cells:
        item = json.loads(c.item_json)
        # Sell barter, keys, surplus armor or quest loot
        if item.get("category") in ["barter", "keys", "armor"] or item.get("name", "").startswith("Военная") or "Хабар" in item.get("description", ""):
            price = item.get("price", 0)
            
            # Dynamic durability price scaling
            dura = item.get("durability")
            if dura and isinstance(dura, dict) and dura.get("max", 0) > 0:
                curr = dura.get("current", dura.get("max", 1))
                ratio = max(0.1, curr / dura["max"])
                price = int(price * ratio)
                
            total_rubles += price
            sold_count += 1
            c.item_json = None
            
    if sold_count == 0:
        return SellAllResponse(
            success=False,
            itemsSold=0,
            rublesEarned=0,
            newRubles=player.rubles,
            praporRep=player.prapor_rep,
            praporSpent=player.prapor_spent,
            message="В схроне нет бартерного хлама или поврежденного снаряжения для срочной продажи Прапору."
        )
        
    player.rubles += total_rubles
    player.prapor_spent += total_rubles
    player.prapor_rep = round(player.prapor_rep + (0.01 * min(10, sold_count)), 2)
    
    db.commit()
    db.refresh(player)
    
    return SellAllResponse(
        success=True,
        itemsSold=sold_count,
        rublesEarned=total_rubles,
        newRubles=player.rubles,
        praporRep=player.prapor_rep,
        praporSpent=player.prapor_spent,
        message=f"Прапор выкупил {sold_count} предметов на сумму {total_rubles:,} ₽ с учетом износа!"
    )

# 4. Raid Engine: Start, Action & Friend Gear Recovery
@app.post("/api/raid/start", response_model=RaidStageStateSchema)
def start_raid(
    req: RaidStartRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    player.raids_count += 1
    
    raid_id = f"raid-{uuid.uuid4().hex[:8]}"
    initial_log = [
        f"Оперативник {player.callsign} проник на локацию '{req.locationId.upper()}'.",
        "Сформирована ветвящаяся матрица сценариев. Начат этап 1 из 15."
    ]
    
    session = RaidSessionModel(
        id=raid_id,
        player_id=player.id,
        location_id=req.locationId,
        tactic_id=req.tacticId,
        current_stage=1,
        max_stages=15,
        health=440,
        max_health=440,
        kills=0,
        exp_earned=100,
        rubles_found=0,
        damage_taken=0,
        friend_gear_found=False,
        friend_gear_secured=False,
        partner_status="ok",
        partner_hp=100,
        injuries_json="[]",
        standard_loot_json="[]",
        secure_container_loot_json="[]",
        logs_json=json.dumps(initial_log)
    )
    db.add(session)
    db.commit()
    
    return generate_stage_state(
        raid_id=raid_id,
        stage_idx=1,
        health=440,
        kills=0,
        exp_earned=100,
        rubles_found=0,
        damage_taken=0,
        friend_gear_found=False,
        friend_gear_secured=False,
        standard_loot=[],
        secure_loot=[],
        logs=initial_log,
        partner_status="ok",
        partner_hp=100,
        injuries=[],
        location_id=req.locationId
    )

@app.post("/api/raid/action", response_model=RaidActionResultSchema)
def raid_action(
    req: RaidActionRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    session = db.query(RaidSessionModel).filter(RaidSessionModel.id == req.raidId).first()
    if not session:
        raise HTTPException(status_code=404, detail="Активная сессия рейда не найдена")
    if session.is_finished:
        raise HTTPException(status_code=400, detail="Этот рейд уже завершен")
        
    player = session.player
    standard_loot = json.loads(session.standard_loot_json)
    secure_loot = json.loads(session.secure_container_loot_json)
    logs = json.loads(session.logs_json)
    injuries = json.loads(session.injuries_json or "[]")

    equip_db = db.query(EquippedGearModel).filter(EquippedGearModel.player_id == player.id).first()
    equipped_weapon = json.loads(equip_db.weapon_json) if equip_db and equip_db.weapon_json else None
    equipped_armor = json.loads(equip_db.armor_json) if equip_db and equip_db.armor_json else None
    
    (
        new_health, damage, kills_gain, exp_gain, rubles_gain,
        friend_gear_found, friend_gear_secured,
        partner_status, partner_hp, injuries,
        standard_loot, secure_loot, outcome_text, newly_found,
        is_finished, is_survived
    ) = resolve_raid_choice(
        current_stage=session.current_stage,
        choice_id=req.choiceId,
        health=session.health,
        tactic_id=session.tactic_id,
        friend_gear_found=session.friend_gear_found,
        friend_gear_secured=session.friend_gear_secured,
        standard_loot=standard_loot,
        secure_loot=secure_loot,
        partner_status=session.partner_status,
        partner_hp=session.partner_hp,
        injuries=injuries,
        equipped_weapon=equipped_weapon,
        equipped_armor=equipped_armor,
        location_id=session.location_id
    )
    
    session.health = new_health
    session.damage_taken += damage
    session.kills += kills_gain
    session.exp_earned += exp_gain
    session.rubles_found += rubles_gain
    session.friend_gear_found = friend_gear_found
    session.friend_gear_secured = friend_gear_secured
    session.partner_status = partner_status
    session.partner_hp = partner_hp
    session.injuries_json = json.dumps(injuries)
    session.standard_loot_json = json.dumps(standard_loot)
    session.secure_container_loot_json = json.dumps(secure_loot)
    
    logs.append(f"[Этап {session.current_stage}/15] {outcome_text}")
    
    status_state = "continue"
    
    # Check KIA
    if session.health <= 0:
        session.is_finished = True
        session.is_survived = False
        status_state = "kia"
        logs.append("КРИТИЧЕСКИЙ УРОН: Оперативник погиб в бою (M.I.A).")
        
        # Transfer secure container items to stash!
        for sec_item in secure_loot:
            empty_cell = db.query(StashCellModel).filter(
                StashCellModel.player_id == player.id,
                StashCellModel.item_json == None
            ).first()
            if empty_cell:
                empty_cell.item_json = json.dumps(sec_item)
                
        player.exp += session.exp_earned // 2
        
    # Check Survival (early extract or stage 15 completed)
    elif is_finished or session.current_stage >= 15 or "extract" in req.choiceId:
        session.is_finished = True
        session.is_survived = True
        status_state = "survived"
        player.survived_count += 1
        
        # Add bonus for friend's gear rescue
        friend_bonus = 150000 if session.friend_gear_found else 0
        if session.friend_gear_secured:
            friend_bonus += 50000
            
        player.rubles += session.rubles_found + friend_bonus
        player.exp += session.exp_earned + (1000 if session.friend_gear_found else 0)
        player.kills_count += session.kills
        
        # Level up check
        if player.exp >= player.next_level_exp:
            player.level += 1
            player.next_level_exp = int(player.next_level_exp * 1.5)
            
        # Place all retrieved loot (standard + secure) into stash
        all_loot = standard_loot + secure_loot
        for loot_item in all_loot:
            empty_cell = db.query(StashCellModel).filter(
                StashCellModel.player_id == player.id,
                StashCellModel.item_json == None
            ).first()
            if empty_cell:
                empty_cell.item_json = json.dumps(loot_item)
                
        logs.append("УСПЕШНАЯ ЭВАКУАЦИЯ: Весь вынесенный хабар и спасенный шмот напарника доставлены в схрон!")
    else:
        session.current_stage += 1
        
    session.logs_json = json.dumps(logs)
    db.commit()
    db.refresh(session)
    db.refresh(player)
    
    stage_state = generate_stage_state(
        raid_id=session.id,
        stage_idx=session.current_stage,
        health=session.health,
        kills=session.kills,
        exp_earned=session.exp_earned,
        rubles_found=session.rubles_found,
        damage_taken=session.damage_taken,
        friend_gear_found=session.friend_gear_found,
        friend_gear_secured=session.friend_gear_secured,
        standard_loot=standard_loot,
        secure_loot=secure_loot,
        logs=logs,
        partner_status=session.partner_status,
        partner_hp=session.partner_hp,
        injuries=injuries,
        location_id=session.location_id,
        is_finished=session.is_finished,
        is_survived=session.is_survived
    )
    
    return RaidActionResultSchema(
        stage=stage_state,
        outcomeText=outcome_text,
        damageTakenThisTurn=damage,
        newItemsFound=[TarkovItemSchema(**x) for x in newly_found],
        status=status_state
    )

@app.post("/api/raid/return_friend_gear", response_model=ReturnFriendGearResponse)
def return_friend_gear(
    req: ReturnFriendGearRequest,
    db: Session = Depends(get_db),
    user: TelegramUser = Depends(get_current_user)
):
    player = get_or_create_player(db, user)
    reward = 120000
    rep_gain = 0.08
    player.rubles += reward
    player.prapor_rep = round(player.prapor_rep + rep_gain, 2)
    db.commit()

    return ReturnFriendGearResponse(
        success=True,
        message=f"Снаряжение и жетон напарника {req.friendUsername} успешно возвращены законному владельцу через Прапора! Получено вознаграждение за верность.",
        returnedItems=[],
        reputationGain=rep_gain,
        rewardRubles=reward
    )

# 5. ZIP download endpoint
@app.get("/api/download-zip")
def download_project_zip():
    zip_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "public", "tarkov-miniapp-fullstack.zip")
    if not os.path.exists(zip_path):
        raise HTTPException(status_code=404, detail="ZIP архив еще не собран")
    return FileResponse(
        path=zip_path,
        filename="tarkov-miniapp-fullstack.zip",
        media_type="application/zip"
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", 8000)), reload=True)
