"""
Tarkov Raid Engine with Dynamic Story-Branching Matrix, Injury System, Ballistics & Early Extraction
"""

import random
import uuid
import json
from typing import Dict, Any, List, Tuple, Optional
from schemas import TarkovItemSchema, TacticalChoiceSchema, RaidStageStateSchema
from raid_events_pool import RAID_EVENTS_POOL, get_events_for_stage

# High-value Tarkov items pool found during raids
RAID_LOOT_POOL = [
    {
        "id": "loot-ledx",
        "name": "Медицинский трансиллюминатор LEDX",
        "shortName": "LEDX",
        "category": "barter",
        "description": "Ультраредкий военный медицинский прибор. Самый дорогой бартерный предмет в Таркове.",
        "price": 680000,
        "rarity": "classified",
        "slots": 1,
        "weight": 0.2,
        "iconName": "HeartPulse",
        "inRaid": True
    },
    {
        "id": "loot-bitcoin",
        "name": "Физический Биткоин (0.2 BTC)",
        "shortName": "Биткоин",
        "category": "barter",
        "description": "Монета из чистого золота с приватным ключом. Невероятная ценность у скупщика.",
        "price": 380000,
        "rarity": "classified",
        "slots": 1,
        "weight": 0.1,
        "iconName": "CircleDollarSign",
        "inRaid": True
    },
    {
        "id": "loot-gpu",
        "name": "Видеокарта NVIDIA GeForce RTX 4090",
        "shortName": "RTX 4090",
        "category": "barter",
        "description": "Топовый графический процессор для майнинг-фермы в Убежище. Ценный хабар.",
        "price": 450000,
        "rarity": "classified",
        "slots": 2,
        "weight": 1.4,
        "iconName": "Cpu",
        "inRaid": True
    },
    {
        "id": "loot-altyn",
        "name": "Штурмовой шлем 'Алтын' с забралом (Класс 5)",
        "shortName": "Алтын с забралом",
        "category": "armor",
        "description": "Легендарный титановый шлем с пулестойким стеклом 5 класса защиты.",
        "price": 280000,
        "rarity": "epic",
        "slots": 2,
        "weight": 3.9,
        "armorClass": 5,
        "durability": {"current": 50, "max": 50},
        "iconName": "Shield",
        "inRaid": True
    },
    {
        "id": "loot-m4a1-friend",
        "name": "Тюнингованный карабин Colt M4A1 (Оружие Гюрзы)",
        "shortName": "M4A1 Гюрзы",
        "category": "weapons",
        "description": "Именное оружие боевого товарища. Глушитель KAC, прицел EOTech, рукоятка Magpul.",
        "price": 185000,
        "rarity": "epic",
        "slots": 2,
        "weight": 3.8,
        "caliber": "5.56x45 мм",
        "durability": {"current": 95, "max": 100},
        "iconName": "Crosshair",
        "inRaid": True
    },
    {
        "id": "loot-val-mag",
        "name": "Винтовка специальная снайперская ВСС 'Винторез'",
        "shortName": "ВСС Винторез",
        "category": "weapons",
        "description": "Бесшумный снайперский комплекс калибра 9x39 мм со встроенным глушителем.",
        "price": 195000,
        "rarity": "epic",
        "slots": 2,
        "weight": 3.4,
        "caliber": "9x39 мм",
        "durability": {"current": 100, "max": 100},
        "iconName": "Crosshair",
        "inRaid": True
    },
    {
        "id": "loot-korund",
        "name": "Бронежилет Корунд-ВМ (Класс 5)",
        "shortName": "Корунд-ВМ",
        "category": "armor",
        "description": "Тяжелый армейский бронежилет 5 класса защиты с керамическими бронеплитами.",
        "price": 220000,
        "rarity": "epic",
        "slots": 2,
        "weight": 9.5,
        "armorClass": 5,
        "durability": {"current": 45, "max": 45},
        "iconName": "Shield",
        "inRaid": True
    },
    {
        "id": "loot-dogtag-friend",
        "name": "Золотой жетон ЧВК (Позывной 'Гюрза', ур. 42)",
        "shortName": "Жетон Гюрзы",
        "category": "barter",
        "description": "Именной армейский жетон товарища. Прапор щедро отблагодарит за его спасение.",
        "price": 120000,
        "rarity": "epic",
        "slots": 1,
        "weight": 0.05,
        "iconName": "Award",
        "inRaid": True
    },
    {
        "id": "loot-flashdrive",
        "name": "Зашифрованный военный Flash Drive (Секретные данные)",
        "shortName": "Флешка",
        "category": "barter",
        "description": "USB-накопитель с грифом 'СОВ. СЕКРЕТНО'. Разведданные для Прапора.",
        "price": 95000,
        "rarity": "rare",
        "slots": 1,
        "weight": 0.05,
        "iconName": "Zap",
        "inRaid": True
    },
    {
        "id": "loot-morphine",
        "name": "Боевой медицинский стимулятор (Морфий)",
        "shortName": "Морфий",
        "category": "meds",
        "description": "Мгновенное обезболивающее и стимулятор для полевой реанимации раненых бойцов.",
        "price": 45000,
        "rarity": "rare",
        "slots": 1,
        "weight": 0.1,
        "iconName": "HeartPulse",
        "inRaid": True
    },
    {
        "id": "loot-splint",
        "name": "Иммобилизирующая медицинская шина",
        "shortName": "Шина шинирования",
        "category": "meds",
        "description": "Быстрое устранение переломов конечностей в полевых условиях.",
        "price": 12000,
        "rarity": "common",
        "slots": 1,
        "weight": 0.2,
        "iconName": "Shield",
        "inRaid": True
    },
    {
        "id": "loot-esmarch",
        "name": "Кровоостанавливающий жгут Эсмарха",
        "shortName": "Жгут Эсмарха",
        "category": "meds",
        "description": "Останавливает тяжелые кровотечения за 3 секунды.",
        "price": 8500,
        "rarity": "common",
        "slots": 1,
        "weight": 0.1,
        "iconName": "HeartPulse",
        "inRaid": True
    }
]


def calculate_armor_absorption(incoming_damage: int, armor_item: Optional[Dict[str, Any]]) -> Tuple[int, int, Optional[Dict[str, Any]]]:
    """
    Realistic ballistic formula:
    - High-class armor (5-6) absorbs up to 85-95% of incoming scav bullets (buckshot/pistols/carbines)
    - Armor takes durability damage proportional to absorbed force
    - If durability reaches 0, armor is shredded and remaining damage penetrates straight to flesh
    Returns (flesh_damage, armor_durability_loss, updated_armor_item)
    """
    if not armor_item:
        return (incoming_damage, 0, None)

    armor_class = armor_item.get("armorClass", 3)
    durability = armor_item.get("durability", {"current": 40, "max": 40})
    curr_dura = durability.get("current", 40)
    max_dura = max(1, durability.get("max", 40))

    if curr_dura <= 0:
        # Broken armor provides 0 protection
        return (incoming_damage, 0, armor_item)

    # Durability factor (0.0 to 1.0)
    dura_ratio = curr_dura / max_dura

    # Base absorption: class 5-6 absorbs 75% to 92% of bullet impact
    base_reduction = min(0.92, (armor_class * 0.16) * dura_ratio)
    absorbed_amount = int(incoming_damage * base_reduction)
    flesh_damage = max(2, incoming_damage - absorbed_amount)

    # Armor durability loss
    dura_loss = max(1, int(incoming_damage * 0.25))
    new_dura = max(0, curr_dura - dura_loss)

    updated_armor = armor_item.copy()
    updated_armor["durability"] = {"current": new_dura, "max": max_dura}

    return (flesh_damage, dura_loss, updated_armor)


def calculate_weapon_effectiveness(weapon_item: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    High-tier weaponry (AK-74M Magpul, VSS Vintorez, M4A1) annihilates Scavs rapidly,
    increasing kill counts and mitigating incoming threat.
    """
    if not weapon_item:
        return {"power_tier": "low", "kill_bonus": 0, "damage_reduction": 0}

    name = weapon_item.get("name", "").lower()
    caliber = weapon_item.get("caliber", "")

    if "магпул" in name or "винторез" in name or "m4a1" in name or caliber in ["9x39 мм", "5.56x45 мм", "7.62x54 мм"]:
        return {"power_tier": "high", "kill_bonus": 1, "damage_reduction": 15}
    elif "ак-74" in name or "mp5" in name:
        return {"power_tier": "medium", "kill_bonus": 0, "damage_reduction": 5}
    return {"power_tier": "low", "kill_bonus": 0, "damage_reduction": 0}


def get_scenario_for_stage(location_id: str, stage_idx: int) -> Dict[str, Any]:
    """Retrieves an event from the 84+ scenarios pool matching location and stage."""
    loc_events = [e for e in RAID_EVENTS_POOL if e["location_id"] == location_id]
    if not loc_events:
        loc_events = RAID_EVENTS_POOL

    # Deterministic yet diverse index based on stage
    ev_idx = (stage_idx * 3 + 1) % len(loc_events)
    return loc_events[ev_idx]


def generate_stage_state(
    raid_id: str,
    stage_idx: int,
    health: int,
    kills: int,
    exp_earned: int,
    rubles_found: int,
    damage_taken: int,
    friend_gear_found: bool,
    friend_gear_secured: bool,
    standard_loot: List[Dict[str, Any]],
    secure_loot: List[Dict[str, Any]],
    logs: List[str],
    partner_status: str = "ok",
    partner_hp: int = 100,
    injuries: Optional[List[str]] = None,
    location_id: str = "customs",
    is_finished: bool = False,
    is_survived: bool = False
) -> RaidStageStateSchema:
    if injuries is None:
        injuries = []

    scenario = get_scenario_for_stage(location_id, stage_idx)
    poi_name = scenario.get("poi_name", f"Сектор рейда #{stage_idx}")
    situation_text = scenario.get("situation_text", "Оперативная обстановка в секторе.")

    choices: List[TacticalChoiceSchema] = []

    # If partner is unconscious, provide the required 3 rescue dilemma choices!
    if partner_status == "unconscious":
        choices = [
            TacticalChoiceSchema(
                id="rescue_morphine",
                title="[🩹 Реанимировать Морфием]",
                description="Вколоть инъектор стимулятора, привести бойца в чувство и вернуть в строй (40 HP).",
                actionType="rescue_friend",
                riskLevel="Умеренный",
                lootBonus=1.1,
                survivalModifier=15
            ),
            TacticalChoiceSchema(
                id="rescue_carry",
                title="[🏋️‍♂️ Тащить раненого напарника на себе]",
                description="Взвалить товарища на плечи. Штраф к урону и скрытности группы, но напарник доживет до эвакуации.",
                actionType="rescue_friend",
                riskLevel="Высокий",
                lootBonus=0.8,
                survivalModifier=-10
            ),
            TacticalChoiceSchema(
                id="early_extract_rescue",
                title="[🏃‍♂️ Пойти на досрочный выход чтобы спасти его жизнь]",
                description="Прервать рейд и экстренно эвакуировать истекающего кровью напарника на броневике.",
                actionType="extract",
                riskLevel="Низкий",
                lootBonus=1.0,
                survivalModifier=30
            )
        ]
    else:
        # Standard tactical matrix choices (Assault vs Flank)
        assault_data = scenario.get("assault", {})
        flank_data = scenario.get("flank", {})

        # If player has fracture injury, flank is impaired / blocked with warning
        flank_title = flank_data.get("action_title", "[🥷 Обход] Скрытный тактический маневр")
        flank_desc = flank_data.get("action_desc", "Бесшумное просачивание с контролем звука.")
        if "fracture" in injuries:
            flank_title += " ⚠️ [ПЕРЕЛОМ НОГИ: Шум шагов повышен]"
            flank_desc = "Из-за перелома ступни каждый шаг отдается хрустом и стоном. Требуется Шина!"

        choices.append(
            TacticalChoiceSchema(
                id=f"act_assault_{stage_idx}",
                title=assault_data.get("action_title", "[🔫 Штурм] Прямой огневой контакт"),
                description=assault_data.get("action_desc", "Подавление врага огнем и гранатами."),
                actionType="combat",
                riskLevel=assault_data.get("risk_level", "Высокий"),
                lootBonus=assault_data.get("loot_bonus", 1.8),
                survivalModifier=-5
            )
        )

        choices.append(
            TacticalChoiceSchema(
                id=f"act_flank_{stage_idx}",
                title=flank_title,
                description=flank_desc,
                actionType="flank",
                riskLevel=flank_data.get("risk_level", "Низкий"),
                lootBonus=flank_data.get("loot_bonus", 1.2),
                survivalModifier=15
            )
        )

        # Persistent Early Extraction Option on EVERY stage!
        choices.append(
            TacticalChoiceSchema(
                id=f"act_early_extract_{stage_idx}",
                title="[🏃‍♂️ Пойти на выход] (Досрочная эвакуация)",
                description="Сохранить весь спасенный редкий хабар и не рисковать жизнью в дальнейших стычках.",
                actionType="extract",
                riskLevel="Низкий",
                lootBonus=1.0,
                survivalModifier=25
            )
        )

    return RaidStageStateSchema(
        raidId=raid_id,
        currentStage=stage_idx,
        maxStages=15,
        stageTitle=scenario.get("title", f"Этап {stage_idx}: Разведка сектора"),
        situationText=situation_text,
        poiName=poi_name,
        hotZoneAlert="ОПАСНАЯ ЗОНА" if stage_idx in [4, 8, 11, 14] else None,
        health=health,
        maxHealth=440,
        kills=kills,
        expEarned=exp_earned,
        rublesFound=rubles_found,
        damageTaken=damage_taken,
        friendGearFound=friend_gear_found,
        friendGearSecured=friend_gear_secured,
        partnerStatus=partner_status,
        partnerHp=partner_hp,
        injuries=injuries,
        canEarlyExtract=True,
        availableChoices=choices,
        standardLoot=[TarkovItemSchema(**it) for it in standard_loot],
        secureContainerLoot=[TarkovItemSchema(**it) for it in secure_loot],
        logs=logs,
        isFinished=is_finished,
        isSurvived=is_survived
    )


def resolve_raid_choice(
    current_stage: int,
    choice_id: str,
    health: int,
    tactic_id: str,
    friend_gear_found: bool,
    friend_gear_secured: bool,
    standard_loot: List[Dict[str, Any]],
    secure_loot: List[Dict[str, Any]],
    partner_status: str = "ok",
    partner_hp: int = 100,
    injuries: Optional[List[str]] = None,
    equipped_weapon: Optional[Dict[str, Any]] = None,
    equipped_armor: Optional[Dict[str, Any]] = None,
    location_id: str = "customs"
) -> Tuple[int, int, int, int, int, bool, bool, str, int, List[str], List[Dict[str, Any]], List[Dict[str, Any]], str, List[Dict[str, Any]], bool, bool]:
    """
    Advanced tactical resolution:
    - Calculates ballistics and armor durability
    - Handles dynamic injuries and partner state
    - Supports early extraction at any stage
    Returns:
    (new_health, damage_taken_this_turn, new_kills, exp_gain, rubles_gain,
     updated_friend_gear_found, updated_friend_gear_secured,
     updated_partner_status, updated_partner_hp, updated_injuries,
     updated_standard_loot, updated_secure_loot, outcome_text, newly_found_items,
     is_finished, is_survived)
    """
    if injuries is None:
        injuries = []

    scenario = get_scenario_for_stage(location_id, current_stage)
    weapon_eff = calculate_weapon_effectiveness(equipped_weapon)

    outcome_text = ""
    damage = 0
    kills_gain = 0
    exp_gain = 120
    rubles_gain = random.randint(8000, 22000)
    newly_found = []
    is_finished = False
    is_survived = False

    # 1. EARLY EXTRACTION
    if "early_extract" in choice_id or choice_id == "c15_complete_exfil":
        is_finished = True
        is_survived = True
        exp_gain += 500
        rubles_gain += 15000
        outcome_text = "ДОСРОЧНАЯ ЭВАКУАЦИЯ УСПЕШНА: Отряд оперативно вышел к броневику эвакуации! Весь спасенный хабар доставлен на базу в целости."
        return (
            health, 0, kills_gain, exp_gain, rubles_gain,
            friend_gear_found, friend_gear_secured,
            partner_status, partner_hp, injuries,
            standard_loot, secure_loot, outcome_text, newly_found,
            is_finished, is_survived
        )

    # 2. RESCUE PARTNER DILEMMA CHOICES
    if choice_id == "rescue_morphine":
        partner_status = "revived"
        partner_hp = 40
        exp_gain += 300
        outcome_text = "ПОЛЕВАЯ РЕАНИМАЦИЯ: Введен шприц-тюбик Морфия! Напарник глубоко вздохнул, открыл глаза и поднялся на ноги. Группа снова в полном составе."
        return (
            health, 0, 0, exp_gain, rubles_gain,
            friend_gear_found, friend_gear_secured,
            partner_status, partner_hp, injuries,
            standard_loot, secure_loot, outcome_text, newly_found,
            is_finished, is_survived
        )
    elif choice_id == "rescue_carry":
        partner_status = "carried"
        exp_gain += 250
        outcome_text = "ЭВАКУАЦИЯ НА СЕБЕ: Вы закинули руку раненого напарника себе на шею. Скорость и маневренность снижены, но брат по оружию останется жив!"
        return (
            health, 0, 0, exp_gain, rubles_gain,
            friend_gear_found, friend_gear_secured,
            partner_status, partner_hp, injuries,
            standard_loot, secure_loot, outcome_text, newly_found,
            is_finished, is_survived
        )

    # 3. HEAVY BLEEDING EFFECT
    if "heavy_bleeding" in injuries:
        bleed_dmg = 15
        health = max(1, health - bleed_dmg)
        damage += bleed_dmg
        outcome_text += "🩸 [Кровотечение отнимает -15 HP] "

    # 4. TACTICAL CHOICE EXECUTION (Assault vs Flank)
    is_assault = "assault" in choice_id or "combat" in choice_id
    opt = scenario.get("assault" if is_assault else "flank", {})

    outcome_text += opt.get("outcome_text", "Тактический маневр завершен.")
    base_dmg = opt.get("base_damage", 25 if is_assault else 5)

    # Armor & Weapon ballistics
    if is_assault:
        kills_gain = opt.get("kill_count", 1) + weapon_eff["kill_bonus"]
        exp_gain += 180 * kills_gain
        raw_damage = max(10, base_dmg - weapon_eff["damage_reduction"])
        flesh_dmg, dura_loss, updated_armor = calculate_armor_absorption(raw_damage, equipped_armor)
        damage += flesh_dmg
        health = max(1, health - flesh_dmg)

        if equipped_armor and dura_loss > 0:
            outcome_text += f" (Бронежилет поглотил {raw_damage - flesh_dmg} урона, прочность -{dura_loss})"

        # Dynamic injury roll on high damage
        if flesh_dmg >= 30 and random.random() < 0.45:
            new_injury = random.choice(["heavy_bleeding", "fracture", "concussion"])
            if new_injury not in injuries:
                injuries.append(new_injury)
                inj_names = {
                    "heavy_bleeding": "Тяжелое кровотечение",
                    "fracture": "Перелом ноги",
                    "concussion": "Контузия"
                }
                outcome_text += f" ⚠️ Получена травма: {inj_names[new_injury]}!"

        # Partner damage roll in assault
        if partner_status == "ok" and random.random() < 0.35:
            partner_hp = max(0, partner_hp - random.randint(25, 60))
            if partner_hp <= 0:
                partner_status = "unconscious"
                outcome_text += " 🚨 ВНИМАНИЕ: Напарник попал под перекрестный огонь и упал БЕЗ СОЗНАНИЯ! Требуется немедленное решение отряда!"
    else:
        # Flank execution
        kills_gain = opt.get("kill_count", 0)
        exp_gain += 100
        raw_damage = max(0, base_dmg - (5 if "concussion" not in injuries else 0))
        flesh_dmg, dura_loss, _ = calculate_armor_absorption(raw_damage, equipped_armor)
        damage += flesh_dmg
        health = max(1, health - flesh_dmg)

    # Check Loot drop
    loot_chance = opt.get("loot_chance", 0.60)
    if random.random() < loot_chance:
        special_ids = opt.get("special_loot_ids")
        candidate = None
        if special_ids:
            for sid in special_ids:
                match = next((x for x in RAID_LOOT_POOL if x["id"] == sid), None)
                if match:
                    candidate = match
                    break
        if not candidate:
            candidate = random.choice(RAID_LOOT_POOL)

        new_item = candidate.copy()
        new_item["id"] = f"{new_item['id']}-{uuid.uuid4().hex[:6]}"
        standard_loot.append(new_item)
        newly_found.append(new_item)
        outcome_text += f" Обнаружен ценный трофей: {new_item['name']} ({new_item['price']:,} ₽)!"

        # Auto secure high-tier items if secure container has space (< 4 items)
        if new_item["rarity"] == "classified" and len(secure_loot) < 4:
            secure_loot.append(new_item)
            standard_loot.pop()
            outcome_text += " [Автоматически спрятано в защищенный подсумок]"

    # Final stage check
    if current_stage >= 15:
        is_finished = True
        is_survived = health > 0

    return (
        health, damage, kills_gain, exp_gain, rubles_gain,
        friend_gear_found, friend_gear_secured,
        partner_status, partner_hp, injuries,
        standard_loot, secure_loot, outcome_text, newly_found,
        is_finished, is_survived
    )
