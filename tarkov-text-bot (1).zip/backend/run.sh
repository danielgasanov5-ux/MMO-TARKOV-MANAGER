#!/usr/bin/env bash
set -euo pipefail

# Единая точка запуска текстового Telegram-бота из корня проекта.
cd "$(dirname "$0")/.."
exec python3 bot.py
