"""
Tarkov Telegram Bot Group Raid Handler
Uses Command("raid", ignore_mention=True) to launch group raid lobbies seamlessly in group chats.
"""

from typing import Dict, Any, List
import uuid

# Simulated or real aiogram components
try:
    from aiogram import Router, F
    from aiogram.filters import Command
    from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
    AIOGRAM_AVAILABLE = True
except ImportError:
    AIOGRAM_AVAILABLE = False


# In-memory lobbies registry for group chat sessions
ACTIVE_RAID_LOBBIES: Dict[str, Dict[str, Any]] = {}


def build_raid_lobby_keyboard(lobby_id: str) -> Any:
    """Builds inline keyboard for Telegram group chat raid lobby."""
    if not AIOGRAM_AVAILABLE:
        return None
        
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔫 Присоединиться к отряду", callback_data=f"raid_join:{lobby_id}"),
            InlineKeyboardButton(text="🎒 Схрон и Снаряжение", callback_data=f"raid_stash:{lobby_id}")
        ],
        [
            InlineKeyboardButton(text="🚀 Запустить рейд (Лидер)", callback_data=f"raid_start:{lobby_id}"),
            InlineKeyboardButton(text="🏃‍♂️ Досрочный выход", callback_data=f"raid_extract:{lobby_id}")
        ],
        [
            InlineKeyboardButton(text="🩹 Реанимация напарника", callback_data=f"raid_rescue:{lobby_id}"),
            InlineKeyboardButton(text="🤝 Вернуть шмот друга", callback_data=f"raid_return:{lobby_id}")
        ]
    ])
    return kb


if AIOGRAM_AVAILABLE:
    router = Router(name="group_raid_router")

    # Command("raid", ignore_mention=True) triggers immediately without requiring @bot_username in group chats!
    @router.message(Command("raid", ignore_mention=True))
    async def cmd_raid_handler(message: Message):
        """
        Launches an interactive raid lobby in the group chat.
        Works in both direct messages and group chats without needing bot mention!
        """
        lobby_id = f"lobby_{uuid.uuid4().hex[:8]}"
        user_name = message.from_user.full_name if message.from_user else "Оперативник"
        user_id = message.from_user.id if message.from_user else 0

        ACTIVE_RAID_LOBBIES[lobby_id] = {
            "leader_id": user_id,
            "leader_name": user_name,
            "members": [{"id": user_id, "name": user_name}],
            "location": "customs",
            "status": "recruiting"
        }

        text = (
            f"⚡️ <b>ТАКТИЧЕСКИЙ РЕЙД TARKOV // СБОР ОТРЯДА</b>\n\n"
            f"📍 Локация: <b>Таможня (Зона повышенной опасности)</b>\n"
            f"🎖 Лидер группы: <b>{user_name}</b>\n"
            f"👥 Бойцов в отряде: <b>1/4</b>\n\n"
            f"<i>Экипируйте броню 5-6 класса, проверьте боезапас и нажмите 'Присоединиться', чтобы зайти в рейд вместе!</i>"
        )

        keyboard = build_raid_lobby_keyboard(lobby_id)
        await message.reply(text, reply_markup=keyboard, parse_mode="HTML")

    @router.callback_query(F.data.startswith("raid_join:"))
    async def callback_join_raid(callback: CallbackQuery):
        lobby_id = callback.data.split(":")[1]
        lobby = ACTIVE_RAID_LOBBIES.get(lobby_id)
        if not lobby:
            await callback.answer("⚠️ Лобби рейда устарело или уже завершено.", show_alert=True)
            return

        user_id = callback.from_user.id
        user_name = callback.from_user.full_name

        if any(m["id"] == user_id for m in lobby["members"]):
            await callback.answer("Вы уже в составе отряда!", show_alert=False)
            return

        if len(lobby["members"]) >= 4:
            await callback.answer("Отряд уже полон (максимум 4 бойца)!", show_alert=True)
            return

        lobby["members"].append({"id": user_id, "name": user_name})
        await callback.answer(f"✅ Вы вступили в отряд {lobby['leader_name']}!")
        
        member_list = "\n".join([f"• {m['name']}" for m in lobby["members"]])
        new_text = (
            f"⚡️ <b>ТАКТИЧЕСКИЙ РЕЙД TARKOV // СБОР ОТРЯДА</b>\n\n"
            f"📍 Локация: <b>Таможня</b>\n"
            f"🎖 Лидер: <b>{lobby['leader_name']}</b>\n"
            f"👥 Бойцов: <b>{len(lobby['members'])}/4</b>\n"
            f"{member_list}\n\n"
            f"<i>Ожидаем готовности командира к десантированию.</i>"
        )
        await callback.message.edit_text(new_text, reply_markup=build_raid_lobby_keyboard(lobby_id), parse_mode="HTML")

    @router.callback_query(F.data.startswith("raid_start:"))
    async def callback_start_raid(callback: CallbackQuery):
        lobby_id = callback.data.split(":")[1]
        lobby = ACTIVE_RAID_LOBBIES.get(lobby_id)
        if not lobby:
            await callback.answer("⚠️ Лобби не найдено.", show_alert=True)
            return

        if callback.from_user.id != lobby["leader_id"]:
            await callback.answer("⛔️ Только лидер отряда может дать команду на десантирование!", show_alert=True)
            return

        lobby["status"] = "in_raid"
        await callback.answer("🚀 Высадка начата! Все бойцы в секторе.")
        await callback.message.edit_text(
            f"🔴 <b>ОТРЯД В РЕЙДЕ: ТАМОЖНЯ</b>\n\n"
            f"Бойцы десантировались. Открывайте Mini App для управления тактикой, штурмом и спасением раненых!",
            parse_mode="HTML"
        )

    @router.callback_query(F.data.startswith("raid_extract:"))
    async def callback_extract_raid(callback: CallbackQuery):
        await callback.answer("🏃‍♂️ Активирована досрочная эвакуация! Отряд двигается к броневику.")

    @router.callback_query(F.data.startswith("raid_rescue:"))
    async def callback_rescue_raid(callback: CallbackQuery):
        await callback.answer("🩹 Напарнику оказана экстренная медицинская помощь стимулятором Морфий!")

    @router.callback_query(F.data.startswith("raid_return:"))
    async def callback_return_gear(callback: CallbackQuery):
        await callback.answer("🤝 Спасенное снаряжение и жетоны возвращены в схрон законного владельца!")


def handle_simulated_raid_command(user_id: int, user_name: str, args: str = "") -> Dict[str, Any]:
    """Helper function for testing and headless bot execution."""
    lobby_id = f"lobby_{uuid.uuid4().hex[:8]}"
    ACTIVE_RAID_LOBBIES[lobby_id] = {
        "leader_id": user_id,
        "leader_name": user_name,
        "members": [{"id": user_id, "name": user_name}],
        "location": "customs",
        "status": "recruiting"
    }
    return {
        "status": "ok",
        "lobby_id": lobby_id,
        "leader": user_name,
        "command": "/raid",
        "ignore_mention": True,
        "message": f"Рейд-лобби {lobby_id} успешно создано по команде /raid без тега бота."
    }
