from typing import List, Optional, Dict, Any
try:
    from pydantic import BaseModel, Field
except ImportError:
    class BaseModel:
        def __init__(self, **kwargs):
            # Set default class attributes
            for attr in dir(self.__class__):
                if not attr.startswith('_') and not callable(getattr(self.__class__, attr)):
                    setattr(self, attr, getattr(self.__class__, attr))
            for k, v in kwargs.items():
                setattr(self, k, v)
        def dict(self):
            return self.__dict__
    def Field(*args, **kwargs):
        return None

class TarkovItemSchema(BaseModel):
    id: str
    name: str
    shortName: str
    category: str
    description: str
    price: int
    rarity: str
    slots: int
    weight: float
    caliber: Optional[str] = None
    armorClass: Optional[int] = None
    durability: Optional[Dict[str, int]] = None
    quantity: Optional[int] = None
    iconName: str
    inRaid: Optional[bool] = False

class StashCellSchema(BaseModel):
    index: int
    item: Optional[TarkovItemSchema] = None

class EquippedGearSchema(BaseModel):
    weapon: Optional[TarkovItemSchema] = None
    armor: Optional[TarkovItemSchema] = None
    helmet: Optional[TarkovItemSchema] = None
    rig: Optional[TarkovItemSchema] = None
    headset: Optional[TarkovItemSchema] = None
    secureContainer: Optional[TarkovItemSchema] = None

class StashResponse(BaseModel):
    cells: List[StashCellSchema]
    equipped: EquippedGearSchema
    freeSlots: int
    totalSlots: int = 100
    stashValue: int
    rubles: int

class EquipItemRequest(BaseModel):
    cellIndex: int
    slotType: str # 'weapon' | 'armor' | 'helmet' | 'rig' | 'headset'

class UnequipItemRequest(BaseModel):
    slotType: str # 'weapon' | 'armor' | 'helmet' | 'rig' | 'headset'

class ReturnFriendGearRequest(BaseModel):
    raidId: str
    friendUsername: str = "@Gurza_PMC"

class ReturnFriendGearResponse(BaseModel):
    success: bool
    message: str
    returnedItems: List[TarkovItemSchema]
    reputationGain: float
    rewardRubles: int

class MoveItemRequest(BaseModel):
    fromIndex: int
    toIndex: int

class MarketItemSchema(BaseModel):
    id: str
    item: TarkovItemSchema
    stock: int
    loyaltyRequired: int
    price: int

class MarketResponse(BaseModel):
    items: List[MarketItemSchema]
    page: int
    limit: int
    total: int
    totalPages: int
    praporRep: float
    praporSpent: int
    playerRubles: int
    currentLoyaltyLevel: int

class BuyItemRequest(BaseModel):
    marketItemId: str
    quantity: int = 1

class BuyItemResponse(BaseModel):
    success: bool
    message: str
    boughtItem: Optional[TarkovItemSchema] = None
    newRubles: int
    praporRep: float
    praporSpent: int
    placedIndex: Optional[int] = None

class SellItemRequest(BaseModel):
    cellIndex: int

class SellItemResponse(BaseModel):
    success: bool
    rublesEarned: int
    newRubles: int
    message: str

class SellAllResponse(BaseModel):
    success: bool
    itemsSold: int
    rublesEarned: int
    newRubles: int
    praporRep: float
    praporSpent: int
    message: str

# 15-Stage Raid Engine Schemas
class TacticalChoiceSchema(BaseModel):
    id: str
    title: str
    description: str
    actionType: str # 'combat' | 'flank' | 'loot_poi' | 'rescue_friend' | 'secure_pouch' | 'extract'
    riskLevel: str
    lootBonus: float
    survivalModifier: int
    icon: Optional[str] = None

class RaidStageStateSchema(BaseModel):
    raidId: str
    currentStage: int
    maxStages: int = 15
    stageTitle: str
    situationText: str
    poiName: str
    hotZoneAlert: Optional[str] = None
    health: int
    maxHealth: int
    kills: int
    expEarned: int
    rublesFound: int
    damageTaken: int
    friendGearFound: bool
    friendGearSecured: bool
    partnerStatus: str = "ok" # 'ok' | 'wounded' | 'unconscious' | 'carried' | 'revived'
    partnerHp: int = 100
    injuries: List[str] = [] # 'heavy_bleeding', 'fracture', 'concussion'
    canEarlyExtract: bool = True
    availableChoices: List[TacticalChoiceSchema]
    standardLoot: List[TarkovItemSchema]
    secureContainerLoot: List[TarkovItemSchema] # Items preserved on KIA
    logs: List[str]
    isFinished: bool
    isSurvived: bool

class RaidStartRequest(BaseModel):
    locationId: str
    tacticId: str = "stealth"

class RaidActionRequest(BaseModel):
    raidId: str
    choiceId: str
    stashToSecureContainerItemId: Optional[str] = None # Move item to secure pouch (подсумок)

class RaidActionResultSchema(BaseModel):
    stage: RaidStageStateSchema
    outcomeText: str
    damageTakenThisTurn: int
    newItemsFound: List[TarkovItemSchema]
    status: str # 'continue' | 'survived' | 'kia'

class PlayerProfileResponse(BaseModel):
    id: int
    telegramId: int
    username: str
    callsign: str
    faction: str
    level: int
    exp: int
    nextLevelExp: int
    rubles: int
    dollars: int
    euros: int
    praporRep: float
    praporSpent: int
    raidsCount: int
    survivedCount: int
    killsCount: int
