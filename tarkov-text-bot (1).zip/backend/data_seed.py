import json
from typing import List, Dict, Any

STARTER_EQUIPMENT = {
    "weapon": {
        "id": "item-ak74m",
        "name": "Автомат Калашникова АК-74М 5.45x39",
        "shortName": "АК-74М",
        "category": "weapons",
        "description": "Складной пластиковый приклад, планка под оптику. Основное оружие в Таркове.",
        "price": 44000,
        "rarity": "rare",
        "slots": 2,
        "weight": 3.4,
        "caliber": "5.45x39 мм",
        "durability": {"current": 100, "max": 100},
        "iconName": "Crosshair",
        "inRaid": False
    },
    "armor": {
        "id": "item-6b23-1",
        "name": "Бронежилет 6Б23-1 (Флора)",
        "shortName": "6Б23-1",
        "category": "armor",
        "description": "Общевойсковой бронежилет 3 класса защиты. Стальные бронепластины.",
        "price": 38000,
        "rarity": "common",
        "slots": 2,
        "weight": 8.1,
        "armorClass": 3,
        "durability": {"current": 60, "max": 60},
        "iconName": "Shield",
        "inRaid": False
    },
    "helmet": {
        "id": "item-ssh68",
        "name": "Стальной шлем СШ-68 (Каска)",
        "shortName": "СШ-68",
        "category": "armor",
        "description": "Советский стальной шлем. 3 класс защиты с высоким шансом рикошета.",
        "price": 22000,
        "rarity": "common",
        "slots": 2,
        "weight": 1.3,
        "armorClass": 3,
        "durability": {"current": 30, "max": 30},
        "iconName": "Shield",
        "inRaid": False
    },
    "rig": {
        "id": "item-tarzan",
        "name": "Тактический жилет Тарзан М22",
        "shortName": "Тарзан",
        "category": "armor",
        "description": "Удобный разгрузочный жилет на 16 слотов под магазины АК и гранаты.",
        "price": 18000,
        "rarity": "common",
        "slots": 2,
        "weight": 1.1,
        "iconName": "Briefcase",
        "inRaid": False
    },
    "headset": {
        "id": "item-gssh01",
        "name": "Активные наушники ГСШ-01 6М2",
        "shortName": "ГСШ-01",
        "category": "armor",
        "description": "Армейские активные наушники. Усиливают тихие звуки шагов и приглушают взрывы.",
        "price": 19000,
        "rarity": "common",
        "slots": 1,
        "weight": 0.4,
        "iconName": "Headphones",
        "inRaid": False
    },
    "secureContainer": {
        "id": "item-alpha-container",
        "name": "Защищенный контейнер Альфа (2x2)",
        "shortName": "Альфа",
        "category": "barter",
        "description": "Элитный защищенный контейнер ЧВК. Все предметы внутри сохраняются даже в случае гибели в рейде.",
        "price": 150000,
        "rarity": "classified",
        "slots": 2,
        "weight": 1.0,
        "iconName": "Lock",
        "inRaid": False
    }
}

STARTER_STASH_ITEMS: List[Dict[str, Any]] = [
    {
        "index": 0,
        "item": {
            "id": "item-ak74m-spare",
            "name": "Автомат Калашникова АК-74М 5.45x39",
            "shortName": "АК-74М",
            "category": "weapons",
            "description": "Резервный автомат в схроне.",
            "price": 44000,
            "rarity": "rare",
            "slots": 2,
            "weight": 3.4,
            "caliber": "5.45x39 мм",
            "durability": {"current": 100, "max": 100},
            "iconName": "Crosshair",
            "inRaid": False
        }
    },
    {
        "index": 2,
        "item": {
            "id": "item-salewa-1",
            "name": "Индивидуальная аптечка Salewa",
            "shortName": "Salewa",
            "category": "meds",
            "description": "Восстанавливает до 400 HP и останавливает тяжелые кровотечения.",
            "price": 28000,
            "rarity": "rare",
            "slots": 2,
            "weight": 0.8,
            "durability": {"current": 400, "max": 400},
            "iconName": "HeartPulse",
            "inRaid": False
        }
    },
    {
        "index": 4,
        "item": {
            "id": "item-salewa-2",
            "name": "Индивидуальная аптечка Salewa",
            "shortName": "Salewa",
            "category": "meds",
            "description": "Полевая аптечка первой помощи.",
            "price": 28000,
            "rarity": "rare",
            "slots": 2,
            "weight": 0.8,
            "durability": {"current": 400, "max": 400},
            "iconName": "HeartPulse",
            "inRaid": False
        }
    },
    {
        "index": 6,
        "item": {
            "id": "item-bt-ammo-1",
            "name": "Патроны 5.45x39 мм БТ гж (Пачка)",
            "shortName": "5.45 БТ",
            "category": "ammo",
            "description": "Бронебойно-трассирующий патрон с хорошим пробитием 4 класса брони.",
            "price": 18500,
            "rarity": "rare",
            "slots": 1,
            "weight": 0.4,
            "caliber": "5.45x39 мм",
            "quantity": 60,
            "iconName": "Crosshair",
            "inRaid": False
        }
    },
    {
        "index": 7,
        "item": {
            "id": "item-bt-ammo-2",
            "name": "Патроны 5.45x39 мм БТ гж (Пачка)",
            "shortName": "5.45 БТ",
            "category": "ammo",
            "description": "Бронебойно-трассирующий патрон 5.45.",
            "price": 18500,
            "rarity": "rare",
            "slots": 1,
            "weight": 0.4,
            "caliber": "5.45x39 мм",
            "quantity": 60,
            "iconName": "Crosshair",
            "inRaid": False
        }
    },
    {
        "index": 8,
        "item": {
            "id": "item-f1-grenade",
            "name": "Ручная граната Ф-1 (Лимонка)",
            "shortName": "Ф-1",
            "category": "weapons",
            "description": "Оборонительная граната с радиусом разлета осколков до 30 метров.",
            "price": 14000,
            "rarity": "common",
            "slots": 1,
            "weight": 0.6,
            "iconName": "Bomb",
            "inRaid": False
        }
    },
    {
        "index": 9,
        "item": {
            "id": "item-painkillers",
            "name": "Обезболивающее (Анальгин)",
            "shortName": "Анальгин",
            "category": "meds",
            "description": "Снимает эффект болевого шока при переломах конечностей.",
            "price": 5500,
            "rarity": "common",
            "slots": 1,
            "weight": 0.1,
            "durability": {"current": 4, "max": 4},
            "iconName": "Pill",
            "inRaid": False
        }
    },
    {
        "index": 10,
        "item": {
            "id": "item-military-circuit",
            "name": "Военная печатная плата (Хабар)",
            "shortName": "Воен. плата",
            "category": "barter",
            "description": "Электроника с секретной аппаратуры Росрезерва. Дорого покупается торговцами.",
            "price": 42000,
            "rarity": "rare",
            "slots": 1,
            "weight": 0.3,
            "iconName": "Cpu",
            "inRaid": True
        }
    },
    {
        "index": 11,
        "item": {
            "id": "item-gold-chain",
            "name": "Золотая цепочка",
            "shortName": "Золото",
            "category": "barter",
            "description": "Ювелирное украшение. Идеально для продажи Прапору или обмена.",
            "price": 35000,
            "rarity": "rare",
            "slots": 1,
            "weight": 0.1,
            "iconName": "CircleDollarSign",
            "inRaid": True
        }
    },
    {
        "index": 12,
        "item": {
            "id": "item-factory-key",
            "name": "Ключ от завода (Аварийный выход)",
            "shortName": "Ключ Завод",
            "category": "keys",
            "description": "Открывает закрытые аварийные двери эвакуации на локации Завод.",
            "price": 85000,
            "rarity": "epic",
            "slots": 1,
            "weight": 0.05,
            "durability": {"current": 50, "max": 50},
            "iconName": "Key",
            "inRaid": True
        }
    }
]

PRAPOR_MARKET_CATALOG = [
    {
        "id": "pr-ak74m",
        "stock": 15,
        "loyaltyRequired": 1,
        "price": 44000,
        "item": {
            "id": "item-ak74m",
            "name": "Автомат Калашникова АК-74М 5.45x39",
            "shortName": "АК-74М",
            "category": "weapons",
            "description": "Складной пластиковый приклад, планка под оптику. Основное оружие в Таркове.",
            "price": 44000,
            "rarity": "rare",
            "slots": 2,
            "weight": 3.4,
            "caliber": "5.45x39 мм",
            "durability": {"current": 100, "max": 100},
            "iconName": "Crosshair"
        }
    },
    {
        "id": "pr-bundle-starter",
        "stock": 8,
        "loyaltyRequired": 1,
        "price": 75000,
        "item": {
            "id": "item-starter-bundle",
            "name": "Сборный тактический пакет 'Штурмовик Прапора'",
            "shortName": "Пакет 'Штурмовик'",
            "category": "weapons",
            "description": "Готовый комплект: Модифицированный АК-74М, 2 пачки БТ патронов и аптечка Salewa.",
            "price": 75000,
            "rarity": "epic",
            "slots": 2,
            "weight": 4.5,
            "iconName": "Package"
        }
    },
    {
        "id": "pr-mp133",
        "stock": 22,
        "loyaltyRequired": 1,
        "price": 24500,
        "item": {
            "id": "item-mp133",
            "name": "Помповое ружье МР-133 12к",
            "shortName": "МР-133",
            "category": "weapons",
            "description": "Ружье для охоты и отстрела Диких. Требуется для квеста 'Дебют'.",
            "price": 24500,
            "rarity": "common",
            "slots": 2,
            "weight": 3.2,
            "caliber": "12/70",
            "durability": {"current": 100, "max": 100},
            "iconName": "Crosshair"
        }
    },
    {
        "id": "pr-6b23",
        "stock": 10,
        "loyaltyRequired": 1,
        "price": 38000,
        "item": {
            "id": "item-6b23-1",
            "name": "Бронежилет 6Б23-1 (Флора)",
            "shortName": "6Б23-1",
            "category": "armor",
            "description": "Общевойсковой бронежилет 3 класса защиты со стальными пластинами.",
            "price": 38000,
            "rarity": "common",
            "slots": 2,
            "weight": 8.1,
            "armorClass": 3,
            "durability": {"current": 60, "max": 60},
            "iconName": "Shield"
        }
    },
    {
        "id": "pr-ssh68",
        "stock": 25,
        "loyaltyRequired": 1,
        "price": 22000,
        "item": {
            "id": "item-ssh68",
            "name": "Стальной шлем СШ-68 (Каска)",
            "shortName": "СШ-68",
            "category": "armor",
            "description": "Советский стальной шлем. 3 класс защиты с рикошетом.",
            "price": 22000,
            "rarity": "common",
            "slots": 2,
            "weight": 1.3,
            "armorClass": 3,
            "durability": {"current": 30, "max": 30},
            "iconName": "Shield"
        }
    },
    {
        "id": "pr-bt-pack",
        "stock": 40,
        "loyaltyRequired": 1,
        "price": 18500,
        "item": {
            "id": "item-bt-ammo-1",
            "name": "Патроны 5.45x39 мм БТ гж (60 шт)",
            "shortName": "5.45 БТ",
            "category": "ammo",
            "description": "Бронебойно-трассирующие патроны с пробитием 4 класса.",
            "price": 18500,
            "rarity": "rare",
            "slots": 1,
            "weight": 0.4,
            "caliber": "5.45x39 мм",
            "quantity": 60,
            "iconName": "Crosshair"
        }
    },
    {
        "id": "pr-korund",
        "stock": 6,
        "loyaltyRequired": 2,
        "price": 98000,
        "item": {
            "id": "item-korund",
            "name": "Бронежилет Корунд-ВМ",
            "shortName": "Корунд",
            "category": "armor",
            "description": "Штурмовой тяжелый бронежилет 5 класса защиты.",
            "price": 98000,
            "rarity": "rare",
            "slots": 2,
            "weight": 9.5,
            "armorClass": 5,
            "durability": {"current": 45, "max": 45},
            "iconName": "Shield"
        }
    },
    {
        "id": "pr-val",
        "stock": 4,
        "loyaltyRequired": 2,
        "price": 115000,
        "item": {
            "id": "item-as-val",
            "name": "Бесшумный автомат АС 'ВАЛ' 9x39",
            "shortName": "АС ВАЛ",
            "category": "weapons",
            "description": "Интегрированный глушитель, колоссальный урон и скорострельность 900 выстр/мин.",
            "price": 115000,
            "rarity": "epic",
            "slots": 2,
            "weight": 2.5,
            "caliber": "9x39 мм",
            "durability": {"current": 100, "max": 100},
            "iconName": "Crosshair"
        }
    },
    {
        "id": "pr-altyn",
        "stock": 3,
        "loyaltyRequired": 3,
        "price": 160000,
        "item": {
            "id": "item-altyn",
            "name": "Шлем Алтын с бронезабралом",
            "shortName": "Алтын",
            "category": "armor",
            "description": "Легендарный титановый шлем 5 класса с опущенным забралом. Защищает от выстрелов в лицо.",
            "price": 160000,
            "rarity": "epic",
            "slots": 2,
            "weight": 4.0,
            "armorClass": 5,
            "durability": {"current": 50, "max": 50},
            "iconName": "Shield"
        }
    },
    {
        "id": "pr-rsass",
        "stock": 2,
        "loyaltyRequired": 4,
        "price": 280000,
        "item": {
            "id": "item-rsass",
            "name": "Снайперская винтовка Remington RSASS 7.62x51",
            "shortName": "RSASS",
            "category": "weapons",
            "description": "Высокоточная марксманская полуавтоматическая винтовка НАТО калибра .308.",
            "price": 280000,
            "rarity": "classified",
            "slots": 2,
            "weight": 5.2,
            "caliber": "7.62x51 мм",
            "durability": {"current": 100, "max": 100},
            "iconName": "Crosshair"
        }
    }
]
