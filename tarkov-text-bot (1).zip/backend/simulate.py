"""
Automated unit and integration test suite for Tarkov Raid Engine & Mini App.
Tests all callback routes, early extraction, ballistics, partner rescue choices,
and ensures zero errors.
"""

import sys
import os
import json

# Add backend directory to sys.path so imports resolve
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from raid_events_pool import RAID_EVENTS_POOL, get_events_for_stage
from raid_engine import (
    generate_stage_state,
    resolve_raid_choice,
    calculate_armor_absorption,
    calculate_weapon_effectiveness,
    RAID_LOOT_POOL
)
from raid import handle_simulated_raid_command, ACTIVE_RAID_LOBBIES

def run_tests():
    print("=" * 65)
    print("🚀 ЗАПУСК АВТОМАТИЧЕСКИХ ЮНИТ-ТЕСТОВ TARKOV RAID ENGINE & MINI APP")
    print("=" * 65)

    passed = 0
    total = 0

    # 1. Test Story-Branching Matrix Events Pool (84+ events)
    total += 1
    pool_count = len(RAID_EVENTS_POOL)
    assert pool_count >= 84, f"Expected at least 84 events, found {pool_count}"
    print(f"✅ [1/8] ПУЛ СОБЫТИЙ: Загружено {pool_count} уникальных сценариев (Таможня, Завод, Лес)")
    passed += 1

    # 2. Test Realistic Ballistics & Class 5-6 Armor
    total += 1
    incoming_scav_damage = 60
    heavy_armor = {
        "id": "loot-korund",
        "name": "Корунд-ВМ",
        "armorClass": 5,
        "durability": {"current": 45, "max": 45}
    }
    flesh_dmg, dura_loss, updated_armor = calculate_armor_absorption(incoming_scav_damage, heavy_armor)
    assert flesh_dmg < 20, f"Class 5 armor must absorb majority of damage, got flesh: {flesh_dmg}"
    assert dura_loss > 0, "Armor must lose durability upon bullet impact"
    assert updated_armor["durability"]["current"] == 45 - dura_loss
    print(f"✅ [2/8] БАЛЛИСТИКА И БРОНЯ: Входящий урон 60 -> тело получило {flesh_dmg} HP, броня поглотила {incoming_scav_damage - flesh_dmg} урона (износ: -{dura_loss})")
    passed += 1

    # 3. Test High-Tier Weapon Effectiveness (AK-74M Magpul / VSS Vintorez)
    total += 1
    vss_weapon = {
        "id": "loot-val-mag",
        "name": "Винтовка ВСС 'Винторез'",
        "caliber": "9x39 мм"
    }
    eff = calculate_weapon_effectiveness(vss_weapon)
    assert eff["power_tier"] == "high"
    assert eff["kill_bonus"] >= 1
    print(f"✅ [3/8] ОРУЖИЕ ВЫСШЕГО КЛАССА: ВСС 'Винторез' 9x39 мм (+{eff['kill_bonus']} к уничтоженным врагам, -{eff['damage_reduction']} к угрозе)")
    passed += 1

    # 4. Test 15-Stage Raid Generation with Persistent Early Extract
    total += 1
    stage_state = generate_stage_state(
        raid_id="test-raid-101",
        stage_idx=1,
        health=440,
        kills=0,
        exp_earned=100,
        rubles_found=0,
        damage_taken=0,
        friend_gear_found=False,
        friend_gear_secured=False,
        standard_loot=[],
        secure_loot=[],
        logs=["Высадка в секторе."],
        location_id="customs"
    )
    assert stage_state.currentStage == 1
    assert stage_state.maxStages == 15
    assert stage_state.canEarlyExtract is True
    has_extract_button = any(c.actionType == "extract" for c in stage_state.availableChoices)
    assert has_extract_button, "Persistent early extraction button must be available on all stages"
    print(f"✅ [4/8] 15 ЭТАПОВ И ДОСРОЧНЫЙ ВЫХОД: Этап 1 инициализирован, кнопка '[🏃‍♂️ Пойти на выход]' активна")
    passed += 1

    # 5. Test Early Extraction Mechanic with High-Value Loot
    total += 1
    bitcoin = next(x for x in RAID_LOOT_POOL if x["id"] == "loot-bitcoin").copy()
    (
        hp, dmg, kills, exp, rubles,
        f_found, f_sec, p_status, p_hp, inj,
        std_loot, sec_loot, out_text, newly,
        is_finished, is_survived
    ) = resolve_raid_choice(
        current_stage=3,
        choice_id="act_early_extract_3",
        health=400,
        tactic_id="flank",
        friend_gear_found=False,
        friend_gear_secured=False,
        standard_loot=[bitcoin],
        secure_loot=[],
        location_id="customs"
    )
    assert is_finished is True, "Early extraction must finish the raid"
    assert is_survived is True, "Early extraction must mark player as survived"
    assert "ДОСРОЧНАЯ ЭВАКУАЦИЯ" in out_text
    print("✅ [5/8] МЕХАНИКА ДОСРОЧНОГО ВЫХОДА: Успешная эвакуация с Биткоином к броневику без боя с финальным боссом")
    passed += 1

    # 6. Test Stop-Loop Partner Trauma & 3 Interactive Rescue Choices
    total += 1
    # Generate stage with unconscious partner
    stage_unconscious = generate_stage_state(
        raid_id="test-raid-rescue",
        stage_idx=6,
        health=320,
        kills=2,
        exp_earned=500,
        rubles_found=15000,
        damage_taken=80,
        friend_gear_found=False,
        friend_gear_secured=False,
        standard_loot=[],
        secure_loot=[],
        logs=[],
        partner_status="unconscious",
        partner_hp=0
    )
    choice_ids = [c.id for c in stage_unconscious.availableChoices]
    assert "rescue_morphine" in choice_ids, "Must offer [🩹 Реанимировать Морфием]"
    assert "rescue_carry" in choice_ids, "Must offer [🏋️‍♂️ Тащить раненого на себе]"
    assert "early_extract_rescue" in choice_ids, "Must offer [🏃‍♂️ Пойти на досрочный выход]"
    print("✅ [6/8] СТОП-ПОВТОРЫ СМЕРТИ: Напарник без сознания -> 3 интерактивных пути спасения предоставлены")
    passed += 1

    # 7. Test Rescue Resolution with Morphine
    total += 1
    (
        hp, dmg, kills, exp, rubles,
        f_found, f_sec, p_status, p_hp, inj,
        std_loot, sec_loot, out_text, newly,
        is_finished, is_survived
    ) = resolve_raid_choice(
        current_stage=6,
        choice_id="rescue_morphine",
        health=320,
        tactic_id="assault",
        friend_gear_found=False,
        friend_gear_secured=False,
        standard_loot=[],
        secure_loot=[],
        partner_status="unconscious",
        partner_hp=0
    )
    assert p_status == "revived", "Partner must be revived by morphine"
    assert p_hp == 40, "Partner HP restored to 40"
    assert "ПОЛЕВАЯ РЕАНИМАЦИЯ" in out_text
    print("✅ [7/8] РЕАНИМАЦИЯ НАПАРНИКА: Морфий возвращает бойца в строй с 40 HP")
    passed += 1

    # 8. Test Telegram Bot /raid Command with ignore_mention=True
    total += 1
    bot_res = handle_simulated_raid_command(user_id=888777, user_name="Капитан Прайс")
    assert bot_res["status"] == "ok"
    assert bot_res["ignore_mention"] is True
    lobby_id = bot_res["lobby_id"]
    assert lobby_id in ACTIVE_RAID_LOBBIES
    print(f"✅ [8/8] TELEGRAM BOT: Команда Command('raid', ignore_mention=True) мгновенно запускает лобби в беседах без тега")
    passed += 1

    print("=" * 65)
    print(f"🎉 ВСЕ {passed}/{total} ЮНИТ-ТЕСТОВ ПРОЙДЕНЫ С ОТЛИЧИЕМ! 0 ОШИБОК.")
    print("=" * 65)
    return True

if __name__ == "__main__":
    if not run_tests():
        sys.exit(1)
