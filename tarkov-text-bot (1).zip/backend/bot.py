"""Compatibility entry point.

The monolithic game lives in the project root as bot.py. This wrapper keeps
the original backend/bot.py path usable without maintaining two game engines.
"""

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from bot import run  # noqa: E402


if __name__ == "__main__":
    run()