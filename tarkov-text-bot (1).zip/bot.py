"""Tarkov MMO: текстовый экономический менеджер для Telegram.

Единственный интерфейс игры — Telegram InlineKeyboardButton/callback_data.
Состояние хранится в локальном database.json, секрет BOT_TOKEN берётся только
из Replit Secrets / переменных окружения.
"""

from __future__ import annotations

import hashlib
import html
import json
import logging
import os
import random
import threading
import time
from typing import Any, Optional

import telebot
from telebot import types

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
DATABASE_FILE = os.environ.get(
    "DATABASE_FILE",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "database.json"),
)
ADMIN_USERNAME = "revenuts"
MAX_LEVEL = 120
P2P_TAX = 0.10
RAID_DURATION_SECONDS = 20 * 60
LAND_SUPPLY_SECONDS = 30 * 60
SEA_SUPPLY_SECONDS = 120 * 60

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - [%(levelname)s] - %(message)s",
)
logger = logging.getLogger("TarkovTextMMO")

if not BOT_TOKEN:
    logger.warning("BOT_TOKEN is empty. Add it in Replit Tools → Secrets.")
bot = telebot.TeleBot(BOT_TOKEN or "000000000:SET_BOT_TOKEN_IN_SECRETS")


# ---------------------------------------------------------------------------
# Catalog: 500 named Tarkov items
# ---------------------------------------------------------------------------

RARITY_SCORE = {"common": 1, "rare": 2, "epic": 3, "legendary": 4}
RARITY_LABEL = {
    "common": "Common",
    "rare": "Rare",
    "epic": "Epic",
    "legendary": "Legendary",
}


def generate_tarkov_catalog() -> dict[str, dict[str, Any]]:
    """Build exactly 500 unique, named items from real Tarkov item families."""

    seeds = [
        # id, name, market category, warehouse, rarity, price, combat power
        ("wpn_toz106", "ТОЗ-106", "weapons", "weapons", "common", 12000, 24),
        ("wpn_ak74m", "АК-74М", "weapons", "weapons", "common", 42000, 58),
        ("wpn_pm", "Пистолет Макарова ПМ", "weapons", "weapons", "common", 8500, 22),
        ("wpn_tt", "Пистолет ТТ-33", "weapons", "weapons", "common", 11000, 26),
        ("wpn_grach", "Пистолет Ярыгина MP-443 Грач", "weapons", "weapons", "common", 14000, 30),
        ("wpn_glock17", "Glock 17", "weapons", "weapons", "common", 16000, 34),
        ("wpn_m9a3", "Beretta M9A3", "weapons", "weapons", "common", 17500, 35),
        ("wpn_aps", "АПС", "weapons", "weapons", "rare", 24000, 40),
        ("wpn_apb", "АПБ", "weapons", "weapons", "rare", 32000, 46),
        ("wpn_glock18", "Glock 18C", "weapons", "weapons", "epic", 48000, 56),
        ("wpn_fn57", "FN Five-seveN", "weapons", "weapons", "epic", 55000, 60),
        ("wpn_deagle", "Desert Eagle L5", "weapons", "weapons", "legendary", 120000, 85),
        ("wpn_ak74n", "АК-74Н", "weapons", "weapons", "common", 38000, 55),
        ("wpn_akm", "АКМ", "weapons", "weapons", "common", 36000, 54),
        ("wpn_akmn", "АКМН", "weapons", "weapons", "rare", 49000, 63),
        ("wpn_aks74u", "АКС-74У", "weapons", "weapons", "common", 30000, 44),
        ("wpn_aks74ub", "АКС-74УБ", "weapons", "weapons", "rare", 44000, 55),
        ("wpn_ak101", "АК-101", "weapons", "weapons", "rare", 58000, 68),
        ("wpn_ak102", "АК-102", "weapons", "weapons", "rare", 56000, 65),
        ("wpn_ak103", "АК-103", "weapons", "weapons", "rare", 61000, 70),
        ("wpn_ak104", "АК-104", "weapons", "weapons", "rare", 59000, 67),
        ("wpn_ak105", "АК-105", "weapons", "weapons", "rare", 53000, 61),
        ("wpn_ak12", "АК-12", "weapons", "weapons", "epic", 86000, 79),
        ("wpn_ash12", "АШ-12", "weapons", "weapons", "epic", 145000, 93),
        ("wpn_rpk16", "РПК-16", "weapons", "weapons", "epic", 118000, 88),
        ("wpn_rpk74", "РПК-74", "weapons", "weapons", "rare", 74000, 76),
        ("wpn_vpo136", "ВПО-136 Вепрь-КМ", "weapons", "weapons", "common", 28000, 43),
        ("wpn_vpo209", "ВПО-209", "weapons", "weapons", "common", 26000, 40),
        ("wpn_sks", "СКС", "weapons", "weapons", "common", 27000, 45),
        ("wpn_svd", "СВД", "weapons", "weapons", "epic", 160000, 96),
        ("wpn_svds", "СВДС", "weapons", "weapons", "epic", 175000, 100),
        ("wpn_mosin", "Винтовка Мосина", "weapons", "weapons", "common", 28000, 51),
        ("wpn_mosin_inf", "Мосина пехотная", "weapons", "weapons", "common", 25000, 47),
        ("wpn_vpo215", "ВПО-215 Горностай", "weapons", "weapons", "rare", 62000, 72),
        ("wpn_m4a1", "Colt M4A1", "weapons", "weapons", "epic", 138000, 91),
        ("wpn_hk416", "HK 416A5", "weapons", "weapons", "epic", 155000, 94),
        ("wpn_hkmp7", "HK MP7A1", "weapons", "weapons", "epic", 126000, 86),
        ("wpn_mp5", "HK MP5", "weapons", "weapons", "rare", 54000, 58),
        ("wpn_mp5sd", "HK MP5SD", "weapons", "weapons", "epic", 77000, 69),
        ("wpn_mp7a2", "HK MP7A2", "weapons", "weapons", "epic", 132000, 89),
        ("wpn_mp9", "B&T MP9-N", "weapons", "weapons", "rare", 64000, 65),
        ("wpn_p90", "FN P90", "weapons", "weapons", "epic", 108000, 82),
        ("wpn_vector9", "KRISS Vector 9x19", "weapons", "weapons", "epic", 128000, 87),
        ("wpn_vector45", "KRISS Vector .45", "weapons", "weapons", "epic", 134000, 89),
        ("wpn_ppsh", "ППШ-41", "weapons", "weapons", "common", 33000, 48),
        ("wpn_pp19", "ПП-19-01 Витязь", "weapons", "weapons", "rare", 46000, 55),
        ("wpn_saiga9", "Сайга-9", "weapons", "weapons", "common", 28000, 44),
        ("wpn_saiga12", "Сайга-12К", "weapons", "weapons", "rare", 68000, 72),
        ("wpn_mp153", "МР-153", "weapons", "weapons", "common", 32000, 50),
        ("wpn_mp155", "МР-155", "weapons", "weapons", "rare", 46000, 60),
        ("wpn_m870", "Remington Model 870", "weapons", "weapons", "rare", 49000, 62),
        ("wpn_m590", "Mossberg 590A1", "weapons", "weapons", "rare", 51000, 64),
        ("wpn_m700", "Remington M700", "weapons", "weapons", "rare", 76000, 80),
        ("wpn_t5000", "ORSIS T-5000", "weapons", "weapons", "epic", 176000, 103),
        ("wpn_dvl10", "DVL-10 Saboteur", "weapons", "weapons", "legendary", 265000, 124),
        ("wpn_sv98", "СВ-98", "weapons", "weapons", "epic", 145000, 98),
        ("wpn_vss", "ВСС Винторез", "weapons", "weapons", "epic", 195000, 106),
        ("wpn_val", "АС ВАЛ", "weapons", "weapons", "epic", 182000, 101),
        ("wpn_ump45", "HK UMP 45", "weapons", "weapons", "rare", 52000, 59),
        ("wpn_mcxspear", "MCX SPEAR", "weapons", "weapons", "legendary", 238000, 122),
        ("wpn_sr25", "Knight's SR-25", "weapons", "weapons", "legendary", 248000, 127),
        ("wpn_rsass", "Remington RSASS", "weapons", "weapons", "legendary", 255000, 129),
        ("wpn_sa58", "SA-58", "weapons", "weapons", "epic", 152000, 99),
        ("wpn_fal", "FN FAL", "weapons", "weapons", "epic", 149000, 97),
        ("wpn_mdr556", "DT MDR 5.56", "weapons", "weapons", "epic", 142000, 95),
        ("wpn_mdr762", "DT MDR 7.62", "weapons", "weapons", "legendary", 209000, 116),
        ("arm_paca", "Бронежилет PACA", "equipment", "armor", "common", 24000, 24),
        ("arm_6b2", "Бронежилет 6Б2", "equipment", "armor", "common", 19000, 21),
        ("arm_6b23", "Бронежилет 6Б23-1", "equipment", "armor", "common", 38000, 42),
        ("arm_untar", "Бронежилет UNTAR", "equipment", "armor", "common", 36000, 40),
        ("arm_6b13", "Бронежилет 6Б13", "equipment", "armor", "rare", 75000, 66),
        ("arm_trooper", "Highcom Trooper TFO", "equipment", "armor", "rare", 95000, 72),
        ("arm_korund", "Корунд-ВМ", "equipment", "armor", "epic", 140000, 88),
        ("arm_redut", "FORT Редут-М", "equipment", "armor", "epic", 165000, 94),
        ("arm_gen4", "IOTV Gen4", "equipment", "armor", "epic", 190000, 101),
        ("arm_slick", "Slick Plate Carrier", "equipment", "armor", "legendary", 360000, 132),
        ("arm_hexgrid", "5.11 Hexgrid", "equipment", "armor", "legendary", 350000, 128),
        ("arm_6b43", "6Б43 Забрало-Ш", "equipment", "armor", "legendary", 380000, 136),
        ("arm_cpc", "Crye Precision CPC", "equipment", "armor", "legendary", 310000, 120),
        ("gear_rig", "Тактическая разгрузка Тарзан", "equipment", "gear", "common", 18000, 15),
        ("gear_avs", "Spiritus Systems AVS", "equipment", "gear", "rare", 68000, 35),
        ("gear_blackrock", "BlackRock", "equipment", "gear", "rare", 74000, 38),
        ("gear_alpha", "Защищенный контейнер Альфа", "equipment", "gear", "rare", 150000, 0),
        ("gear_docs", "Документыный кейс", "equipment", "gear", "epic", 220000, 0),
        ("med_ai2", "Аптечка AI-2", "medicine", "gear", "common", 5500, 0),
        ("med_ifak", "Аптечка IFAK", "medicine", "gear", "rare", 28000, 0),
        ("med_salewa", "Salewa", "medicine", "gear", "rare", 32000, 0),
        ("med_grizzly", "Grizzly", "medicine", "gear", "epic", 88000, 0),
        ("med_splint", "Шина Крамера", "medicine", "gear", "common", 6500, 0),
        ("med_morphine", "Морфин", "medicine", "gear", "rare", 15000, 0),
        ("med_propital", "Пропитал", "medicine", "gear", "epic", 42000, 0),
        ("med_obdolbos", "Обдолбос", "medicine", "gear", "epic", 53000, 0),
        ("valuables_gpu", "Видеокарта", "valuables", "components", "epic", 280000, 0),
        ("valuables_reap", "Тепловизор REAP-IR", "valuables", "components", "legendary", 520000, 0),
        ("valuables_ledx", "LEDX", "valuables", "components", "legendary", 680000, 0),
        ("valuables_keycard", "Ключ-карта от Лаборатории", "valuables", "components", "legendary", 620000, 0),
        ("valuables_bitcoin", "Физический Биткоин", "valuables", "components", "legendary", 500000, 0),
        ("valuables_tetriz", "Портативная приставка Тетриз", "valuables", "components", "rare", 95000, 0),
        ("valuables_chain", "Золотая цепочка", "valuables", "components", "rare", 35000, 0),
        ("valuables_rolex", "Rolex", "valuables", "components", "epic", 145000, 0),
        ("component_wire", "Бухта медных проводов", "components", "components", "common", 18000, 0),
        ("component_nails", "Упаковка строительных гвоздей", "components", "components", "common", 12000, 0),
        ("component_screws", "Пачка каленых саморезов", "components", "components", "common", 11000, 0),
        ("component_toolset", "Комплект инструментов", "components", "components", "rare", 52000, 0),
        ("component_fuel", "Канистра топлива", "components", "components", "rare", 85000, 0),
        ("component_filter", "Воздушный фильтр FP-100", "components", "components", "epic", 195000, 0),
        ("component_bp", "Ящик патронов 7.62x39 БП", "components", "components", "epic", 125000, 0),
        ("component_igolnik", "Ящик патронов 5.45 Игольник", "components", "components", "epic", 145000, 0),
        ("component_m995", "Пачка патронов 5.56 M995", "components", "components", "epic", 160000, 0),
        ("component_moonshine", "Самогон «Тарковская слеза»", "components", "components", "epic", 240000, 0),
        ("food_magnat", "Сухпаек Магнат", "medicine", "gear", "common", 16000, 0),
    ]

    items: dict[str, dict[str, Any]] = {}
    for item_id, name, market, warehouse, rarity, price, power in seeds:
        items[item_id] = {
            "id": item_id,
            "name": f"{name} ({RARITY_LABEL[rarity]})",
            "market_category": market,
            "warehouse": warehouse,
            "rarity": rarity,
            "base_price": price,
            "power": power,
        }

    # Named real variants make the catalog broad while keeping every entry
    # recognizable and useful in the economy.
    variant_labels = [
        "Резерв Прапора",
        "Полевой комплект",
        "Модификация BEAR",
        "Модификация USEC",
        "Серийная партия",
        "Партия Госрезерва",
        "Экспортная партия",
        "Трофей с Таможни",
    ]
    seed_items = list(items.values())
    index = 0
    while len(items) < 500:
        source = seed_items[index % len(seed_items)]
        label = variant_labels[index % len(variant_labels)]
        new_id = f"{source['id']}_v{index + 1}"
        rarity = source["rarity"]
        if index % 17 == 0 and rarity != "legendary":
            rarity = ["common", "rare", "epic", "legendary"][
                min(3, RARITY_SCORE[rarity])
            ]
        items[new_id] = {
            **source,
            "id": new_id,
            "name": f"{source['name']} — {label}",
            "rarity": rarity,
            "base_price": int(source["base_price"] * (1 + (index % 5) * 0.08)),
            "power": source["power"] + (index % 5),
        }
        index += 1
    return items


TARKOV_ITEMS = generate_tarkov_catalog()


# ---------------------------------------------------------------------------
# Game data
# ---------------------------------------------------------------------------

WAREHOUSES = {
    "weapons": ("🔫 Оружейный арсенал", 5, 3),
    "armor": ("🪖 Броне-ангар", 5, 3),
    "gear": ("🎒 Вещевой склад", 8, 4),
    "components": ("⚙️ Склад компонентов", 15, 10),
}
WAREHOUSE_COSTS = [0, 25_000, 65_000, 140_000, 280_000, 520_000, 950_000, 1_700_000, 3_000_000, 5_500_000]

HIDEOUT_MODULES = {
    "generator": ("Генератор", "снижает кулдаун ЧВК и Поставок"),
    "workbench": ("Патронный станок", "открывает крафт патронов БП/Игольник"),
    "bitcoin_farm": ("Майнинг-ферма", "пассивно генерирует Биткоины"),
    "intel_center": ("Разведцентр", "сокращает время рейдов Диких"),
    "medstation": ("Медблок", "ускоряет выход наемников из кулдауна"),
    "moonshine_still": ("Самогонный аппарат", "производит алкоголь для продажи"),
    "water_collector": ("Водосборник", "снижает затраты на рейды"),
    "rest_space": ("Зона отдыха", "дает буст к получаемому XP"),
    "stash": ("Склад / Stash", "расширяет лимиты специализированных складов"),
    "weapon_stand": ("Оружейный стенд", "повышает шанс PvP-дуэлей и элитного лута"),
}

SHADOW_BUSINESSES = {
    "topography": ("🖨️ Подпольная Топография", "печать фальшивых карт и пропусков ООН", 650),
    "buyers": ("🏪 Сеть Скупщиков", "пассивный сбор дани с Челоботов", 1_250),
    "chem_lab": ("🧪 Хим-Лаборатория", "производство армейских стимуляторов", 2_400),
    "traffic": ("🚚 Контрабандный Трафик", "платный провоз грузов через блокпосты BEAR/USEC", 4_500),
}

PMC_ROSTER = {
    "viper": ("Viper", 60, 120),
    "nomad": ("Nomad", 70, 135),
    "ronin": ("Ronin", 80, 150),
    "specter": ("Specter", 90, 165),
    "ares": ("Ares", 100, 180),
    "zenith": ("Zenith", 105, 195),
    "fenrir": ("Fenrir", 110, 210),
    "stalker": ("Stalker", 115, 225),
    "siren": ("Siren", 118, 240),
    "pharaoh": ("Pharaoh", 120, 260),
    "revenant": ("Revenant", 60, 999),
}

BOSS_RELICS = {
    "relic_tagilla": ("Кувалда Тагиллы", "+20% к силе Диких и пассивному доходу", 0.20),
    "relic_killa": ("Маска Киллы", "Генератор и Поставки работают на 15% быстрее", 0.15),
    "relic_reshala": ("Золотой ТТ Решалы", "+10% рублей из рейдов", 0.10),
    "relic_shturman": ("СВД Штурмана", "кулдауны ЧВК на 15% быстрее", 0.15),
}

MARKET_CATEGORIES = [
    ("weapons", "🔫 Оружие"),
    ("medicine", "🩺 Медицина"),
    ("valuables", "💎 Драгоценности"),
    ("equipment", "🪖 Экипировка"),
    ("components", "⚙️ Компоненты"),
]

for _item in TARKOV_ITEMS.values():
    _item["display_rarity"] = RARITY_LABEL[_item["rarity"]]


# ---------------------------------------------------------------------------
# JSON database and anti-exploit state transitions
# ---------------------------------------------------------------------------


class Database:
    def __init__(self, path: str):
        self.path = path
        self.lock = threading.RLock()
        self.data: dict[str, Any] = {
            "users": {},
            "p2p_market": [],
            "darkzone_duels": {},
            "active_airdrops": {},
            "known_chats": [],
            "meta": {"next_airdrop_at": time.time() + random.randint(5400, 7200)},
        }
        self.load()

    def load(self):
        with self.lock:
            if os.path.exists(self.path):
                try:
                    with open(self.path, "r", encoding="utf-8") as file:
                        loaded = json.load(file)
                    if isinstance(loaded, dict):
                        self.data.update(loaded)
                except (OSError, ValueError) as exc:
                    logger.error("Could not load database: %s", exc)
            self.data.setdefault("users", {})
            self.data.setdefault("p2p_market", [])
            self.data.setdefault("darkzone_duels", {})
            self.data.setdefault("active_airdrops", {})
            self.data.setdefault("known_chats", [])
            self.data.setdefault(
                "meta",
                {"next_airdrop_at": time.time() + random.randint(5400, 7200)},
            )
            self.save()

    def save(self):
        with self.lock:
            directory = os.path.dirname(os.path.abspath(self.path))
            os.makedirs(directory, exist_ok=True)
            tmp = f"{self.path}.tmp"
            with open(tmp, "w", encoding="utf-8") as file:
                json.dump(self.data, file, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)

    @staticmethod
    def fresh_player(tg_user: types.User) -> dict[str, Any]:
        return {
            "user_id": tg_user.id,
            "username": tg_user.username or f"PMC_{tg_user.id}",
            "first_name": tg_user.first_name or "Оперативник",
            "registered_at": int(time.time()),
            "level": 1,
            "xp": 0,
            "rubles": 50_000,
            "btc": 0.0,
            "mined_btc": 0.0,
            "wilds": 1,
            "warehouses": {
                "weapons": ["wpn_toz106", "wpn_ak74m"],
                "armor": [],
                "gear": ["med_ai2", "med_ai2", "food_magnat"],
                "components": [],
            },
            "warehouse_levels": {key: 1 for key in WAREHOUSES},
            "hideout_level": 1,
            "modules": {key: 0 for key in HIDEOUT_MODULES},
            "businesses": {key: 0 for key in SHADOW_BUSINESSES},
            "supply_levels": {"land": 1, "sea": 1},
            "supplies": {"land": None, "sea": None},
            "wild_raid": None,
            "pmc_cooldowns": {},
            "relics": [],
            "last_economy_tick": time.time(),
            "stats": {
                "raids": 0,
                "raid_wins": 0,
                "darkzone_wins": 0,
                "darkzone_losses": 0,
                "containers": 0,
                "p2p_sales": 0,
            },
        }

    def normalize_player(self, user: dict[str, Any]):
        """Migrate players from earlier builds without losing their inventory."""
        user.setdefault("level", 1)
        user.setdefault("xp", user.pop("exp", 0))
        user.setdefault("rubles", 50_000)
        user.setdefault("btc", float(user.pop("bitcoins", 0) or 0))
        user.setdefault("mined_btc", 0.0)
        user.setdefault("wilds", user.pop("scavs_count", 1))
        user.setdefault("warehouses", {})
        for key in WAREHOUSES:
            user["warehouses"].setdefault(key, [])
        user.setdefault("warehouse_levels", {})
        for key in WAREHOUSES:
            user["warehouse_levels"].setdefault(key, 1)
        user.setdefault("hideout_level", user.get("hideout", {}).get("level", 1))
        old_modules = user.get("hideout", {}).get("modules", {})
        user.setdefault("modules", {})
        for key in HIDEOUT_MODULES:
            user["modules"].setdefault(key, old_modules.get(key, 0))
        user.setdefault("businesses", {key: 0 for key in SHADOW_BUSINESSES})
        for key in SHADOW_BUSINESSES:
            user["businesses"].setdefault(key, 0)
        user.setdefault("supply_levels", {"land": 1, "sea": 1})
        user["supply_levels"].setdefault("land", 1)
        user["supply_levels"].setdefault("sea", 1)
        user.setdefault("supplies", {"land": None, "sea": None})
        user["supplies"].setdefault("land", None)
        user["supplies"].setdefault("sea", None)
        user.setdefault("wild_raid", None)
        user.setdefault("pmc_cooldowns", {})
        user.setdefault("relics", [])
        user.setdefault("last_economy_tick", time.time())
        user.setdefault("stats", {})
        for key in Database.fresh_player(types.User(0, False, "x"))["stats"]:
            user["stats"].setdefault(key, 0)
        user["level"] = max(1, min(MAX_LEVEL, int(user["level"])))
        user["wilds"] = max(0, int(user["wilds"]))

    def accrue(self, user: dict[str, Any], now: Optional[float] = None):
        """Credit passive businesses and mined BTC exactly once per timestamp."""
        now = now or time.time()
        last = float(user.get("last_economy_tick", now))
        elapsed = max(0.0, min(now - last, 7 * 24 * 3600))
        if elapsed <= 0:
            return
        income_per_hour = sum(
            SHADOW_BUSINESSES[key][2] * int(user["businesses"].get(key, 0))
            for key in SHADOW_BUSINESSES
        )
        if "relic_tagilla" in user.get("relics", []):
            income_per_hour *= 1.20
        user["rubles"] += int(income_per_hour * elapsed / 3600)
        mining_level = int(user["modules"].get("bitcoin_farm", 0))
        if mining_level:
            hourly_btc = min(0.10, 0.01 * mining_level)
            user["mined_btc"] = round(
                user.get("mined_btc", 0.0) + hourly_btc * elapsed / 3600,
                6,
            )
        user["last_economy_tick"] = now

    def get_user(self, tg_user: types.User) -> dict[str, Any]:
        uid = str(tg_user.id)
        with self.lock:
            if uid not in self.data["users"]:
                self.data["users"][uid] = self.fresh_player(tg_user)
            user = self.data["users"][uid]
            self.normalize_player(user)
            if tg_user.username:
                user["username"] = tg_user.username
            user["first_name"] = tg_user.first_name or user.get("first_name", "Оперативник")
            self.accrue(user)
            self.save()
            return user

    def find_username(self, username: str) -> Optional[dict[str, Any]]:
        needle = username.lstrip("@").lower()
        for user in self.data["users"].values():
            if str(user.get("username", "")).lower() == needle:
                self.normalize_player(user)
                self.accrue(user)
                return user
        return None

    def register_chat(self, chat_id: int):
        with self.lock:
            if chat_id not in self.data["known_chats"]:
                self.data["known_chats"].append(chat_id)
                self.save()


db = Database(DATABASE_FILE)


# ---------------------------------------------------------------------------
# Economy helpers
# ---------------------------------------------------------------------------


def is_admin(tg_user: types.User) -> bool:
    return (tg_user.username or "").lower() == ADMIN_USERNAME


def exp_for_level(level: int) -> int:
    return int(900 * (level**1.35))


def add_xp(user: dict[str, Any], amount: int):
    boost = 1 + 0.05 * int(user["modules"].get("rest_space", 0))
    user["xp"] += int(amount * boost)
    while user["level"] < MAX_LEVEL and user["xp"] >= exp_for_level(user["level"]):
        user["xp"] -= exp_for_level(user["level"])
        user["level"] += 1


def rank_for(user: dict[str, Any]) -> str:
    if str(user.get("username", "")).lower() == ADMIN_USERNAME:
        return "💀 [ADMIN] 💰 REVENANT GD 💰 💀"
    bands = [
        (15, "Топорщик"),
        (35, "Челобот"),
        (55, "Одиночка"),
        (75, "ЧВК-Оперативник"),
        (95, "Ветеран"),
        (115, "Легенда Барахолки"),
        (MAX_LEVEL, "Хозяин Таркова"),
    ]
    return next(title for top, title in bands if user["level"] <= top)


def warehouse_capacity(user: dict[str, Any], key: str) -> int:
    _, base, per_level = WAREHOUSES[key]
    level = int(user["warehouse_levels"].get(key, 1))
    bonus = 1 + 0.05 * int(user["modules"].get("stash", 0))
    return int((base + (level - 1) * per_level) * bonus)


def can_store(user: dict[str, Any], item_id: str) -> bool:
    item = TARKOV_ITEMS.get(item_id)
    return bool(item and len(user["warehouses"][item["warehouse"]]) < warehouse_capacity(user, item["warehouse"]))


def store_item(user: dict[str, Any], item_id: str) -> bool:
    if not can_store(user, item_id):
        return False
    user["warehouses"][TARKOV_ITEMS[item_id]["warehouse"]].append(item_id)
    return True


def remove_item(user: dict[str, Any], item_id: str) -> bool:
    item = TARKOV_ITEMS.get(item_id)
    if not item:
        return False
    bucket = user["warehouses"][item["warehouse"]]
    if item_id not in bucket:
        return False
    bucket.remove(item_id)
    return True


def items_in_warehouse(user: dict[str, Any], item_id: str) -> int:
    return user["warehouses"][TARKOV_ITEMS[item_id]["warehouse"]].count(item_id)


def sorted_gear(user: dict[str, Any], warehouse: str, reverse: bool) -> list[str]:
    candidates = [
        item_id
        for item_id in user["warehouses"][warehouse]
        if item_id in TARKOV_ITEMS
    ]
    return sorted(
        candidates,
        key=lambda item_id: (
            RARITY_SCORE[TARKOV_ITEMS[item_id]["rarity"]],
            TARKOV_ITEMS[item_id]["power"],
            TARKOV_ITEMS[item_id]["base_price"],
        ),
        reverse=reverse,
    )


def combat_power(user: dict[str, Any]) -> int:
    weapons = sorted_gear(user, "weapons", True)
    armor = sorted_gear(user, "armor", True)
    weapon_power = TARKOV_ITEMS[weapons[0]]["power"] if weapons else 0
    armor_power = TARKOV_ITEMS[armor[0]]["power"] if armor else 0
    module_bonus = 1 + 0.03 * int(user["modules"].get("weapon_stand", 0))
    relic_bonus = 1.20 if "relic_tagilla" in user.get("relics", []) else 1.0
    return int((user["wilds"] * 25 + weapon_power + armor_power) * module_bonus * relic_bonus)


def price_for(item: dict[str, Any]) -> int:
    hour = int(time.time() // 3600)
    digest = hashlib.sha256(f"{item['id']}:{hour}".encode()).hexdigest()
    factor = 0.80 + (int(digest[:8], 16) / 0xFFFFFFFF) * 0.40
    return max(1, int(item["base_price"] * factor))


def btc_price() -> int:
    hour = int(time.time() // 3600)
    digest = hashlib.sha256(f"btc:{hour}".encode()).hexdigest()
    return int(500_000 * (0.80 + int(digest[:8], 16) / 0xFFFFFFFF * 0.40))


def fmt_seconds(seconds: float) -> str:
    seconds = max(0, int(seconds))
    return f"{seconds // 3600:02d}:{(seconds % 3600) // 60:02d}:{seconds % 60:02d}"


def cooldown_seconds(user: dict[str, Any], base_minutes: int, kind: str = "pmc") -> int:
    reduction = 0.03 * int(user["modules"].get("generator", 0))
    if kind == "pmc":
        reduction += 0.02 * int(user["modules"].get("medstation", 0))
    if "relic_killa" in user.get("relics", []):
        reduction += 0.15
    if kind == "pmc" and "relic_shturman" in user.get("relics", []):
        reduction += 0.15
    return max(300, int(base_minutes * 60 * max(0.40, 1 - reduction)))


def raid_duration(user: dict[str, Any]) -> int:
    reduction = 0.04 * int(user["modules"].get("intel_center", 0))
    return max(8 * 60, int(RAID_DURATION_SECONDS * max(0.40, 1 - reduction)))


def raid_cost(user: dict[str, Any], base: int) -> int:
    reduction = 0.02 * int(user["modules"].get("water_collector", 0))
    return max(1000, int(base * max(0.65, 1 - reduction)))


def pick_loadout(user: dict[str, Any], style: str) -> list[str]:
    reverse = style == "top"
    weapon_candidates = sorted_gear(user, "weapons", reverse)
    armor_candidates = sorted_gear(user, "armor", reverse)
    if style == "low":
        weapon_candidates = [
            item_id for item_id in weapon_candidates if TARKOV_ITEMS[item_id]["rarity"] == "common"
        ] or weapon_candidates
        armor_candidates = [
            item_id for item_id in armor_candidates if TARKOV_ITEMS[item_id]["rarity"] == "common"
        ] or armor_candidates
    else:
        top_rarities = {"epic", "legendary"}
        weapon_candidates = [
            item_id for item_id in weapon_candidates if TARKOV_ITEMS[item_id]["rarity"] in top_rarities
        ] or weapon_candidates
        armor_candidates = [
            item_id for item_id in armor_candidates if TARKOV_ITEMS[item_id]["rarity"] in top_rarities
        ] or armor_candidates
    selected: list[str] = []
    if weapon_candidates:
        selected.append(weapon_candidates[0])
    if armor_candidates:
        selected.append(armor_candidates[0])
    return selected


# ---------------------------------------------------------------------------
# Text rendering and inline keyboards
# ---------------------------------------------------------------------------


def button(text: str, callback: str) -> types.InlineKeyboardButton:
    return types.InlineKeyboardButton(text, callback_data=callback)


def main_menu(user: dict[str, Any], admin: bool = False) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(button("👤 Профиль", "menu_profile"), button("🎒 Склады", "menu_warehouses"))
    kb.add(button("🪓 Дикие и рейды", "menu_wilds"), button("🪖 ЧВК", "menu_pmc"))
    kb.add(button("🏚️ Убежище", "menu_hideout"), button("💼 Теневые бизнесы", "menu_businesses"))
    kb.add(button("🏪 Барахолка", "market_menu"), button("⚔️ Даркзон", "darkzone_menu"))
    kb.add(button("🚚 Поставки", "supply_menu"), button("📦 Контейнеры", "container_menu"))
    kb.add(button("🪂 Эирдропы", "airdrop_info"), button("ℹ️ Помощь", "help"))
    if admin:
        kb.add(button("👑 Админ-панель", "admin_menu"))
    return kb


def back_menu(callback: str = "menu_main") -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup()
    kb.add(button("🔙 Назад", callback))
    return kb


def profile_text(user: dict[str, Any]) -> str:
    raid = user.get("wild_raid")
    raid_line = "нет"
    if raid:
        raid_line = f"{raid['style_label']} — ещё {fmt_seconds(raid['finish_at'] - time.time())}"
    business_income = sum(
        SHADOW_BUSINESSES[key][2] * int(user["businesses"].get(key, 0))
        for key in SHADOW_BUSINESSES
    )
    return (
        "🪖 <b>ДОСЬЕ ОПЕРАТИВНИКА</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"👤 @{html.escape(str(user['username']))}\n"
        f"🏅 Ранг: <b>{html.escape(rank_for(user))}</b>\n"
        f"⭐ Уровень: <b>{user['level']}/{MAX_LEVEL}</b> | XP {user['xp']:,}/{exp_for_level(user['level']):,}\n"
        f"💰 Рубли: <b>{user['rubles']:,} ₽</b>\n"
        f"₿ Кошелёк: <b>{user['btc']:.4f} BTC</b> | Намайнено: {user['mined_btc']:.4f}\n"
        f"🪓 Дикие: <b>{user['wilds']}</b> | Рейд: <b>{raid_line}</b>\n"
        f"💼 Автодоход бизнесов: <b>{business_income:,} ₽/ч</b>\n"
        f"⚔️ Боевая мощь: <b>{combat_power(user)}</b>\n"
        f"🏆 Реликвии: {', '.join(BOSS_RELICS[r][0] for r in user['relics'] if r in BOSS_RELICS) or 'нет'}"
    )


def warehouses_text(user: dict[str, Any]) -> str:
    rows = []
    for key, (title, _, _) in WAREHOUSES.items():
        rows.append(
            f"{title}: ур. {user['warehouse_levels'][key]}/10 — "
            f"{len(user['warehouses'][key])}/{warehouse_capacity(user, key)}"
        )
    return "📦 <b>СПЕЦИАЛИЗИРОВАННЫЕ СКЛАДЫ</b>\n━━━━━━━━━━━━━━━━━━\n" + "\n".join(rows)


def hideout_text(user: dict[str, Any]) -> str:
    lines = [
        f"🏚️ <b>УБЕЖИЩЕ — УРОВЕНЬ {user['hideout_level']}/10</b>",
        "Уровень модуля не может быть выше уровня Убежища.\n",
    ]
    for key, (name, bonus) in HIDEOUT_MODULES.items():
        lines.append(f"• {name}: {user['modules'][key]}/10 — {bonus}")
    return "\n".join(lines)


def wilds_text(user: dict[str, Any]) -> str:
    active = user.get("wild_raid")
    status = "Рейд не запущен."
    if active:
        status = (
            f"⏱️ {active['style_label']} завершится через "
            f"<b>{fmt_seconds(active['finish_at'] - time.time())}</b>."
        )
    return (
        "🪓 <b>ОТРЯД ДИКИХ</b>\n━━━━━━━━━━━━━━━━━━\n"
        f"В отряде: <b>{user['wilds']}</b>\n"
        f"{status}\n\n"
        "Снаряжение резервируется на время рейда. При провале оно теряется."
    )


def businesses_text(user: dict[str, Any]) -> str:
    rows = ["💼 <b>4 ТЕНЕВЫХ БИЗНЕСА</b>\n━━━━━━━━━━━━━━━━━━"]
    rows.append("Уровень 0: 🔒 Заблокировано. Доход начисляется автоматически.")
    for key, (name, description, rate) in SHADOW_BUSINESSES.items():
        level = user["businesses"][key]
        rows.append(f"{name}: <b>{level}/10</b> — {description}; {rate * level:,} ₽/ч")
    return "\n".join(rows)


def containers_text() -> str:
    return (
        "📦 <b>КОНТЕЙНЕРЫ КОНТРАБАНДЫ</b>\n━━━━━━━━━━━━━━━━━━\n"
        "Редкие контейнеры могут содержать эксклюзивные реликвии боссов.\n"
        "• Common: 15 000 ₽\n• Rare: 75 000 ₽\n"
        "• Epic: 250 000 ₽\n• Legendary: 750 000 ₽"
    )


def market_items(category: str, page: int) -> tuple[list[dict[str, Any]], int, int]:
    selected = [x for x in TARKOV_ITEMS.values() if x["market_category"] == category]
    per_page = 6
    pages = max(1, (len(selected) + per_page - 1) // per_page)
    page = page % pages
    return selected[page * per_page : (page + 1) * per_page], page, pages


def market_text(category: str, page: int) -> tuple[str, types.InlineKeyboardMarkup]:
    title = dict(MARKET_CATEGORIES).get(category, "Барахолка")
    items, page, pages = market_items(category, page)
    text = f"🏪 <b>{title.upper()}</b> — {page + 1}/{pages}\nЦены обновляются каждый час на ±20%.\n\n"
    kb = types.InlineKeyboardMarkup(row_width=1)
    for item in items:
        text += f"• {item['name']} — <b>{price_for(item):,} ₽</b>\n"
        kb.add(button(f"Купить: {item['name'][:25]}", f"market_buy:{item['id']}"))
    nav = []
    if page:
        nav.append(button("⬅️ Back", f"market_page:{category}:{page - 1}"))
    if page < pages - 1:
        nav.append(button("Next ➡️", f"market_page:{category}:{page + 1}"))
    if nav:
        kb.row(*nav)
    kb.add(button("💸 Быстрая продажа Прапору (30%)", "quick_sell_menu"))
    kb.add(button("🤝 P2P-рынок (налог 10%)", "p2p_menu"))
    kb.add(button("₿ BTC: курс и продажа", "btc_menu"))
    kb.add(button("🔙 Категории", "market_menu"))
    return text, kb


# ---------------------------------------------------------------------------
# Raid, supply, airdrop and timed jobs
# ---------------------------------------------------------------------------


def start_wild_raid(user: dict[str, Any], style: str, chat_id: int) -> tuple[bool, str]:
    if user.get("wild_raid"):
        return False, "У отряда уже идёт рейд."
    base_cost = 5_000 if style == "low" else 50_000
    cost = raid_cost(user, base_cost)
    if user["rubles"] < cost:
        return False, f"Нужно {cost:,} ₽."
    loadout = pick_loadout(user, style)
    for item_id in loadout:
        remove_item(user, item_id)
    duration = raid_duration(user)
    user["rubles"] -= cost
    user["stats"]["raids"] += 1
    user["wild_raid"] = {
        "style": style,
        "style_label": "🪓 Снарядить по-бомжу" if style == "low" else "👑 Снарядить в ТОП",
        "started_at": time.time(),
        "finish_at": time.time() + duration,
        "chat_id": chat_id,
        "loadout": loadout,
        "cost": cost,
    }
    return True, (
        f"✅ Рейд запущен на реальные <b>{fmt_seconds(duration)}</b>.\n"
        f"Списано: <b>{cost:,} ₽</b>.\n"
        f"Зарезервировано предметов: {len(loadout)}.\n"
        "По завершении бот пришлёт уведомление."
    )


def complete_wild_raid(user: dict[str, Any]) -> Optional[str]:
    raid = user.get("wild_raid")
    if not raid or raid["finish_at"] > time.time():
        return None
    style = raid["style"]
    loadout = raid.get("loadout", [])
    quality = sum(TARKOV_ITEMS.get(item, {}).get("power", 0) for item in loadout)
    base_survival = 0.56 if style == "low" else 0.91
    chance = min(0.97, base_survival + quality / 2500)
    survived = random.random() < chance
    user["wild_raid"] = None
    if not survived:
        user["wilds"] = max(0, user["wilds"] - (1 if random.random() < 0.35 else 0))
        add_xp(user, 35)
        return (
            "💀 <b>ДИКИЕ НЕ ВЕРНУЛИСЬ</b>\n"
            "Рейд провален. Зарезервированное снаряжение потеряно.\n"
            f"Шанс выживания был: {chance:.0%}."
        )

    for item_id in loadout:
        store_item(user, item_id)
    loot_cash = random.randint(12_000, 30_000) if style == "low" else random.randint(75_000, 155_000)
    if "relic_reshala" in user["relics"]:
        loot_cash = int(loot_cash * 1.10)
    user["rubles"] += loot_cash
    loot_names = []
    candidates = list(TARKOV_ITEMS)
    for _ in range(random.randint(1, 2 if style == "low" else 4)):
        item_id = random.choice(candidates)
        if store_item(user, item_id):
            loot_names.append(TARKOV_ITEMS[item_id]["name"])
    user["stats"]["raid_wins"] += 1
    add_xp(user, 220 if style == "low" else 500)
    return (
        "🎉 <b>ДИКИЕ ВЕРНУЛИСЬ С ДОБЫЧЕЙ</b>\n"
        f"💰 Чистая добыча: <b>+{loot_cash:,} ₽</b>\n"
        f"📦 Лут: {', '.join(loot_names) or 'склады переполнены'}\n"
        f"⭐ XP начислен. Шанс выживания был: {chance:.0%}."
    )


def start_supply(user: dict[str, Any], channel: str, chat_id: Optional[int] = None) -> tuple[bool, str]:
    if user["supplies"].get(channel):
        return False, "Этот канал уже в пути."
    level = int(user["supply_levels"][channel])
    base_time = LAND_SUPPLY_SECONDS if channel == "land" else SEA_SUPPLY_SECONDS
    reduction = 0.04 * level + 0.03 * int(user["modules"].get("generator", 0))
    if "relic_killa" in user["relics"]:
        reduction += 0.15
    duration = max(10 * 60, int(base_time * max(0.35, 1 - reduction)))
    fee = 7_500 if channel == "land" else 25_000
    fee = max(1000, int(fee * max(0.65, 1 - 0.02 * user["modules"].get("water_collector", 0))))
    if user["rubles"] < fee:
        return False, f"Для поставки нужно {fee:,} ₽."
    user["rubles"] -= fee
    user["supplies"][channel] = {
        "finish_at": time.time() + duration,
        "fee": fee,
        "chat_id": chat_id or user["user_id"],
    }
    return True, f"🚚 Поставка принята. Прибытие через <b>{fmt_seconds(duration)}</b>."


def complete_supply(user: dict[str, Any], channel: str) -> Optional[str]:
    job = user["supplies"].get(channel)
    if not job or job["finish_at"] > time.time():
        return None
    user["supplies"][channel] = None
    received = []
    for _ in range(3 if channel == "land" else 7):
        item_id = random.choice(list(TARKOV_ITEMS))
        if store_item(user, item_id):
            received.append(TARKOV_ITEMS[item_id]["name"])
    return f"📦 <b>Поставка прибыла ({channel})</b>\n" + "\n".join(f"• {x}" for x in received) if received else "📦 Поставка прибыла, но склады заполнены."


def trigger_airdrop():
    with db.lock:
        drop_id = f"drop_{int(time.time())}"
        db.data["active_airdrops"][drop_id] = {
            "claimed": False,
            "created_at": time.time(),
            "claimed_by": None,
        }
        db.data["meta"]["next_airdrop_at"] = time.time() + random.randint(5400, 7200)
        db.save()
    kb = types.InlineKeyboardMarkup()
    kb.add(button("📦 ОБЫСКАТЬ ЯЩИК", f"airdrop_claim:{drop_id}"))
    message = (
        "🛩️ <b>ЭИРДРОП В ТАРКОВЕ!</b>\n"
        "Первый оперативник забирает содержимое ящика.\n"
        "Внутри: Биткоин или эксклюзивный трофей босса."
    )
    for chat_id in list(db.data.get("known_chats", [])):
        try:
            bot.send_message(chat_id, message, parse_mode="HTML", reply_markup=kb)
        except Exception as exc:
            logger.warning("airdrop to %s failed: %s", chat_id, exc)


def timed_worker():
    while True:
        try:
            notifications: list[tuple[int, str]] = []
            with db.lock:
                for user in db.data["users"].values():
                    db.normalize_player(user)
                    db.accrue(user)
                    raid_chat_id = user.get("wild_raid", {}).get("chat_id", user["user_id"]) if user.get("wild_raid") else user["user_id"]
                    raid_message = complete_wild_raid(user)
                    if raid_message:
                        notifications.append((raid_chat_id, raid_message))
                    for channel in ("land", "sea"):
                        supply_chat_id = user.get("supplies", {}).get(channel, {}).get("chat_id", user["user_id"]) if user.get("supplies", {}).get(channel) else user["user_id"]
                        supply_message = complete_supply(user, channel)
                        if supply_message:
                            notifications.append((supply_chat_id, supply_message))
                if time.time() >= db.data["meta"].get("next_airdrop_at", 0):
                    should_drop = True
                else:
                    should_drop = False
                db.save()
            for chat_id, message in notifications:
                try:
                    bot.send_message(chat_id, message, parse_mode="HTML", reply_markup=back_menu())
                except Exception as exc:
                    logger.warning("timer notification failed: %s", exc)
            if should_drop:
                trigger_airdrop()
        except Exception:
            logger.exception("timed worker iteration failed")
        time.sleep(10)


# ---------------------------------------------------------------------------
# Menus and commands
# ---------------------------------------------------------------------------


def send_home(chat_id: int, user: dict[str, Any], message_id: Optional[int] = None):
    text = profile_text(user)
    markup = main_menu(user, str(user["username"]).lower() == ADMIN_USERNAME)
    if message_id:
        bot.edit_message_text(text, chat_id, message_id, parse_mode="HTML", reply_markup=markup)
    else:
        bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=markup)


@bot.message_handler(commands=["start", "menu"])
def command_start(message: types.Message):
    db.register_chat(message.chat.id)
    user = db.get_user(message.from_user)
    send_home(message.chat.id, user)


@bot.message_handler(commands=["profile"])
def command_profile(message: types.Message):
    user = db.get_user(message.from_user)
    bot.send_message(message.chat.id, profile_text(user), parse_mode="HTML", reply_markup=back_menu())


def admin_target(parts: list[str]) -> Optional[dict[str, Any]]:
    return db.find_username(parts[1]) if len(parts) > 1 else None


def resolve_item(query: str) -> Optional[str]:
    normalized = query.strip().lower().replace("_", " ")
    exact = [
        item_id for item_id, item in TARKOV_ITEMS.items()
        if item["name"].lower() == normalized or item_id.lower() == normalized
    ]
    if exact:
        return exact[0]
    return next(
        (item_id for item_id, item in TARKOV_ITEMS.items() if normalized in item["name"].lower()),
        None,
    )


def admin_only(message: types.Message) -> bool:
    if is_admin(message.from_user):
        return True
    bot.reply_to(message, "⛔ Команда доступна только @revenuts.")
    return False


@bot.message_handler(commands=["give_money"])
def command_give_money(message: types.Message):
    if not admin_only(message):
        return
    parts = message.text.split()
    target = admin_target(parts)
    try:
        amount = int(parts[2])
    except (IndexError, ValueError):
        bot.reply_to(message, "Формат: /give_money @username 500000")
        return
    if not target or amount <= 0:
        bot.reply_to(message, "Игрок не найден или сумма некорректна.")
        return
    target["rubles"] += amount
    db.save()
    bot.reply_to(message, f"✅ @{target['username']} получил {amount:,} ₽.")


@bot.message_handler(commands=["give_item"])
def command_give_item(message: types.Message):
    if not admin_only(message):
        return
    parts = message.text.split(maxsplit=2)
    target = admin_target(parts)
    item_id = resolve_item(parts[2]) if len(parts) > 2 else None
    if not target or not item_id:
        bot.reply_to(message, "Формат: /give_item @username название предмета")
        return
    if not store_item(target, item_id):
        bot.reply_to(message, "Соответствующий склад игрока заполнен.")
        return
    db.save()
    bot.reply_to(message, f"✅ Выдано: {TARKOV_ITEMS[item_id]['name']}.")


def resolve_module(query: str) -> Optional[str]:
    q = query.lower().strip()
    for key, (name, _) in HIDEOUT_MODULES.items():
        if q == key or q in name.lower():
            return key
    return None


@bot.message_handler(commands=["set_module"])
def command_set_module(message: types.Message):
    if not admin_only(message):
        return
    parts = message.text.split(maxsplit=2)
    target = admin_target(parts)
    module_query = ""
    level_text = ""
    if len(parts) > 2:
        module_query, _, level_text = parts[2].rpartition(" ")
    module = resolve_module(module_query)
    try:
        level = int(level_text)
    except ValueError:
        level = -1
    if not target or not module or not 0 <= level <= 10:
        bot.reply_to(message, "Формат: /set_module @username generator 5")
        return
    target["modules"][module] = min(level, target["hideout_level"])
    db.save()
    bot.reply_to(message, f"✅ {HIDEOUT_MODULES[module][0]} установлен на уровень {target['modules'][module]}.")


@bot.message_handler(commands=["set_level"])
def command_set_level(message: types.Message):
    if not admin_only(message):
        return
    parts = message.text.split()
    target = admin_target(parts)
    try:
        level = int(parts[2])
    except (IndexError, ValueError):
        level = -1
    if not target or not 1 <= level <= MAX_LEVEL:
        bot.reply_to(message, f"Формат: /set_level @username 1-{MAX_LEVEL}")
        return
    target["level"] = level
    target["xp"] = 0
    db.save()
    bot.reply_to(message, f"✅ Уровень @{target['username']} установлен: {level}.")


@bot.message_handler(commands=["reset_player"])
def command_reset_player(message: types.Message):
    if not admin_only(message):
        return
    parts = message.text.split()
    target = admin_target(parts)
    if not target:
        bot.reply_to(message, "Формат: /reset_player @username")
        return
    identity = types.User(target["user_id"], False, target.get("first_name", "Оперативник"), username=target.get("username"))
    db.data["users"][str(target["user_id"])] = db.fresh_player(identity)
    db.save()
    bot.reply_to(message, f"♻️ Прогресс @{target['username']} полностью сброшен.")


# ---------------------------------------------------------------------------
# Callback router: all gameplay actions are buttons
# ---------------------------------------------------------------------------


@bot.callback_query_handler(func=lambda call: True)
def callback_router(call: types.CallbackQuery):
    db.lock.acquire()
    try:
        user = db.get_user(call.from_user)
        db.register_chat(call.message.chat.id)
        data = call.data or ""
        chat_id = call.message.chat.id
        message_id = call.message.message_id
        bot.answer_callback_query(call.id)

        finished = complete_wild_raid(user)
        if finished:
            bot.send_message(chat_id, finished, parse_mode="HTML")
            db.save()

        if data == "menu_main":
            send_home(chat_id, user, message_id)
        elif data == "menu_profile":
            bot.edit_message_text(profile_text(user), chat_id, message_id, parse_mode="HTML", reply_markup=back_menu())
        elif data == "menu_warehouses":
            kb = types.InlineKeyboardMarkup(row_width=2)
            for key, (title, _, _) in WAREHOUSES.items():
                kb.add(button(f"{title} {len(user['warehouses'][key])}/{warehouse_capacity(user, key)}", f"warehouse_view:{key}"))
            kb.add(button("⬆️ Улучшить склады", "warehouse_upgrades"), button("🔙 Меню", "menu_main"))
            bot.edit_message_text(warehouses_text(user), chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("warehouse_view:"):
            key = data.split(":", 1)[1]
            items = user["warehouses"][key]
            text = f"{WAREHOUSES[key][0]}\n\n" + "\n".join(
                f"• {TARKOV_ITEMS[item]['name']}" for item in items if item in TARKOV_ITEMS
            )
            kb = types.InlineKeyboardMarkup()
            kb.add(button("🔙 Склады", "menu_warehouses"))
            bot.edit_message_text(text or "Склад пуст.", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data == "warehouse_upgrades":
            kb = types.InlineKeyboardMarkup(row_width=1)
            for key, (title, _, _) in WAREHOUSES.items():
                level = user["warehouse_levels"][key]
                if level < 10:
                    cost = WAREHOUSE_COSTS[level]
                    kb.add(button(f"{title}: {level}→{level + 1} ({cost:,} ₽)", f"warehouse_upgrade:{key}"))
                else:
                    kb.add(button(f"{title}: MAX", "noop"))
            kb.add(button("🔙 Склады", "menu_warehouses"))
            bot.edit_message_text("⬆️ <b>ПРОКАЧКА СКЛАДОВ</b>\nКаждый тип имеет 10 уровней.", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("warehouse_upgrade:"):
            key = data.split(":", 1)[1]
            level = user["warehouse_levels"][key]
            cost = WAREHOUSE_COSTS[level] if level < 10 else 0
            if level >= 10 or user["rubles"] < cost:
                bot.answer_callback_query(call.id, "Недостаточно рублей или склад уже максимального уровня.", show_alert=True)
            else:
                user["rubles"] -= cost
                user["warehouse_levels"][key] += 1
                add_xp(user, 100)
                db.save()
                bot.answer_callback_query(call.id, "Склад улучшен.", show_alert=True)
                bot.edit_message_text(warehouses_text(user), chat_id, message_id, parse_mode="HTML", reply_markup=back_menu("menu_warehouses"))
        elif data == "menu_wilds":
            kb = types.InlineKeyboardMarkup(row_width=1)
            kb.add(button("🪓 Снарядить по-бомжу — 5 000 ₽", "raid_start:low"))
            kb.add(button("👑 Снарядить в ТОП — 50 000 ₽", "raid_start:top"))
            kb.add(button("🔙 Меню", "menu_main"))
            bot.edit_message_text(wilds_text(user), chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("raid_start:"):
            style = data.split(":", 1)[1]
            ok, result = start_wild_raid(user, style, chat_id)
            db.save()
            bot.answer_callback_query(call.id, result.replace("<b>", "").replace("</b>", ""), show_alert=not ok)
            bot.edit_message_text(result, chat_id, message_id, parse_mode="HTML", reply_markup=back_menu("menu_wilds"))
        elif data == "menu_hideout":
            kb = types.InlineKeyboardMarkup(row_width=1)
            for key, (name, _) in HIDEOUT_MODULES.items():
                level = user["modules"][key]
                kb.add(button(f"{name}: {level}/10", f"module_upgrade:{key}"))
            if user["hideout_level"] < 10:
                cost = int(75_000 * 1.8 ** (user["hideout_level"] - 1))
                kb.add(button(f"⬆️ Убежище {user['hideout_level'] + 1} ({cost:,} ₽)", "hideout_upgrade"))
            kb.add(button("🔙 Меню", "menu_main"))
            bot.edit_message_text(hideout_text(user), chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data == "hideout_upgrade":
            level = user["hideout_level"]
            cost = int(75_000 * 1.8 ** (level - 1))
            if level >= 10 or user["rubles"] < cost:
                bot.answer_callback_query(call.id, "Недостаточно рублей.", show_alert=True)
            else:
                user["rubles"] -= cost
                user["hideout_level"] += 1
                db.save()
                bot.edit_message_text(hideout_text(user), chat_id, message_id, parse_mode="HTML", reply_markup=back_menu("menu_hideout"))
        elif data.startswith("module_upgrade:"):
            key = data.split(":", 1)[1]
            level = user["modules"][key]
            cost = int(25_000 * 1.65 ** level)
            if level >= user["hideout_level"] or level >= 10 or user["rubles"] < cost:
                bot.answer_callback_query(call.id, "Сначала поднимите Убежище или накопите рублей.", show_alert=True)
            else:
                user["rubles"] -= cost
                user["modules"][key] += 1
                db.save()
                bot.edit_message_text(hideout_text(user), chat_id, message_id, parse_mode="HTML", reply_markup=back_menu("menu_hideout"))
        elif data == "menu_businesses":
            kb = types.InlineKeyboardMarkup(row_width=1)
            for key, (name, _, _) in SHADOW_BUSINESSES.items():
                level = user["businesses"][key]
                cost = int(20_000 * 1.7 ** level)
                kb.add(button(f"{name}: {level}/10 ({cost:,} ₽)", f"business_upgrade:{key}"))
            kb.add(button("🔙 Меню", "menu_main"))
            bot.edit_message_text(businesses_text(user), chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("business_upgrade:"):
            key = data.split(":", 1)[1]
            level = user["businesses"][key]
            cost = int(20_000 * 1.7 ** level)
            if level >= 10 or user["rubles"] < cost:
                bot.answer_callback_query(call.id, "Недостаточно рублей или бизнес уже 10 уровня.", show_alert=True)
            else:
                user["rubles"] -= cost
                user["businesses"][key] += 1
                db.save()
                bot.edit_message_text(businesses_text(user), chat_id, message_id, parse_mode="HTML", reply_markup=back_menu("menu_businesses"))
        elif data == "menu_pmc":
            kb = types.InlineKeyboardMarkup(row_width=2)
            for key, (name, minutes, power) in PMC_ROSTER.items():
                if key == "revenant" and str(user["username"]).lower() != ADMIN_USERNAME:
                    continue
                remaining = user["pmc_cooldowns"].get(key, 0) - time.time()
                label = f"⏳ {name} ({fmt_seconds(remaining)})" if remaining > 0 else f"⚔️ {name}"
                kb.add(button(label, "noop" if remaining > 0 else f"pmc_run:{key}"))
            kb.add(button("🔙 Меню", "menu_main"))
            bot.edit_message_text("🪖 <b>11 УНИКАЛЬНЫХ ЧВК</b>\n10 элитных бойцов и Revenant только для @revenuts.\nКулдаун считается по timestamp.", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("pmc_run:"):
            key = data.split(":", 1)[1]
            if key not in PMC_ROSTER or (key == "revenant" and str(user["username"]).lower() != ADMIN_USERNAME):
                bot.answer_callback_query(call.id, "Доступ запрещён.", show_alert=True)
            else:
                name, minutes, power = PMC_ROSTER[key]
                if user["pmc_cooldowns"].get(key, 0) > time.time():
                    bot.answer_callback_query(call.id, "ЧВК ещё на кулдауне.", show_alert=True)
                else:
                    user["pmc_cooldowns"][key] = time.time() + cooldown_seconds(user, minutes)
                    reward = random.randint(35_000, 95_000) + power * 100
                    if "relic_reshala" in user["relics"]:
                        reward = int(reward * 1.1)
                    user["rubles"] += reward
                    add_xp(user, 180)
                    db.save()
                    bot.edit_message_text(f"✅ <b>{name}</b> вернулся с рейда.\n💰 +{reward:,} ₽\n⏱️ Следующий выход через {minutes} минут с учетом модулей.", chat_id, message_id, parse_mode="HTML", reply_markup=back_menu("menu_pmc"))
        elif data == "darkzone_menu":
            kb = types.InlineKeyboardMarkup(row_width=2)
            for stake in (5_000, 10_000, 25_000, 50_000, 100_000):
                kb.add(button(f"⚔️ Вызов на {stake:,} ₽", f"duel_create:{stake}"))
            kb.add(button("🔙 Меню", "menu_main"))
            bot.edit_message_text(f"⚔️ <b>ДАРКЗОН В БЕСЕДЕ</b>\nМощь вашего отряда: <b>{combat_power(user)}</b>\nБанк получает победитель.", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("duel_create:"):
            stake = int(data.split(":", 1)[1])
            if user["rubles"] < stake or user["wilds"] < 1:
                bot.answer_callback_query(call.id, "Нужны деньги и хотя бы один Дикий.", show_alert=True)
            else:
                duel_id = f"duel_{user['user_id']}_{int(time.time() * 1000)}"
                user["rubles"] -= stake
                db.data["darkzone_duels"][duel_id] = {
                    "creator_id": user["user_id"],
                    "creator_name": user["username"],
                    "stake": stake,
                    "created_at": time.time(),
                    "chat_id": chat_id,
                }
                db.save()
                kb = types.InlineKeyboardMarkup()
                kb.add(button("⚔️ Принять бой", f"duel_accept:{duel_id}"))
                bot.send_message(chat_id, f"💀 <b>ВЫЗОВ В ДАРКЗОН</b>\n@{html.escape(user['username'])} выставил {stake:,} ₽.\nБанк: <b>{stake * 2:,} ₽</b>.", parse_mode="HTML", reply_markup=kb)
        elif data.startswith("duel_accept:"):
            duel_id = data.split(":", 1)[1]
            duel = db.data["darkzone_duels"].get(duel_id)
            if not duel or duel["creator_id"] == user["user_id"]:
                bot.answer_callback_query(call.id, "Этот бой недоступен.", show_alert=True)
            elif user["rubles"] < duel["stake"] or user["wilds"] < 1:
                bot.answer_callback_query(call.id, "Нужны деньги и Дикий.", show_alert=True)
            else:
                creator = db.data["users"].get(str(duel["creator_id"]))
                if not creator:
                    db.data["darkzone_duels"].pop(duel_id, None)
                    db.save()
                    bot.answer_callback_query(call.id, "Создатель не найден.", show_alert=True)
                else:
                    creator_power = combat_power(creator) * random.uniform(0.90, 1.10)
                    acceptor_power = combat_power(user) * random.uniform(0.90, 1.10)
                    user["rubles"] -= duel["stake"]
                    winner, loser = (creator, user) if creator_power >= acceptor_power else (user, creator)
                    winner["rubles"] += duel["stake"] * 2
                    loser["wilds"] = max(0, loser["wilds"] - 1)
                    winner["stats"]["darkzone_wins"] += 1
                    loser["stats"]["darkzone_losses"] += 1
                    db.data["darkzone_duels"].pop(duel_id, None)
                    db.save()
                    bot.edit_message_text(f"⚔️ <b>ИТОГ ДАРКЗОНЫ</b>\n🏆 Победитель: @{winner['username']}\n💰 Банк: {duel['stake'] * 2:,} ₽\n📉 Проигравший потерял одного Дикого.", chat_id, message_id, parse_mode="HTML")
        elif data == "market_menu":
            kb = types.InlineKeyboardMarkup(row_width=2)
            for key, title in MARKET_CATEGORIES:
                kb.add(button(title, f"market_page:{key}:0"))
            kb.add(button("₿ BTC", "btc_menu"), button("🤝 P2P", "p2p_menu"))
            kb.add(button("💸 Продать Прапору за 30%", "quick_sell_menu"), button("🔙 Меню", "menu_main"))
            bot.edit_message_text("🏪 <b>БАРАХОЛКА ТАРКОВА</b>\nВыберите категорию.", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("market_page:"):
            _, category, page = data.split(":")
            text, kb = market_text(category, int(page))
            bot.edit_message_text(text, chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("market_buy:"):
            item_id = data.split(":", 1)[1]
            item = TARKOV_ITEMS.get(item_id)
            price = price_for(item) if item else 0
            if not item or user["rubles"] < price or not store_item(user, item_id):
                bot.answer_callback_query(call.id, "Недостаточно рублей или соответствующий склад заполнен.", show_alert=True)
            else:
                user["rubles"] -= price
                add_xp(user, 20)
                db.save()
                bot.answer_callback_query(call.id, f"Куплено за {price:,} ₽.", show_alert=True)
        elif data == "quick_sell_menu":
            kb = types.InlineKeyboardMarkup(row_width=1)
            shown = set()
            for bucket in user["warehouses"].values():
                for item_id in bucket:
                    if item_id not in shown and item_id in TARKOV_ITEMS:
                        shown.add(item_id)
                        kb.add(button(f"Продать {TARKOV_ITEMS[item_id]['name'][:28]}", f"quick_sell:{item_id}"))
            kb.add(button("🔙 Барахолка", "market_menu"))
            bot.edit_message_text("💸 <b>БЫСТРАЯ ПРОДАЖА ПРАПОРУ</b>\nЗа любую вещь начисляется ровно 30% базовой стоимости.", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("quick_sell:"):
            item_id = data.split(":", 1)[1]
            if remove_item(user, item_id):
                value = int(TARKOV_ITEMS[item_id]["base_price"] * 0.30)
                user["rubles"] += value
                db.save()
                bot.answer_callback_query(call.id, f"+{value:,} ₽.", show_alert=True)
            else:
                bot.answer_callback_query(call.id, "Предмет уже продан.", show_alert=True)
        elif data == "btc_menu":
            kb = types.InlineKeyboardMarkup()
            kb.add(button("💰 Забрать намайненное", "btc_collect"))
            kb.add(button(f"₿ Продать BTC по {btc_price():,} ₽", "btc_sell"))
            kb.add(button("🔙 Барахолка", "market_menu"))
            bot.edit_message_text(f"₿ <b>БИТКОИН-ФЕРМА</b>\nНакоплено: {user['mined_btc']:.4f} BTC\nКошелёк: {user['btc']:.4f} BTC\nКурс меняется каждый час: {btc_price():,} ₽.", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data == "btc_collect":
            user["btc"] = round(user["btc"] + user["mined_btc"], 6)
            user["mined_btc"] = 0.0
            db.save()
            bot.answer_callback_query(call.id, "Намайненное переведено в кошелёк.", show_alert=True)
        elif data == "btc_sell":
            if user["btc"] <= 0:
                bot.answer_callback_query(call.id, "В кошельке нет BTC.", show_alert=True)
            else:
                value = int(user["btc"] * btc_price())
                user["btc"] = 0.0
                user["rubles"] += value
                db.save()
                bot.answer_callback_query(call.id, f"Продано на {value:,} ₽.", show_alert=True)
        elif data == "p2p_menu":
            active = [lot for lot in db.data["p2p_market"] if not lot.get("sold")]
            kb = types.InlineKeyboardMarkup(row_width=1)
            for lot in active[:10]:
                kb.add(button(f"Купить {TARKOV_ITEMS[lot['item_id']]['name'][:22]} · {lot['price']:,} ₽", f"p2p_buy:{lot['lot_id']}"))
            kb.add(button("📤 Выставить предмет", "p2p_sell_menu"), button("🔙 Барахолка", "market_menu"))
            bot.edit_message_text(f"🤝 <b>P2P-РЫНОК</b>\nАктивных лотов: {len(active)}\nНалог системы: 10%.", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data == "p2p_sell_menu":
            kb = types.InlineKeyboardMarkup(row_width=1)
            shown = set()
            for bucket in user["warehouses"].values():
                for item_id in bucket:
                    if item_id in shown:
                        continue
                    shown.add(item_id)
                    item = TARKOV_ITEMS[item_id]
                    kb.add(button(f"{item['name'][:25]} — 100%", f"p2p_sell:{item_id}:100"))
                    kb.add(button(f"{item['name'][:25]} — 150%", f"p2p_sell:{item_id}:150"))
            kb.add(button("🔙 P2P", "p2p_menu"))
            bot.edit_message_text("📤 Выберите предмет и фиксированный коэффициент цены.", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("p2p_sell:"):
            _, item_id, coefficient = data.split(":")
            if not remove_item(user, item_id):
                bot.answer_callback_query(call.id, "Предмет уже отсутствует.", show_alert=True)
            else:
                lot_id = f"lot_{user['user_id']}_{int(time.time() * 1000)}"
                price = int(TARKOV_ITEMS[item_id]["base_price"] * int(coefficient) / 100)
                db.data["p2p_market"].append({"lot_id": lot_id, "seller_id": user["user_id"], "seller_name": user["username"], "item_id": item_id, "price": price, "sold": False})
                db.save()
                bot.answer_callback_query(call.id, "Лот выставлен.", show_alert=True)
        elif data.startswith("p2p_buy:"):
            lot_id = data.split(":", 1)[1]
            lot = next((x for x in db.data["p2p_market"] if x["lot_id"] == lot_id and not x.get("sold")), None)
            if not lot or lot["seller_id"] == user["user_id"] or user["rubles"] < lot["price"] or not store_item(user, lot["item_id"]):
                bot.answer_callback_query(call.id, "Лот недоступен, нет денег или склад заполнен.", show_alert=True)
            else:
                user["rubles"] -= lot["price"]
                seller = db.data["users"].get(str(lot["seller_id"]))
                if seller:
                    seller["rubles"] += int(lot["price"] * (1 - P2P_TAX))
                    seller["stats"]["p2p_sales"] += 1
                lot["sold"] = True
                db.save()
                bot.answer_callback_query(call.id, "Предмет куплен.", show_alert=True)
        elif data == "supply_menu":
            kb = types.InlineKeyboardMarkup(row_width=1)
            for channel, title in (("land", "🚚 Наземная — 30 мин"), ("sea", "🚢 Морская — 120 мин")):
                job = user["supplies"].get(channel)
                label = f"{title}: ещё {fmt_seconds(job['finish_at'] - time.time())}" if job else title
                kb.add(button(label, "noop" if job else f"supply_start:{channel}"))
                level = user["supply_levels"][channel]
                if level < 10:
                    kb.add(button(f"⬆️ Улучшить канал {channel} · {level}→{level + 1}", f"supply_upgrade:{channel}"))
            kb.add(button("🔙 Меню", "menu_main"))
            bot.edit_message_text("🚚 <b>ПОСТАВКИ В РЕАЛЬНОМ ВРЕМЕНИ</b>\nПрокачка каналов и Генератор сокращают таймер.", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("supply_start:"):
            channel = data.split(":", 1)[1]
            ok, result = start_supply(user, channel, chat_id)
            db.save()
            bot.answer_callback_query(call.id, result.replace("<b>", "").replace("</b>", ""), show_alert=not ok)
            bot.edit_message_text(result, chat_id, message_id, parse_mode="HTML", reply_markup=back_menu("supply_menu"))
        elif data.startswith("supply_upgrade:"):
            channel = data.split(":", 1)[1]
            level = user["supply_levels"][channel]
            cost = int(30_000 * 1.7 ** (level - 1))
            if level >= 10 or user["rubles"] < cost:
                bot.answer_callback_query(call.id, "Недостаточно рублей.", show_alert=True)
            else:
                user["rubles"] -= cost
                user["supply_levels"][channel] += 1
                db.save()
                bot.edit_message_text("✅ Канал поставок улучшен.", chat_id, message_id, parse_mode="HTML", reply_markup=back_menu("supply_menu"))
        elif data == "container_menu":
            kb = types.InlineKeyboardMarkup(row_width=2)
            for rarity, cost in (("common", 15_000), ("rare", 75_000), ("epic", 250_000), ("legendary", 750_000)):
                kb.add(button(f"{RARITY_LABEL[rarity]} · {cost:,} ₽", f"container_buy:{rarity}"))
            kb.add(button("🔙 Меню", "menu_main"))
            bot.edit_message_text(containers_text(), chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data.startswith("container_buy:"):
            rarity = data.split(":", 1)[1]
            cost = {"common": 15_000, "rare": 75_000, "epic": 250_000, "legendary": 750_000}[rarity]
            if user["rubles"] < cost:
                bot.answer_callback_query(call.id, "Недостаточно рублей.", show_alert=True)
            else:
                user["rubles"] -= cost
                pool = [item_id for item_id, item in TARKOV_ITEMS.items() if item["rarity"] == rarity]
                loot = random.choice(pool)
                stored = store_item(user, loot)
                relic = None
                if rarity in ("rare", "epic", "legendary") and random.random() < {"rare": 0.08, "epic": 0.22, "legendary": 0.38}[rarity]:
                    available = [key for key in BOSS_RELICS if key not in user["relics"]]
                    if available:
                        relic = random.choice(available)
                        user["relics"].append(relic)
                user["stats"]["containers"] += 1
                add_xp(user, 100)
                db.save()
                message = f"🎁 <b>Контейнер вскрыт</b>\n• {TARKOV_ITEMS[loot]['name'] if stored else 'склады заполнены'}"
                if relic:
                    message += f"\n🔥 {BOSS_RELICS[relic][0]} — {BOSS_RELICS[relic][1]}"
                bot.edit_message_text(message, chat_id, message_id, parse_mode="HTML", reply_markup=back_menu("container_menu"))
        elif data.startswith("airdrop_claim:"):
            drop_id = data.split(":", 1)[1]
            with db.lock:
                drop = db.data["active_airdrops"].get(drop_id)
                if not drop or drop.get("claimed"):
                    bot.answer_callback_query(call.id, "Ящик уже забрали.", show_alert=True)
                else:
                    drop["claimed"] = True
                    drop["claimed_by"] = user["username"]
                    if random.random() < 0.35 and len(user["relics"]) < len(BOSS_RELICS):
                        available = [key for key in BOSS_RELICS if key not in user["relics"]]
                        relic = random.choice(available)
                        user["relics"].append(relic)
                        reward = BOSS_RELICS[relic][0]
                    else:
                        user["btc"] = round(user["btc"] + 1.0, 6)
                        reward = "1 BTC"
                    add_xp(user, 300)
                    db.save()
                    bot.edit_message_text(f"🎉 <b>ЭИРДРОП ЗАХВАЧЕН</b>\nНаграда: <b>{reward}</b>", chat_id, message_id, parse_mode="HTML")
        elif data == "airdrop_info":
            remaining = db.data["meta"].get("next_airdrop_at", time.time()) - time.time()
            bot.edit_message_text(f"🪂 Следующий эирдроп по таймеру примерно через <b>{fmt_seconds(remaining)}</b>.\nПервый нажавший забирает ящик.", chat_id, message_id, parse_mode="HTML", reply_markup=back_menu())
        elif data == "admin_menu" and str(user["username"]).lower() == ADMIN_USERNAME:
            kb = types.InlineKeyboardMarkup(row_width=1)
            kb.add(button("📊 Статистика игроков", "admin_stats"))
            kb.add(button("⚡ Максимум модулей себе", "admin_max_self"))
            kb.add(button("🎁 Получить случайную реликвию", "admin_relic_self"))
            kb.add(button("🔙 Меню", "menu_main"))
            bot.edit_message_text("👑 <b>АДМИН-ПАНЕЛЬ REVENANT</b>\nТекстовые команды: /give_money, /give_item, /set_module, /set_level, /reset_player", chat_id, message_id, parse_mode="HTML", reply_markup=kb)
        elif data == "admin_stats" and str(user["username"]).lower() == ADMIN_USERNAME:
            bot.edit_message_text(f"📊 Игроков в базе: {len(db.data['users'])}\nАктивных дуэлей: {len(db.data['darkzone_duels'])}\nАктивных эирдропов: {len(db.data['active_airdrops'])}", chat_id, message_id, reply_markup=back_menu("admin_menu"))
        elif data == "admin_max_self" and str(user["username"]).lower() == ADMIN_USERNAME:
            user["hideout_level"] = 10
            for key in user["modules"]:
                user["modules"][key] = 10
            for key in user["warehouse_levels"]:
                user["warehouse_levels"][key] = 10
            db.save()
            bot.answer_callback_query(call.id, "Модули и склады выставлены на максимум.", show_alert=True)
        elif data == "admin_relic_self" and str(user["username"]).lower() == ADMIN_USERNAME:
            available = [key for key in BOSS_RELICS if key not in user["relics"]]
            if available:
                user["relics"].append(random.choice(available))
                db.save()
            bot.answer_callback_query(call.id, "Реликвия выдана.", show_alert=True)
        elif data == "help":
            bot.edit_message_text("ℹ️ <b>УПРАВЛЕНИЕ</b>\nВсе игровые действия выполняются inline-кнопками. Таймеры живут в timestamp database.json.\n\nНовый игрок: 50 000 ₽, 1 Дикий, ТОЗ-106, АК-74М, AI-2 x2 и Сухпаек Магнат.\n\nДля @revenuts доступны Revenant и админ-команды.", chat_id, message_id, parse_mode="HTML", reply_markup=back_menu())
        elif data == "noop":
            pass
    except Exception as exc:
        logger.exception("callback %s failed: %s", call.data, exc)
        try:
            bot.answer_callback_query(call.id, "Ошибка действия, попробуйте ещё раз.", show_alert=True)
        except Exception:
            pass
    finally:
        db.lock.release()


# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------

def run():
    logger.info("Starting Tarkov text MMO; catalog=%d items", len(TARKOV_ITEMS))
    threading.Thread(target=timed_worker, daemon=True, name="timed-game-worker").start()
    if not BOT_TOKEN:
        raise SystemExit("BOT_TOKEN is not set. Add it in Replit Secrets.")
    bot.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=30)


if __name__ == "__main__":
    run()