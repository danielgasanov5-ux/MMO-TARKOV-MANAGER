# -*- coding: utf-8 -*-
"""
Loot Generator & Raid System for Escape from Tarkov
Real-time deliveries, airdrops with boss items, military crates,
and 6-player cooperative raids across 5 difficulty tiers.

STRICT BALANCE:
- Epic drop chance in raids/crates: 3%
- Legendary drop chance in raids/crates: < 0.5%
- Supply delivery: 1% legendary at lvl 1 to 12% at lvl 10
"""

import random
from tarkov_engine import ITEMS_LIST, ITEMS_BY_ID, has_buff
try:
    from relics_system import ALL_30_RELICS, has_boss_set_bonus
except ImportError:
    ALL_30_RELICS = []
    def has_boss_set_bonus(u, b): return False

# Helper to filter out any relic items
def is_relic_item(item):
    if not item:
        return True
    iid = str(item.get("id", "")).lower()
    cat = str(item.get("category", "")).lower()
    return "relic" in cat or iid.startswith("relic_") or "boss" in cat

# Filter item pools by rarity (strictly from the 720 game items, NO relics)
POOL_LEGENDARY = [i for i in ITEMS_LIST if not is_relic_item(i) and (i.get("rarity") == "legendary" or i.get("price", 0) >= 380000)]
POOL_EPIC = [i for i in ITEMS_LIST if not is_relic_item(i) and i.get("rarity") == "epic" and i not in POOL_LEGENDARY]
POOL_RARE = [i for i in ITEMS_LIST if not is_relic_item(i) and i.get("rarity") == "rare"]
POOL_COMMON = [i for i in ITEMS_LIST if not is_relic_item(i) and i.get("rarity") == "common"]

def pick_item_by_rarity(rarity):
    if rarity == "legendary" and POOL_LEGENDARY:
        return random.choice(POOL_LEGENDARY)
    if rarity == "epic" and POOL_EPIC:
        return random.choice(POOL_EPIC)
    if rarity == "rare" and POOL_RARE:
        return random.choice(POOL_RARE)
    if POOL_COMMON:
        return random.choice(POOL_COMMON)
    clean_items = [i for i in ITEMS_LIST if not is_relic_item(i)]
    return random.choice(clean_items if clean_items else ITEMS_LIST)

def roll_strict_tarkov_loot(user=None):
    """
    Strict balance:
    Legendary: 0.4% (< 0.5%)
    Epic: 3.0%
    Rare: 20.0%
    Common: 76.6%
    Draws exclusively from the 720 items catalog. Relics never drop here!
    """
    leg_chance = 0.004
    epic_chance = 0.030
    rare_chance = 0.200

    if user and has_buff(user, "loot_bonus"):
        leg_chance += 0.003
        epic_chance += 0.015

    r = random.random()
    if r < leg_chance:
        return pick_item_by_rarity("legendary")
    elif r < leg_chance + epic_chance:
        return pick_item_by_rarity("epic")
    elif r < leg_chance + epic_chance + rare_chance:
        return pick_item_by_rarity("rare")
    else:
        return pick_item_by_rarity("common")

def roll_supply_item(supply_lvl, user):
    """
    Base chance for Legendary: Lvl 1 = 1%, Lvl 5 = 5%, Lvl 10 = 12%
    Epic: Lvl 1 = 9%, Lvl 10 = 35%
    Draws strictly from 720 items catalog, never drops relics!
    """
    lvl = max(1, min(10, supply_lvl))
    leg_chance = 0.01 + (lvl - 1) * (0.11 / 9.0)
    epic_chance = 0.09 + (lvl - 1) * (0.26 / 9.0)

    if user and has_buff(user, "loot_bonus"):
        leg_chance += 0.05
        epic_chance += 0.08

    roll = random.random()
    if roll < leg_chance:
        return pick_item_by_rarity("legendary")
    elif roll < (leg_chance + epic_chance):
        return pick_item_by_rarity("epic")
    elif roll < (leg_chance + epic_chance + 0.35):
        return pick_item_by_rarity("rare")
    else:
        return pick_item_by_rarity("common")

def generate_airdrop_loot():
    """
    Restores full 720-item pool utilization with high-end military cargo:
    - 2-3 Elite technical/medical components (GPUs, Military Cables, Phasemeters, Toolsets, etc.)
    - 2-3 Top Epic and Legendary weapons / armor from the 720 catalog (Slick, Altyn, AXMC, G28, RSASS)
    - Substantial rubles (600,000 - 1,800,000 ₽) and Bitcoin (0.5 - 2.0 BTC)
    - Low 10% chance for ONE random standard Boss Relic (never a SET relic directly!).
      If relic doesn't drop, an extra legendary item from 720 catalog is awarded.
    """
    loot = {
        "items": [],
        "rubles": random.randint(600000, 1800000),
        "btc": round(random.uniform(0.5, 2.0), 3)
    }

    # 1. 2-3 Elite technical & hideout components from 720 items (no common junk!)
    elite_components = [
        it for it in ITEMS_LIST
        if not is_relic_item(it) and it.get("category") in ["components", "valuable"] and (
            it.get("rarity") in ["epic", "legendary"] or
            (it.get("rarity") == "rare" and (
                it.get("is_hideout_component") or
                any(w in it.get("name", "").lower() for w in ["видеокарт", "плата", "инструмент", "процессор", "аккумулятор", "блок питания", "файл", "кабель", "фильтр"])
            ))
        )
    ]
    if not elite_components:
        elite_components = [it for it in ITEMS_LIST if not is_relic_item(it) and it.get("category") in ["components", "valuable"] and it.get("rarity") in ["rare", "epic", "legendary"]]
    if not elite_components:
        elite_components = POOL_EPIC

    for _ in range(random.randint(2, 3)):
        loot["items"].append(random.choice(elite_components))

    # 2. 2-3 Top Epic and Legendary weapons / body armor / helmets from 720 items
    top_gear = [
        it for it in ITEMS_LIST
        if not is_relic_item(it) and it.get("rarity") in ["legendary", "epic"] and it.get("category") in ["weapons", "armor", "gear"]
    ]
    if not top_gear:
        top_gear = POOL_LEGENDARY if POOL_LEGENDARY else POOL_EPIC

    for _ in range(random.randint(2, 3)):
        loot["items"].append(random.choice(top_gear))

    # 3. 10% isolated chance for ONE random standard Boss Relic
    # SET-relics (5/5 bonus) can NEVER drop directly!
    if ALL_30_RELICS and random.random() < 0.10:
        boss_relic = random.choice(ALL_30_RELICS)
        loot["items"].append(boss_relic)
        loot["has_relic"] = True
    else:
        # Extra top legendary item from the 720 catalog instead
        if POOL_LEGENDARY:
            loot["items"].append(random.choice(POOL_LEGENDARY))

    return loot

# Container & Case Definitions with Mathematical Risk vs Reward Balance
CONTAINER_DEFINITIONS = {
    "scav_box_150k": {
        "id": "scav_box_150k",
        "name": "🧰 Контрабандный Ящик Диких",
        "price": 150000,
        "badge": "🧰",
        "desc": "Сбитый из досок ящик с кустарной контрабандой Диких. Высокий риск неокупа.",
        "item_count": (2, 3),
        "loss_range": (45000, 105000),
        "even_range": (125000, 175000),
        "profit_range": (195000, 320000),
        "probabilities": [0.50, 0.35, 0.15]
    },
    "army_container_750k": {
        "id": "army_container_750k",
        "name": "📦 Армейский Спецконтейнер",
        "price": 750000,
        "badge": "📦",
        "desc": "Герметичный военный контейнер ВС РФ / UNTAR. Лут может не окупить затраты!",
        "item_count": (3, 4),
        "loss_range": (220000, 490000),      # ~48% НЕОКУП
        "even_range": (620000, 820000),      # ~34% ОКОЛО НУЛЯ
        "profit_range": (880000, 1250000),   # ~14% ОКУП
        "jackpot_range": (1350000, 2000000), # ~4% ДЖЕКПОТ
        "probabilities": [0.48, 0.34, 0.14, 0.04]
    },
    "terragroup_case_2500k": {
        "id": "terragroup_case_2500k",
        "name": "💼 Секретный Кейс TerraGroup",
        "price": 2500000,
        "badge": "💼",
        "desc": "Титановый сейф-кейс лаборатории. Дорогостоящий риск ради ключ-карт и прототипов.",
        "item_count": (3, 5),
        "loss_range": (1100000, 1850000),    # ~50% НЕОКУП
        "even_range": (2200000, 2750000),    # ~32% ОКОЛО НУЛЯ
        "profit_range": (3100000, 4200000),  # ~15% ОКУП
        "jackpot_range": (5000000, 7500000), # ~3% ДЖЕКПОТ
        "probabilities": [0.50, 0.32, 0.15, 0.03]
    }
}

def generate_container_loot(container_id, user=None):
    """
    Generates balanced container loot where total items value may not pay off.
    Strictly balances the 750k container and others against guaranteed millions.
    """
    cfg = CONTAINER_DEFINITIONS.get(container_id, CONTAINER_DEFINITIONS["army_container_750k"])
    price = cfg["price"]
    probs = list(cfg["probabilities"])

    if user and has_buff(user, "loot_bonus"):
        if len(probs) == 4:
            probs[0] = max(0.35, probs[0] - 0.05)
            probs[2] += 0.05
        else:
            probs[0] = max(0.35, probs[0] - 0.05)
            probs[2] += 0.05

    roll = random.random()
    if len(probs) == 4:
        if roll < probs[0]:
            outcome = "loss"
            target = random.randint(*cfg["loss_range"])
        elif roll < probs[0] + probs[1]:
            outcome = "even"
            target = random.randint(*cfg["even_range"])
        elif roll < probs[0] + probs[1] + probs[2]:
            outcome = "profit"
            target = random.randint(*cfg["profit_range"])
        else:
            outcome = "jackpot"
            target = random.randint(*cfg["jackpot_range"])
    else:
        if roll < probs[0]:
            outcome = "loss"
            target = random.randint(*cfg["loss_range"])
        elif roll < probs[0] + probs[1]:
            outcome = "even"
            target = random.randint(*cfg["even_range"])
        else:
            outcome = "profit"
            target = random.randint(*cfg["profit_range"])

    min_cnt, max_cnt = cfg["item_count"]
    count = random.randint(min_cnt, max_cnt)
    chosen = []
    current_sum = 0
    remaining_target = target

    clean_catalog = [it for it in ITEMS_LIST if not is_relic_item(it)]
    if not clean_catalog:
        clean_catalog = ITEMS_LIST

    for i in range(count - 1):
        budget = max(5000, remaining_target // (count - i))
        min_p = max(5000, int(budget * 0.35))
        max_p = int(budget * 1.65)
        candidates = [it for it in clean_catalog if min_p <= it.get("price", 0) <= max_p]
        if not candidates:
            candidates = [it for it in clean_catalog if it.get("price", 0) <= max_p * 1.5]
        if not candidates:
            candidates = clean_catalog
        it = random.choice(candidates)
        chosen.append(it)
        current_sum += it.get("price", 0)
        remaining_target = max(5000, target - current_sum)

    last_cands = [it for it in clean_catalog if abs(it.get("price", 0) - remaining_target) < remaining_target * 0.5]
    if not last_cands:
        last_cands = [it for it in clean_catalog if it.get("price", 0) <= remaining_target * 1.5]
    if not last_cands:
        last_cands = clean_catalog
    last_it = min(last_cands, key=lambda it: abs(it.get("price", 0) - remaining_target))
    chosen.append(last_it)

    total_val = sum(it.get("price", 0) for it in chosen)

    # 1% chance for ONE random Boss Relic in 2.5m Military Case (terragroup_case_2500k)
    # Strictly 1% chance. When this 1% hits, it awards 1 standard boss relic (never a SET relic directly!).
    relic_won = None
    if cfg["id"] == "terragroup_case_2500k" and ALL_30_RELICS:
        if random.random() < 0.01:
            relic_won = random.choice(ALL_30_RELICS)
            chosen.append(relic_won)
            total_val += relic_won.get("price", 10000000)

    delta = total_val - price

    return {
        "container_id": cfg["id"],
        "name": cfg["name"],
        "price": price,
        "items": chosen,
        "relic_won": relic_won,
        "total_value": total_val,
        "delta": delta,
        "outcome": outcome
    }

# Solo Raid Locations
RAID_LOCATIONS = {
    "factory": {
        "name": "🏭 Завод (Factory)",
        "desc": "Жестокий ближний бой, легкие Дикие и шанс встретить Тагиллу.",
        "difficulty": 35,
        "cooldown": 180, # 3 minutes
        "scav_fee": 0,
        "loot_count": (1, 2)
    },
    "customs": {
        "name": "🌲 Таможня (Customs)",
        "desc": "Общаги, стройка, заправка. Охрана босса Решалы.",
        "difficulty": 65,
        "cooldown": 300, # 5 minutes
        "scav_fee": 5000,
        "loot_count": (2, 3)
    },
    "woods": {
        "name": "🏕️ Лес (Woods)",
        "desc": "Снайперские дуэли, лесопилка, снайпер Штурман с СВД.",
        "difficulty": 90,
        "cooldown": 420,
        "scav_fee": 10000,
        "loot_count": (2, 4)
    },
    "reserve": {
        "name": "🏢 Военная база 'Резерв'",
        "desc": "Бункеры, бронепоезд, элитная свита Глухаря и военный лут.",
        "difficulty": 130,
        "cooldown": 600,
        "scav_fee": 20000,
        "loot_count": (3, 5)
    },
    "labs": {
        "name": "🧪 Лаборатория TerraGroup",
        "desc": "Рейдеры ЧВК, тяжелая броня, электронные ключ-карты и LEDX.",
        "difficulty": 180,
        "cooldown": 900,
        "scav_fee": 50000,
        "loot_count": (4, 6)
    }
}

RAID_LOOT_RATES = {
    "factory": {"legendary": 0.002, "epic": 0.028, "rare": 0.220},
    "customs": {"legendary": 0.006, "epic": 0.064, "rare": 0.330},
    "woods": {"legendary": 0.015, "epic": 0.115, "rare": 0.420},
    "reserve": {"legendary": 0.040, "epic": 0.210, "rare": 0.500},
    "labs": {"legendary": 0.100, "epic": 0.350, "rare": 0.450}
}

COOP_LOOT_RATES = {
    "easy": {"legendary": 0.002, "epic": 0.048, "rare": 0.250},
    "normal": {"legendary": 0.010, "epic": 0.090, "rare": 0.350},
    "hard": {"legendary": 0.030, "epic": 0.170, "rare": 0.450},
    "ultra": {"legendary": 0.070, "epic": 0.280, "rare": 0.450},
    "colossal": {"legendary": 0.150, "epic": 0.350, "rare": 0.400}
}

def roll_raid_loot(location_key, user=None):
    rates = RAID_LOOT_RATES.get(location_key, RAID_LOOT_RATES["factory"])
    leg_ch = rates["legendary"]
    epic_ch = rates["epic"]
    rare_ch = rates["rare"]

    if user and has_buff(user, "loot_bonus"):
        leg_ch += 0.015
        epic_ch += 0.040

    r = random.random()
    if r < leg_ch:
        return pick_item_by_rarity("legendary")
    elif r < leg_ch + epic_ch:
        return pick_item_by_rarity("epic")
    elif r < leg_ch + epic_ch + rare_ch:
        return pick_item_by_rarity("rare")
    else:
        return pick_item_by_rarity("common")

def roll_coop_raid_loot(diff_key, user=None):
    rates = COOP_LOOT_RATES.get(diff_key, COOP_LOOT_RATES["easy"])
    leg_ch = rates["legendary"]
    epic_ch = rates["epic"]
    rare_ch = rates["rare"]

    if user and has_buff(user, "loot_bonus"):
        leg_ch += 0.015
        epic_ch += 0.040

    r = random.random()
    if r < leg_ch:
        return pick_item_by_rarity("legendary")
    elif r < leg_ch + epic_ch:
        return pick_item_by_rarity("epic")
    elif r < leg_ch + epic_ch + rare_ch:
        return pick_item_by_rarity("rare")
    else:
        return pick_item_by_rarity("common")

def simulate_raid(location_key, user, squad_power, squad_armor):
    loc = RAID_LOCATIONS.get(location_key, RAID_LOCATIONS["factory"])
    diff = loc["difficulty"]

    # Success chance based on power + armor
    combined_stat = (squad_power * 1.2) + (squad_armor * 0.8)
    ratio = combined_stat / max(1, diff)

    win_chance = min(0.95, max(0.15, ratio / (ratio + 1.0) * 1.3))
    if has_buff(user, "pvp_bonus"):
        win_chance = min(0.98, win_chance + 0.10)
    if has_boss_set_bonus(user, "killa"):
        win_chance = min(0.99, win_chance + 0.75)

    roll = random.random()
    success = roll < win_chance

    min_l, max_l = loc["loot_count"]
    found_items = []
    earned_rubles = 0

    if success:
        loot_count = random.randint(min_l, max_l)
        if has_boss_set_bonus(user, "shturman"):
            loot_count *= 2
        for _ in range(loot_count):
            found_items.append(roll_raid_loot(location_key, user))
        earned_rubles = random.randint(15000, 35000) * (loc["difficulty"] // 30)
        if has_buff(user, "prapor_bonus"):
            earned_rubles = int(earned_rubles * 1.1)
        if has_boss_set_bonus(user, "shturman"):
            earned_rubles *= 2

    return {
        "success": success,
        "location": loc["name"],
        "items": found_items,
        "rubles": earned_rubles,
        "win_chance": round(win_chance * 100, 1)
    }

# ----------------- COOPERATIVE RAIDS (UP TO 6 PLAYERS) -----------------
COOP_DIFFICULTIES = {
    "easy": {
        "id": "easy",
        "name": "🟢 Легкая (Свалка / Промзона)",
        "badge": "🟢",
        "desc": "Заброшенные склады, патрули Диких и банда мародеров.",
        "requires_keycard": False,
        "base_win_chance": 35, # 35% base
        "member_bonus": 8,     # +8% per PMC (up to +48%)
        "rubles_reward": (120000, 250000),
        "loot_count": (2, 3)
    },
    "normal": {
        "id": "normal",
        "name": "🟡 Нормальная (Торговый центр Ультра)",
        "badge": "🟡",
        "desc": "Запутанные коридоры, магазины техники, засады рейдеров ЧВК.",
        "requires_keycard": False,
        "base_win_chance": 25, # 25% base
        "member_bonus": 7,     # +7% per PMC
        "rubles_reward": (300000, 600000),
        "loot_count": (2, 4)
    },
    "hard": {
        "id": "hard",
        "name": "🔴 Тяжелая (Бункер Резерва Глухаря)",
        "badge": "🔴",
        "desc": "Гермобункеры, элитная охрана с пулеметами и гранатометами. ⚠️ Требуется Лабораторная ключ-карта (Legendary) у лидера!",
        "requires_keycard": True,
        "base_win_chance": 16, # 16% base
        "member_bonus": 6,     # +6% per PMC
        "rubles_reward": (700000, 1400000),
        "loot_count": (3, 5)
    },
    "ultra": {
        "id": "ultra",
        "name": "🟣 Ультра (Очистные сооружения / Отступники)",
        "badge": "🟣",
        "desc": "Снайперские вышки, пулеметчики Rogue на крышах, минные поля. ⚠️ Требуется Лабораторная ключ-карта (Legendary) у лидера!",
        "requires_keycard": True,
        "base_win_chance": 10, # 10% base
        "member_bonus": 5,     # +5% per PMC
        "rubles_reward": (1500000, 3000000),
        "loot_count": (4, 6)
    },
    "colossal": {
        "id": "colossal",
        "name": "☠️ Колоссальная (TerraGroup Labs Underground)",
        "badge": "☠️",
        "desc": "Глубокий засекреченный подземный комплекс. Безжалостные рейдеры в шлемах Вулкан-5 и с Mk-18. ⚠️ Требуется Лабораторная ключ-карта (Legendary) у лидера!",
        "requires_keycard": True,
        "base_win_chance": 5,  # 5% base
        "member_bonus": 4,     # +4% per PMC (max 6 PMCs => 5 + 24 = 29% max!)
        "rubles_reward": (3500000, 7000000),
        "loot_count": (5, 8)
    }
}

def simulate_coop_raid(diff_key, members_list, force_success=False):
    """
    Simulates coop raid outcome for up to 6 players.
    Returns:
    {
        "success": bool,
        "win_chance": float,
        "diff": dict,
        "members_rewards": {user_id: {"rubles": int, "items": list}},
        "relic_dropped": dict or None,
        "lucky_user_id": str or None
    }
    """
    diff = COOP_DIFFICULTIES.get(diff_key, COOP_DIFFICULTIES["easy"])
    member_count = len(members_list)
    win_chance = min(90, diff["base_win_chance"] + member_count * diff["member_bonus"])

    if force_success:
        success = True
    else:
        roll = random.random() * 100.0
        success = roll < win_chance

    members_rewards = {}
    relic_dropped = None
    lucky_user_id = None

    if success:
        min_r, max_r = diff["rubles_reward"]
        min_l, max_l = diff["loot_count"]
        for m in members_list:
            u_id = str(m["user_id"])
            m_rub = random.randint(min_r, max_r)
            m_items = []
            count = random.randint(min_l, max_l)
            if has_boss_set_bonus(m, "shturman"):
                count *= 2
                m_rub *= 2
            for _ in range(count):
                m_items.append(roll_coop_raid_loot(diff_key, m))
            members_rewards[u_id] = {
                "rubles": m_rub,
                "items": m_items
            }

        # Exact Boss Relic Drop Rates for the whole group:
        # Colossal: 10%, Ultra: 4%, Hard: 1%, Normal: 0%, Easy: 0%
        relic_chance_map = {
            "colossal": 0.10,
            "ultra": 0.04,
            "hard": 0.01,
            "normal": 0.0,
            "easy": 0.0
        }
        relic_chance = relic_chance_map.get(diff_key, 0.0)
        if ALL_30_RELICS and random.random() < relic_chance and members_list:
            relic_dropped = random.choice(ALL_30_RELICS)
            lucky_member = random.choice(members_list)
            lucky_user_id = str(lucky_member["user_id"])
            if lucky_user_id in members_rewards:
                members_rewards[lucky_user_id]["items"].append(relic_dropped)
                members_rewards[lucky_user_id]["dropped_relic"] = relic_dropped

    return {
        "success": success,
        "win_chance": round(win_chance, 1),
        "diff": diff,
        "members_rewards": members_rewards,
        "relic_dropped": relic_dropped,
        "lucky_user_id": lucky_user_id
    }
