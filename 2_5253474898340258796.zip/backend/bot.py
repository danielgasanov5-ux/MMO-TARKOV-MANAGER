# -*- coding: utf-8 -*-
"""
ESCAPE FROM TARKOV MMO ECONOMIC MANAGER TELEGRAM BOT
Built with pyTelegramBotAPI (telebot).
Complete text-based Telegram Bot with:
- 720 Items Database
- Dynamic Economic Crises (+/-30-50% per category daily)
- Balanced Flea Market (6 Categories, P2P with 10% tax and cancel lot, Prapor 30% buyout, Deficit components)
- 6-Player Cooperative Raids (5 difficulties, Legendary Keycards on Hard+, 2-hour penalty on failure)
- 4 Equipment Slots (Weapon, Body Armor, Helmet, Headset) with Auto-equip and Selective Equip
- 4 Specialized Warehouses (up to 10 tiers with exact upgrade costs on buttons)
- Full Admin Panel and Text Commands for @revenuts with Rank 💀 [ADMIN] 💰 REVENANT GD 💰 💀
"""

import os
import sys
import time
import random
import json
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import telebot
from telebot import types

from tarkov_engine import (
    load_db, save_db, create_new_player, generate_scav_gear,
    PMC_DEFINITIONS, HIDEOUT_UPGRADE_COSTS, MODULE_NAMES, BUSINESS_NAMES, BUSINESS_CONFIG,
    WAREHOUSE_NAMES, BASE_WAREHOUSE_CAPS, MARKET_CATEGORIES,
    get_warehouse_upgrade_cost, get_module_upgrade_cost, get_business_upgrade_cost, SUPPLY_CHANNEL_COSTS,
    get_current_btc_rate, get_business_hourly_income, get_mining_hourly_btc,
    has_buff, get_warehouse_capacity, get_warehouse_count, can_store_item,
    calculate_squad_power, check_and_update_economic_crisis, get_crisis_price,
    ITEMS_BY_ID, ITEMS_LIST, is_admin
)

from loot_generator import (
    roll_supply_item, generate_airdrop_loot, simulate_raid, RAID_LOCATIONS,
    CONTAINER_DEFINITIONS, generate_container_loot, roll_strict_tarkov_loot,
    COOP_DIFFICULTIES
)

from coop_system import (
    handle_menu_coop, handle_coop_difficulty_view, handle_create_coop_lobby,
    handle_join_coop_lobby, handle_leave_coop_lobby, handle_start_coop_lobby,
    render_lobby_ui, get_leader_keycard
)

from relics_system import (
    BOSS_SETS, ALL_30_RELICS, RELICS_BY_ID,
    get_player_relics, get_player_boss_sets, has_boss_set_bonus, get_active_boss_bonuses_list
)

BOT_TOKEN = os.environ.get("BOT_TOKEN", "").strip()
if not BOT_TOKEN:
    print("[WARNING] BOT_TOKEN is not set in environment or Secrets!")
    print("Please set BOT_TOKEN in your environment or Secrets before starting the bot.")

bot = telebot.TeleBot(BOT_TOKEN if BOT_TOKEN else "DUMMY_TOKEN_PLEASE_SET_BOT_TOKEN", parse_mode="HTML")

# Format rubles helper
def fmt_rub(val):
    return f"{int(val):,} ₽".replace(",", " ")

def get_player(user_id, username=None):
    db = load_db()
    uid = str(user_id)
    if uid in db["users"]:
        u = db["users"][uid]
        if username and u.get("username") != username:
            u["username"] = username
            save_db(db)
        return u, db
    return None, db

# ----------------- MAIN KEYBOARDS -----------------
def get_main_menu_markup(user):
    markup = types.InlineKeyboardMarkup(row_width=2)
    b_profile = types.InlineKeyboardButton("👤 Профиль ЧВК", callback_data="menu_profile")
    b_squad = types.InlineKeyboardButton("🪖 Мой Отряд", callback_data="menu_squad")
    b_stash = types.InlineKeyboardButton("📦 Склады и Схрон", callback_data="menu_stash")
    b_market = types.InlineKeyboardButton("🏪 Барахолка и P2P", callback_data="menu_market")
    b_hideout = types.InlineKeyboardButton("🏚️ Убежище и Бизнес", callback_data="menu_hideout")
    b_supply = types.InlineKeyboardButton("🚚 Контрабанда", callback_data="menu_supply")
    b_raids = types.InlineKeyboardButton("⚔️ Рейды в Тарков", callback_data="menu_raids")
    b_darkzone = types.InlineKeyboardButton("💀 Даркзон (PvP)", callback_data="menu_darkzone")
    b_income = types.InlineKeyboardButton("🎁 Собрать Доход", callback_data="claim_income")
    b_containers = types.InlineKeyboardButton("🧰 Военные Кейсы", callback_data="menu_containers")
    b_airdrop = types.InlineKeyboardButton("📦 Эирдроп Зоны", callback_data="menu_airdrop")

    markup.add(b_profile, b_squad)
    markup.add(b_stash, b_market)
    markup.add(b_hideout, b_supply)
    markup.add(b_raids, b_darkzone)
    markup.add(b_income, b_containers)
    markup.add(b_airdrop)

    if is_admin(user["user_id"], user.get("username")):
        markup.add(types.InlineKeyboardButton("💀 Admin-панель (@reventus)", callback_data="menu_admin"))

    return markup

# ----------------- START & PMC SELECTION -----------------
@bot.message_handler(commands=['start', 'help'])
def cmd_start(message):
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    player, db = get_player(user_id, username)

    if not player or not player.get("pmc_signature"):
        txt = (
            "<b>⚔️ ДОБРО ПОЖАЛОВАТЬ В ТАРКОВ: МЕНЕДЖЕР ЧВК</b>\n\n"
            "Норвинская область охвачена войной. Прежде чем выйти в рейд и развернуть Убежище, "
            "<b>вы обязаны навсегда выбрать своего Сигнатурного ЧВК</b>.\n\n"
            "Каждый ЧВК дает нерушимый пассивный бафф вашей военной корпорации:\n\n"
        )
        for key, p in PMC_DEFINITIONS.items():
            if key == "Revenant":
                continue
            txt += f"{p['icon']} <b>{p['name']}</b>: {p['desc']}\n"

        markup = types.InlineKeyboardMarkup(row_width=2)
        buttons = []
        for key, p in PMC_DEFINITIONS.items():
            if key == "Revenant":
                continue
            buttons.append(types.InlineKeyboardButton(f"{p['icon']} {p['name']}", callback_data=f"select_pmc_{key}"))

        for i in range(0, len(buttons), 2):
            markup.row(*buttons[i:i+2])

        if is_admin(user_id, username):
            markup.add(types.InlineKeyboardButton("💀 REVENANT [ADMIN EXCLUSIVE]", callback_data="select_pmc_Revenant"))

        bot.send_message(message.chat.id, txt, reply_markup=markup)
        return

    show_main_menu(message.chat.id, player)

def show_main_menu(chat_id, user, message_id=None):
    db = load_db()
    check_and_update_economic_crisis(db)
    save_db(db)

    pow_val, arm_val = calculate_squad_power(user)
    pmc = user.get("pmc_signature", "Viper")
    pmc_icon = PMC_DEFINITIONS.get(pmc, {}).get("icon", "🎖️")

    rank_title = "Рядовой ЧВК"
    if is_admin(user["user_id"], user.get("username")) or pmc == "Revenant":
        rank_title = "💀 [ADMIN] 💰 REVENANT GD 💰 💀"
    elif user.get("hideout_lvl", 1) >= 8:
        rank_title = "Генерал Норвинского Сектора"
    elif user.get("hideout_lvl", 1) >= 5:
        rank_title = "Командир Синдиката"
    elif user.get("hideout_lvl", 1) >= 3:
        rank_title = "Опытный Наемник"

    crisis = db.get("economic_crisis", {})
    crisis_banner = ""
    if crisis and crisis.get("expires_at", 0) > time.time():
        sign = "+" if crisis.get("direction") == "surge" else "-"
        crisis_banner = f"🚨 <b>КРИЗИС РЫНКА:</b> {crisis.get('category')} ({sign}{crisis.get('shift_pct')}%)\n"

    coop_cooldown_banner = ""
    if user.get("coop_cooldown_until", 0) > time.time():
        rem = int((user["coop_cooldown_until"] - time.time()) // 60)
        coop_cooldown_banner = f"🚑 <b>ТРАВМА ОТРЯДА:</b> Медблок {rem} мин. (Бафф ЧВК отключен!)\n"

    txt = (
        f"<b>🏢 ШТАБ-КВАРТИРА ЧВК: {user.get('username', 'Оператор')}</b>\n"
        f"Статус: <b>{rank_title}</b>\n"
        f"Сигнатурный ЧВК: {pmc_icon} <b>{pmc}</b>\n"
        f"────────────────────────\n"
        f"{crisis_banner}{coop_cooldown_banner}"
        f"💰 Баланс: <b>{fmt_rub(user.get('money', 0))}</b> | 🪙 BTC: <b>{user.get('btc', 0):.4f}</b>\n"
        f"🪖 Отряд: <b>{len(user.get('squad', []))}/5 бойцов</b>\n"
        f"⚔️ Огневая мощь: <b>{pow_val}</b> | 🛡️ Броня: <b>{arm_val}</b>\n"
        f"🏚️ Убежище: <b>Уровень {user.get('hideout_lvl', 1)}/10</b>\n"
        f"────────────────────────\n"
        f"<i>Выберите действие в меню ниже:</i>"
    )

    markup = get_main_menu_markup(user)
    if message_id:
        try:
            bot.edit_message_text(txt, chat_id, message_id, reply_markup=markup)
            return
        except Exception:
            pass
    bot.send_message(chat_id, txt, reply_markup=markup)

# ----------------- CALLBACK QUERY DISPATCHER -----------------
@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    user_id = call.from_user.id
    username = call.from_user.username or call.from_user.first_name
    data = call.data
    chat_id = call.message.chat.id
    msg_id = call.message.message_id

    # 1. PMC Selection
    if data.startswith("select_pmc_"):
        pmc_key = data.replace("select_pmc_", "")
        if pmc_key == "Revenant" and not is_admin(user_id, username):
            bot.answer_callback_query(call.id, "❌ ЧВК Revenant доступен только @reventus!", show_alert=True)
            return
        db = load_db()
        player = create_new_player(user_id, username, pmc_key)
        db["users"][str(user_id)] = player
        save_db(db)
        p_info = PMC_DEFINITIONS.get(pmc_key, {})
        bot.answer_callback_query(call.id, f"✅ Вы выбрали ЧВК {pmc_key}!")
        bot.send_message(
            chat_id,
            f"🎉 <b>Добро пожаловать на службу, ЧВК {pmc_key}!</b>\n\n"
            f"{p_info.get('icon', '🎖️')} <b>Ваш бонус:</b> {p_info.get('desc')}\n\n"
            f"Вам выдано стартовое снаряжение со стоимостью:\n"
            f"• 💰 <b>50 000 ₽</b> наличными\n"
            f"• 🪖 <b>1 Нанятый боец</b> (Дикий #1)\n"
            f"• 🔫 <b>АК-74М</b> — {fmt_rub(38000)}\n"
            f"• 🔫 <b>ТОЗ-106</b> — {fmt_rub(9500)}\n"
            f"• 🎧 <b>Активные наушники ГСШ-01</b> — {fmt_rub(18000)}\n"
            f"• 🪖 <b>Шлем Колпак-1С</b> — {fmt_rub(12000)}\n"
            f"• 💊 <b>Аптечка АИ-2 (2 шт)</b> — {fmt_rub(24000)}\n"
            f"• 🩹 <b>Бинт и медицинская шина</b> — {fmt_rub(14000)}\n"
            f"• 📦 <b>Патроны 5.45x39 БТ (120 шт)</b> — {fmt_rub(48000)}\n"
            f"• 🏢 <b>4 специализированных склада</b> 1-го уровня"
        )
        show_main_menu(chat_id, player)
        return

    player, db = get_player(user_id, username)
    if not player:
        bot.answer_callback_query(call.id, "⚠️ Начните игру через /start", show_alert=True)
        return

    # Navigation
    if data == "main_menu":
        bot.answer_callback_query(call.id)
        show_main_menu(chat_id, player, msg_id)
        return

    # Profile
    elif data == "menu_profile":
        bot.answer_callback_query(call.id)
        handle_menu_profile(chat_id, msg_id, player)
        return

    # Squad & Recruitment
    elif data == "menu_squad":
        bot.answer_callback_query(call.id)
        handle_menu_squad(chat_id, msg_id, player)
        return
    elif data == "hire_scav":
        handle_hire_fighter(call, player, db, "scav", 2500)
        return
    elif data == "hire_pmc":
        handle_hire_fighter(call, player, db, "pmc", 25000)
        return
    elif data.startswith("disband_fighter_"):
        f_id = int(data.replace("disband_fighter_", ""))
        handle_disband_fighter(call, player, db, f_id)
        return
    elif data == "auto_equip":
        handle_auto_equip(call, player, db)
        return
    elif data.startswith("view_fighter_"):
        f_id = int(data.replace("view_fighter_", ""))
        handle_view_fighter(chat_id, msg_id, player, f_id)
        return
    elif data.startswith("slot_choose_"):
        parts = data.split("_")
        f_id = int(parts[2])
        slot_type = parts[3]
        page = int(parts[4]) if len(parts) > 4 else 1
        handle_slot_choose(chat_id, msg_id, player, f_id, slot_type, page)
        return
    elif data.startswith("slot_equip_"):
        parts = data.split("_", 4)
        f_id = int(parts[2])
        slot_type = parts[3]
        uid = parts[4]
        handle_slot_equip(call, player, db, f_id, slot_type, uid)
        return
    elif data.startswith("slot_unequip_"):
        parts = data.split("_")
        f_id = int(parts[2])
        slot_type = parts[3]
        handle_slot_unequip(call, player, db, f_id, slot_type)
        return
    elif data == "view_relics_collection":
        bot.answer_callback_query(call.id)
        handle_view_relics_collection(chat_id, msg_id, player)
        return
    elif data == "container_sell_all":
        handle_container_sell_all(call, player, db)
        return

    # Stash & Warehouses
    elif data == "menu_stash":
        bot.answer_callback_query(call.id)
        handle_menu_stash(chat_id, msg_id, player)
        return
    elif data.startswith("stash_cat_"):
        parts = data.split("_")
        cat = parts[2]
        page = int(parts[3]) if len(parts) > 3 else 1
        handle_stash_category(chat_id, msg_id, player, cat, page)
        return
    elif data.startswith("prapor_sell_"):
        uid = data.replace("prapor_sell_", "")
        handle_prapor_sell(call, player, db, uid)
        return
    elif data.startswith("upgrade_wh_"):
        cat = data.replace("upgrade_wh_", "")
        handle_upgrade_warehouse(call, player, db, cat)
        return

    # Flea Market & P2P
    elif data == "menu_market":
        bot.answer_callback_query(call.id)
        handle_menu_market(chat_id, msg_id, player, db)
        return
    elif data.startswith("market_cat_"):
        cat_name = data.replace("market_cat_", "")
        handle_market_catalog(chat_id, msg_id, player, db, cat_name, 1)
        return
    elif data.startswith("market_page_"):
        parts = data.split("_")
        cat_name = parts[2]
        page = int(parts[3])
        handle_market_catalog(chat_id, msg_id, player, db, cat_name, page)
        return
    elif data.startswith("market_buy_"):
        parts = data.split("_")
        item_id = parts[2]
        cat_name = parts[3]
        page = int(parts[4])
        handle_market_buy_action(call, player, db, item_id, cat_name, page)
        return
    elif data == "market_sell_btc":
        handle_sell_btc(call, player, db)
        return
    elif data == "market_p2p":
        bot.answer_callback_query(call.id)
        handle_p2p_market(chat_id, msg_id, player, db)
        return
    elif data == "p2p_list_menu":
        bot.answer_callback_query(call.id)
        handle_p2p_list_menu(chat_id, msg_id, player, db)
        return
    elif data.startswith("p2p_list_"):
        uid = data.replace("p2p_list_", "")
        handle_p2p_list_action(call, player, db, uid)
        return
    elif data.startswith("buy_p2p_"):
        lot_id = data.replace("buy_p2p_", "")
        handle_buy_p2p_lot(call, player, db, lot_id)
        return
    elif data.startswith("cancel_p2p_"):
        lot_id = data.replace("cancel_p2p_", "")
        handle_cancel_p2p_lot(call, player, db, lot_id)
        return

    # Hideout & Businesses
    elif data == "menu_hideout":
        bot.answer_callback_query(call.id)
        handle_menu_hideout(chat_id, msg_id, player)
        return
    elif data == "upgrade_hideout":
        handle_upgrade_hideout(call, player, db)
        return
    elif data.startswith("upgrade_module_"):
        mod_key = data.replace("upgrade_module_", "")
        handle_upgrade_module(call, player, db, mod_key)
        return
    elif data.startswith("upgrade_biz_"):
        biz_key = data.replace("upgrade_biz_", "")
        handle_upgrade_business(call, player, db, biz_key)
        return
    elif data == "claim_income":
        handle_claim_income(call, player, db)
        return

    # Supplies
    elif data == "menu_supply":
        bot.answer_callback_query(call.id)
        handle_menu_supply(chat_id, msg_id, player)
        return
    elif data.startswith("order_supply_tier_"):
        tier = int(data.replace("order_supply_tier_", ""))
        handle_order_supply(call, player, db, tier)
        return
    elif data == "upgrade_supply_channel":
        handle_upgrade_supply_channel(call, player, db)
        return
    elif data == "claim_supply":
        handle_claim_supply(call, player, db)
        return

    # Solo Raids
    elif data == "menu_raids":
        bot.answer_callback_query(call.id)
        handle_menu_raids(chat_id, msg_id, player)
        return
    elif data.startswith("start_solo_raid_"):
        loc_key = data.replace("start_solo_raid_", "")
        handle_start_solo_raid(call, player, db, loc_key)
        return

    # Cooperative Raids (Up to 6 players)
    elif data == "menu_coop_raids":
        bot.answer_callback_query(call.id)
        handle_menu_coop(chat_id, msg_id, player, db, bot)
        return
    elif data.startswith("coop_view_"):
        diff_key = data.replace("coop_view_", "")
        bot.answer_callback_query(call.id)
        handle_coop_difficulty_view(chat_id, msg_id, player, diff_key, bot)
        return
    elif data.startswith("create_coop_"):
        diff_key = data.replace("create_coop_", "")
        handle_create_coop_lobby(call, player, db, diff_key, bot)
        return
    elif data.startswith("join_coop_"):
        lobby_id = data.replace("join_coop_", "")
        handle_join_coop_lobby(call, player, db, lobby_id, bot)
        return
    elif data.startswith("leave_coop_"):
        lobby_id = data.replace("leave_coop_", "")
        handle_leave_coop_lobby(call, player, db, lobby_id, bot)
        return
    elif data.startswith("start_coop_"):
        lobby_id = data.replace("start_coop_", "")
        handle_start_coop_lobby(call, player, db, lobby_id, bot)
        return
    elif data.startswith("cancel_coop_"):
        lobby_id = data.replace("cancel_coop_", "")
        if lobby_id in db.get("coop_lobbies", {}):
            db["coop_lobbies"].pop(lobby_id, None)
            save_db(db)
            bot.answer_callback_query(call.id, "❌ Лобби распущено.")
            handle_menu_coop(chat_id, msg_id, player, db, bot)
        return
    elif data.startswith("refresh_coop_"):
        lobby_id = data.replace("refresh_coop_", "")
        lobby = db.get("coop_lobbies", {}).get(lobby_id)
        if lobby:
            render_lobby_ui(chat_id, msg_id, lobby, player, bot)
            bot.answer_callback_query(call.id, "🔄 Лобби обновлено!")
        else:
            bot.answer_callback_query(call.id, "❌ Лобби закрыто.")
            handle_menu_coop(chat_id, msg_id, player, db, bot)
        return

    # Darkzone PvP
    elif data == "menu_darkzone":
        bot.answer_callback_query(call.id)
        handle_menu_darkzone(chat_id, msg_id, player, db)
        return
    elif data == "darkzone_search_bot":
        handle_darkzone_bot_duel(call, player, db)
        return
    elif data == "darkzone_create_pvp":
        handle_darkzone_create_pvp(call, player, db)
        return
    elif data.startswith("accept_pvp_"):
        duel_id = data.replace("accept_pvp_", "")
        handle_darkzone_accept_pvp(call, player, db, duel_id)
        return

    # Containers
    elif data == "menu_containers":
        bot.answer_callback_query(call.id)
        handle_menu_containers(chat_id, msg_id, player)
        return
    elif data.startswith("open_container_"):
        cid = data.replace("open_container_", "")
        handle_open_container(call, player, db, cid)
        return
    elif data == "container_sell_all":
        handle_container_sell_all(call, player, db)
        return

    # Airdrop
    elif data == "menu_airdrop":
        bot.answer_callback_query(call.id)
        handle_menu_airdrop(chat_id, msg_id, player, db)
        return
    elif data == "loot_airdrop_box":
        handle_loot_airdrop_box(call, player, db)
        return

    # Admin Panel
    elif data == "menu_admin":
        if not is_admin(user_id, username):
            bot.answer_callback_query(call.id, "❌ Доступ разрешен только @reventus!", show_alert=True)
            return
        bot.answer_callback_query(call.id)
        handle_menu_admin(chat_id, msg_id, player)
        return
    elif data.startswith("admin_action_"):
        if not is_admin(user_id, username):
            return
        act = data.replace("admin_action_", "")
        handle_admin_action(call, player, db, act)
        return

# ----------------- SECTION 1: PROFILE -----------------
def handle_menu_profile(chat_id, msg_id, player):
    pmc = player.get("pmc_signature", "Viper")
    p_info = PMC_DEFINITIONS.get(pmc, {})
    pow_val, arm_val = calculate_squad_power(player)
    st = player.get("stats", {})

    rank_title = "Рядовой ЧВК"
    if is_admin(player["user_id"], player.get("username")) or pmc == "Revenant":
        rank_title = "💀 [ADMIN] 💰 REVENANT GD 💰 💀"
    elif player.get("hideout_lvl", 1) >= 8:
        rank_title = "Генерал Норвинского Сектора"
    elif player.get("hideout_lvl", 1) >= 5:
        rank_title = "Командир Синдиката"
    elif player.get("hideout_lvl", 1) >= 3:
        rank_title = "Опытный Наемник"

    coop_injury_txt = ""
    if player.get("coop_cooldown_until", 0) > time.time():
        rem = int((player["coop_cooldown_until"] - time.time()) // 60)
        coop_injury_txt = f"\n⚠️ <b>ТРАВМА ОТРЯДА:</b> Медблок {rem} мин. (Пассивный бафф отключен!)"

    owned_relics = get_player_relics(player)
    active_bonuses = get_active_boss_bonuses_list(player)
    boss_sets_status = get_player_boss_sets(player)

    relics_txt = f"🏆 Реликвий Боссов: <b>{len(owned_relics)}/30</b>\n"
    if active_bonuses:
        relics_txt += "🔥 <b>Активные бонусы сетов:</b>\n"
        for b_desc in active_bonuses:
            relics_txt += f"  • {b_desc}\n"
    else:
        relics_txt += "<i>(Соберите 5/5 реликвий любого босса для активации бонуса сета)</i>\n"

    txt = (
        f"<b>👤 ПРОФИЛЬ ОПЕРАТОРА ЧВК</b>\n"
        f"────────────────────────\n"
        f"Позывной: <b>@{player.get('username', 'PMC')}</b> (ID: <code>{player['user_id']}</code>)\n"
        f"Ранг: <b>{rank_title}</b>\n"
        f"Класс ЧВК: {p_info.get('icon', '🎖️')} <b>{pmc}</b>\n"
        f"Бафф: <i>{p_info.get('desc')}</i>{coop_injury_txt}\n"
        f"────────────────────────\n"
        f"💰 Рубли: <b>{fmt_rub(player.get('money', 0))}</b>\n"
        f"🪙 Биткоины: <b>{player.get('btc', 0):.4f} BTC</b>\n"
        f"🏚️ Уровень Убежища: <b>{player.get('hideout_lvl', 1)}/10</b>\n"
        f"🚚 Канал снабжения: <b>{player.get('supply_channel_lvl', 1)}/10</b>\n"
        f"⚔️ Суммарная мощь: <b>{pow_val}</b> | 🛡️ Броня: <b>{arm_val}</b>\n"
        f"────────────────────────\n"
        f"{relics_txt}"
        f"────────────────────────\n"
        f"📊 <b>Боевая статистика:</b>\n"
        f"• Рейдов завершено: {st.get('raids_count', 0)}\n"
        f"• Кооп-рейдов: {st.get('coop_raids_count', 0)} (Побед: {st.get('coop_wins', 0)} | Разгромов: {st.get('coop_losses', 0)})\n"
        f"• PvP побед / поражений: {st.get('pvp_wins', 0)} / {st.get('pvp_losses', 0)}\n"
        f"• Захвачено эирдропов: {st.get('airdrop_looted', 0)}"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🏆 Коллекция Реликвий (30 шт)", callback_data="view_relics_collection"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_view_relics_collection(chat_id, msg_id, player):
    owned_relics = get_player_relics(player)
    sets_status = get_player_boss_sets(player)

    txt = (
        f"<b>🏆 КОЛЛЕКЦИЯ РЕЛИКВИЙ И СЕТОВ БОССОВ</b>\n"
        f"Собрано реликвий: <b>{len(owned_relics)}/30</b>\n"
        f"────────────────────────\n"
        f"Каждая реликвия оценивается в <b>10 000 000 ₽</b>.\n"
        f"Полный сет из 5 реликвий одного Босса стоит <b>50 000 000 ₽</b> и дает мощный пассивный эффект!\n\n"
    )

    for b_key, b_info in sets_status.items():
        boss_data = BOSS_SETS[b_key]
        status_badge = "🔥 <b>[АКТИВЕН 5/5]</b>" if b_info["is_active"] else f"[{b_info['owned_count']}/5]"
        txt += f"{b_info['icon']} <b>{boss_data['boss_name']}</b> — {status_badge}\n"
        txt += f"✨ <i>Бонус (5/5): {boss_data['desc']}</i>\n"
        for r in boss_data["relics"]:
            is_owned = r["id"] in owned_relics
            check_icon = "✅" if is_owned else "❌"
            txt += f"  {check_icon} {r['name']} (10 000 000 ₽)\n"
        txt += "\n"

    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🔙 К Профилю", callback_data="menu_profile"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

# ----------------- SECTION 2: SQUAD & 4 SLOTS EQUIPMENT -----------------
def handle_menu_squad(chat_id, msg_id, player):
    squad = player.get("squad", [])
    pow_val, arm_val = calculate_squad_power(player)
    stash = {itm["uid"]: itm for itm in player.get("stash", [])}

    txt = (
        f"<b>🪖 БОЕВОЙ ОТРЯД ЧВК ({len(squad)}/5)</b>\n"
        f"Огневая мощь отряда: <b>{pow_val}</b> | Броня: <b>{arm_val}</b>\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    for idx, f in enumerate(squad, start=1):
        f_type = "Дикий" if f.get("type") == "scav" else "ЧВК"
        w_uid = f.get("weapon_uid")
        a_uid = f.get("armor_uid")
        h_uid = f.get("helmet_uid")
        hs_uid = f.get("headset_uid")

        w_name = ITEMS_BY_ID.get(stash[w_uid].get("item_id"), {}).get("name", "Нет") if w_uid and w_uid in stash else "Кулаки"
        a_name = ITEMS_BY_ID.get(stash[a_uid].get("item_id"), {}).get("name", "Нет") if a_uid and a_uid in stash else "Одежда"
        h_name = ITEMS_BY_ID.get(stash[h_uid].get("item_id"), {}).get("name", "Нет") if h_uid and h_uid in stash else "Нет"
        hs_name = ITEMS_BY_ID.get(stash[hs_uid].get("item_id"), {}).get("name", "Нет") if hs_uid and hs_uid in stash else "Нет"

        txt += (
            f"<b>{idx}. {f.get('name', f_type)}</b> [{f_type}]\n"
            f"   🔫 Оружие: <i>{w_name}</i>\n"
            f"   🛡️ Броня: <i>{a_name}</i>\n"
            f"   🪖 Шлем: <i>{h_name}</i>\n"
            f"   🎧 Наушники: <i>{hs_name}</i>\n\n"
        )
        markup.add(
            types.InlineKeyboardButton(f"⚙️ Экипировать {f.get('name', f_type)}", callback_data=f"view_fighter_{f['id']}"),
            types.InlineKeyboardButton("❌ Уволить", callback_data=f"disband_fighter_{f['id']}")
        )

    markup.add(
        types.InlineKeyboardButton("📦 Снарядить Всё Автоматом", callback_data="auto_equip")
    )
    if len(squad) < 5:
        scav_cost = 2000 if has_buff(player, "scav_discount") else 2500
        markup.add(
            types.InlineKeyboardButton(f"➕ Нанять Дикого ({fmt_rub(scav_cost)})", callback_data="hire_scav"),
            types.InlineKeyboardButton(f"➕ Нанять ЧВК ({fmt_rub(25000)})", callback_data="hire_pmc")
        )

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_view_fighter(chat_id, msg_id, player, f_id):
    squad = player.get("squad", [])
    fighter = next((f for f in squad if f["id"] == f_id), None)
    if not fighter:
        handle_menu_squad(chat_id, msg_id, player)
        return

    f_type = fighter.get("type", "pmc")
    stash = {itm["uid"]: itm for itm in player.get("stash", [])}
    w_uid = fighter.get("weapon_uid")
    a_uid = fighter.get("armor_uid")
    h_uid = fighter.get("helmet_uid")
    hs_uid = fighter.get("headset_uid")

    w_name = ITEMS_BY_ID.get(stash[w_uid].get("item_id"), {}).get("name", "—") if w_uid and w_uid in stash else "Нет"
    a_name = ITEMS_BY_ID.get(stash[a_uid].get("item_id"), {}).get("name", "—") if a_uid and a_uid in stash else "Нет"
    h_name = ITEMS_BY_ID.get(stash[h_uid].get("item_id"), {}).get("name", "—") if h_uid and h_uid in stash else "Нет"
    hs_name = ITEMS_BY_ID.get(stash[hs_uid].get("item_id"), {}).get("name", "—") if hs_uid and hs_uid in stash else "Нет"

    if f_type == "scav":
        txt = (
            f"<b>⚠️ ДИКИЙ: {fighter.get('name')}</b>\n"
            f"────────────────────────\n"
            f"Стартовый комплект «бомж-снаряжения» (менять нельзя):\n\n"
            f"1. 🔫 Оружие: <b>{w_name}</b>\n"
            f"2. 🛡️ Бронежилет: <b>{a_name}</b>\n"
            f"3. 🪖 Шлем/Головной убор: <b>{h_name}</b>\n"
            f"4. 🎧 Наушники: <b>{hs_name}</b>\n"
        )
        markup = types.InlineKeyboardMarkup(row_width=1).add(
            types.InlineKeyboardButton("❌ Уволить Дикого", callback_data=f"disband_fighter_{f_id}"),
            types.InlineKeyboardButton("🔙 К Отряду", callback_data="menu_squad")
        )
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
        return

    if f_type == "signature":
        txt = (
            f"<b>🎖️ СИГНАТУРНЫЙ ЧВК: {fighter.get('name')}</b>\n"
            f"────────────────────────\n"
            f"Сигнатурный боец прибыл со своим уникальным сетом экипировки, менять его нельзя.\n\n"
            f"1. 🔫 Оружие: <b>{w_name}</b>\n"
            f"2. 🛡️ Бронежилет: <b>{a_name}</b>\n"
            f"3. 🪖 Шлем: <b>{h_name}</b>\n"
            f"4. 🎧 Наушники: <b>{hs_name}</b>\n"
        )
        markup = types.InlineKeyboardMarkup(row_width=1).add(
            types.InlineKeyboardButton("🔙 К Отряду", callback_data="menu_squad")
        )
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
        return

    txt = (
        f"<b>⚙️ НАСТРОЙКА ЭКИПИРОВКИ ЧВК: {fighter.get('name')}</b>\n"
        f"Полная кастомизация 4 слотов снаряжения из вашего схрона:\n"
        f"────────────────────────\n"
        f"1. 🔫 Оружие: <b>{w_name}</b>\n"
        f"2. 🛡️ Бронежилет: <b>{a_name}</b>\n"
        f"3. 🪖 Шлем: <b>{h_name}</b>\n"
        f"4. 🎧 Наушники: <b>{hs_name}</b>\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    # Weapon Slot
    markup.add(
        types.InlineKeyboardButton(f"🔫 Оружие: {w_name[:14]}", callback_data=f"slot_choose_{f_id}_weapon_1"),
        types.InlineKeyboardButton("Снять 🔫", callback_data=f"slot_unequip_{f_id}_weapon")
    )
    # Armor Slot
    markup.add(
        types.InlineKeyboardButton(f"🛡️ Броня: {a_name[:14]}", callback_data=f"slot_choose_{f_id}_armor_1"),
        types.InlineKeyboardButton("Снять 🛡️", callback_data=f"slot_unequip_{f_id}_armor")
    )
    # Helmet Slot
    markup.add(
        types.InlineKeyboardButton(f"🪖 Шлем: {h_name[:14]}", callback_data=f"slot_choose_{f_id}_helmet_1"),
        types.InlineKeyboardButton("Снять 🪖", callback_data=f"slot_unequip_{f_id}_helmet")
    )
    # Headset Slot
    markup.add(
        types.InlineKeyboardButton(f"🎧 Наушники: {hs_name[:14]}", callback_data=f"slot_choose_{f_id}_headset_1"),
        types.InlineKeyboardButton("Снять 🎧", callback_data=f"slot_unequip_{f_id}_headset")
    )

    markup.add(types.InlineKeyboardButton("🔙 К Отряду", callback_data="menu_squad"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_slot_choose(chat_id, msg_id, player, f_id, slot_type, page=1):
    squad = player.get("squad", [])
    fighter = next((f for f in squad if f["id"] == f_id), None)
    if not fighter or fighter.get("type") != "pmc":
        bot.send_message(chat_id, "❌ Экипировать можно только обычных наемников ЧВК!")
        return

    stash = player.get("stash", [])
    matching_items = []

    for itm in stash:
        if itm.get("equipped_to") is None:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            cat = info.get("category")
            sub = info.get("subcategory")
            mcat = info.get("market_cat")
            name_low = info.get("name", "").lower()

            if slot_type == "weapon" and cat == "weapons":
                matching_items.append((itm, info))
            elif slot_type == "helmet" and (sub == "helmet" or "шлем" in name_low):
                matching_items.append((itm, info))
            elif slot_type == "armor" and cat == "armor" and sub != "helmet" and "шлем" not in name_low:
                matching_items.append((itm, info))
            elif slot_type == "headset" and (sub == "headset" or mcat == "Наушники" or "наушник" in name_low):
                matching_items.append((itm, info))

    per_page = 6
    total_pages = max(1, (len(matching_items) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start_idx = (page - 1) * per_page
    page_items = matching_items[start_idx : start_idx + per_page]

    slot_names = {"weapon": "Оружие", "armor": "Бронежилет", "helmet": "Шлем", "headset": "Наушники"}
    txt = (
        f"<b>🎒 СХРОН: {slot_names.get(slot_type, slot_type).upper()} (Стр. {page}/{total_pages})</b>\n"
        f"Выберите предмет для наемника <b>{fighter.get('name')}</b>:\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not page_items:
        txt += "<i>В вашем схроне нет доступных свободных предметов этого типа.</i>\n"
    else:
        for itm, info in page_items:
            r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(info.get("rarity"), "⬜")
            stat = f"⚔️ +{info.get('combat', 0)}" if slot_type == "weapon" else f"🛡️ +{info.get('armor', 0)}"
            markup.add(
                types.InlineKeyboardButton(
                    f"{r_b} {info.get('name')[:20]} | {stat}",
                    callback_data=f"slot_equip_{f_id}_{slot_type}_{itm['uid']}"
                )
            )

    nav_btns = []
    if page > 1:
        nav_btns.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"slot_choose_{f_id}_{slot_type}_{page-1}"))
    nav_btns.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_btns.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"slot_choose_{f_id}_{slot_type}_{page+1}"))

    if nav_btns:
        markup.row(*nav_btns)

    markup.add(types.InlineKeyboardButton("🔙 К Бойцу", callback_data=f"view_fighter_{f_id}"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_slot_equip(call, player, db, f_id, slot_type, uid):
    squad = player.get("squad", [])
    fighter = next((f for f in squad if f["id"] == f_id), None)
    if not fighter:
        bot.answer_callback_query(call.id, "❌ Боец не найден!")
        return

    if fighter.get("type") != "pmc":
        bot.answer_callback_query(call.id, "❌ Экипировать можно только наемников ЧВК!", show_alert=True)
        return

    stash = player.get("stash", [])
    item_entry = next((i for i in stash if i.get("uid") == uid), None)
    if not item_entry or item_entry.get("equipped_to") is not None:
        bot.answer_callback_query(call.id, "❌ Предмет недоступен или уже надет!", show_alert=True)
        return

    slot_key = f"{slot_type}_uid"
    prev_uid = fighter.get(slot_key)
    if prev_uid:
        prev_entry = next((i for i in stash if i.get("uid") == prev_uid), None)
        if prev_entry:
            prev_entry["equipped_to"] = None

    fighter[slot_key] = uid
    item_entry["equipped_to"] = f_id
    save_db(db)

    info = ITEMS_BY_ID.get(item_entry.get("item_id"), {})
    bot.answer_callback_query(call.id, f"✅ Экипировано: {info.get('name')}")
    handle_view_fighter(call.message.chat.id, call.message.message_id, player, f_id)

def handle_slot_unequip(call, player, db, f_id, slot_type):
    squad = player.get("squad", [])
    fighter = next((f for f in squad if f["id"] == f_id), None)
    if not fighter:
        return

    if fighter.get("type") != "pmc":
        bot.answer_callback_query(call.id, "❌ Нельзя снимать снаряжение у этого бойца!", show_alert=True)
        return

    slot_key = f"{slot_type}_uid"
    prev_uid = fighter.get(slot_key)
    if prev_uid:
        stash = player.get("stash", [])
        prev_entry = next((i for i in stash if i.get("uid") == prev_uid), None)
        if prev_entry:
            prev_entry["equipped_to"] = None
        fighter[slot_key] = None
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Слот освобожден!")
    else:
        bot.answer_callback_query(call.id, "⚠️ Слот и так пуст.")

    handle_view_fighter(call.message.chat.id, call.message.message_id, player, f_id)

def handle_auto_equip(call, player, db):
    squad = player.get("squad", [])
    if not squad:
        bot.answer_callback_query(call.id, "❌ В отряде нет бойцов!", show_alert=True)
        return

    pmc_fighters = [f for f in squad if f.get("type") == "pmc"]
    if not pmc_fighters:
        bot.answer_callback_query(call.id, "ℹ️ В отряде нет наемников ЧВК для экипировки (у Диких и Сигнатурных сет фиксирован).", show_alert=True)
        return

    stash = player.get("stash", [])

    free_weapons = []
    free_armors = []
    free_helmets = []
    free_headsets = []

    for itm in stash:
        if itm.get("equipped_to") is None:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            cat = info.get("category")
            sub = info.get("subcategory")
            mcat = info.get("market_cat")
            name_low = info.get("name", "").lower()

            if cat == "weapons":
                free_weapons.append((info.get("combat", 0), itm))
            elif sub == "helmet" or "шлем" in name_low:
                free_helmets.append((info.get("armor", 0), itm))
            elif cat == "armor" and sub != "helmet" and "шлем" not in name_low:
                free_armors.append((info.get("armor", 0), itm))
            elif sub == "headset" or mcat == "Наушники" or "наушник" in name_low:
                free_headsets.append((info.get("combat", 0) + info.get("armor", 0), itm))

    free_weapons.sort(key=lambda x: x[0], reverse=True)
    free_armors.sort(key=lambda x: x[0], reverse=True)
    free_helmets.sort(key=lambda x: x[0], reverse=True)
    free_headsets.sort(key=lambda x: x[0], reverse=True)

    w_i = a_i = h_i = hs_i = 0
    equipped_count = 0

    for f in pmc_fighters:
        if not f.get("weapon_uid") and w_i < len(free_weapons):
            _, itm = free_weapons[w_i]
            w_i += 1
            f["weapon_uid"] = itm["uid"]
            itm["equipped_to"] = f["id"]
            equipped_count += 1
        if not f.get("armor_uid") and a_i < len(free_armors):
            _, itm = free_armors[a_i]
            a_i += 1
            f["armor_uid"] = itm["uid"]
            itm["equipped_to"] = f["id"]
            equipped_count += 1
        if not f.get("helmet_uid") and h_i < len(free_helmets):
            _, itm = free_helmets[h_i]
            h_i += 1
            f["helmet_uid"] = itm["uid"]
            itm["equipped_to"] = f["id"]
            equipped_count += 1
        if not f.get("headset_uid") and hs_i < len(free_headsets):
            _, itm = free_headsets[hs_i]
            hs_i += 1
            f["headset_uid"] = itm["uid"]
            itm["equipped_to"] = f["id"]
            equipped_count += 1

    save_db(db)
    bot.answer_callback_query(call.id, f"✅ Авто-экипировано {equipped_count} предметов для ЧВК!", show_alert=True)
    handle_menu_squad(call.message.chat.id, call.message.message_id, player)

def handle_hire_fighter(call, player, db, f_type, cost):
    if len(player.get("squad", [])) >= 5:
        bot.answer_callback_query(call.id, "❌ Отряд уже полон (макс. 5 бойцов)!", show_alert=True)
        return
    if f_type == "scav" and has_buff(player, "scav_discount"):
        cost = int(cost * 0.8)
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно средств! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    squad = player.setdefault("squad", [])
    new_id = max([f["id"] for f in squad] + [0]) + 1

    if f_type == "scav":
        # Guaranteed starting 'bomzh-gear' strictly from the database Common pool!
        scav_items, scav_uids = generate_scav_gear(new_id)
        player.setdefault("stash", []).extend(scav_items)
        squad.append({
            "id": new_id,
            "type": "scav",
            "name": f"Дикий #{new_id}",
            "weapon_uid": scav_uids["weapon_uid"],
            "armor_uid": scav_uids["armor_uid"],
            "helmet_uid": scav_uids["helmet_uid"],
            "headset_uid": scav_uids["headset_uid"]
        })
    else:
        squad.append({
            "id": new_id,
            "type": "pmc",
            "name": f"ЧВК #{new_id}",
            "weapon_uid": None,
            "armor_uid": None,
            "helmet_uid": None,
            "headset_uid": None
        })

    save_db(db)
    bot.answer_callback_query(call.id, f"✅ Новый боец нанят за {fmt_rub(cost)}!")
    handle_menu_squad(call.message.chat.id, call.message.message_id, player)

def handle_disband_fighter(call, player, db, f_id):
    squad = player.get("squad", [])
    fighter = next((f for f in squad if f["id"] == f_id), None)
    if not fighter:
        bot.answer_callback_query(call.id, "❌ Боец не найден!")
        return

    stash = player.get("stash", [])
    if fighter.get("type") == "scav":
        # Scav's personal non-detachable common gear leaves with them
        player["stash"] = [itm for itm in stash if itm.get("equipped_to") != f_id]
        msg = f"✅ {fighter.get('name')} уволен со своим стартовым комплектом."
    else:
        # PMC gear is returned unequipped to player stash
        for itm in stash:
            if itm.get("equipped_to") == f_id:
                itm["equipped_to"] = None
        msg = f"✅ {fighter.get('name')} уволен, экипировка снята в схрон."

    player["squad"] = [f for f in squad if f["id"] != f_id]
    save_db(db)
    bot.answer_callback_query(call.id, msg)
    handle_menu_squad(call.message.chat.id, call.message.message_id, player)

# ----------------- SECTION 3: STASH & 5 WAREHOUSES -----------------
def handle_menu_stash(chat_id, msg_id, player):
    wh = player.get("warehouses", {})
    txt = (
        f"<b>📦 СКЛАДЫ И СХРОН ОПЕРАТОРА ЧВК</b>\n"
        f"────────────────────────\n"
        f"Вместимость ваших 5 специализированных складов и сейфа:\n\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    categories = [
        ("weapons", "🔫 Оружие"),
        ("armor", "🛡️ Броня"),
        ("gear", "🎧 Снаряжение & Наушники"),
        ("components", "🔩 Компоненты"),
        ("valuables", "💼 Ценности и документы")
    ]

    for cat_key, label in categories:
        cap = get_warehouse_capacity(player, cat_key)
        cnt = get_warehouse_count(player, cat_key)
        lvl = wh.get(cat_key, 1)
        txt += f"• <b>{label}:</b> {cnt}/{cap} (Ур. {lvl})\n"
        markup.add(
            types.InlineKeyboardButton(f"📂 Открыть {label}", callback_data=f"stash_cat_{cat_key}_1")
        )
        cost = get_warehouse_upgrade_cost(lvl)
        if cost is not None:
            markup.add(
                types.InlineKeyboardButton(f"🔼 {label} до {lvl+1} ур. | {fmt_rub(cost)}", callback_data=f"upgrade_wh_{cat_key}")
            )

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_stash_category(chat_id, msg_id, player, cat_key, page=1):
    db = load_db()
    stash = player.get("stash", [])
    matching = []

    def is_val(info):
        cat = info.get("category", "")
        mcat = info.get("market_cat", "")
        name = info.get("name", "").lower()
        i_id = info.get("id", "").lower()
        return (
            cat in ["relic", "valuable", "valuables"] or
            mcat == "Драгоценности" or
            "keycard" in i_id or
            "ключ-карт" in name or
            "документ" in name or
            "флешк" in name or
            i_id.startswith("relic_")
        )

    for itm in stash:
        info = ITEMS_BY_ID.get(itm.get("item_id"), {})
        if cat_key == "valuables":
            if is_val(info):
                matching.append((itm, info))
        elif cat_key == "gear":
            if info.get("category") == "gear" and not is_val(info):
                matching.append((itm, info))
        elif info.get("category") == cat_key:
            matching.append((itm, info))

    per_page = 6
    total_pages = max(1, (len(matching) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start_idx = (page - 1) * per_page
    page_items = matching[start_idx : start_idx + per_page]

    prapor_rate = 0.40 if has_buff(player, "prapor_bonus") else 0.30

    txt = (
        f"<b>📂 СКЛАД: {WAREHOUSE_NAMES.get(cat_key, cat_key).upper()} (Стр. {page}/{total_pages})</b>\n"
        f"Выкуп Прапора: <b>{int(prapor_rate*100)}%</b> от рыночной стоимости с учетом кризиса\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not page_items:
        txt += "<i>В этом складе нет предметов.</i>\n"
    else:
        for itm, info in page_items:
            r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(info.get("rarity"), "⬜")
            cr_p = get_crisis_price(info.get("price", 10000), info.get("market_cat"), db)
            buyout = int(cr_p * prapor_rate)
            eq_status = f" [Надет #{itm['equipped_to']}]" if itm.get("equipped_to") else ""

            txt += (
                f"{r_b} <b>{info.get('name')}</b>{eq_status}\n"
                f"   🏷️ Каталог: {fmt_rub(cr_p)} | 💰 Выкуп Прапора: <b>{fmt_rub(buyout)}</b>\n"
            )
            if not itm.get("equipped_to"):
                markup.add(
                    types.InlineKeyboardButton(f"💸 Продать Прапору (+{fmt_rub(buyout)})", callback_data=f"prapor_sell_{itm['uid']}")
                )

    nav_btns = []
    if page > 1:
        nav_btns.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"stash_cat_{cat_key}_{page-1}"))
    nav_btns.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_btns.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"stash_cat_{cat_key}_{page+1}"))

    if nav_btns:
        markup.row(*nav_btns)

    markup.add(types.InlineKeyboardButton("🔙 К Складам", callback_data="menu_stash"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_prapor_sell(call, player, db, uid):
    stash = player.get("stash", [])
    entry = next((i for i in stash if i.get("uid") == uid), None)
    if not entry:
        bot.answer_callback_query(call.id, "❌ Предмет не найден!", show_alert=True)
        return
    if entry.get("equipped_to"):
        bot.answer_callback_query(call.id, "❌ Сначала снимите предмет с бойца!", show_alert=True)
        return

    info = ITEMS_BY_ID.get(entry.get("item_id"), {})
    cr_p = get_crisis_price(info.get("price", 10000), info.get("market_cat"), db)
    prapor_rate = 0.40 if has_buff(player, "prapor_bonus") else 0.30
    buyout = int(cr_p * prapor_rate)

    stash.remove(entry)
    player["money"] = player.get("money", 0) + buyout
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"✅ Прапор выкупил {info.get('name')[:18]}!\n💰 Получено: +{fmt_rub(buyout)} ({int(prapor_rate*100)}%)",
        show_alert=True
    )
    handle_stash_category(call.message.chat.id, call.message.message_id, player, info.get("category", "gear"))

def handle_upgrade_warehouse(call, player, db, cat_key):
    wh = player.setdefault("warehouses", {})
    current_lvl = wh.get(cat_key, 1)
    if current_lvl >= 10:
        bot.answer_callback_query(call.id, "❌ Склад уже максимального 10 уровня!", show_alert=True)
        return

    cost = get_warehouse_upgrade_cost(current_lvl)
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    wh[cat_key] = current_lvl + 1
    save_db(db)

    bot.answer_callback_query(call.id, f"🎉 {WAREHOUSE_NAMES.get(cat_key)} улучшен до {current_lvl + 1} уровня!", show_alert=True)
    handle_menu_stash(call.message.chat.id, call.message.message_id, player)

# ----------------- SECTION 4: FLEA MARKET & P2P -----------------
def handle_menu_market(chat_id, msg_id, player, db):
    btc_rate = get_current_btc_rate()
    if has_boss_set_bonus(player, "reshala"):
        tax_rate = 0
    elif has_buff(player, "market_tax"):
        tax_rate = 5
    else:
        tax_rate = 10

    crisis = db.get("economic_crisis", {})

    crisis_txt = ""
    if crisis and crisis.get("expires_at", 0) > time.time():
        crisis_txt = f"\n🚨 <b>АКТИВНЫЙ ЭКОНОМИЧЕСКИЙ КРИЗИС:</b> {crisis.get('headline')}\n"

    reshala_note = " (Сет Решалы: 0% налог! 🔥)" if has_boss_set_bonus(player, "reshala") else ""

    txt = (
        f"<b>🏪 БАРАХОЛКА ТАРКОВА & P2P РЫНОК</b>\n"
        f"────────────────────────\n"
        f"🪙 Курс Bitcoin: <b>{fmt_rub(btc_rate)} / 1 BTC</b>\n"
        f"Баланс BTC: <b>{player.get('btc', 0):.4f} BTC</b>\n"
        f"Комиссия P2P: <b>{tax_rate}%</b>{reshala_note}\n"
        f"{crisis_txt}"
        f"────────────────────────\n"
        f"Выберите категорию товаров магазина Прапора:"
    )

    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("🔫 Оружие", callback_data="market_cat_Оружие"),
        types.InlineKeyboardButton("🛡️ Броня", callback_data="market_cat_Экипировка")
    )
    markup.add(
        types.InlineKeyboardButton("🪖 Шлемы", callback_data="market_cat_Шлемы"),
        types.InlineKeyboardButton("🎧 Наушники", callback_data="market_cat_Наушники")
    )
    markup.add(
        types.InlineKeyboardButton("💉 Медицина", callback_data="market_cat_Медицина"),
        types.InlineKeyboardButton("💎 Драгоценности", callback_data="market_cat_Драгоценности")
    )
    markup.add(
        types.InlineKeyboardButton("🔩 Компоненты", callback_data="market_cat_Компоненты")
    )

    if player.get("btc", 0) > 0.001:
        markup.add(types.InlineKeyboardButton(f"💰 Продать все BTC | +{fmt_rub(player.get('btc', 0) * btc_rate)}", callback_data="market_sell_btc"))

    markup.add(types.InlineKeyboardButton("🛒 P2P Торговля Игроков", callback_data="market_p2p"))
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_market_catalog(chat_id, msg_id, player, db, cat_name, page=1):
    if cat_name == "Шлемы":
        items = [i for i in ITEMS_LIST if i.get("subcategory") == "helmet" or ("шлем" in i.get("name", "").lower() and i.get("category") == "armor")]
    elif cat_name == "Экипировка":
        items = [i for i in ITEMS_LIST if i.get("market_cat") == "Экипировка" and i.get("subcategory") != "helmet" and "шлем" not in i.get("name", "").lower()]
    else:
        items = [i for i in ITEMS_LIST if i.get("market_cat") == cat_name]

    per_page = 6
    total_pages = max(1, (len(items) + per_page - 1) // per_page)
    page = max(1, min(page, total_pages))
    start_idx = (page - 1) * per_page
    page_items = items[start_idx : start_idx + per_page]

    crisis = db.get("economic_crisis", {})
    is_crisis_cat = crisis and crisis.get("expires_at", 0) > time.time() and crisis.get("category") == cat_name

    txt = (
        f"<b>🏪 БАРАХОЛКА: {cat_name.upper()} (Стр. {page}/{total_pages})</b>\n"
        f"Всего в реестре: <b>{len(items)}</b> предметов\n"
    )
    if is_crisis_cat:
        sign = "+" if crisis.get("direction") == "surge" else "-"
        txt += f"🚨 <b>КРИЗИС КАТЕГОРИИ:</b> Цены изменены на {sign}{crisis.get('shift_pct')}%\n"
    txt += "────────────────────────\n"

    markup = types.InlineKeyboardMarkup(row_width=1)
    for itm in page_items:
        r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        price = get_crisis_price(itm.get("price", 10000), itm.get("market_cat", cat_name), db)

        is_sold_by_prapor = itm.get("rarity") in ["common", "rare"] and itm.get("category") != "relic"

        txt += f"{r_b} <b>{itm['name']}</b> — <b>{fmt_rub(price)}</b>\n<i>{itm.get('desc', '')}</i>\n"

        if not is_sold_by_prapor:
            txt += "⚠️ <i>АРМЕЙСКИЙ ЗАПРЕТ: Прапор продает только Обычные (Common) и Редкие (Rare) предметы. Эпические и легендарные вещи ищите в рейдах, кейсах или на P2P рынке!</i>\n\n"
        else:
            txt += "\n"
            markup.add(
                types.InlineKeyboardButton(f"🛒 Купить {itm['name'][:18]} | {fmt_rub(price)}", callback_data=f"market_buy_{itm['id']}_{cat_name}_{page}")
            )

    nav_buttons = []
    if page > 1:
        nav_buttons.append(types.InlineKeyboardButton("⬅️ Назад", callback_data=f"market_page_{cat_name}_{page-1}"))
    nav_buttons.append(types.InlineKeyboardButton(f"📄 {page}/{total_pages}", callback_data="none"))
    if page < total_pages:
        nav_buttons.append(types.InlineKeyboardButton("Вперед ➡️", callback_data=f"market_page_{cat_name}_{page+1}"))

    if nav_buttons:
        markup.row(*nav_buttons)

    markup.add(types.InlineKeyboardButton("🔙 К Барахолке", callback_data="menu_market"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_market_buy_action(call, player, db, item_id, cat_name, page):
    info = ITEMS_BY_ID.get(item_id)
    if not info:
        bot.answer_callback_query(call.id, "❌ Предмет не найден!")
        return

    if info.get("rarity") not in ["common", "rare"] or info.get("category") == "relic":
        bot.answer_callback_query(call.id, "❌ Прапор продает только Обычные (Common) и Редкие (Rare) предметы! Эпик и Легендарки ищите в рейдах или на P2P!", show_alert=True)
        return

    price = get_crisis_price(info.get("price", 10000), info.get("market_cat", cat_name), db)
    if player.get("money", 0) < price:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(price)}", show_alert=True)
        return

    cat = info.get("category", "gear")
    if not can_store_item(player, item_id):
        bot.answer_callback_query(call.id, f"❌ Склад '{WAREHOUSE_NAMES.get(cat)}' переполнен! Улучшите склад.", show_alert=True)
        return

    player["money"] -= price
    player.setdefault("stash", []).append({
        "uid": f"mkt_{int(time.time())}_{random.randint(100,999)}",
        "item_id": item_id,
        "equipped_to": None
    })
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Куплено: {info.get('name')} за {fmt_rub(price)}!", show_alert=True)
    handle_market_catalog(call.message.chat.id, call.message.message_id, player, db, cat_name, page)

def handle_sell_btc(call, player, db):
    btc = player.get("btc", 0.0)
    if btc < 0.001:
        bot.answer_callback_query(call.id, "❌ У вас нет Биткоинов для продажи!", show_alert=True)
        return
    rate = get_current_btc_rate()
    rub = int(btc * rate)
    player["money"] = player.get("money", 0) + rub
    player["btc"] = 0.0
    save_db(db)
    bot.answer_callback_query(
        call.id,
        f"✅ Продано {btc:.4f} BTC!\n📊 Курс: {fmt_rub(rate)}\n💰 Получено: +{fmt_rub(rub)}",
        show_alert=True
    )
    handle_menu_market(call.message.chat.id, call.message.message_id, player, db)

def get_p2p_tax_rate(u):
    if not u:
        return 0.10
    if has_boss_set_bonus(u, "reshala"):
        return 0.0
    if has_buff(u, "market_tax"):
        return 0.05
    return 0.10

def handle_p2p_market(chat_id, msg_id, player, db):
    lots = db.get("p2p_market", [])
    tax_pct = get_p2p_tax_rate(player)
    tax_rate = int(tax_pct * 100)

    txt = (
        f"<b>🛒 P2P РЫНОК ИГРОКОВ (БАРАХОЛКА)</b>\n"
        f"Комиссия на продажу: <b>{tax_rate}%</b> | Активных лотов: <b>{len(lots)}</b>\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not lots:
        txt += "<i>Сейчас на P2P рынке нет выставленных предметов.</i>\n"
    else:
        for lot in lots[:10]:
            itm = lot["item"]
            r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
            txt += (
                f"{r_b} <b>{itm['name']}</b>\n"
                f"   💰 Цена покупки: <b>{fmt_rub(lot['price'])}</b>\n"
                f"   👤 Продавец: @{lot.get('seller_name', 'Player')}\n"
            )
            if lot.get("seller_id") != player["user_id"]:
                markup.add(types.InlineKeyboardButton(f"🛒 Купить {itm['name'][:18]} | {fmt_rub(lot['price'])}", callback_data=f"buy_p2p_{lot['lot_id']}"))
            else:
                markup.add(types.InlineKeyboardButton(f"❌ Снять с продажи: {itm['name'][:18]}", callback_data=f"cancel_p2p_{lot['lot_id']}"))

    markup.add(
        types.InlineKeyboardButton("📤 Выставить предмет из схрона", callback_data="p2p_list_menu"),
        types.InlineKeyboardButton("🔙 К Барахолке", callback_data="menu_market")
    )
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_p2p_list_menu(chat_id, msg_id, player, db):
    stash = [i for i in player.get("stash", []) if not i.get("equipped_to")]
    tax_pct = get_p2p_tax_rate(player)
    tax_rate = int(tax_pct * 100)

    txt = (
        f"<b>📤 ВЫСТАВИТЬ ПРЕДМЕТ НА P2P РЫНОК</b>\n"
        f"Комиссия Барахолки: <b>{tax_rate}%</b>\n\n"
        f"<i>Выберите предмет из вашего свободного схрона:</i>\n"
        f"────────────────────────\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    if not stash:
        txt += "<i>В вашем схроне нет свободных предметов для выставления.</i>\n"
    else:
        for itm in stash[:12]:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            p = get_crisis_price(info.get("price", 10000), info.get("market_cat"), db)
            fee = int(p * tax_pct)
            net = p - fee
            r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(info.get("rarity"), "⬜")
            markup.add(
                types.InlineKeyboardButton(
                    f"{r_b} {info.get('name')[:18]} | {fmt_rub(p)} (Вам: +{fmt_rub(net)})",
                    callback_data=f"p2p_list_{itm['uid']}"
                )
            )

    markup.add(types.InlineKeyboardButton("🔙 Назад к P2P", callback_data="market_p2p"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_p2p_list_action(call, player, db, uid):
    stash = player.get("stash", [])
    item_entry = next((i for i in stash if i.get("uid") == uid), None)
    if not item_entry or item_entry.get("equipped_to"):
        bot.answer_callback_query(call.id, "❌ Предмет недоступен для выставки!", show_alert=True)
        return

    info = ITEMS_BY_ID.get(item_entry.get("item_id"), {})
    price = get_crisis_price(info.get("price", 10000), info.get("market_cat"), db)
    tax_pct = get_p2p_tax_rate(player)
    fee = int(price * tax_pct)
    net = price - fee

    stash.remove(item_entry)
    db.setdefault("p2p_market", []).append({
        "lot_id": f"lot_{int(time.time())}_{random.randint(100,999)}",
        "seller_id": player["user_id"],
        "seller_name": player.get("username", "PMC"),
        "price": price,
        "item": info
    })
    save_db(db)

    bot.answer_callback_query(
        call.id,
        f"✅ Лот выставлен на P2P рынок!\n📦 {info.get('name')}\n🏷️ Цена: {fmt_rub(price)}\n💰 К выплате при покупке: +{fmt_rub(net)}",
        show_alert=True
    )
    handle_p2p_market(call.message.chat.id, call.message.message_id, player, db)

def handle_buy_p2p_lot(call, player, db, lot_id):
    lots = db.get("p2p_market", [])
    lot = next((l for l in lots if l["lot_id"] == lot_id), None)
    if not lot:
        bot.answer_callback_query(call.id, "❌ Этот лот уже выкуплен другим игроком!", show_alert=True)
        handle_p2p_market(call.message.chat.id, call.message.message_id, player, db)
        return

    if player.get("money", 0) < lot["price"]:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(lot['price'])}", show_alert=True)
        return

    item_info = lot["item"]
    if not can_store_item(player, item_info["id"]):
        bot.answer_callback_query(call.id, "❌ Ваш склад переполнен! Улучшите склад.", show_alert=True)
        return

    player["money"] -= lot["price"]
    player.setdefault("stash", []).append({
        "uid": f"p2p_{int(time.time())}_{random.randint(100,999)}",
        "item_id": item_info["id"],
        "equipped_to": None
    })

    # Payout to seller minus tax
    seller_id = str(lot["seller_id"])
    seller = db["users"].get(seller_id)
    tax_pct = get_p2p_tax_rate(seller)
    seller_payout = lot["price"] - int(lot["price"] * tax_pct)
    if seller:
        seller["money"] = seller.get("money", 0) + seller_payout

    lots.remove(lot)
    save_db(db)

    bot.answer_callback_query(call.id, f"🎉 Лот успешно выкуплен! {item_info['name']} отправлен в ваш схрон.", show_alert=True)
    handle_p2p_market(call.message.chat.id, call.message.message_id, player, db)

def handle_cancel_p2p_lot(call, player, db, lot_id):
    lots = db.get("p2p_market", [])
    lot = next((l for l in lots if l["lot_id"] == lot_id), None)
    if not lot:
        bot.answer_callback_query(call.id, "❌ Лот не найден!")
        return

    if lot.get("seller_id") != player["user_id"]:
        bot.answer_callback_query(call.id, "❌ Это не ваш лот!")
        return

    item_info = lot["item"]
    player.setdefault("stash", []).append({
        "uid": f"ret_{int(time.time())}_{random.randint(100,999)}",
        "item_id": item_info["id"],
        "equipped_to": None
    })
    lots.remove(lot)
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Лот {item_info['name']} снят с продажи и возвращен в схрон.", show_alert=True)
    handle_p2p_market(call.message.chat.id, call.message.message_id, player, db)

# ----------------- SECTION 5: HIDEOUT & BUSINESSES -----------------
def handle_menu_hideout(chat_id, msg_id, player):
    hlvl = player.get("hideout_lvl", 1)
    mods = player.get("modules", {})
    bizs = player.get("businesses", {})
    h_cost = HIDEOUT_UPGRADE_COSTS.get(hlvl)

    txt = (
        f"<b>🏚️ УБЕЖИЩЕ ЧВК & ТЕНЕВЫЕ БИЗНЕСЫ (Уровень {hlvl}/10)</b>\n"
        f"────────────────────────\n"
        f"<b>Статус модулей Убежища:</b>\n"
    )
    for m_key, m_name in MODULE_NAMES.items():
        txt += f"• {m_name}: <b>Ур. {mods.get(m_key, 0)}/{hlvl}</b>\n"

    txt += "\n<b>Теневые бизнесы (пассивный доход ₽/час):</b>\n"
    total_rub_hr = 0
    for b_key, b_name in BUSINESS_NAMES.items():
        b_lvl = bizs.get(b_key, 0)
        hr_p = get_business_hourly_income(b_key, b_lvl)
        if has_buff(player, "business_income"):
            hr_p = int(hr_p * 1.15)
        total_rub_hr += hr_p
        txt += f"• {b_name}: <b>Ур. {b_lvl}/{hlvl}</b> (+{fmt_rub(hr_p)}/час)\n"

    btc_hr = get_mining_hourly_btc(mods.get("mining_farm", 0))
    if has_buff(player, "btc_bonus"):
        btc_hr = round(btc_hr * 1.15, 4)
    txt += f"• ⛏️ Майнинг-ферма BTC: <b>+{btc_hr} BTC/час</b>\n"
    txt += f"────────────────────────\nСуммарный доход: <b>+{fmt_rub(total_rub_hr)}/час</b>"

    markup = types.InlineKeyboardMarkup(row_width=2)
    if h_cost:
        markup.add(types.InlineKeyboardButton(f"🔼 Улучшить Убежище до {hlvl+1} ур. ({fmt_rub(h_cost)})", callback_data="upgrade_hideout"))

    for m_key, m_name in MODULE_NAMES.items():
        m_lvl = mods.get(m_key, 0)
        if m_lvl < hlvl and m_lvl < 10:
            c = get_module_upgrade_cost(m_lvl)
            markup.add(types.InlineKeyboardButton(f"⚙️ {m_name} {m_lvl+1} ур. ({fmt_rub(c)})", callback_data=f"upgrade_module_{m_key}"))

    for b_key, b_name in BUSINESS_NAMES.items():
        b_lvl = bizs.get(b_key, 0)
        if b_lvl < hlvl and b_lvl < 10:
            c = get_business_upgrade_cost(b_key, b_lvl)
            if c:
                markup.add(types.InlineKeyboardButton(f"💼 {b_name[:14]} {b_lvl+1} ур. ({fmt_rub(c)})", callback_data=f"upgrade_biz_{b_key}"))

    markup.add(types.InlineKeyboardButton("🎁 Забрать Накопленный Доход", callback_data="claim_income"))
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_upgrade_hideout(call, player, db):
    hlvl = player.get("hideout_lvl", 1)
    cost = HIDEOUT_UPGRADE_COSTS.get(hlvl)
    if not cost or hlvl >= 10:
        bot.answer_callback_query(call.id, "❌ Убежище уже максимального уровня!", show_alert=True)
        return
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    player["hideout_lvl"] = hlvl + 1
    save_db(db)
    bot.answer_callback_query(call.id, f"🎉 Убежище прокачано до {hlvl + 1} уровня!", show_alert=True)
    handle_menu_hideout(call.message.chat.id, call.message.message_id, player)

def handle_upgrade_module(call, player, db, mod_key):
    hlvl = player.get("hideout_lvl", 1)
    mods = player.setdefault("modules", {})
    cur_lvl = mods.get(mod_key, 0)
    if cur_lvl >= hlvl:
        bot.answer_callback_query(call.id, f"❌ Модуль ограничен уровнем Убежища ({hlvl})! Сначала прокачайте Убежище.", show_alert=True)
        return
    cost = get_module_upgrade_cost(cur_lvl)
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    mods[mod_key] = cur_lvl + 1
    save_db(db)
    bot.answer_callback_query(call.id, f"✅ Модуль {MODULE_NAMES.get(mod_key)} прокачан до {cur_lvl + 1} ур.!")
    handle_menu_hideout(call.message.chat.id, call.message.message_id, player)

def handle_upgrade_business(call, player, db, biz_key):
    hlvl = player.get("hideout_lvl", 1)
    bizs = player.setdefault("businesses", {})
    cur_lvl = bizs.get(biz_key, 0)
    if cur_lvl >= hlvl:
        bot.answer_callback_query(call.id, f"❌ Бизнес ограничен уровнем Убежища ({hlvl})! Сначала прокачайте Убежище.", show_alert=True)
        return
    cost = get_business_upgrade_cost(biz_key, cur_lvl)
    if not cost or player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    bizs[biz_key] = cur_lvl + 1
    save_db(db)
    bot.answer_callback_query(call.id, f"✅ {BUSINESS_NAMES.get(biz_key)} расширен до {cur_lvl + 1} уровня!")
    handle_menu_hideout(call.message.chat.id, call.message.message_id, player)

def handle_claim_income(call, player, db):
    now = int(time.time())
    last_claim = player.get("last_income_claim", now)
    diff = max(0, min(now - last_claim, 86400)) # Up to 24h offline pool
    if diff < 60:
        bot.answer_callback_query(call.id, "⏳ Доход начисляется поминутно! Подождите немного.", show_alert=True)
        return

    hours = diff / 3600.0
    bizs = player.get("businesses", {})
    mods = player.get("modules", {})

    total_rub_hr = 0
    for b_key in BUSINESS_NAMES:
        lvl = bizs.get(b_key, 0)
        p = get_business_hourly_income(b_key, lvl)
        if has_buff(player, "business_income"):
            p = int(p * 1.15)
        total_rub_hr += p

    earned_rubles = int(total_rub_hr * hours)

    btc_hr = get_mining_hourly_btc(mods.get("mining_farm", 0))
    if has_buff(player, "btc_bonus"):
        btc_hr = round(btc_hr * 1.15, 4)
    earned_btc = round(btc_hr * hours, 4)

    if earned_rubles == 0 and earned_btc == 0.0:
        bot.answer_callback_query(call.id, "⚠️ У вас еще нет работающих бизнесов или фермы! Постройте их в Убежище.", show_alert=True)
        return

    player["money"] = player.get("money", 0) + earned_rubles
    player["btc"] = round(player.get("btc", 0.0) + earned_btc, 4)
    player["last_income_claim"] = now
    save_db(db)

    mins = int(diff // 60)
    bot.answer_callback_query(
        call.id,
        f"🎁 Доход собран за {mins} мин. работы!\n💰 +{fmt_rub(earned_rubles)}\n🪙 +{earned_btc:.4f} BTC",
        show_alert=True
    )
    show_main_menu(call.message.chat.id, player)

# ----------------- SECTION 6: SUPPLIES -----------------
def handle_menu_supply(chat_id, msg_id, player):
    ch_lvl = player.get("supply_channel_lvl", 1)
    act_del = player.get("active_delivery")
    now = int(time.time())

    txt = (
        f"<b>🚚 КОНТРАБАНДНЫЙ ТРАФИК (Канал снабжения: {ch_lvl}/10 ур.)</b>\n"
        f"────────────────────────\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)

    if act_del:
        rem = act_del["finish_time"] - now
        if rem <= 0:
            txt += "📦 <b>ГРУЗ ДОСТАВЛЕН!</b> Контрабандисты выгрузили ящики на конспиративной квартире.\n"
            markup.add(types.InlineKeyboardButton("🎁 Вскрыть доставленный груз", callback_data="claim_supply"))
        else:
            txt += f"⏳ <b>Груз в пути...</b> До прибытия каравана: <b>{rem} сек.</b>\n"
            markup.add(types.InlineKeyboardButton("🔄 Обновить статус каравана", callback_data="menu_supply"))
    else:
        txt += "Выберите партию контрабанды для заказа:\n\n"
        tiers = [
            (1, "Партия медикаментов и патронов", 15000, 60),
            (2, "Армейский груз UNTAR", 45000, 180),
            (3, "Спец-контрабанда TerraGroup", 120000, 360)
        ]
        for t_idx, t_name, cost, t_time in tiers:
            if has_buff(player, "supply_speed"):
                t_time = int(t_time * 0.8)
            txt += f"• <b>Тир {t_idx}:</b> {t_name} — <b>{fmt_rub(cost)}</b> ({t_time} сек.)\n"
            markup.add(types.InlineKeyboardButton(f"Заказать Тир {t_idx} ({fmt_rub(cost)})", callback_data=f"order_supply_tier_{t_idx}"))

    up_cost = SUPPLY_CHANNEL_COSTS.get(ch_lvl)
    if up_cost:
        markup.add(types.InlineKeyboardButton(f"🔼 Улучшить канал до {ch_lvl+1} ур. ({fmt_rub(up_cost)})", callback_data="upgrade_supply_channel"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception:
        pass

def handle_order_supply(call, player, db, tier):
    if player.get("active_delivery"):
        bot.answer_callback_query(call.id, "❌ У вас уже есть активная доставка в пути!", show_alert=True)
        return

    costs = {1: 15000, 2: 45000, 3: 120000}
    times = {1: 60, 2: 180, 3: 360}
    cost = costs.get(tier, 15000)
    dur = times.get(tier, 60)

    if has_buff(player, "supply_speed"):
        dur = int(dur * 0.8)

    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    now = int(time.time())
    player["money"] -= cost
    player["active_delivery"] = {
        "tier": tier,
        "start_time": now,
        "finish_time": now + dur
    }
    save_db(db)

    bot.answer_callback_query(call.id, f"🚚 Караван Тир {tier} отправлен в путь! Ожидание: {dur} сек.")
    handle_menu_supply(call.message.chat.id, call.message.message_id, player)

def handle_claim_supply(call, player, db):
    act = player.get("active_delivery")
    if not act:
        bot.answer_callback_query(call.id, "❌ Нет активной доставки!")
        return

    now = int(time.time())
    if act["finish_time"] > now:
        bot.answer_callback_query(call.id, "⏳ Груз еще в пути!")
        return

    ch_lvl = player.get("supply_channel_lvl", 1)
    loot = roll_supply_item(ch_lvl, player)
    player["active_delivery"] = None

    player.setdefault("stash", []).append({
        "uid": f"sup_{now}_{random.randint(100,999)}",
        "item_id": loot["id"],
        "equipped_to": None
    })
    save_db(db)

    r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(loot.get("rarity"), "⬜")
    bot.answer_callback_query(
        call.id,
        f"🎉 Груз получен!\n{r_b} {loot['name']}\n🏷️ Стоимость: {fmt_rub(loot.get('price', 0))}",
        show_alert=True
    )
    handle_menu_supply(call.message.chat.id, call.message.message_id, player)

def handle_upgrade_supply_channel(call, player, db):
    ch_lvl = player.get("supply_channel_lvl", 1)
    cost = SUPPLY_CHANNEL_COSTS.get(ch_lvl)
    if not cost or ch_lvl >= 10:
        bot.answer_callback_query(call.id, "❌ Канал поставок уже максимального уровня!", show_alert=True)
        return
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    player["supply_channel_lvl"] = ch_lvl + 1
    save_db(db)
    bot.answer_callback_query(call.id, f"🎉 Канал поставок улучшен до {ch_lvl + 1} уровня!")
    handle_menu_supply(call.message.chat.id, call.message.message_id, player)

# ----------------- SECTION 7: SOLO RAIDS -----------------
def handle_menu_raids(chat_id, msg_id, player):
    pow_val, arm_val = calculate_squad_power(player)

    txt = (
        f"<b>⚔️ РЕЙДЫ В ЗОНУ ТАРКОВА (БЕЗ КУЛДАУНА)</b>\n"
        f"Огневая мощь вашего отряда: <b>{pow_val}</b> | Броня: <b>{arm_val}</b>\n"
        f"────────────────────────\n"
        f"Шанс выживания зависит от силы бойцов и надетого снаряжения (оружие, броня, шлемы, наушники).\n"
        f"⚡ Одиночные рейды доступны мгновенно и без таймера ожидания!\n\n"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("👥 Кооперативные рейды (до 6 бойцов)", callback_data="menu_coop_raids")
    )

    for loc_key, loc in RAID_LOCATIONS.items():
        ratio = ((pow_val * 1.2) + (arm_val * 0.8)) / max(1, loc["difficulty"])
        win_ch = min(95, max(15, int(ratio / (ratio + 1.0) * 1.3 * 100)))
        txt += f"• <b>{loc['name']}</b>: Шанс успеха ~<b>{win_ch}%</b>\n"
        markup.add(types.InlineKeyboardButton(f"🚀 В рейд: {loc['name']} (~{win_ch}%)", callback_data=f"start_solo_raid_{loc_key}"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_start_solo_raid(call, player, db, loc_key):
    now = int(time.time())
    pow_val, arm_val = calculate_squad_power(player)
    res = simulate_raid(loc_key, player, pow_val, arm_val)

    player["last_raid_time"] = now
    player.setdefault("stats", {})["raids_count"] = player.get("stats", {}).get("raids_count", 0) + 1

    txt = (
        f"<b>⚔️ РЕЙД: {res['location']}</b>\n"
        f"Расчетный шанс на выживание был: <b>{res['win_chance']}%</b>\n"
        f"────────────────────────\n"
    )

    if res["success"]:
        txt += f"🎉 <b>УСПЕШНАЯ ЭВАКУАЦИЯ!</b>\nОтряд вынес из зоны: +<b>{fmt_rub(res['rubles'])}</b>\n\n<b>Найденный хабар:</b>\n"
        player["money"] = player.get("money", 0) + res["rubles"]
        for itm in res["items"]:
            r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
            txt += f"{r_b} {itm['name']} ({fmt_rub(itm.get('price', 0))})\n"
            player.setdefault("stash", []).append({
                "uid": f"raid_{now}_{random.randint(1000,9999)}",
                "item_id": itm["id"],
                "equipped_to": None
            })
    else:
        txt += (
            "💀 <b>ОТРЯД ПОГИБ В БОЮ!</b>\n"
            "Вы попали в засаду рейдеров.\n"
        )
        if has_boss_set_bonus(player, "tagilla"):
            txt += "🛡️ <b>СЕТ ТАГИЛЛЫ:</b> Благодаря несокрушимой броне Тагиллы всё снаряжение отряда спасено (0% потерь)!\n"
        else:
            txt += "Все ранены, экипировка бойцов утеряна!\n"
            stash = player.get("stash", [])
            for f in player.get("squad", []):
                for slot_key in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
                    uid = f.get(slot_key)
                    if uid:
                        item_entry = next((i for i in stash if i.get("uid") == uid), None)
                        if item_entry:
                            stash.remove(item_entry)
                        f[slot_key] = None

    save_db(db)
    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🔙 К Меню Рейдов", callback_data="menu_raids")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)

# ----------------- SECTION 8: DARKZONE (PVP) -----------------
def handle_menu_darkzone(chat_id, msg_id, player, db):
    pow_val, arm_val = calculate_squad_power(player)
    txt = (
        "<b>💀 ДАРКЗОН — ЗОНА ТОТАЛЬНОГО PVP</b>\n"
        "────────────────────────\n"
        f"Ваша боевая мощь: <b>{pow_val}</b> | Броня: <b>{arm_val}</b>\n\n"
        "В Даркзоне нет правил. Победитель забирает крупный денежный куш и трофеи!\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🤖 Быстрая дуэль с ЧВК-ботом", callback_data="darkzone_search_bot"),
        types.InlineKeyboardButton("⚔️ Бросить вызов в чат (Ставка: 100 000 ₽)", callback_data="darkzone_create_pvp"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_darkzone_bot_duel(call, player, db):
    pow_val, arm_val = calculate_squad_power(player)
    bot_power = random.randint(max(20, pow_val - 25), pow_val + 35)

    player_score = pow_val * random.uniform(0.8, 1.25)
    if has_buff(player, "pvp_bonus"):
        player_score *= 1.15
    if has_boss_set_bonus(player, "killa"):
        player_score *= 1.75
    bot_score = bot_power * random.uniform(0.8, 1.25)

    txt = (
        "<b>💀 ДАРКЗОН: БОЙ С ВРАЖЕСКИМ ЧВК</b>\n"
        f"Ваша сила: <b>{pow_val}</b> vs Сила врага: <b>{bot_power}</b>\n"
        "────────────────────────\n"
    )

    now = int(time.time())
    if player_score >= bot_score:
        reward = random.randint(45000, 110000)
        loot = roll_strict_tarkov_loot(player)
        player["money"] = player.get("money", 0) + reward
        player.setdefault("stash", []).append({
            "uid": f"dz_{now}_{random.randint(100,999)}",
            "item_id": loot["id"],
            "equipped_to": None
        })
        player.setdefault("stats", {})["pvp_wins"] = player.get("stats", {}).get("pvp_wins", 0) + 1
        txt += (
            f"🏆 <b>ПОБЕДА! Вражеский ЧВК ликвидирован!</b>\n"
            f"💰 Забрано наличными: +<b>{fmt_rub(reward)}</b>\n"
            f"🎁 Снятый трофей: <b>{loot['name']}</b>\n"
        )
    else:
        loss_rub = min(player.get("money", 0), random.randint(20000, 50000))
        player["money"] = max(0, player.get("money", 0) - loss_rub)
        player.setdefault("stats", {})["pvp_losses"] = player.get("stats", {}).get("pvp_losses", 0) + 1
        txt += (
            "💀 <b>ПОРАЖЕНИЕ!</b> Враг оказался быстрее и точнее.\n"
            f"Вам удалось спастись бегством, потеряв: -<b>{fmt_rub(loss_rub)}</b>\n"
        )

    save_db(db)
    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🔙 К Даркзону", callback_data="menu_darkzone")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)

def handle_darkzone_create_pvp(call, player, db):
    stake = 100000
    if player.get("money", 0) < stake:
        bot.answer_callback_query(call.id, f"❌ Для ставки требуется {fmt_rub(stake)} наличными!", show_alert=True)
        return

    duel_id = f"duel_{int(time.time())}_{random.randint(100,999)}"
    db.setdefault("active_duels", {})[duel_id] = {
        "creator_id": player["user_id"],
        "creator_name": player.get("username", "PMC"),
        "stake": stake,
        "created_at": int(time.time())
    }
    save_db(db)

    bot.answer_callback_query(call.id, "⚔️ Вызов на PvP опубликован в чате!")
    bot.send_message(
        call.message.chat.id,
        f"⚔️ <b>ОПЕРАТОР @{player.get('username')} БРОСАЕТ ВЫЗОВ В ДАРКЗОНЕ!</b>\n"
        f"Ставка поединка: <b>{fmt_rub(stake)}</b> (Победитель забирает {fmt_rub(stake * 2)})\n"
        f"Нажмите кнопку ниже, чтобы принять смертельный бой:",
        reply_markup=types.InlineKeyboardMarkup().add(
            types.InlineKeyboardButton("💀 ПРИНЯТЬ БОЙ (100 000 ₽)", callback_data=f"accept_pvp_{duel_id}")
        )
    )

def handle_darkzone_accept_pvp(call, player, db, duel_id):
    duel = db.get("active_duels", {}).get(duel_id)
    if not duel:
        bot.answer_callback_query(call.id, "❌ Вызов уже недействителен или бой состоялся!", show_alert=True)
        return

    if player["user_id"] == duel["creator_id"]:
        bot.answer_callback_query(call.id, "❌ Вы не можете сражаться сами с собой!", show_alert=True)
        return

    stake = duel["stake"]
    if player.get("money", 0) < stake:
        bot.answer_callback_query(call.id, f"❌ У вас недостаточно денег для ставки {fmt_rub(stake)}!", show_alert=True)
        return

    creator_id = str(duel["creator_id"])
    creator = db["users"].get(creator_id)
    if not creator or creator.get("money", 0) < stake:
        bot.answer_callback_query(call.id, "❌ У создателя дуэли недостаточно денег!", show_alert=True)
        db["active_duels"].pop(duel_id, None)
        save_db(db)
        return

    # Calculate combat
    c_pow, _ = calculate_squad_power(creator)
    p_pow, _ = calculate_squad_power(player)

    c_mult = random.uniform(0.85, 1.25)
    p_mult = random.uniform(0.85, 1.25)

    if has_boss_set_bonus(creator, "shturman"):
        c_mult *= 1.25
    if has_boss_set_bonus(player, "shturman"):
        p_mult *= 1.25

    if has_boss_set_bonus(creator, "tagilla"):
        c_mult = max(1.05, c_mult)
    if has_boss_set_bonus(player, "tagilla"):
        p_mult = max(1.05, p_mult)

    if has_buff(creator, "pvp_bonus"):
        c_mult *= 1.15
    if has_buff(player, "pvp_bonus"):
        p_mult *= 1.15

    c_score = c_pow * c_mult
    p_score = p_pow * p_mult

    if c_score >= p_score:
        winner = creator
        loser = player
        w_score = int(c_score)
        l_score = int(p_score)
    else:
        winner = player
        loser = creator
        w_score = int(p_score)
        l_score = int(c_score)

    loser["money"] = max(0, loser.get("money", 0) - stake)
    winner["money"] = winner.get("money", 0) + stake
    winner.setdefault("stats", {})["pvp_wins"] = winner.get("stats", {}).get("pvp_wins", 0) + 1
    loser.setdefault("stats", {})["pvp_losses"] = loser.get("stats", {}).get("pvp_losses", 0) + 1

    # FULL LOOT: Strip all equipment from loser's fighters and wipe loser squad!
    loser_squad = loser.get("squad", [])
    loser_stash = loser.get("stash", [])
    winner_stash = winner.setdefault("stash", [])

    equipped_uids = set()
    for f in loser_squad:
        for slot in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
            u = f.get(slot)
            if u:
                equipped_uids.add(u)

    looted_items = []
    burned_items = []

    loser_remaining_stash = []
    for itm in loser_stash:
        if itm.get("uid") in equipped_uids:
            item_id = itm.get("item_id")
            info = ITEMS_BY_ID.get(item_id, {})
            if can_store_item(winner, item_id):
                itm["equipped_to"] = None
                winner_stash.append(itm)
                looted_items.append(info)
            else:
                burned_items.append(info)
        else:
            loser_remaining_stash.append(itm)

    loser["stash"] = loser_remaining_stash
    loser["squad"] = []  # 100% squad wipe in Full Loot Darkzone

    db["active_duels"].pop(duel_id, None)
    save_db(db)

    loot_txt = ""
    if looted_items:
        loot_txt += "\n<b>🎒 Захваченное снаряжение проигравшего (FULL LOOT):</b>\n"
        for itm in looted_items:
            r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
            loot_txt += f"• {r_b} {itm.get('name')} ({fmt_rub(itm.get('price', 0))})\n"
    if burned_items:
        loot_txt += f"\n⚠️ <i>{len(burned_items)} предметов уничтожено из-за переполнения складов победителя!</i>\n"

    bot.send_message(
        call.message.chat.id,
        f"☠️ <b>КРОВАВАЯ ДУЭЛЬ В ДАРКЗОНЕ (FULL LOOT)!</b>\n"
        f"────────────────────────\n"
        f"🏆 Победитель: <b>@{winner.get('username')}</b> (Боевой счет: {w_score})\n"
        f"💀 Проигравший: <b>@{loser.get('username')}</b> (Боевой счет: {l_score})\n\n"
        f"💰 Победитель забрал ставку: +<b>{fmt_rub(stake)}</b>\n"
        f"⚠️ Отряд @{loser.get('username')} полностью ликвидирован (бойцы погибли)!\n"
        f"{loot_txt}"
    )

# ----------------- SECTION 9: CONTAINERS -----------------
def handle_menu_containers(chat_id, msg_id, player):
    txt = (
        "<b>🧰 ВОЕННЫЕ КЕЙСЫ И КОНТЕЙНЕРЫ</b>\n"
        "────────────────────────\n"
        "Вскрытие контейнеров сопряжено с риском. Лут может не окупить цену покупки!\n"
        "• Шанс выпадения Epic предметов: <b>3%</b>\n"
        "• Шанс выпадения Legendary предметов: <b>менее 0.5%</b>\n\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    for c_id, c in CONTAINER_DEFINITIONS.items():
        txt += f"• <b>{c['name']}</b> — <b>{fmt_rub(c['price'])}</b>\n<i>{c['desc']}</i>\n\n"
        markup.add(types.InlineKeyboardButton(f"Вскрыть {c['badge']} ({fmt_rub(c['price'])})", callback_data=f"open_container_{c_id}"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_open_container(call, player, db, c_id):
    c_def = CONTAINER_DEFINITIONS.get(c_id)
    if not c_def:
        return
    cost = c_def["price"]
    if player.get("money", 0) < cost:
        bot.answer_callback_query(call.id, f"❌ Недостаточно рублей! Требуется {fmt_rub(cost)}", show_alert=True)
        return

    player["money"] -= cost
    res = generate_container_loot(c_id, player)
    now = int(time.time())

    batch_uids = []
    total_fullprice = 0

    for itm in res["items"]:
        uid = f"box_{now}_{random.randint(1000,9999)}"
        batch_uids.append(uid)
        total_fullprice += itm.get("price", 0)
        player.setdefault("stash", []).append({
            "uid": uid,
            "item_id": itm["id"],
            "equipped_to": None
        })

    player["last_opened_box"] = {
        "uids": batch_uids,
        "total_fullprice": total_fullprice,
        "timestamp": now,
        "container_name": c_def["name"]
    }
    save_db(db)

    out_msg = "📉 НЕОКУП" if res["delta"] < 0 else "📈 ОКУП!"
    txt = (
        f"<b>{c_def['badge']} ВСКРЫТИЕ: {c_def['name']}</b>\n"
        f"Затрачено: <b>{fmt_rub(cost)}</b>\n"
        f"Суммарная ценность лута: <b>{fmt_rub(res['total_value'])}</b> ({out_msg})\n"
        f"────────────────────────\n"
        f"<b>Выпавшие предметы:</b>\n"
    )
    for itm in res["items"]:
        r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        txt += f"{r_b} <b>{itm['name']}</b> — {fmt_rub(itm.get('price', 0))}\n"

    if res.get("relic_won"):
        txt += (
            f"\n🏆 <b>СВЕРХРЕДКИЙ ДЖЕКПОТ (Шанс 1%)!</b>\n"
            f"Вам выпала Реликвия Босса: <b>{res['relic_won']['name']}</b> (+10 000 000 ₽)!\n"
            f"<i>💡 Напоминание: Сет-бонус 5/5 активируется в Профиле только при сборе всех 5 реликвий одного босса!</i>\n"
        )

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(f"💰 Продать всё за фуллпрайс (+{fmt_rub(total_fullprice)})", callback_data="container_sell_all"),
        types.InlineKeyboardButton("🔙 К Кейсам", callback_data="menu_containers"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)

def handle_container_sell_all(call, player, db):
    last_box = player.get("last_opened_box")
    if not last_box or not last_box.get("uids"):
        bot.answer_callback_query(call.id, "❌ Нет предметов для продажи за фуллпрайс или они уже проданы!", show_alert=True)
        return

    uids_to_sell = set(last_box.get("uids", []))
    stash = player.get("stash", [])
    sold_items = []
    gained_rubles = 0

    new_stash = []
    for itm in stash:
        if itm.get("uid") in uids_to_sell and not itm.get("equipped_to"):
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            base_p = info.get("price", 0)
            gained_rubles += base_p
            sold_items.append(info)
        else:
            new_stash.append(itm)

    player["stash"] = new_stash
    player["money"] = player.get("money", 0) + gained_rubles
    player.pop("last_opened_box", None)
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Продано {len(sold_items)} предметов за {fmt_rub(gained_rubles)} (100% стоимости)!", show_alert=True)

    txt = (
        f"<b>💰 МГНОВЕННАЯ РАСПРОДАЖА КЕЙСА ЗА ФУЛЛПРАЙС</b>\n"
        f"────────────────────────\n"
        f"Все {len(sold_items)} предметов из последнего вскрытия были сданы по 100% каталожной стоимости без комиссии!\n\n"
        f"💵 Начислено оператору: +<b>{fmt_rub(gained_rubles)}</b>\n"
        f"Текущий баланс: <b>{fmt_rub(player.get('money', 0))}</b>\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=1).add(
        types.InlineKeyboardButton("🧰 Открыть еще кейс", callback_data="menu_containers"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup)

# ----------------- SECTION 10: AIRDROP -----------------
def handle_menu_airdrop(chat_id, msg_id, player, db):
    airdrop = db.get("airdrop", {})
    now = int(time.time())
    last_s = airdrop.get("last_spawn", 0)

    txt = "<b>📦 ВОЕННЫЙ ЭИРДРОП СЕКТОРА ТАРКОВА</b>\n────────────────────────\n"
    markup = types.InlineKeyboardMarkup()

    if airdrop.get("active"):
        txt += "🚨 <b>ВНИМАНИЕ! САМОЛЕТ ИЛ-76 СБРОСИЛ КОНТЕЙНЕР НА ПАРАШЮТЕ!</b>\nКто первым успеет нажать кнопку — заберет весь армейский лут и реликвии боссов!\n"
        markup.add(types.InlineKeyboardButton("📦 ЗАБРАТЬ ЭИРДРОП", callback_data="loot_airdrop_box"))
    else:
        txt += "Над Норвинской областью периодически пролетает военно-транспортный самолет Ил-76.\n"
        if is_admin(player["user_id"], player.get("username")):
            markup.add(types.InlineKeyboardButton("✈️ Вызвать Ил-76 (Admin @reventus)", callback_data="admin_action_airdrop"))

    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_loot_airdrop_box(call, player, db):
    # Always reload fresh database state to prevent multi-click or race condition exploits
    db = load_db()
    player = db["users"].get(str(call.from_user.id))
    if not player:
        player, _ = get_player(call.from_user.id, call.from_user.username)
        db["users"][str(call.from_user.id)] = player

    airdrop = db.get("airdrop", {})
    if not airdrop.get("active"):
        bot.answer_callback_query(call.id, "❌ Эирдроп уже забран другим игроком!", show_alert=True)
        try:
            bot.edit_message_text("📦 <i>Ящик военного эирдропа уже пуст и обыскан другим выжившим!</i>", call.message.chat.id, call.message.message_id)
        except Exception:
            pass
        return

    # Deactivate immediately
    airdrop["active"] = False
    now = int(time.time())
    airdrop["looted_by"] = player.get("username") or str(player["user_id"])
    airdrop["looted_at"] = now

    loot = generate_airdrop_loot()

    player["money"] = player.get("money", 0) + loot["rubles"]
    player["btc"] = round(player.get("btc", 0.0) + loot["btc"], 3)
    player.setdefault("stats", {})["airdrop_looted"] = player.get("stats", {}).get("airdrop_looted", 0) + 1

    for itm in loot["items"]:
        player.setdefault("stash", []).append({
            "uid": f"air_{now}_{random.randint(100,999)}",
            "item_id": itm["id"],
            "equipped_to": None
        })
    save_db(db)

    # Edit caller message so others see it's looted
    try:
        looter_tag = f"@{player.get('username')}" if player.get("username") else f"Боец #{player['user_id']}"
        bot.edit_message_text(
            f"📦 <b>ВОЕННЫЙ ЭИРДРОП ОБЫСКАН!</b>\n"
            f"Счастливчик {looter_tag} первым добрался до контейнера и забрал военный груз!",
            call.message.chat.id,
            call.message.message_id
        )
    except Exception:
        pass

    txt = (
        f"🎉 <b>ВЫ ПЕРВЫМ ДОБРАЛИСЬ ДО ЭИРДРОПА!</b>\n"
        f"💰 Наличные: +<b>{fmt_rub(loot['rubles'])}</b>\n"
        f"🪙 Биткоины: +<b>{loot['btc']} BTC</b>\n\n"
        f"<b>Захваченное армейское снаряжение:</b>\n"
    )
    for itm in loot["items"]:
        r_b = {"legendary": "🟨", "epic": "🟪", "rare": "🟦", "common": "⬜"}.get(itm.get("rarity"), "⬜")
        price_str = f" ({fmt_rub(itm.get('price', 0))})" if itm.get("price") else ""
        txt += f"{r_b} <b>{itm['name']}</b>{price_str}\n"

    markup = types.InlineKeyboardMarkup(row_width=1).add(
        types.InlineKeyboardButton("📦 Открыть Схрон", callback_data="menu_stash"),
        types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu")
    )
    bot.send_message(call.message.chat.id, txt, reply_markup=markup)
    bot.answer_callback_query(call.id, "✅ Эирдроп успешно залутан!")

# ----------------- SECTION 11: ADMIN PANEL (@reventus) -----------------
def handle_menu_admin(chat_id, msg_id, player):
    txt = (
        "<b>💀 ПАНЕЛЬ УПРАВЛЕНИЯ РАЗРАБОТЧИКА: @reventus</b>\n"
        "Ранг: <b>💀 [ADMIN] 💰 REVENANT GD 💰 💀</b>\n"
        "────────────────────────\n"
        "Быстрые отладочные функции и административные команды:\n"
    )
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton("💰 +1 000 000 ₽", callback_data="admin_action_give1m"),
        types.InlineKeyboardButton("💰 +10 000 000 ₽", callback_data="admin_action_give10m")
    )
    markup.add(
        types.InlineKeyboardButton("🪙 +10 BTC", callback_data="admin_action_give10btc"),
        types.InlineKeyboardButton("🔑 3x Ключ-карты Лабы", callback_data="admin_action_givekeycards")
    )
    markup.add(
        types.InlineKeyboardButton("🪖 Топ-Экипировка", callback_data="admin_action_topgear"),
        types.InlineKeyboardButton("🔩 Редкие Компоненты", callback_data="admin_action_components")
    )
    markup.add(
        types.InlineKeyboardButton("🏚️ Макс. Убежище (Ур. 10)", callback_data="admin_action_maxhideout"),
        types.InlineKeyboardButton("🏢 Макс. Склады (Ур. 10)", callback_data="admin_action_maxwarehouses")
    )
    markup.add(
        types.InlineKeyboardButton("⏳ Сбросить Кулдауны", callback_data="admin_action_resetcds"),
        types.InlineKeyboardButton("📉 Сменить Кризис", callback_data="admin_action_newcrisis")
    )
    markup.add(
        types.InlineKeyboardButton("✈️ Сбросить Эирдроп", callback_data="admin_action_airdrop"),
        types.InlineKeyboardButton("🔄 Сбросить профиль", callback_data="admin_action_reset")
    )
    markup.add(types.InlineKeyboardButton("🔙 Главное Меню", callback_data="main_menu"))
    bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)

def handle_admin_action(call, player, db, act):
    now = int(time.time())
    if act == "give1m":
        player["money"] = player.get("money", 0) + 1000000
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Начислено +1 000 000 ₽")
    elif act == "give10m":
        player["money"] = player.get("money", 0) + 10000000
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Начислено +10 000 000 ₽")
    elif act == "give10btc":
        player["btc"] = round(player.get("btc", 0.0) + 10.0, 4)
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Начислено +10 BTC")
    elif act == "givekeycards":
        for i in range(3):
            player.setdefault("stash", []).append({
                "uid": f"adm_kc_{now}_{i}",
                "item_id": "terragroup_red_keycard_legendary",
                "equipped_to": None
            })
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Выдано 3x Красных Ключ-карты Лаборатории!")
    elif act == "topgear":
        items = ["mk18_mjolnir_legendary", "slick_plate_carrier_legendary", "vulcan_5_helmet_legendary", "headset_opscore_amp_epic"]
        for idx, tid in enumerate(items):
            player.setdefault("stash", []).append({"uid": f"adm_{now}_{idx}", "item_id": tid, "equipped_to": None})
        save_db(db)
        bot.answer_callback_query(call.id, "✅ В схрон добавлены Mk-18, Slick, Вулкан-5 и Ops-Core AMP!")
    elif act == "components":
        for i in range(5):
            player.setdefault("stash", []).append({"uid": f"adm_cmp_{now}_{i}", "item_id": "military_board_epic", "equipped_to": None})
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Добавлены военные платы!")
    elif act == "airdrop":
        db.setdefault("airdrop", {})["active"] = True
        db["airdrop"]["last_spawn"] = now
        save_db(db)
        bot.answer_callback_query(call.id, "🚨 Эирдроп активирован в зоне!")
        bot.send_message(
            call.message.chat.id,
            "✈️ <b>ВНИМАНИЕ! ИЛ-76 СБРОСИЛ ВОЕННЫЙ ЭИРДРОП!</b>\n"
            "Контейнер опустился на парашюте! Кто первый нажмет кнопку — заберет лут!",
            reply_markup=types.InlineKeyboardMarkup().add(
                types.InlineKeyboardButton("📦 ОБЫСКАТЬ ЯЩИК", callback_data="loot_airdrop_box")
            )
        )
    elif act == "maxhideout":
        player["hideout_lvl"] = 10
        for m in player.get("modules", {}):
            player["modules"][m] = 10
        for b in player.get("businesses", {}):
            player["businesses"][b] = 10
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Убежище, модули и бизнесы прокачаны до 10 уровня!")
    elif act == "maxwarehouses":
        wh = player.setdefault("warehouses", {})
        for cat in BASE_WAREHOUSE_CAPS:
            wh[cat] = 10
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Все 4 склада прокачаны до 10 уровня!")
    elif act == "resetcds":
        player["last_raid_time"] = 0
        player["coop_cooldown_until"] = 0
        save_db(db)
        bot.answer_callback_query(call.id, "✅ Все кулдауны и травмы отряда сброшены!")
    elif act == "newcrisis":
        db["economic_crisis"]["expires_at"] = 0
        check_and_update_economic_crisis(db)
        save_db(db)
        bot.answer_callback_query(call.id, "📉 Новый экономический кризис сгенерирован!")
    elif act == "reset":
        db["users"][str(player["user_id"])] = create_new_player(player["user_id"], player.get("username"), "Revenant")
        save_db(db)
        bot.answer_callback_query(call.id, "🔄 Профиль сброшен к начальному состоянию!")

    handle_menu_admin(call.message.chat.id, call.message.message_id, db["users"][str(player["user_id"])])

# Admin Text Commands
@bot.message_handler(commands=['airdrop', 'spawn_airdrop'])
def cmd_airdrop(message):
    if not is_admin(message.from_user.id, message.from_user.username):
        bot.reply_to(message, "❌ Вызывать самолет Ил-76 с эирдропом может только администратор @reventus!")
        return
    db = load_db()
    db.setdefault("airdrop", {})["active"] = True
    db["airdrop"]["last_spawn"] = int(time.time())
    save_db(db)
    bot.send_message(
        message.chat.id,
        "✈️ <b>ВОЕННЫЙ ЭИРДРОП СБРОШЕН В СЕКТОРЕ!</b>\n"
        "Нажмите кнопку, чтобы забрать армейский лут!",
        reply_markup=types.InlineKeyboardMarkup().add(
            types.InlineKeyboardButton("📦 ОБЫСКАТЬ ЯЩИК", callback_data="loot_airdrop_box")
        )
    )

def find_target_player(db, target_str, caller_id):
    if not target_str:
        return db["users"].get(str(caller_id))
    clean = target_str.lstrip("@").lower()
    if clean in db["users"]:
        return db["users"][clean]
    for u in db["users"].values():
        if (u.get("username") or "").lower().lstrip("@") == clean:
            return u
    return None

@bot.message_handler(commands=['give_money', 'give_item', 'set_module', 'set_level', 'reset_player'])
def cmd_admin_commands(message):
    if not is_admin(message.from_user.id, message.from_user.username):
        return
    parts = message.text.split()
    cmd = parts[0].lower()
    db = load_db()
    caller_id = message.from_user.id

    try:
        if cmd == "/give_money":
            if len(parts) >= 2:
                amount = int(parts[1])
                target_arg = parts[2] if len(parts) >= 3 else None
                u = find_target_player(db, target_arg, caller_id)
                if u:
                    u["money"] = u.get("money", 0) + amount
                    save_db(db)
                    bot.reply_to(message, f"✅ Выдано {fmt_rub(amount)} игроку @{u.get('username')}")
                else:
                    bot.reply_to(message, "❌ Игрок не найден")

        elif cmd == "/give_item":
            if len(parts) >= 2:
                item_id = parts[1]
                target_arg = parts[2] if len(parts) >= 3 else None
                u = find_target_player(db, target_arg, caller_id)
                if u and item_id in ITEMS_BY_ID:
                    u.setdefault("stash", []).append({
                        "uid": f"cmd_{int(time.time())}_{random.randint(100,999)}",
                        "item_id": item_id,
                        "equipped_to": None
                    })
                    save_db(db)
                    bot.reply_to(message, f"✅ Предмет {item_id} добавлен игроку @{u.get('username')}")
                else:
                    bot.reply_to(message, "❌ Игрок или предмет не найден")

        elif cmd == "/set_module":
            if len(parts) >= 3:
                mod_key = parts[1]
                lvl = int(parts[2])
                target_arg = parts[3] if len(parts) >= 4 else None
                u = find_target_player(db, target_arg, caller_id)
                if u:
                    u.setdefault("modules", {})[mod_key] = max(0, min(10, lvl))
                    save_db(db)
                    bot.reply_to(message, f"✅ Модуль {mod_key} игрока @{u.get('username')} установлен на {lvl}")

        elif cmd == "/set_level":
            if len(parts) >= 2:
                lvl = int(parts[1])
                target_arg = parts[2] if len(parts) >= 3 else None
                u = find_target_player(db, target_arg, caller_id)
                if u:
                    u["hideout_lvl"] = max(1, min(10, lvl))
                    save_db(db)
                    bot.reply_to(message, f"✅ Уровень Убежища игрока @{u.get('username')} установлен на {lvl}")

        elif cmd == "/reset_player":
            if len(parts) >= 2:
                target_arg = parts[1]
                u = find_target_player(db, target_arg, caller_id)
                if u:
                    uid = u["user_id"]
                    uname = u.get("username")
                    db["users"][str(uid)] = create_new_player(uid, uname, "Revenant" if (uname or "").lower() in ["reventus", "revenuts"] else "Viper")
                    save_db(db)
                    bot.reply_to(message, f"✅ Профиль игрока @{uname} сброшен")

    except Exception as e:
        bot.reply_to(message, f"❌ Ошибка выполнения: {e}")

if __name__ == "__main__":
    print("🚀 Starting Escape from Tarkov MMO Telegram Bot...")
    try:
        bot.infinity_polling(timeout=20, long_polling_timeout=20)
    except Exception as e:
        print(f"Bot crashed: {e}")
