# -*- coding: utf-8 -*-
"""
Full-scale Tarkov Co-op Event Builder
Generates 15 authentic, atmospheric Acts for every location + 3 Evacuation acts.
Each Act = 1 consequential choice.
Risk levels:
  'safe': 0 damage guaranteed. Rewards tactical thinking, stealth, lockpicking, scouting.
  'low': 20% chance of 6-12 dmg (mitigated by armor/dodge).
  'medium': 45% chance of 14-22 dmg (mitigated by armor/dodge).
  'high': 70% chance of 24-36 dmg, but grants high rubles (+75%..+100%) or rare loot.
"""
import json

def make_opt(text, strategy, risk, loot_mult=1.0, dmg_deal_mult=1.0, consequence=""):
    return {
        "text": text,
        "strategy": strategy,
        "risk": risk,
        "loot_mult": loot_mult,
        "dmg_deal_mult": dmg_deal_mult,
        "consequence": consequence
    }

print("Loaded make_opt helper")
