# -*- coding: utf-8 -*-
import json
import os

# We will write the full python generator
print("Starting creation of full coop events generator...")
