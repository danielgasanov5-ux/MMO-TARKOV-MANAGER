# -*- coding: utf-8 -*-
import json
import os

print("Writing location encounters generator...")
