# -*- coding: utf-8 -*-
"""
Full Game Simulation & Deep Audit Script
Testing the 5 requested core mechanics:
1. Signature PMC Skills (Навыки сигнатурных ЧВК)
2. Mythic Reserve Key (Мифический ключ от Росрезерва)
3. 2.5 Billion Business (Бизнес за 2.5 млрд - Подземная шахта Д-2)
4. Signature PMC SpecOps (Спецоперации сигнатурного ЧВК)
5. Prestige System (Система Престижа)
"""
import sys
import os
import time
import random
import unittest
from unittest.mock import MagicMock, patch

sys.path.insert(0, "/tmp/game")

from signature_skills_system import (
    SIGNATURE_PMC_TREES,
    get_signature_pmc_progress,
    award_signature_pmc_points,
    get_signature_skill_bonus,
    handle_upgrade_signature_skill,
    handle_reset_signature_skills
)
from mythic_system import (
    MYTHIC_ITEMS,
    MYTHIC_ARMORS,
    has_mythic_item,
    add_mythic_item_to_player,
    can_claim_reserve_armor,
    claim_reserve_armor_supply,
    can_send_reserve_contraband_truck,
    send_reserve_contraband_truck
)
from tarkov_engine import (
    SPECIAL_BUSINESSES,
    get_special_businesses_income,
    get_mining_hourly_btc,
    add_player_rubles,
    ITEMS_BY_ID
)
from signature_raid_system import (
    can_launch_signature_raid,
    handle_start_signature_raid,
    get_elite_loot_pool,
    SIGNATURE_RAID_REQUIRED_LEVEL
)
from prestige import (
    PRESTIGE_TIERS,
    get_player_prestige,
    check_prestige_requirements,
    execute_prestige_reset,
    get_goons_token_drop_chance,
    get_reserve_key_drop_chance
)

def run_simulation():
    findings = []
    print("=" * 70)
    print("🚀 НАЧАЛО ГЛОБАЛЬНОЙ СИМУЛЯЦИИ И АУДИТА 5 МЕХАНИК")
    print("=" * 70)

    # -------------------------------------------------------------
    # 1. СИМУЛЯЦИЯ: НАВЫКИ СИГНАТУРНЫХ ЧВК
    # -------------------------------------------------------------
    print("\n[1/5] ТЕСТИРОВАНИЕ: Навыки сигнатурных ЧВК (11 операторов, 99 навыков)...")
    player = {
        "user_id": 777001,
        "username": "tester_pmc",
        "level": 10,
        "pmc_signature": "Viper",
        "signature_pmc_skills": {}
    }

    # Тест стартовых очков и начисления
    prog_viper = get_signature_pmc_progress(player, "Viper")
    if prog_viper.get("points") != 5:
        findings.append({
            "category": "Навыки сигнатурных ЧВК",
            "severity": "Низкая",
            "desc": f"Стартовые очки Viper инициализируются как {prog_viper.get('points')} вместо 5."
        })

    award_signature_pmc_points(player, "Viper", 3, "Test SpecOp")
    if prog_viper.get("points") != 8:
        findings.append({
            "category": "Навыки сигнатурных ЧВК",
            "severity": "Средняя",
            "desc": f"Начисление очков талантов работает некорректно: {prog_viper.get('points')} != 8."
        })

    # Тест прокачки всех веток и сброса
    sim_call = MagicMock()
    sim_call.id = "call_1"
    sim_call.data = "sig_up_Viper_nitro_sprint"
    sim_call.message.chat.id = 123
    sim_call.message.message_id = 456

    mock_bot = MagicMock()
    mock_db = {"users": {str(player["user_id"]): player}}

    # Качаем 3 уровня навыка
    for _ in range(3):
        handle_upgrade_signature_skill(sim_call, player, mock_db, mock_bot)

    if prog_viper["skills"].get("nitro_sprint") != 3:
        findings.append({
            "category": "Навыки сигнатурных ЧВК",
            "severity": "Высокая",
            "desc": "Не удалось прокачать навык nitro_sprint до 3 уровня."
        })

    cd_reduc = get_signature_skill_bonus(player, "Viper", "sig_cooldown_reduction")
    if cd_reduc != 3 * 1800:
        findings.append({
            "category": "Навыки сигнатурных ЧВК",
            "severity": "Высокая",
            "desc": f"Бонус кулдауна спецоперации Viper рассчитан неверно: {cd_reduc} != {3 * 1800}"
        })

    # Тест сброса навыков
    reset_call = MagicMock()
    reset_call.id = "call_reset"
    reset_call.data = "sig_reset_Viper"
    reset_call.message.chat.id = 123
    reset_call.message.message_id = 456
    handle_reset_signature_skills(reset_call, player, mock_db, mock_bot)

    if prog_viper["skills"] != {} or prog_viper["points"] != 8:
        findings.append({
            "category": "Навыки сигнатурных ЧВК",
            "severity": "Высокая",
            "desc": f"Сброс навыков ЧВК не вернул все очки: points={prog_viper['points']} (ожидалось 8), skills={prog_viper['skills']}"
        })

    # Проверка "мертвых" bonus_type
    all_bonus_types = set()
    for pmc_tree in SIGNATURE_PMC_TREES.values():
        for b_data in pmc_tree.get("branches", {}).values():
            for s_data in b_data.get("skills", {}).values():
                all_bonus_types.add(s_data.get("bonus_type"))

    # Сканируем код игры на вызовы get_signature_skill_bonus
    import subprocess, re
    cmd = "grep -rn 'get_signature_skill_bonus' /tmp/game"
    grep_out = subprocess.check_output(cmd, shell=True, text=True)
    queried_bonuses = set(re.findall(r"get_signature_skill_bonus\([^)]*[\"\'](\w+)[\"\']", grep_out))

    unhooked_types = all_bonus_types - queried_bonuses
    if unhooked_types:
        findings.append({
            "category": "Навыки сигнатурных ЧВК",
            "severity": "Высокая",
            "desc": (
                f"В древе навыков 11 ЧВК присутствуют типы бонусов, которые объявлены в навыках, "
                f"но НИ РАЗУ не запрашиваются в игровом движке (являются «мертвыми» бонусами): {sorted(list(unhooked_types))}. "
                f"В частности: 'keycard_drop_mult' (Спектр), 'hideout_cost_discount' (Сирена), "
                f"'hourly_rubles_flat' (Фараон), 'insurance_rebate' (Ревенант), "
                f"'vault_capacity_mult' (Арес/Фараон), 'gd_business_income_mult' (Арес/Ревенант)."
            )
        })

    print("  ✓ Навыки ЧВК проверены.")

    # -------------------------------------------------------------
    # 2. СИМУЛЯЦИЯ: МИФИЧЕСКИЙ КЛЮЧ ОТ РОСРЕЗЕРВА
    # -------------------------------------------------------------
    print("\n[2/5] ТЕСТИРОВАНИЕ: Мифический ключ от Росрезерва (Бункер и Бронегрузовик)...")
    player_keyless = {
        "user_id": 777002,
        "stash": [],
        "mythic_items": []
    }

    # Попытка открыть бункер БЕЗ ключа
    can_c, rem_c = can_claim_reserve_armor(player_keyless)
    succ_c, itm_c, msg_c = claim_reserve_armor_supply(player_keyless)
    if "Кулдаун арсенала еще активен" in msg_c or "-1" in msg_c:
        findings.append({
            "category": "Мифический ключ",
            "severity": "Средняя",
            "desc": (
                f"Ошибочное форматирование при отсутствии ключа: метод claim_reserve_armor_supply "
                f"возвращает '{msg_c}' вместо понятного сообщения о том, что у игрока отсутствует Ключ от Росрезерва."
            )
        })

    # Попытка отправить грузовик БЕЗ ключа
    can_t, rem_t = can_send_reserve_contraband_truck(player_keyless)
    succ_t, msg_t, res_t = send_reserve_contraband_truck(player_keyless)
    if "Возвращение через" in msg_t or "-1" in msg_t:
        findings.append({
            "category": "Мифический ключ",
            "severity": "Средняя",
            "desc": (
                f"Ошибочное форматирование при отсутствии ключа: метод send_reserve_contraband_truck "
                f"возвращает '{msg_t}' вместо сообщения об отсутствии Ключа от Росрезерва."
            )
        })

    # Теперь выдаем ключ и тестируем механику
    player_with_key = {
        "user_id": 777003,
        "stash": [
            {"uid": "u1", "item_id": "ammo_545_bt_rare", "price": 100000},
            {"uid": "u2", "item_id": "m4a1_sopmod_rare", "price": 500000},
            {"uid": "u_relic", "item_id": "relic_boss_tagilla_hammer", "rarity": "relic", "price": 10000000},
            {"uid": "u_key", "item_id": "mythic_state_reserve_key", "rarity": "mythic", "price": 150000000}
        ],
        "mythic_items": ["mythic_state_reserve_key"],
        "squad": [{"weapon_uid": "u2"}]
    }

    # Проверка открытия бункера с ключом
    succ_claim, armor_won, claim_msg = claim_reserve_armor_supply(player_with_key)
    if not succ_claim or not armor_won:
        findings.append({
            "category": "Мифический ключ",
            "severity": "Критическая",
            "desc": f"Не удалось получить мифическую броню из бункера Росрезерва с ключом: {claim_msg}"
        })
    else:
        if armor_won["item_id"] not in [a["id"] for a in MYTHIC_ARMORS]:
            findings.append({
                "category": "Мифический ключ",
                "severity": "Высокая",
                "desc": f"Выпавшая броня {armor_won['id']} отсутствует в каталоге 50 MYTHIC_ARMORS."
            })

    # Проверка кулдауна бункера
    succ_claim2, _, _ = claim_reserve_armor_supply(player_with_key)
    if succ_claim2:
        findings.append({
            "category": "Мифический ключ",
            "severity": "Критическая",
            "desc": "Бункер Росрезерва позволяет лутать броню повторно без учета 24-часового кулдауна!"
        })

    # Проверка грузовика контрабанды (защита экипировки, реликвий и мификов)
    succ_truck, msg_truck, res_truck = send_reserve_contraband_truck(player_with_key)
    if not succ_truck:
        findings.append({
            "category": "Мифический ключ",
            "severity": "Высокая",
            "desc": f"Грузовик контрабанды не отправился: {msg_truck}"
        })
    else:
        remaining_uids = {it.get("uid") for it in player_with_key.get("stash", [])}
        if "u2" not in remaining_uids:
            findings.append({
                "category": "Мифический ключ",
                "severity": "Критическая",
                "desc": "Грузовик контрабанды продал оружие бойца отряда, нарушив защиту экипированных слотов!"
            })
        if "u_relic" not in remaining_uids or "u_key" not in remaining_uids:
            findings.append({
                "category": "Мифический ключ",
                "severity": "Критическая",
                "desc": "Грузовик контрабанды продал защищенную реликвию или мифический ключ!"
            })

    print("  ✓ Мифический ключ проверен.")

    # -------------------------------------------------------------
    # 3. СИМУЛЯЦИЯ: БИЗНЕС ЗА 2.5 МИЛЛИАРДА (d2_underground_btc_mine)
    # -------------------------------------------------------------
    print("\n[3/5] ТЕСТИРОВАНИЕ: Бизнес за 2.5 млрд (Подземная шахта Д-2)...")
    d2_cfg = SPECIAL_BUSINESSES.get("d2_underground_btc_mine")
    if not d2_cfg:
        findings.append({
            "category": "Бизнес за 2.5 миллиарда",
            "severity": "Критическая",
            "desc": "Бизнес 'd2_underground_btc_mine' не зарегистрирован в SPECIAL_BUSINESSES!"
        })
    else:
        if d2_cfg.get("cost") != 2_500_000_000:
            findings.append({
                "category": "Бизнес за 2.5 миллиарда",
                "severity": "Высокая",
                "desc": f"Стоимость бизнеса равна {d2_cfg.get('cost')}, а ожидалась 2 500 000 000 ₽."
            })
        if d2_cfg.get("hourly_income") != 15_000_000:
            findings.append({
                "category": "Бизнес за 2.5 миллиарда",
                "severity": "Средняя",
                "desc": f"Доход шахты Д-2 равен {d2_cfg.get('hourly_income')} ₽/ч вместо 15 000 000 ₽/ч."
            })

    # Тест начисления дохода
    player_biz = {
        "user_id": 777004,
        "special_businesses": {"d2_underground_btc_mine": True},
        "modules": {"mining_farm": 10, "generator": 10},
        "businesses": {}
    }
    hourly_inc, inc_items = get_special_businesses_income(player_biz)
    if hourly_inc < 15_000_000:
        findings.append({
            "category": "Бизнес за 2.5 миллиарда",
            "severity": "Высокая",
            "desc": f"get_special_businesses_income не учитывает доход шахты Д-2 (получено {hourly_inc} ₽/ч)."
        })

    # Тест ускорения добычи BTC
    btc_without = get_mining_hourly_btc(10, {"modules": {"mining_farm": 10, "generator": 10}, "special_businesses": {}})
    btc_with = get_mining_hourly_btc(10, player_biz)
    if abs(btc_with - (btc_without * 2.0)) > 0.001:
        findings.append({
            "category": "Бизнес за 2.5 миллиарда",
            "severity": "Высокая",
            "desc": f"Шахта Д-2 не удваивает добычу фермы: без шахты={btc_without} BTC/ч, с шахтой={btc_with} BTC/ч (множитель != 2.0)."
        })

    # Тест сброса престижа: сохраняется ли или инициализируется ли шахта Д-2?
    player_prestige_test = {
        "user_id": 777005,
        "level": 10,
        "money": 100_000_000,
        "prestige": 0,
        "special_businesses": {
            "d2_underground_btc_mine": True,
            "gd_shadow_agent": True
        },
        "stash": [],
        "clothes_stash": [],
        "equipped_clothes": {}
    }
    execute_prestige_reset(player_prestige_test, 1)
    spec_biz_after = player_prestige_test.get("special_businesses", {})
    if "d2_underground_btc_mine" not in spec_biz_after:
        findings.append({
            "category": "Бизнес за 2.5 миллиарда",
            "severity": "Средняя",
            "desc": (
                "После выполнения execute_prestige_reset ключ 'd2_underground_btc_mine' полностью "
                "удаляется из словаря player['special_businesses'] (остаются только smugglers_fleet, "
                "fence_protection и gd_shadow_agent). Если шахта сгорает, ключ должен быть явно False, "
                "а если сохраняется как GD Military за 5 млрд — должна быть сохранена."
            )
        })

    print("  ✓ Бизнес за 2.5 млрд проверен.")

    # -------------------------------------------------------------
    # 4. СИМУЛЯЦИЯ: СПЕЦОПЕРАЦИИ СИГНАТУРНОГО ЧВК
    # -------------------------------------------------------------
    print("\n[4/5] ТЕСТИРОВАНИЕ: Спецоперации сигнатурного ЧВК...")
    player_specop_low = {"level": 9, "pmc_signature": "Viper"}
    can_l, reason_l, _ = can_launch_signature_raid(player_specop_low)
    if can_l:
        findings.append({
            "category": "Спецоперации сигнатурного ЧВК",
            "severity": "Критическая",
            "desc": "Спецоперация запустилась для игрока 9 уровня, нарушая ограничение 10 уровня!"
        })

    player_specop_ok = {
        "user_id": 777006,
        "level": 10,
        "pmc_signature": "Viper",
        "money": 0,
        "stash": [],
        "signature_raid_cooldown_until": 0,
        "stats": {}
    }
    can_l2, _, _ = can_launch_signature_raid(player_specop_ok)
    if not can_l2:
        findings.append({
            "category": "Спецоперации сигнатурного ЧВК",
            "severity": "Критическая",
            "desc": "Игрок 10 уровня без кулдауна не может запустить спецоперацию!"
        })

    # Запуск спецоперации и аудит наград
    call_raid = MagicMock()
    call_raid.id = "c_raid"
    call_raid.message.chat.id = 111
    call_raid.message.message_id = 222
    db_sim = {"users": {str(player_specop_ok["user_id"]): player_specop_ok}}
    bot_sim = MagicMock()

    handle_start_signature_raid(call_raid, player_specop_ok, db_sim, bot_sim)

    # Проверка начисленных денег (30-50M)
    m_earned = player_specop_ok.get("money", 0)
    if m_earned < 30_000_000 or m_earned > 50_000_000:
        findings.append({
            "category": "Спецоперации сигнатурного ЧВК",
            "severity": "Высокая",
            "desc": f"Спецоперация начислила {m_earned} ₽, что выходит за пределы заявленных 30 000 000 — 50 000 000 ₽."
        })

    # Проверка кулдауна
    cd_until = player_specop_ok.get("signature_raid_cooldown_until", 0)
    now_ts = int(time.time())
    cd_duration = cd_until - now_ts
    if not (21500 <= cd_duration <= 21600):
        findings.append({
            "category": "Спецоперации сигнатурного ЧВК",
            "severity": "Средняя",
            "desc": f"Базовый кулдаун спецоперации составил {cd_duration} сек вместо 21600 сек (6 часов)."
        })

    # Проверка текста о кулдауне в bot.edit_message_text
    sent_text = bot_sim.edit_message_text.call_args[0][0]
    if "ровно через 6 часов" in sent_text:
        # Проверим, что будет для игрока с Престижем 2 (где кулдаун 4.5 часа)
        player_p2 = {
            "user_id": 777007,
            "level": 10,
            "prestige": 2,
            "pmc_signature": "Viper",
            "money": 0,
            "stash": [],
            "stats": {}
        }
        bot_sim.reset_mock()
        handle_start_signature_raid(call_raid, player_p2, db_sim, bot_sim)
        p2_text = bot_sim.edit_message_text.call_args[0][0]
        if "ровно через 6 часов" in p2_text:
            findings.append({
                "category": "Спецоперации сигнатурного ЧВК",
                "severity": "Косметическая",
                "desc": (
                    "В финальном сообщении об успешном завершении спецоперации захардкожен текст "
                    "'Следующая спецоперация будет доступна ровно через 6 часов.', даже если у игрока Престиж 2+ "
                    "(4.5 часа) или навыки сокращения кулдауна Вайпера."
                )
            })

    # Проверка правила: Ключ Росрезерва выпадает ТОЛЬКО из кейса за 2.5М
    with open("/tmp/game/signature_raid_system.py") as f:
        sig_code = f.read()
    if "mythic_state_reserve_key" in sig_code:
        findings.append({
            "category": "Спецоперации сигнатурного ЧВК",
            "severity": "Критическая",
            "desc": "Ключ от Росрезерва найден в дропе спецопераций, что нарушает правило: дроп ТОЛЬКО из кейса за 2.5 млн."
        })
    with open("/tmp/game/bot.py") as f:
        bot_code = f.read()
    if "ТОЛЬКО</b> из Военного Кейса TerraGroup за 2 500 000" not in bot_code:
        findings.append({
            "category": "Мифический ключ",
            "severity": "Средняя",
            "desc": "Текст в bot.py не отражает, что ключ выпадает ТОЛЬКО из кейса за 2.5M."
        })

    print("  ✓ Спецоперации сигнатурного ЧВК проверены.")

    # -------------------------------------------------------------
    # 5. СИМУЛЯЦИЯ: СИСТЕМА ПРЕСТИЖА
    # -------------------------------------------------------------
    print("\n[5/5] ТЕСТИРОВАНИЕ: Система Престижа (Уровни 1..5, требования, сброс)...")
    # Проверка требований по всем уровням
    for tier in range(1, 6):
        cfg = PRESTIGE_TIERS[tier]
        reqs = cfg["reqs"]
        if reqs["level"] != 10:
            findings.append({
                "category": "Система Престижа",
                "severity": "Средняя",
                "desc": f"Уровень в требованиях Престижа {tier} равен {reqs['level']} вместо максимального 10."
            })

    # Тест блокировки перехода выше 5
    p5_player = {"level": 10, "money": 2_000_000_000, "prestige": 5, "btc": 100.0, "stats": {}}
    can_up_p5, check_p5 = check_prestige_requirements(p5_player, 6)
    if can_up_p5:
        findings.append({
            "category": "Система Престижа",
            "severity": "Критическая",
            "desc": "Система позволяет повысить уровень Престижа выше максимального 5-го!"
        })

    # Тест множителя дропа Жетона и Ключа на всех уровнях
    for t in range(6):
        g_rate = get_goons_token_drop_chance(t)
        k_rate = get_reserve_key_drop_chance(t)
        if g_rate != k_rate:
            findings.append({
                "category": "Система Престижа",
                "severity": "Критическая",
                "desc": f"Шанс жетона ({g_rate}) не равен шансу ключа ({k_rate}) на Престиже {t}!"
            })

    # Тест перка Престижа 5: "Денежная добыча в рейдах и операциях: x1.5 мультипликатор"
    p0 = {"user_id": 901, "level": 10, "pmc_signature": "Viper", "prestige": 0, "money": 0, "stash": [], "stats": {}}
    p5 = {"user_id": 902, "level": 10, "pmc_signature": "Viper", "prestige": 5, "money": 0, "stash": [], "stats": {}}
    call_m = MagicMock()
    bot_m = MagicMock()
    db_m = {"users": {"901": p0, "902": p5}}
    sum0 = 0
    sum5 = 0
    N = 30
    for _ in range(N):
        p0["money"] = 0
        p0["signature_raid_cooldown_until"] = 0
        handle_start_signature_raid(call_m, p0, db_m, bot_m)
        sum0 += p0["money"]
        p5["money"] = 0
        p5["signature_raid_cooldown_until"] = 0
        handle_start_signature_raid(call_m, p5, db_m, bot_m)
        sum5 += p5["money"]
    ratio = (sum5 / N) / (sum0 / N)
    if ratio < 1.35 or ratio > 1.65:
        findings.append({
            "category": "Система Престижа",
            "severity": "Высокая",
            "desc": f"Множитель наград 5-го Престижа в спецоперациях ЧВК составляет {ratio:.2f}x вместо 1.5x."
        })

    print("  ✓ Система Престижа проверена.")

    print("\n" + "=" * 70)
    print(f"📊 ИТОГИ АУДИТА: Найдено замечаний и недочетов: {len(findings)}")
    print("=" * 70)
    for idx, f in enumerate(findings, 1):
        print(f"\n#{idx} [{f['severity'].upper()}] {f['category']}")
        print(f"   Детали: {f['desc']}")

    return findings

if __name__ == "__main__":
    run_simulation()
