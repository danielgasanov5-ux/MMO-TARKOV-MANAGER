# -*- coding: utf-8 -*-
"""
Mythic Items System (150,000,000 ₽ each) for Escape from Tarkov MMO Telegram Bot:
1. 💼 «Дипломатический кейс Black Division» (mythic_black_division_case)
   - Drops from Co-op Boss Raids
   - Allows sending elite Black Division squad on a chosen boss every 24h
   - Guarantees a targeted Boss Relic (prioritizing missing relics for 5/5 sets) + 5-12M ₽ + elite trophies

2. 🎖️ «Жетон Отступников (The Goons)» (mythic_goons_token)
   - 0.01% chance (1 in 10,000) from the 2,500,000 ₽ TerraGroup Case
   - Automatic 24h supply drop of unique Goons signature gear:
     * Knight Skull Mask & Crye AVS Rig
     * Big Pipe M32A1 Grenade Launcher & Signature Smoke Pipe
     * Birdeye DVL-10 Saboteur Sniper & ComTac IV Recon Headset
   - 24h special raid: deploy the Goons trio (Knight, Big Pipe, Birdeye) into Tarkov
     for 7-15M ₽, elite loot, and 35% chance for a pure Bitcoin!
3. 📟 «Закодированный датчик DSP Смотрителя» (mythic_dsp_sensor)
   - 100% вечная охрана базы от рейдов мародеров + 3 предмета Зрячего каждые 24ч
4. 🗝️ «Ключ от Спецхрана Росрезерва» (mythic_state_reserve_key)
   - 0.01% chance (1 in 10,000) from the 2,500,000 ₽ TerraGroup Case (scales with Prestige up to 1.50%)
   - Раз в 24 часа: выдает 1 случайную Мифическую броню из 50 брутальных тактических вариантов
   - Раз в 3 часа: отправка тяжелого грузовика с контрабандой (до 10 предметов по 100% полной стоимости)
"""

import time
import random

MYTHIC_ITEMS = {
    "mythic_black_division_case": {
        "id": "mythic_black_division_case",
        "name": "💼 Дипломатический кейс Black Division",
        "category": "special",
        "market_cat": "Мифические артефакты",
        "rarity": "mythic",
        "price": 150000000,
        "badge": "💼",
        "desc": (
            "Сверхсекретный титановый дипломат TerraGroup. "
            "Дает возможность раз в 24 часа отправлять элитную ЧВК Black Division "
            "на ликвидацию выбранного Босса за гарантированной реликвией и миллионными трофеями."
        )
    },
    "mythic_goons_token": {
        "id": "mythic_goons_token",
        "name": "🎖️ Жетон Отступников (The Goons)",
        "category": "special",
        "market_cat": "Мифические артефакты",
        "rarity": "mythic",
        "price": 150000000,
        "badge": "🎖️",
        "desc": (
            "Мифический жетон признания банды The Goons (шанс 0.01% с кейса за 2.5М). "
            "Каждые 24 часа снабжает схрон уникальной экипировкой Knight, Big Pipe и Birdeye, "
            "а также позволяет раз в 24 часа отправлять троицу Отступников в рейд зачистки."
        )
    },
    "mythic_dsp_sensor": {
        "id": "mythic_dsp_sensor",
        "name": "📟 Закодированный датчик DSP Смотрителя",
        "category": "special",
        "market_cat": "Мифические артефакты",
        "rarity": "mythic",
        "price": 150000000,
        "badge": "📟",
        "desc": (
            "Специальный закодированный радиопередатчик с персональной частотой Зрячего. "
            "Пока датчик находится у вас, легендарный снайпер берет базу и территории ЧВК под личный круглосуточный дозор. "
            "Обеспечивает 100% вечную защиту территорий от мародеров, краж и рейдерских захватов без необходимости продлевать контракты охраны. "
            "Также каждые 24 часа Смотритель Маяка автоматически присылает в ваш схрон 3 персональных предмета экипировки Зрячего."
        )
    }
,
    "mythic_state_reserve_key": {
        "id": "mythic_state_reserve_key",
        "name": "🗝️ Ключ от Спецхрана Росрезерва",
        "category": "special",
        "market_cat": "Мифические артефакты",
        "rarity": "mythic",
        "price": 150000000,
        "badge": "🗝️",
        "desc": (
            "Сверхсекретный электронный мастер-ключ от подземного арсенала спецхранилища Росрезерва (шанс 0.01% с кейса за 2.5М, растет с Престижем до 1.50%). "
            "1) Раз в 24 часа открывает законсервированный оружейный бункер и выдает 1 случайную Мифическую броню (из 50 брутальных вариантов высшего класса). "
            "2) Раз в 3 часа позволяет лично отправить тяжелый бронегрузовик с контрабандой: "
            "загрузите до 10 предметов из схрона и получите за них 100% полную рыночную стоимость без наценок и комиссий."
        )
    }
}

# Unique signature gear of The Goons (given every 24h via mythic_goons_token)
GOONS_GEAR = [
    {
        "id": "goons_knight_skull_mask",
        "name": "💀 Шлем-маска «Knight Skull»",
        "category": "armor",
        "subcategory": "helmet",
        "market_cat": "Шлемы",
        "rarity": "mythic",
        "price": 25000000,
        "armor": 165,
        "combat": 50,
        "desc": "Культовая баллистическая титановая маска со стилизованным черепом командира Knight. Высшая степень рикошета и устрашения (+165 Броня, +50 Урон)."
    },
    {
        "id": "goons_knight_avs_rig",
        "name": "🛡️ Бронежилет Crye Precision CPC plate carrier (Knight Edition)",
        "category": "armor",
        "subcategory": "body_armor",
        "market_cat": "Броня",
        "rarity": "mythic",
        "price": 35000000,
        "armor": 210,
        "combat": 40,
        "desc": "Сверхтяжелый штурмовой плитник Crye Precision CPC командира Knight с композитными бронеплитами 6+ класса защиты (+210 Броня, +40 Урон)."
    },
    {
        "id": "goons_knight_scar_h",
        "name": "⚔️ Штурмовая винтовка FN SCAR-H «Knight’s Wrath» 7.62x51",
        "category": "weapons",
        "subcategory": "assault_rifle",
        "market_cat": "Штурмовые винтовки",
        "rarity": "mythic",
        "price": 42000000,
        "combat": 250,
        "armor": 30,
        "desc": "Кастомизированная штурмовая винтовка FN SCAR-H командира Knight калибра 7.62x51 NATO с оптикой Vudu и глушителем Wave QD. Пробивает любые укрепления (+250 Урон, +30 Защита)."
    },
    {
        "id": "goons_bigpipe_m32a1",
        "name": "🧨 Гранатомет M32A1 «Big Pipe»",
        "category": "weapons",
        "subcategory": "special",
        "market_cat": "Тяжелое оружие",
        "rarity": "mythic",
        "price": 40000000,
        "combat": 260,
        "armor": 15,
        "desc": "Шестизарядный 40-мм револьверный гранатомет Биг Пайпа. Сметает вражеские укрепления и свиту боссов осколочным шквалом (+260 Урон, +15 Защита)."
    },
    {
        "id": "goons_bigpipe_bandana",
        "name": "🪓 Бандана и трубка «Big Pipe Smoke»",
        "category": "armor",
        "subcategory": "helmet",
        "market_cat": "Шлемы",
        "rarity": "mythic",
        "price": 20000000,
        "combat": 55,
        "armor": 135,
        "desc": "Легендарная курительная трубка и пропитанная порохом кевларовая бандана Биг Пайпа. Внушает животный страх врагам (+135 Броня, +55 Урон)."
    },
    {
        "id": "goons_bigpipe_rec10",
        "name": "💥 Карабин Barrett REC10 «Big Pipe Devastator» 7.62x51",
        "category": "weapons",
        "subcategory": "assault_rifle",
        "market_cat": "Штурмовые винтовки",
        "rarity": "mythic",
        "price": 39000000,
        "combat": 240,
        "armor": 25,
        "desc": "Тяжелый полуавтоматический карабин Barrett REC10 Биг Пайпа с дульным тормозом Lantac Dragon и магазином на 25 патронов (+240 Урон, +25 Защита)."
    },
    {
        "id": "goons_birdeye_dvl10",
        "name": "🎯 Снайперская винтовка DVL-10 «Birdeye Saboteur»",
        "category": "weapons",
        "subcategory": "sniper_rifle",
        "market_cat": "Снайперские винтовки",
        "rarity": "mythic",
        "price": 35000000,
        "combat": 230,
        "armor": 15,
        "desc": "Бесшумная снайперская винтовка Бердая с интегрированным глушителем. Безупречная бесшумная ликвидация (+230 Урон, +15 Защита)."
    },
    {
        "id": "goons_birdeye_comtac",
        "name": "🎧 Гарнитура Peltor ComTac IV «Birdeye Recon»",
        "category": "gear",
        "subcategory": "headset",
        "market_cat": "Наушники",
        "rarity": "mythic",
        "price": 20000000,
        "combat": 65,
        "armor": 125,
        "desc": "Активная гарнитура Бердая. Позволяет улавливать малейший шорох шагов противника, упреждая засады (+125 Броня, +65 Урон)."
    },
    {
        "id": "goons_birdeye_rsass",
        "name": "🦅 Снайперская винтовка Remington RSASS «Birdeye Phantom Eye» 7.62x51",
        "category": "weapons",
        "subcategory": "sniper_rifle",
        "market_cat": "Снайперские винтовки",
        "rarity": "mythic",
        "price": 44000000,
        "combat": 265,
        "armor": 20,
        "desc": "Высокоточная марксманская система Бердая с титановым глушителем Ultra 5 и тепловизионным оптическим комплексом (+265 Урон, +20 Защита)."
    }
]

GOONS_GEAR_BY_ID = {item["id"]: item for item in GOONS_GEAR}

# Unique signature gear of Zryachiy (supplied every 24h via mythic_dsp_sensor)
ZRYACHIY_GEAR = [
    {
        "id": "zryachiy_axmc_338",
        "name": "🎯 Снайперская винтовка Accuracy International AXMC «Глаз Зрячего» .338 Lapua",
        "category": "weapons",
        "subcategory": "sniper_rifle",
        "market_cat": "Снайперские винтовки",
        "rarity": "mythic",
        "price": 42000000,
        "combat": 280,
        "armor": 10,
        "desc": "Высокоточная болтовая винтовка Зрячего под патрон .338 Lapua Magnum с оптическим прицелом Schmidt & Bender и титановым глушителем. Абсолютный урон на любой дистанции (+280 Урон, +10 Защита)."
    },
    {
        "id": "zryachiy_cultist_vest",
        "name": "🛡️ Тяжелый плитник Сектантов «Страж Маяка»",
        "category": "armor",
        "subcategory": "body_armor",
        "market_cat": "Броня",
        "rarity": "mythic",
        "price": 38000000,
        "armor": 220,
        "combat": 35,
        "desc": "Модифицированный разгрузочный бронежилет 6+ класса защиты с ритуальными рунами Сектантов. Поглощает попадания даже тяжелых бронебойных пуль (+220 Броня, +35 Урон)."
    },
    {
        "id": "zryachiy_hood_mask",
        "name": "👁️ Балаклава и капюшон «Ослепленный Жнец»",
        "category": "armor",
        "subcategory": "helmet",
        "market_cat": "Шлемы",
        "rarity": "mythic",
        "price": 24000000,
        "combat": 45,
        "armor": 155,
        "desc": "Плотный темный капюшон с маской, скрывающей слепые бельма Зрячего. Обостряет тактический слух и реакцию бойца (+155 Броня, +45 Урон)."
    }
]

ZRYACHIY_GEAR_BY_ID = {item["id"]: item for item in ZRYACHIY_GEAR}

# Cooldowns in seconds (24 hours = 86400s)
COOLDOWN_24H = 86400

def has_mythic_item(player, item_id):
    """Checks if player owns the specific mythic item."""
    if not player:
        return False
    # Check special mythic_items list
    if item_id in player.get("mythic_items", []):
        return True
    # Check stash
    for itm in player.get("stash", []):
        if itm.get("item_id") == item_id:
            return True
    return False

def add_mythic_item_to_player(player, item_id):
    """Safely grants a mythic item to the player."""
    player.setdefault("mythic_items", [])
    if item_id not in player["mythic_items"]:
        player["mythic_items"].append(item_id)
    # Also add to stash for visualization
    now = int(time.time())
    stash_has = any(itm.get("item_id") == item_id for itm in player.get("stash", []))
    if not stash_has:
        player.setdefault("stash", []).append({
            "uid": f"mythic_{item_id}_{now}",
            "item_id": item_id,
            "equipped_to": None
        })

def get_player_mythics(player):
    """Returns list of all mythic items owned by the player."""
    owned = []
    for mid, mdata in MYTHIC_ITEMS.items():
        if has_mythic_item(player, mid):
            owned.append(mdata)
    return owned

# ----------------- BLACK DIVISION SQUAD RAIDS -----------------

def can_launch_black_division(player):
    """Returns (can_launch: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_black_division_case"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_run = player.get("last_black_division_raid", 0)
    elapsed = now - last_run
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def execute_black_division_raid(player, boss_key):
    """
    Executes Black Division operation against chosen boss:
    - reshala, tagilla, killa, shturman, glukhar, sanitar
    - Guarantees a targeted Boss Relic from that boss!
    - Awards 5,000,000 - 12,000,000 ₽ + high-tier loot + 150 EXP
    """
    from relics_system import BOSS_SETS, get_player_relics

    now = int(time.time())
    b_data = BOSS_SETS.get(boss_key)
    if not b_data:
        boss_key = "killa"
        b_data = BOSS_SETS["killa"]

    # Choose relic: prioritize one the player DOES NOT own yet!
    owned_relic_ids = get_player_relics(player)
    missing_relics = [r for r in b_data["relics"] if r["id"] not in owned_relic_ids]
    if missing_relics:
        chosen_relic = random.choice(missing_relics)
        is_new = True
    else:
        chosen_relic = random.choice(b_data["relics"])
        is_new = False

    # Award relic to stash
    player.setdefault("stash", []).append({
        "uid": f"relic_{now}_{random.randint(1000, 9999)}",
        "item_id": chosen_relic["id"],
        "equipped_to": None
    })

    # Award rubles
    rubles = random.randint(5000000, 12000000)
    player["money"] = player.get("money", 0) + rubles

    # Award EXP
    player["exp"] = player.get("exp", 0) + 150

    # Pick 2-3 elite trophy items
    from loot_generator import roll_strict_tarkov_loot
    trophies = []
    for _ in range(random.randint(2, 3)):
        item = roll_strict_tarkov_loot(player)
        trophies.append(item)
        player.setdefault("stash", []).append({
            "uid": f"bd_loot_{now}_{random.randint(1000, 9999)}",
            "item_id": item["id"],
            "equipped_to": None
        })

    # Update cooldown
    player["last_black_division_raid"] = now

    return {
        "boss_name": b_data["boss_name"],
        "boss_icon": b_data["icon"],
        "relic": chosen_relic,
        "is_new_relic": is_new,
        "rubles": rubles,
        "exp": 150,
        "trophies": trophies
    }

# ----------------- THE GOONS MECHANICS -----------------

def can_claim_goons_supply(player):
    """Returns (can_claim: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_goons_token"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_supply = player.get("last_goons_supply", 0)
    elapsed = now - last_supply
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def claim_goons_gear_supply(player):
    """
    Supplies one random unique Goons signature gear piece to player's stash.
    """
    now = int(time.time())
    gear_item = random.choice(GOONS_GEAR)

    player.setdefault("stash", []).append({
        "uid": f"goons_gear_{now}_{random.randint(1000, 9999)}",
        "item_id": gear_item["id"],
        "equipped_to": None
    })

    player["last_goons_supply"] = now
    return gear_item

def can_launch_goons_raid(player):
    """Returns (can_launch: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_goons_token"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_raid = player.get("last_goons_raid", 0)
    elapsed = now - last_raid
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def execute_goons_raid(player):
    """
    Deploys The Goons trio (Knight, Big Pipe, Birdeye) on a 24h sweep raid:
    - 100% victory (they are The Goons)
    - 7,000,000 - 15,000,000 ₽
    - 3-4 elite items
    - 250 EXP
    - 35% chance for 1 pure Bitcoin (BTC)!
    """
    now = int(time.time())

    rubles = random.randint(7000000, 15000000)
    player["money"] = player.get("money", 0) + rubles
    player["exp"] = player.get("exp", 0) + 250

    # Bitcoin roll (35% chance)
    btc_won = 0.0
    if random.random() < 0.35:
        btc_won = 1.0
        player["btc"] = player.get("btc", 0.0) + 1.0

    # 3-4 high tier items
    from loot_generator import roll_strict_tarkov_loot
    trophies = []
    for _ in range(random.randint(3, 4)):
        item = roll_strict_tarkov_loot(player)
        trophies.append(item)
        player.setdefault("stash", []).append({
            "uid": f"goons_raid_{now}_{random.randint(1000, 9999)}",
            "item_id": item["id"],
            "equipped_to": None
        })

    player["last_goons_raid"] = now

    return {
        "rubles": rubles,
        "btc_won": btc_won,
        "exp": 250,
        "trophies": trophies
    }

# ----------------- ZRYACHIY (LIGHTHOUSE) MECHANICS -----------------

def get_zryachiy_supply_status(player):
    """Returns (can_claim: bool, remaining_seconds: int)."""
    if not has_mythic_item(player, "mythic_dsp_sensor"):
        return False, COOLDOWN_24H
    now = int(time.time())
    last_supply = player.get("last_zryachiy_supply", 0)
    if last_supply == 0:
        return True, 0
    elapsed = now - last_supply
    if elapsed >= COOLDOWN_24H:
        return True, 0
    return False, COOLDOWN_24H - elapsed

def claim_zryachiy_gear_supply(player):
    """
    Supplies all 3 unique Zryachiy signature gear pieces to player's stash.
    """
    now = int(time.time())
    delivered = []
    stash = player.setdefault("stash", [])
    for itm in ZRYACHIY_GEAR:
        uid = f"zryachiy_gear_{now}_{random.randint(1000, 9999)}"
        stash.append({
            "uid": uid,
            "item_id": itm["id"],
            "equipped_to": None
        })
        delivered.append(itm)

    player["last_zryachiy_supply"] = now
    return delivered

def check_zryachiy_daily_supply(player):
    """
    Automatically checks and delivers the 3 Zryachiy items if 24 hours have passed.
    Returns (delivered: bool, items: list).
    """
    can_claim, _ = get_zryachiy_supply_status(player)
    if not can_claim:
        return False, []

    delivered = claim_zryachiy_gear_supply(player)
    notif = (
        "👁️ <b>ПОСТАВКА СМОТРИТЕЛЯ МАЯКА (Каждые 24 часа):</b>\n"
        "Зрячий автоматически доставил в ваш схрон 3 персональных предмета экипировки:\n"
        "• 🎯 AXMC «Глаз Зрячего» .338 Lapua (Урон: +280, Броня: +10)\n"
        "• 🛡️ Плитник Сектантов «Страж Маяка» (Броня: +220, Урон: +35)\n"
        "• 👁️ Капюшон «Ослепленный Жнец» (Броня: +155, Урон: +45)"
    )
    player.setdefault("notifications", []).append(notif)
    return True, delivered



# ----------------- SQUAD MYTHIC GEAR PERKS & SYNERGIES -----------------
def get_squad_mythic_perks(user):
    """
    Scans player's squad and stash for equipped Mythic gear.
    Calculates combat bonuses, rubles multiplier, EXP multiplier,
    survival chance bonus, Bitcoin drop chance, and boss combat advantages.
    """
    defaults = {
        "goons_pieces": 0,
        "zryachiy_pieces": 0,
        "total_mythics": 0,
        "has_goons_set": False,
        "has_zryachiy_set": False,
        "bonus_power": 0,
        "bonus_armor": 0,
        "rubles_mult": 1.0,
        "exp_mult": 1.0,
        "flat_win_chance": 0.0,
        "boss_combat_win_bonus": 0.0,
        "extra_loot_count": 0,
        "btc_roll_chance": 0.0,
        "has_m32a1": False,
        "has_comtac": False,
        "has_axmc": False,
        "equipped_mythics": []
    }
    if not user:
        return defaults

    squad = user.get("squad", [])
    stash = {itm["uid"]: itm for itm in user.get("stash", [])}

    try:
        from tarkov_engine import ITEMS_BY_ID
    except ImportError:
        ITEMS_BY_ID = {}

    goons_count = 0
    zryachiy_count = 0
    other_mythics_count = 0
    equipped = []
    has_m32a1 = False
    has_comtac = False
    has_axmc = False

    for fighter in squad:
        for slot in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
            uid = fighter.get(slot)
            if uid and uid in stash:
                item_id = stash[uid].get("item_id")
                if item_id in GOONS_GEAR_BY_ID:
                    goons_count += 1
                    equipped.append(GOONS_GEAR_BY_ID[item_id])
                    if item_id == "goons_bigpipe_m32a1":
                        has_m32a1 = True
                    elif item_id == "goons_birdeye_comtac":
                        has_comtac = True
                elif item_id in ZRYACHIY_GEAR_BY_ID:
                    zryachiy_count += 1
                    equipped.append(ZRYACHIY_GEAR_BY_ID[item_id])
                    if item_id == "zryachiy_axmc_338":
                        has_axmc = True
                else:
                    info = ITEMS_BY_ID.get(item_id, {})
                    if info.get("rarity") == "mythic":
                        other_mythics_count += 1
                        equipped.append(info)

    total_mythics = goons_count + zryachiy_count + other_mythics_count
    if total_mythics == 0:
        return defaults

    # Multipliers:
    # Each Goons gear piece gives +25% rubles extracted from raids!
    rubles_bonus = goons_count * 0.25 + other_mythics_count * 0.20

    # Each Zryachiy gear piece gives +35% EXP gained!
    exp_bonus = zryachiy_count * 0.35 + other_mythics_count * 0.20

    # Flat win chance bonus:
    flat_win_chance = goons_count * 0.02
    flat_win_chance += zryachiy_count * 0.06
    flat_win_chance += other_mythics_count * 0.04
    if has_axmc:
        flat_win_chance += 0.04

    # Boss ambush combat bonuses:
    boss_win_bonus = 0.0
    if has_m32a1:
        boss_win_bonus += 0.20  # 40mm grenade launcher obliterates boss cover
    if has_comtac:
        boss_win_bonus += 0.15  # Early acoustic intercept prevents surprise
    if total_mythics >= 2:
        boss_win_bonus += 0.10

    # Set bonuses:
    has_goons_set = (goons_count >= 3)
    has_zryachiy_set = (zryachiy_count >= 3)

    bonus_power = 0
    bonus_armor = 0
    extra_loot = 0
    btc_chance = 0.0

    if has_goons_set:
        bonus_power += 150
        bonus_armor += 100
        rubles_bonus += 0.50  # +50% extra rubles (total +125%+)
        btc_chance = 0.15    # 15% chance for a pure Bitcoin in solo raids!
        boss_win_bonus += 0.15

    if has_zryachiy_set:
        bonus_power += 200
        bonus_armor += 120
        exp_bonus += 0.50    # Total +155%+ EXP
        flat_win_chance += 0.08
        extra_loot += 1      # +1 guaranteed high tier loot
        boss_win_bonus += 0.15

    if other_mythics_count > 0:
        bonus_power += other_mythics_count * 80
        bonus_armor += other_mythics_count * 50
        extra_loot += (other_mythics_count // 2)
        if other_mythics_count >= 2:
            boss_win_bonus += 0.15

    return {
        "goons_pieces": goons_count,
        "zryachiy_pieces": zryachiy_count,
        "total_mythics": total_mythics,
        "has_goons_set": has_goons_set,
        "has_zryachiy_set": has_zryachiy_set,
        "bonus_power": bonus_power,
        "bonus_armor": bonus_armor,
        "rubles_mult": round(1.0 + rubles_bonus, 2),
        "exp_mult": round(1.0 + exp_bonus, 2),
        "flat_win_chance": round(flat_win_chance, 3),
        "boss_combat_win_bonus": round(boss_win_bonus, 2),
        "extra_loot_count": extra_loot,
        "btc_roll_chance": btc_chance,
        "has_m32a1": has_m32a1,
        "has_comtac": has_comtac,
        "has_axmc": has_axmc,
        "equipped_mythics": equipped
    }


# ----------------- 50 BRUTAL GROUNDED MYTHIC ARMORS -----------------
MYTHIC_ARMORS = [
    # Серия 1: Тяжелый Штурм и Саперы
    {
        "id": "armor_fort_dubrava",
        "name": "🛡️ Тяжелый саперный панцирь «Форт-Дубрава»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 185, "combat": 35, "durability": 175, "max_durability": 175, "price": 52000000,
        "desc": "Тяжелый саперный штурмовой доспех высшего класса защиты. Плиты из карбида кремния с противоосколочным титановым воротником."
    },
    {
        "id": "armor_voevoda_m",
        "name": "🛡️ Штурмовой комплект «Воевода-М»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 180, "combat": 32, "durability": 170, "max_durability": 170, "price": 50000000,
        "desc": "Модернизированный армейский комплекс прорыва укреплений. Усиленные бронепанели и защита плечевых суставов."
    },
    {
        "id": "armor_zaslon_u",
        "name": "🛡️ Бронекостюм разграждения «Заслон-У»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 175, "combat": 30, "durability": 165, "max_durability": 165, "price": 48000000,
        "desc": "Специализированная штурмовая кираса для работы в узких бункерах и тоннелях под шквальным огнем."
    },
    {
        "id": "armor_grenader",
        "name": "🛡️ Противоосколочный панцирь «Гренадер»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 170, "combat": 28, "durability": 160, "max_durability": 160, "price": 46000000,
        "desc": "Тяжелый плитник с увеличенной площадью кевларового подбоя для защиты от фугасных разрывов гранат."
    },
    {
        "id": "armor_vityaz_sh",
        "name": "🛡️ Штурмовой монолит «Витязь-Ш»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 190, "combat": 38, "durability": 180, "max_durability": 180, "price": 55000000,
        "desc": "Монолитный стале-титановый бронежилет спецназа. Выдерживает прямое попадание бронебойных винтовочных калибров."
    },
    {
        "id": "armor_kuznets_6b",
        "name": "🛡️ Стальной кирасный жилет «Кузнец-6Б»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 165, "combat": 25, "durability": 155, "max_durability": 155, "price": 44000000,
        "desc": "Кованые бронепластины толщиной 8 мм, соединенные армированными стропами. Неприхотлив и невероятно крепок."
    },
    {
        "id": "armor_oplot_r",
        "name": "🛡️ Тяжелый штурмовой бронежилет «Оплот-Р»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 182, "combat": 34, "durability": 172, "max_durability": 172, "price": 51000000,
        "desc": "Штурмовой баллистический пакет Росрезерва с многослойным керамическим экраном и паховым фартуком."
    },
    {
        "id": "armor_molot_heavy",
        "name": "🛡️ Бронекомбинезон зачистки «Молот»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 178, "combat": 30, "durability": 168, "max_durability": 168, "price": 49000000,
        "desc": "Тяжелый бронированный комбинезон бойцов штурмовых групп с интегрированными анатомическими щитками."
    },
    {
        "id": "armor_taran_43",
        "name": "🛡️ Саперный штурмовой фартук «Таран-43»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 172, "combat": 28, "durability": 162, "max_durability": 162, "price": 47000000,
        "desc": "Усиленная модификация фронтального бронефартука для лобового подавления пулеметных точек."
    },
    {
        "id": "armor_bronenosec",
        "name": "🛡️ Композитный бронекостюм «Броненосец»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 188, "combat": 36, "durability": 178, "max_durability": 178, "price": 54000000,
        "desc": "Сверхтяжелый композит на базе диборида титана. Эталон неуязвимости в позиционных городских перестрелках."
    },

    # Серия 2: Ветераны горячих точек и Наемники
    {
        "id": "armor_grozny_95",
        "name": "🛡️ Плитник ветерана «Грозный-95»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 160, "combat": 24, "durability": 150, "max_durability": 150, "price": 42000000,
        "desc": "Проверенный суровыми боями армейский плитник с кустарно усиленными титановыми пластинами в чехле «Флора»."
    },
    {
        "id": "armor_pantsir_afgan",
        "name": "🛡️ Модифицированный бронежилет «Панцирь-Афган»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 158, "combat": 22, "durability": 148, "max_durability": 148, "price": 41000000,
        "desc": "Облегченный для жары, но усиленный двойным слоем баллистического шелка и трофейной стали."
    },
    {
        "id": "armor_volkodav_plate",
        "name": "🛡️ Заказной Plate Carrier «ЧВК Волкодав»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 174, "combat": 30, "durability": 164, "max_durability": 164, "price": 48000000,
        "desc": "Индивидуальный заказ командиров частной военной компании. Превосходная эргономика и бронеплиты Stand-Alone."
    },
    {
        "id": "armor_naemnik_sever",
        "name": "🛡️ Камуфлированный плитник «Наемник-Север»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 168, "combat": 26, "durability": 158, "max_durability": 158, "price": 45000000,
        "desc": "Зимний бронежилет дальних разведывательных рейдов с полимерным термопокрытием бронеэлементов."
    },
    {
        "id": "armor_okopny_myasnik",
        "name": "🛡️ Полевой бронежилет «Окопный Мясник»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 166, "combat": 25, "durability": 156, "max_durability": 156, "price": 44000000,
        "desc": "Покрытый царапинами и вмятинами от пуль стальной жилет ветерана десятков отчаянных рейдов."
    },
    {
        "id": "armor_psy_voyny",
        "name": "🛡️ Баллистический жилет «Псы Войны»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 172, "combat": 28, "durability": 162, "max_durability": 162, "price": 47000000,
        "desc": "Бронежилет синдиката опытных наемников. Отличается выверенным балансом веса и баллистической стойкости."
    },
    {
        "id": "armor_shturm_kavkaz",
        "name": "🛡️ Разгрузочный бронежилет «Штурм-Кавказ»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 164, "combat": 24, "durability": 154, "max_durability": 154, "price": 43000000,
        "desc": "Горно-штурмовой бронежилет с боковыми бронепластинами и усиленной защитой позвоночника."
    },
    {
        "id": "armor_dikaya_diviziya",
        "name": "🛡️ Тактический корсет «Дикая Дивизия»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 170, "combat": 28, "durability": 160, "max_durability": 160, "price": 46000000,
        "desc": "Анатомический бронекорсет с распределением тяжести бронепанелей по поясу и плечам оператора."
    },
    {
        "id": "armor_snayperskiy_zub",
        "name": "🛡️ Плитник ликвидатора «Снайперский Зуб»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 155, "combat": 30, "durability": 145, "max_durability": 145, "price": 40000000,
        "desc": "Низкопрофильный плитник с максимальной подвижностью плеч для ведения прицельной снайперской стрельбы."
    },
    {
        "id": "armor_syndicate_u",
        "name": "🛡️ Трофейный бронекостюм «Синдикат-У»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 176, "combat": 32, "durability": 166, "max_durability": 166, "price": 49000000,
        "desc": "Особая серия трофейного снаряжения европейских ЧВК с керамическими пластинами 6-го класса."
    },

    # Серия 3: Тяжелые Спецподразделения ГРУ/ФСБ
    {
        "id": "armor_alpha_titan",
        "name": "🛡️ Баллистический комплекс «Альфа-Титан»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 186, "combat": 35, "durability": 176, "max_durability": 176, "price": 53000000,
        "desc": "Элитная разработка для штурмовых групп антитеррора. Титановые пластины с антирикошетным покрытием."
    },
    {
        "id": "armor_vympel_t",
        "name": "🛡️ Штурмовой бронежилет «Вымпел-Т»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 184, "combat": 34, "durability": 174, "max_durability": 174, "price": 52000000,
        "desc": "Тактический бронежилет спецопераций повышенного риска. Обеспечивает круговую защиту торса и шеи."
    },
    {
        "id": "armor_grad_spetsnaz",
        "name": "🛡️ Закрытый бронекомбинезон «Град-Спецназ»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 180, "combat": 32, "durability": 170, "max_durability": 170, "price": 50000000,
        "desc": "Штурмовой комплект спецназа госбезопасности для бескомпромиссных операций по ликвидации лидеров банд."
    },
    {
        "id": "armor_spektr_t",
        "name": "🛡️ Плитник спецназа ГРУ «Спектр-Т»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 175, "combat": 30, "durability": 165, "max_durability": 165, "price": 48000000,
        "desc": "Легкий, но бронебойно-устойчивый плитник войсковой разведки с карбид-борными защитными вставками."
    },
    {
        "id": "armor_bastion_vdv",
        "name": "🛡️ Защитный комплект «Бастион ВДВ»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 172, "combat": 28, "durability": 162, "max_durability": 162, "price": 47000000,
        "desc": "Десантно-штурмовой бронежилет с демпфирующей системой гашения заброневой контузионной травмы."
    },
    {
        "id": "armor_kaskad_4",
        "name": "🛡️ Бронежилет антитеррора «Каскад-4»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 178, "combat": 30, "durability": 168, "max_durability": 168, "price": 49000000,
        "desc": "Модульный штурмовой бронежилет 4-й ревизии для оперативной зачистки укрепленных зданий."
    },
    {
        "id": "armor_gvardeets",
        "name": "🛡️ Титановый жилет «Гвардеец»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 168, "combat": 26, "durability": 158, "max_durability": 158, "price": 45000000,
        "desc": "Штампованные титановые секции в износостойком баллистическом чехле повышенной прочности."
    },
    {
        "id": "armor_rubezh_m",
        "name": "🛡️ Модульный бронекостюм «Рубеж-М»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 182, "combat": 33, "durability": 172, "max_durability": 172, "price": 51000000,
        "desc": "Комплекс позиционной обороны границы с быстросменными бронепакетами и защитой поясницы."
    },
    {
        "id": "armor_berkut_m",
        "name": "🛡️ Тяжелый корсет «Беркут-М»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 176, "combat": 31, "durability": 166, "max_durability": 166, "price": 49000000,
        "desc": "Тактический бронежилет с двойными боковыми плитами и распределенной системой крепления подсумков."
    },
    {
        "id": "armor_rys_t",
        "name": "🛡️ Баллистический панцирь «Рысь-Т»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 185, "combat": 35, "durability": 175, "max_durability": 175, "price": 52000000,
        "desc": "Титановый штурмовой панцирь специального назначения. Прошел испытания в самых тяжелых осадах."
    },

    # Серия 4: Кустарные и Трофейные доспехи Боссов
    {
        "id": "armor_tagilla_varvar",
        "name": "🛡️ Нагрудник из гусеничной стали «Тагилла-Варвар»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 182, "combat": 36, "durability": 180, "max_durability": 180, "price": 51000000,
        "desc": "Сварен вручную Тагиллой из закаленных траков гусениц танков Т-90. Неимоверный вес и несокрушимость."
    },
    {
        "id": "armor_tsehovoy_myasnik",
        "name": "🛡️ Сварочная титановая кираса «Цеховой Мясник»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 177, "combat": 32, "durability": 175, "max_durability": 175, "price": 49000000,
        "desc": "Тяжелый фартук сталевара, усиленный арматурой и пластинами от ковшей Завода."
    },
    {
        "id": "armor_killa_double_6b13",
        "name": "🛡️ Сдвоенный бронежилет Киллы «Двойной 6Б13»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 188, "combat": 38, "durability": 178, "max_durability": 178, "price": 54000000,
        "desc": "Легендарная броня защитника ТЦ Ультра с дополнительно вваренными вторым слоем плитами 6Б13-М."
    },
    {
        "id": "armor_glukhar_titan",
        "name": "🛡️ Усиленный плитник свиты Глухаря «Резервный Титан»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 180, "combat": 34, "durability": 170, "max_durability": 170, "price": 50000000,
        "desc": "Трофейная армейская экипировка личной охраны Глухаря с базы Резерва. Повышенная стойкость к дроби."
    },
    {
        "id": "armor_sanitar_himzaschita",
        "name": "🛡️ Кевларовый комбинезон Санитара «Химзащита-С»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 162, "combat": 25, "durability": 155, "max_durability": 155, "price": 43000000,
        "desc": "Многослойный кевларовый бронекостюм с химстойкой пропиткой и внутренними медицинскими карманами."
    },
    {
        "id": "armor_reshala_gold_order",
        "name": "🛡️ Трофейная кираса Решалы «Золотой Заказ»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 170, "combat": 28, "durability": 160, "max_durability": 160, "price": 46000000,
        "desc": "Дорогостоящий заказной бронежилет криминального авторитета Таможни со скрытыми титановыми пластинами."
    },
    {
        "id": "armor_kaban_vepr_6",
        "name": "🛡️ Бронежилет патрульного Кабана «Вепрь-6»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 185, "combat": 35, "durability": 175, "max_durability": 175, "price": 53000000,
        "desc": "Сверхширокий тяжелый бронежилет для массивных бойцов гарнизона автосалона Кабана."
    },
    {
        "id": "armor_cultist_obryad",
        "name": "🛡️ Литой бронещит сектантов «Черный Обряд»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 169, "combat": 32, "durability": 165, "max_durability": 165, "price": 46000000,
        "desc": "Покрытая ритуальными насечками темная закаленная сталь жрецов Сектантов с защитой от яда."
    },
    {
        "id": "armor_util_tyagach",
        "name": "🛡️ Кустарный штурмовой панцирь «Утиль-Тягач»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 174, "combat": 30, "durability": 165, "max_durability": 165, "price": 48000000,
        "desc": "Собран на свалке металлолома из рессор и кусков брони БМП-2. Брутален, тяжел и держит выстрелы в упор."
    },
    {
        "id": "armor_diesel_zavod",
        "name": "🛡️ Кованый бронежилет «Дизель-Завод»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 171, "combat": 28, "durability": 162, "max_durability": 162, "price": 47000000,
        "desc": "Кираса слесаря котельного цеха, усиленная штампованными пластинами жаропрочной стали."
    },

    # Серия 5: Зарубежные контракты и Black Division
    {
        "id": "armor_obsidian_plate",
        "name": "🛡️ Black Division Tier-1 «Obsidian Plate»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 195, "combat": 40, "durability": 185, "max_durability": 185, "price": 58000000,
        "desc": "Секретный штурмовой бронежилет элитных ликвидаторов Black Division из черного монолитного карбида бора."
    },
    {
        "id": "armor_iron_vanguard",
        "name": "🛡️ Тяжелый плитник USEC «Iron Vanguard»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 180, "combat": 32, "durability": 170, "max_durability": 170, "price": 50000000,
        "desc": "Фронтальный плитник ударных отрядов частной корпорации USEC с плитами уровня защиты NIJ IV."
    },
    {
        "id": "armor_crye_gen4_heavy",
        "name": "🛡️ Композитный жилет «Crye Precision Gen4 Heavy»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 183, "combat": 34, "durability": 172, "max_durability": 172, "price": 51000000,
        "desc": "Последнее поколение зарубежных армейских плитников с полной защитой боков и армированными стропами."
    },
    {
        "id": "armor_rhino_carrier",
        "name": "🛡️ Штурмовая баллистика «Rhino Carrier»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 178, "combat": 30, "durability": 168, "max_durability": 168, "price": 49000000,
        "desc": "Тяжелый тактический бронежилет с полиэтиленовыми плитами сверхвысокой молекулярной массы (UHMWPE)."
    },
    {
        "id": "armor_dreadnought_7",
        "name": "🛡️ Баллистический бронежилет «Dreadnought-7»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 192, "combat": 38, "durability": 180, "max_durability": 180, "price": 55000000,
        "desc": "Штурмовой баллистический экзо-жилет для операторов тяжелого вооружения и пулеметчиков прорыва."
    },
    {
        "id": "armor_warhound_tactical",
        "name": "🛡️ Наемный плитник «Warhound Tactical»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 175, "combat": 30, "durability": 165, "max_durability": 165, "price": 48000000,
        "desc": "Заказной бронежилет ветеранов частных военных кампаний в Африке и на Ближнем Востоке."
    },
    {
        "id": "armor_colossus_iv",
        "name": "🛡️ Сверхпрочный бронежилет «Colossus Level IV»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 187, "combat": 36, "durability": 177, "max_durability": 177, "price": 53000000,
        "desc": "Многослойный бронежилет с керамическими изогнутыми пластинами для защиты от бронебойных патронов 7.62x54R."
    },
    {
        "id": "armor_juggernaut_rig",
        "name": "🛡️ Тактический бронекостюм «Juggernaut-Rig»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 189, "combat": 37, "durability": 179, "max_durability": 179, "price": 54000000,
        "desc": "Комплект штурмового оператора повышенной защищенности. Защищает жизненно важные артерии и органы."
    },
    {
        "id": "armor_marauder_heavy",
        "name": "🛡️ Бронежилет ЧВК «Marauder Heavy»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 173, "combat": 29, "durability": 163, "max_durability": 163, "price": 47000000,
        "desc": "Тяжелый мародерский бронежилет с дополнительными стальными пластинами на животе и спине."
    },
    {
        "id": "armor_ghost_recon_carrier",
        "name": "🛡️ Закаленный плитник «Ghost Recon Carrier»",
        "category": "armor", "subcategory": "vest", "market_cat": "Бронежилеты",
        "rarity": "mythic", "armor": 177, "combat": 32, "durability": 167, "max_durability": 167, "price": 49000000,
        "desc": "Малозаметный высококлассный плитник спецгрупп тайных операций со встроенной амортизацией ударов."
    }
]

MYTHIC_ARMORS_BY_ID = {a["id"]: a for a in MYTHIC_ARMORS}

# ----------------- COOLDOWNS & RESERVE VAULT MECHANICS -----------------
COOLDOWN_3H = 3 * 3600  # 10,800 seconds (3 hours)

def can_claim_reserve_armor(player):
    """Checks if player owns the key and can claim the 24h mythic armor from Reserve Vault."""
    if not has_mythic_item(player, "mythic_state_reserve_key"):
        return False, -1
    last_claim = player.get("last_reserve_armor_claim", 0)
    now = int(time.time())
    rem = COOLDOWN_24H - (now - last_claim)
    if rem <= 0:
        return True, 0
    return False, rem

def claim_reserve_armor_supply(player):
    """
    Rolls 1 random armor from the 50 MYTHIC_ARMORS pool and adds it to player's stash.
    Returns (success: bool, item: dict or None, msg: str).
    """
    can_claim, rem = can_claim_reserve_armor(player)
    if not can_claim:
        if rem == -1 or not has_mythic_item(player, "mythic_state_reserve_key"):
            return False, None, "❌ У вас отсутствует Ключ от Спецхрана Росрезерва! Ключ выпадает только из кейса TerraGroup за 2 500 000 ₽."
        hrs = rem // 3600
        mins = (rem % 3600) // 60
        return False, None, f"Кулдаун арсенала еще активен. До следующей поставки: {hrs}ч {mins}м"
    
    armor = random.choice(MYTHIC_ARMORS)
    uid = f"armor_res_{int(time.time())}_{random.randint(1000, 9999)}"
    item = {
        "uid": uid,
        "item_id": armor["id"],
        "name": armor["name"],
        "category": "armor",
        "subcategory": "vest",
        "armor": armor["armor"],
        "combat": armor.get("combat", 30),
        "durability": armor["durability"],
        "max_durability": armor["max_durability"],
        "price": armor["price"],
        "rarity": "mythic"
    }
    player.setdefault("stash", []).append(item)
    player["last_reserve_armor_claim"] = int(time.time())
    return True, item, f"Получен {armor['name']} (Броня: +{armor['armor']}, Прочность: {armor['durability']})!"

def can_send_reserve_contraband_truck(player):
    """Checks if player can send the 3h contraband truck."""
    if not has_mythic_item(player, "mythic_state_reserve_key"):
        return False, -1
    last_truck = player.get("last_reserve_truck_time", 0)
    now = int(time.time())
    rem = COOLDOWN_3H - (now - last_truck)
    if rem <= 0:
        return True, 0
    return False, rem

def send_reserve_contraband_truck(player, item_uids=None):
    """
    Sends a heavy contraband truck loaded with up to 10 items from stash.
    Player receives 100% of their base market value without any dealer commissions.
    Returns (success: bool, msg: str, result_dict: dict).
    """
    can_send, rem = can_send_reserve_contraband_truck(player)
    if not can_send:
        if rem == -1 or not has_mythic_item(player, "mythic_state_reserve_key"):
            return False, "❌ У вас отсутствует Ключ от Спецхрана Росрезерва! Ключ выпадает только из кейса TerraGroup за 2 500 000 ₽.", {}
        hrs = rem // 3600
        mins = (rem % 3600) // 60
        secs = rem % 60
        time_str = f"{hrs}ч {mins}м" if hrs > 0 else f"{mins}м {secs}с"
        return False, f"Грузовик на спецмаршруте. Возвращение через: {time_str}", {}

    stash = player.get("stash", [])
    if not stash:
        return False, "Ваш схрон пуст! Нечего загружать в бронегрузовик.", {}

    # Identify currently equipped items in squad to protect them from accidental liquidation
    equipped_uids = set()
    for fighter in player.get("squad", []):
        for slot in ["weapon_uid", "armor_uid", "helmet_uid", "headset_uid"]:
            if fighter.get(slot):
                equipped_uids.add(fighter[slot])

    try:
        from tarkov_engine import ITEMS_BY_ID
    except ImportError:
        ITEMS_BY_ID = {}

    selected_items = []
    def is_protected(itm):
        if itm.get("uid") in equipped_uids:
            return True
        iid = str(itm.get("item_id", ""))
        # Protect all mythic items and boss relics
        if itm.get("rarity") in ["mythic", "relic"] or iid.startswith("relic_") or iid.startswith("mythic_") or iid in MYTHIC_ITEMS:
            return True
        info = ITEMS_BY_ID.get(iid, {})
        if info.get("rarity") in ["mythic", "relic"] or info.get("category") in ["special", "relic"]:
            return True
        return False

    if item_uids:
        uid_set = set(item_uids[:10])
        for itm in stash:
            if itm.get("uid") in uid_set and not is_protected(itm):
                selected_items.append(itm)
    else:
        # Auto-select up to 10 unequipped items, prioritizing highest value
        candidates = [itm for itm in stash if not is_protected(itm)]
        if not candidates:
            return False, "В схроне нет свободных (не экипированных) предметов для отправки!", {}
        
        def get_item_val(itm):
            p = itm.get("price")
            if p is not None and p > 0:
                return p
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            return info.get("price", 100000)

        candidates.sort(key=get_item_val, reverse=True)
        selected_items = candidates[:10]

    if not selected_items:
        return False, "Не удалось сформировать партию груза для отправки.", {}

    total_value = 0
    sold_details = []
    selected_uids = {itm.get("uid") for itm in selected_items}

    for itm in selected_items:
        price = itm.get("price")
        if price is None or price <= 0:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            price = info.get("price", 100000)
        total_value += price
        name = itm.get("name") or ITEMS_BY_ID.get(itm.get("item_id"), {}).get("name", "Военный предмет")
        sold_details.append({"name": name, "price": price})

    # Remove sold items from stash
    player["stash"] = [itm for itm in stash if itm.get("uid") not in selected_uids]
    
    # Credit 100% full rubles to player balance
    player["money"] = player.get("money", 0) + total_value
    player["last_reserve_truck_time"] = int(time.time())

    return True, f"Грузовик успешно доставил {len(selected_items)} предметов контрабанды!", {
        "items_count": len(selected_items),
        "total_value": total_value,
        "sold_items": sold_details
    }
