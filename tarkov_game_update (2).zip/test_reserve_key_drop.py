# -*- coding: utf-8 -*-
"""
Test Suite for Mythic Reserve Key Drop Mechanics in 2.5M TerraGroup Case
Verifies:
1. Drop rates match Mythic Goons Token exactly across all Prestige tiers (0 to 5).
2. Rate scales with player prestige.
3. Case for 2.5M can drop mythic_state_reserve_key.
4. Prestige reset preserves mythic_state_reserve_key.
5. Bot message formatting is correct.
"""
import random
import unittest
from unittest.mock import patch

from prestige import (
    get_player_prestige,
    get_goons_token_drop_chance,
    get_reserve_key_drop_chance,
    execute_prestige_reset
)
from loot_generator import generate_container_loot
from mythic_system import (
    MYTHIC_ITEMS,
    add_mythic_item_to_player,
    has_mythic_item
)

class TestReserveKeyDrop(unittest.TestCase):
    def test_drop_chances_match_goons_token(self):
        """Verify get_reserve_key_drop_chance matches get_goons_token_drop_chance across all tiers."""
        expected_rates = {
            0: 0.0001,  # 0.01% (1 in 10,000)
            1: 0.0005,  # 0.05% (5x)
            2: 0.0015,  # 0.15% (15x)
            3: 0.0035,  # 0.35% (35x)
            4: 0.0075,  # 0.75% (75x)
            5: 0.0150,  # 1.50% (150x)
        }
        for tier, expected in expected_rates.items():
            dummy_player = {"prestige": tier}
            goons_rate = get_goons_token_drop_chance(dummy_player)
            reserve_rate = get_reserve_key_drop_chance(dummy_player)
            self.assertEqual(goons_rate, expected, f"Tier {tier} goons rate mismatch")
            self.assertEqual(reserve_rate, expected, f"Tier {tier} reserve key rate mismatch")
            self.assertEqual(reserve_rate, goons_rate, f"Tier {tier} reserve rate must equal goons rate")

            # Also check integer argument
            self.assertEqual(get_reserve_key_drop_chance(tier), expected)

    def test_prestige_scaling_strictly_increasing(self):
        """Verify that drop chance scales with every prestige level."""
        chances = [get_reserve_key_drop_chance(t) for t in range(6)]
        for i in range(1, len(chances)):
            self.assertGreater(chances[i], chances[i-1], f"Tier {i} must have higher chance than {i-1}")
        self.assertEqual(chances[5] / chances[0], 150.0, "Prestige 5 should provide 150x multiplier")

    def test_container_drop_simulation(self):
        """Test that terragroup_case_2500k can drop mythic_state_reserve_key when roll succeeds."""
        player = {"user_id": 101, "prestige": 0, "stash": [], "mythic_items": []}
        
        # Force the random roll for reserve key to hit (< 0.0001)
        # In generate_container_loot:
        # roll 1: outcome roll
        # roll 2: item count
        # roll 3: relic check (we pass > 0.01)
        # roll 4: goons check (we pass > token_chance)
        # roll 5: reserve key check (we pass < reserve_key_chance)
        
        call_count = 0
        def mock_random():
            nonlocal call_count
            call_count += 1
            # Return high for general loot rolls, low specifically when checking reserve key
            return 0.5

        # Direct verification with patched random for reserve key
        with patch("loot_generator.random.random", side_effect=[
            0.5,   # loot outcome roll
            0.99,  # relic roll (no relic)
            0.99,  # goons roll (no goons)
            0.00001 # reserve key roll (HIT!)
        ]):
            res = generate_container_loot("terragroup_case_2500k", player)
            self.assertIsNotNone(res.get("mythic_won"))
            self.assertEqual(res["mythic_won"]["id"], "mythic_state_reserve_key")
            item_ids = [it["id"] for it in res["items"]]
            self.assertIn("mythic_state_reserve_key", item_ids)
            self.assertTrue(any(m["id"] == "mythic_state_reserve_key" for m in res.get("mythics_won", [])))

    def test_both_mythics_can_be_tracked(self):
        """Verify that if both roll, both are recorded in mythics_won and total value reflects both."""
        player = {"user_id": 102, "prestige": 5, "stash": [], "mythic_items": []}
        with patch("loot_generator.random.random", side_effect=[
            0.5,    # outcome
            0.99,   # relic roll
            0.00001,# goons roll (HIT!)
            0.00001 # reserve key roll (HIT!)
        ]):
            res = generate_container_loot("terragroup_case_2500k", player)
            won_ids = [m["id"] for m in res.get("mythics_won", [])]
            self.assertIn("mythic_goons_token", won_ids)
            self.assertIn("mythic_state_reserve_key", won_ids)
            self.assertEqual(len(won_ids), 2)

    def test_prestige_reset_preserves_reserve_key(self):
        """Verify execute_prestige_reset keeps mythic_state_reserve_key."""
        test_player = {
            "user_id": 999,
            "prestige": 1,
            "level": 10,
            "money": 100_000_000,
            "raids_count": 100,
            "stash": [
                {"uid": "key_1", "item_id": "mythic_state_reserve_key", "rarity": "mythic"},
                {"uid": "junk_1", "item_id": "bandage_common"}
            ],
            "mythic_items": ["mythic_state_reserve_key"],
            "special_businesses": {},
            "clothes_stash": [],
            "equipped_clothes": {}
        }
        success = execute_prestige_reset(test_player, 2)
        self.assertTrue(success)
        self.assertIn("mythic_state_reserve_key", test_player["mythic_items"])
        stash_ids = [it["item_id"] for it in test_player["stash"]]
        self.assertIn("mythic_state_reserve_key", stash_ids)
        self.assertNotIn("bandage_common", stash_ids)

    def test_add_mythic_item_to_player(self):
        """Verify adding key updates both mythic_items list and player stash."""
        player = {"user_id": 555, "stash": [], "mythic_items": []}
        add_mythic_item_to_player(player, "mythic_state_reserve_key")
        self.assertTrue(has_mythic_item(player, "mythic_state_reserve_key"))
        self.assertTrue(any(it["item_id"] == "mythic_state_reserve_key" for it in player["stash"]))

if __name__ == "__main__":
    print("=== RUNNING RESERVE KEY DROP TESTS ===")
    unittest.main(verbosity=2)
