# -*- coding: utf-8 -*-
"""
Generator tool for coop_events_data.py
Creates all 10 locations with 15 acts + evacuation acts, with 0-damage safe options and clear consequences.
"""
import json

def generate():
    with open("/app/applet/build_complete_coop.py", "r", encoding="utf-8") as f:
        core = f.read()
    print("Core script read")

if __name__ == "__main__":
    generate()
