# -*- coding: utf-8 -*-
"""
Duo Cooperative Raids System (Interactive Roguelike for 2 Online Players)
Features:
- Exclusively 2 players (Duo with their Signature PMCs).
- Pure HP and DMG system with visual color-coded health bars (no armor durability, no ammo mechanics).
- 15 total Acts with progressive scaling and a Final Super-Boss at Act 15.
- Evacuation option appears after Act 5 (requires surviving 3 intense escape acts).
- After EACH Act, both players individually choose 1 out of 3 offered perks.
- Perks are fully stackable with level scaling (x1, x2, x3...).
- Extensive event bank for all 10 locations + evacuation encounters.
"""

import time
import random
import html
import copy

try:
    from telebot import types
except ImportError:
    types = None

from tarkov_engine import (
    save_db, calculate_squad_power, ITEMS_BY_ID, PMC_DEFINITIONS,
    can_store_item, add_player_rubles, add_player_exp
)
from mythic_system import add_mythic_item_to_player
try:
    from relics_system import has_boss_set_bonus
except ImportError:
    def has_boss_set_bonus(p, b): return False
from gd_military_system import has_gd_business, add_gd_bp_exp, roll_gd_raid_weapon

from coop_events_data import (
    COOP_LOCATIONS, COOP_PERKS, TACTICAL_TOOLS, RAID_MODIFIERS,
    roll_event_for_act, get_random_perks_choice, roll_raid_modifier,
    calculate_player_combat_stats, format_hp_bar
)
from coop_narrative import generate_action_chronicle, format_short_alert

def fmt_rub(val):
    return f"{int(val):,} ₽".replace(",", " ")

def get_leader_keycard(player):
    """Finds an unused legendary keycard in player's stash."""
    stash = player.get("stash", [])
    for itm in stash:
        if itm.get("equipped_to") is None:
            info = ITEMS_BY_ID.get(itm.get("item_id"), {})
            iid = info.get("id", "").lower()
            name = info.get("name", "").lower()
            if "keycard" in iid or "ключ-карт" in name:
                return itm, info
    return None, None

# ----------------- CO-OP PROGRESSIVE LOOT SYSTEM (NON-MYTHIC) -----------------
NON_MYTHIC_POOLS = {
    "common": [],
    "rare": [],
    "epic": [],
    "legendary": []
}

def _init_non_mythic_pools():
    if not NON_MYTHIC_POOLS["common"]:
        for iid, itm in ITEMS_BY_ID.items():
            r = itm.get("rarity", "common")
            # Strict rule: Exclude ALL mythics (only Act 15 climax drops mythic case)
            if r in NON_MYTHIC_POOLS and not iid.startswith("mythic_"):
                NON_MYTHIC_POOLS[r].append(iid)

def roll_coop_act_loot(act_num, is_boss=False, is_elite=False, extra_items_bonus=0):
    """
    Rolls non-mythic in-raid loot scaled by act depth.
    - Excludes ANY mythic items.
    - The deeper the act, the higher the tier and value of loot.
    """
    _init_non_mythic_pools()

    # Progressive rarity distribution based on act depth
    if is_boss or act_num >= 15:
        # Act 15 Super-Boss: 65% Legendary, 35% Epic, 0% Rare, 0% Common
        weights = {"common": 0.0, "rare": 0.0, "epic": 0.35, "legendary": 0.65}
        count = 3 + extra_items_bonus
    elif act_num >= 13:
        weights = {"common": 0.0, "rare": 0.15, "epic": 0.45, "legendary": 0.40}
        count = 2 + (1 if random.random() < 0.40 else 0) + extra_items_bonus
    elif act_num >= 10:
        weights = {"common": 0.05, "rare": 0.25, "epic": 0.45, "legendary": 0.25}
        count = 2 if is_elite else (1 + (1 if random.random() < 0.50 else 0)) + extra_items_bonus
    elif act_num >= 7:
        weights = {"common": 0.10, "rare": 0.40, "epic": 0.40, "legendary": 0.10}
        count = 1 + (1 if random.random() < 0.35 else 0) + extra_items_bonus
    elif act_num >= 4:
        weights = {"common": 0.25, "rare": 0.55, "epic": 0.20, "legendary": 0.0}
        count = 2 if is_elite else 1 + extra_items_bonus
    else:
        # Acts 1-3
        weights = {"common": 0.70, "rare": 0.30, "epic": 0.0, "legendary": 0.0}
        count = 1 + extra_items_bonus

    rarities = ["common", "rare", "epic", "legendary"]
    w_list = [weights[r] for r in rarities]

    dropped = []
    for _ in range(max(1, count)):
        chosen_rarity = random.choices(rarities, weights=w_list, k=1)[0]
        pool = NON_MYTHIC_POOLS.get(chosen_rarity) or NON_MYTHIC_POOLS["common"]
        if not pool:
            continue
        item_id = random.choice(pool)
        item_info = ITEMS_BY_ID.get(item_id, {})
        dropped.append({
            "id": item_id,
            "name": item_info.get("name", item_id),
            "rarity": item_info.get("rarity", chosen_rarity),
            "price": item_info.get("price", 50000)
        })
    return dropped

# =====================================================================
# 1. CO-OP MAIN MENU & LOCATION BROWSING
# =====================================================================
def handle_menu_coop(chat_id, msg_id, player, db, bot):
    """Main cooperative raids menu showing active lobbies and location choices."""
    lobbies = db.setdefault("coop_lobbies", {})
    active_lobbies = [lob for lob in lobbies.values() if lob.get("status") in ("waiting", "in_raid")]

    txt = (
        "<b>👥 ДУО КООПЕРАТИВНЫЕ РЕЙДЫ (2 ИГРОКА ОНЛАЙН)</b>\n"
        "────────────────────────\n"
        "Объединяйтесь в боевую пару со своими Сигнатурными ЧВК!\n"
        "• <b>Формат:</b> строго 2 игрока (Дуо-связка)\n"
        "• <b>Боевая система:</b> честная шкала ❤️ HP и показатель 💥 DMG\n"
        "• <b>15 этапов (актов):</b> уникальные события на каждой локации\n"
        "• <b>Выбор перков:</b> после каждого акта каждый боец выбирает 1 из 3 перков\n"
        "• <b>Стаки перков:</b> любые перки складываются и прокачиваются (x1, x2, x3...)\n"
        "• 🚪 <b>Эвакуация:</b> после 5 акта доступна кнопка «Идти на выход» (3 опасных акта прорыва)\n"
        "• 👑 <b>Финал:</b> на 15 акте ждет легендарный Сверхбосс локации с мега-наградой!\n"
        "────────────────────────\n"
    )

    now = time.time()
    if player.get("coop_cooldown_until", 0) > now:
        rem = int((player["coop_cooldown_until"] - now) // 60)
        txt += f"🚑 <b>ВАШ ЧВК В МЕДБЛОКЕ:</b> еще {rem} мин. до восстановления!\n\n"

    txt += "<b>Выберите локацию для парного рейда:</b>"

    markup = types.InlineKeyboardMarkup(row_width=1)
    for loc_key, loc in COOP_LOCATIONS.items():
        markup.add(
            types.InlineKeyboardButton(
                f"{loc['badge']} {loc['name']} — {loc['difficulty_label']}",
                callback_data=f"coop_view_{loc_key}"
            )
        )

    # Show my active lobby or search
    my_lobby = next((lob for lob in active_lobbies if str(lob.get("leader_id")) == str(player["user_id"]) or any(str(m.get("user_id")) == str(player["user_id"]) for m in lob.get("members", []))), None)
    if my_lobby:
        status_label = "РЕЙД ИДЕТ" if my_lobby.get("status") == "in_raid" else "ОЖИДАНИЕ"
        markup.add(
            types.InlineKeyboardButton(f"👉 ВЕРНУТЬСЯ В ВАШЕ ДУО-ЛОББИ ({status_label})", callback_data=f"join_coop_{my_lobby['id']}")
        )

    waiting_lobbies = [lob for lob in active_lobbies if lob.get("status") == "waiting"]
    if waiting_lobbies:
        txt += f"\n\n<b>Открытые лобби в поиске напарника ({len(waiting_lobbies)}):</b>"
        for lob in waiting_lobbies[:5]:
            loc = COOP_LOCATIONS.get(lob.get("diff_key"), COOP_LOCATIONS["factory"])
            m_cnt = len(lob.get("members", []))
            markup.add(
                types.InlineKeyboardButton(
                    f"⚔️ {loc['badge']} {loc['name']} от @{lob.get('leader_name', 'Лидер')} ({m_cnt}/2)",
                    callback_data=f"join_coop_{lob['id']}"
                )
            )

    markup.add(types.InlineKeyboardButton("🔙 К Меню Рейдов", callback_data="menu_raids"))
    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception:
        try:
            bot.send_message(chat_id, txt, reply_markup=markup)
        except Exception:
            pass

def handle_coop_difficulty_view(chat_id, msg_id, player, loc_key, bot):
    """Shows details about the selected location before lobby creation."""
    loc = COOP_LOCATIONS.get(loc_key, COOP_LOCATIONS["factory"])

    txt = (
        f"<b>{loc['badge']} ЛОКАЦИЯ ДУО: {loc['name']}</b>\n"
        f"────────────────────────\n"
        f"<i>{loc['desc']}</i>\n\n"
        f"⚔️ <b>Сложность:</b> {loc['difficulty_label']}\n"
        f"🎯 <b>Пул врагов:</b> {loc['base_enemy_hp'][0]}–{loc['base_enemy_hp'][1]} HP\n"
        f"👑 <b>Сверхбосс 15 акта:</b> <b>{loc['boss_name']}</b> ({loc['boss_hp']} HP | 💥 {loc['boss_dmg']} DMG)\n"
        f"💰 <b>Коэффициент добычи:</b> x{loc['rubles_scale']}\n"
        f"🚪 <b>Эвакуация:</b> возможна после 5 акта (3 этапа отхода)\n"
        f"────────────────────────\n"
        f"<i>При высадке оба бойца входят со своими Сигнатурными ЧВК и базовыми 100 HP.</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(f"🚀 Создать Дуо-лобби (1/2)", callback_data=f"create_coop_{loc_key}")
    )
    markup.add(types.InlineKeyboardButton("🔙 К списку локаций", callback_data="menu_coop_raids"))
    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception:
        try:
            bot.send_message(chat_id, txt, reply_markup=markup)
        except Exception:
            pass

# =====================================================================
# 2. DUO LOBBY CREATION, JOINING & STARTING
# =====================================================================
def handle_create_coop_lobby(call, player, db, loc_key, bot):
    now = int(time.time())
    loc = COOP_LOCATIONS.get(loc_key, COOP_LOCATIONS["factory"])

    if player.get("coop_cooldown_until", 0) > now:
        rem = int((player["coop_cooldown_until"] - now) // 60)
        bot.answer_callback_query(call.id, f"🚑 Ваш сигнатурный ЧВК в медблоке! Восстановление: {rem} мин.", show_alert=True)
        return

    if loc_key == "labs":
        kc_itm, kc_info = get_leader_keycard(player)
        if not kc_itm:
            bot.answer_callback_query(call.id, "🔒 Для рейда в Лабораторию требуется Ключ-карта доступа TerraGroup Labs!", show_alert=True)
            return

    lobby_id = f"coop_{now}_{random.randint(100, 999)}"
    pow_val, arm_val = calculate_squad_power(player)

    lobby = {
        "id": lobby_id,
        "leader_id": player["user_id"],
        "leader_name": player.get("username", f"PMC_{player['user_id']}"),
        "diff_key": loc_key,
        "created_at": now,
        "status": "waiting",
        "chat_id": call.message.chat.id,
        "message_id": call.message.message_id,
        "members": [
            {
                "user_id": player["user_id"],
                "username": player.get("username", f"PMC_{player['user_id']}"),
                "pmc_signature": player.get("pmc_signature", "Viper"),
                "custom_pmc_callsign": player.get("custom_pmc_callsign"),
                "power": pow_val,
                "chat_id": call.message.chat.id,
                "message_id": call.message.message_id
            }
        ]
    }

    db.setdefault("coop_lobbies", {})[lobby_id] = lobby
    save_db(db)

    bot.answer_callback_query(call.id, f"✅ Дуо-лобби создано! Ожидаем напарника (1/2).")
    render_lobby_ui(call.message.chat.id, call.message.message_id, lobby, player, bot)

def render_lobby_ui(chat_id, msg_id, lobby, viewer_player, bot):
    loc = COOP_LOCATIONS.get(lobby.get("diff_key"), COOP_LOCATIONS["factory"])
    members = lobby.get("members", [])
    m_count = len(members)

    txt = (
        f"<b>🛡️ ДУО-ЛОББИ РЕЙДА #{lobby['id'][-4:]}</b>\n"
        f"Локация: <b>{loc['badge']} {loc['name']}</b>\n"
        f"Лидер рейда: @{lobby['leader_name']}\n"
        f"Формат: <b>Строго 2 бойца ЧВК (Дуо)</b>\n"
        f"────────────────────────\n"
        f"<b>Бойцы в связке ({m_count}/2):</b>\n"
    )

    for idx, m in enumerate(members, start=1):
        p_info = PMC_DEFINITIONS.get(m['pmc_signature'], {})
        pmc_disp = m.get('custom_pmc_callsign') or m['pmc_signature']
        txt += f"{idx}. @{m['username']} — ЧВК {p_info.get('icon', '🎖️')} <b>{pmc_disp}</b> (Мощь: {m['power']})\n"

    if m_count < 2:
        txt += f"2. <i>Ожидание напарника... Отправьте ID #{lobby['id'][-4:]} другу!</i>\n"

    txt += (
        f"────────────────────────\n"
        f"<i>Как только напарник вступит в лобби (2/2), лидер сможет начать 15-этапный рейд!</i>"
    )

    markup = types.InlineKeyboardMarkup(row_width=1)
    is_leader = str(viewer_player.get("user_id")) == str(lobby.get("leader_id"))
    is_member = any(str(m.get("user_id")) == str(viewer_player.get("user_id")) for m in members)

    if not is_member and m_count < 2:
        markup.add(types.InlineKeyboardButton("➕ Вступить напарником (2/2)", callback_data=f"join_coop_{lobby['id']}"))

    if is_member and not is_leader:
        markup.add(types.InlineKeyboardButton("🚪 Покинуть лобби", callback_data=f"leave_coop_{lobby['id']}"))

    if is_leader:
        if m_count == 2:
            markup.add(types.InlineKeyboardButton("🚀 ВЫЙТИ В ДУО-РЕЙД (2/2 ГОТОВЫ)", callback_data=f"start_coop_{lobby['id']}"))
        else:
            markup.add(types.InlineKeyboardButton("⏳ Ожидание второго бойца (1/2)", callback_data="none"))
        markup.add(types.InlineKeyboardButton("❌ Распустить лобби", callback_data=f"cancel_coop_{lobby['id']}"))

    markup.add(types.InlineKeyboardButton("🔄 Обновить статус", callback_data=f"refresh_coop_{lobby['id']}"))
    markup.add(types.InlineKeyboardButton("🔙 К списку локаций", callback_data="menu_coop_raids"))

    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception:
        try:
            bot.send_message(chat_id, txt, reply_markup=markup)
        except Exception:
            pass

def handle_join_coop_lobby(call, player, db, lobby_id, bot):
    lobbies = db.setdefault("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby:
        bot.answer_callback_query(call.id, "❌ Лобби не найдено!", show_alert=True)
        return

    # If already in raid, re-render raid UI
    if lobby.get("status") == "in_raid":
        bot.answer_callback_query(call.id, "Возвращение в рейд...")
        render_duo_raid_screen(call.message.chat.id, call.message.message_id, lobby, str(player["user_id"]), db, bot)
        return

    members = lobby.setdefault("members", [])
    if any(str(m["user_id"]) == str(player["user_id"]) for m in members):
        bot.answer_callback_query(call.id, "Вы уже в лобби.")
        render_lobby_ui(call.message.chat.id, call.message.message_id, lobby, player, bot)
        return

    if len(members) >= 2:
        bot.answer_callback_query(call.id, "❌ В лобби уже есть напарник (2/2)!", show_alert=True)
        return

    now = int(time.time())
    if player.get("coop_cooldown_until", 0) > now:
        rem = int((player["coop_cooldown_until"] - now) // 60)
        bot.answer_callback_query(call.id, f"🚑 Ваш ЧВК в медблоке! Восстановление: {rem} мин.", show_alert=True)
        return

    pow_val, _ = calculate_squad_power(player)
    members.append({
        "user_id": player["user_id"],
        "username": player.get("username", f"PMC_{player['user_id']}"),
        "pmc_signature": player.get("pmc_signature", "Viper"),
        "custom_pmc_callsign": player.get("custom_pmc_callsign"),
        "power": pow_val,
        "chat_id": call.message.chat.id,
        "message_id": call.message.message_id
    })
    save_db(db)

    bot.answer_callback_query(call.id, "✅ Вы успешно вступили напарником!")
    render_lobby_ui(call.message.chat.id, call.message.message_id, lobby, player, bot)

    # Notify leader that partner joined
    leader_member = members[0]
    if str(leader_member["user_id"]) != str(player["user_id"]):
        try:
            render_lobby_ui(leader_member["chat_id"], leader_member["message_id"], lobby, leader_member, bot)
        except Exception:
            pass

def handle_leave_coop_lobby(call, player, db, lobby_id, bot):
    lobbies = db.setdefault("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "waiting":
        bot.answer_callback_query(call.id, "❌ Лобби не найдено!")
        return

    members = lobby.get("members", [])
    lobby["members"] = [m for m in members if str(m["user_id"]) != str(player["user_id"])]
    if str(player["user_id"]) == str(lobby.get("leader_id")):
        if lobby["members"]:
            new_lead = lobby["members"][0]
            lobby["leader_id"] = new_lead["user_id"]
            lobby["leader_name"] = new_lead["username"]
        else:
            lobbies.pop(lobby_id, None)
    save_db(db)

    bot.answer_callback_query(call.id, "🚪 Вы покинули лобби.")
    handle_menu_coop(call.message.chat.id, call.message.message_id, player, db, bot)

def handle_start_coop_lobby(call, player, db, lobby_id, bot):
    lobbies = db.setdefault("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "waiting":
        bot.answer_callback_query(call.id, "❌ Лобби уже запущено или не найдено!", show_alert=True)
        return

    if str(player.get("user_id")) != str(lobby.get("leader_id")):
        bot.answer_callback_query(call.id, "❌ Только лидер может запустить рейд!", show_alert=True)
        return

    members = lobby.get("members", [])
    if len(members) < 2:
        bot.answer_callback_query(call.id, "❌ В лобби должен быть второй боец (2/2)!", show_alert=True)
        return

    # Check medical cooldown for both members
    now_ts = int(time.time())
    for m in members:
        m_user = db.get("users", {}).get(str(m.get("user_id"))) or db.get("users", {}).get(m.get("user_id"))
        if m_user and m_user.get("coop_cooldown_until", 0) > now_ts:
            bot.answer_callback_query(call.id, f"🚑 Боец @{m.get('username')} находится в медблоке!", show_alert=True)
            return

    # Initialize full Duo Raid state
    loc_key = lobby.get("diff_key", "factory")
    p1_uid = str(members[0]["user_id"])
    p2_uid = str(members[1]["user_id"])

    p1_profile = db.get("users", {}).get(p1_uid, {})
    p2_profile = db.get("users", {}).get(p2_uid, {})

    p1_stats = calculate_player_combat_stats(p1_profile, {"perks": {}})
    p2_stats = calculate_player_combat_stats(p2_profile, {"perks": {}})

    raid_modifier = roll_raid_modifier()
    first_act_event = roll_event_for_act(loc_key, 1, raid_modifier=raid_modifier)

    starter_tool_key = random.choice(["recon_drone", "electronic_keycard", "propital_injector"])
    starter_tool_obj = copy.deepcopy(TACTICAL_TOOLS[starter_tool_key])

    raid_state = {
        "act": 1,
        "max_acts": 15,
        "is_evacuating": False,
        "evac_act": 0,
        "raid_bank": 100000,
        "raid_loot": [],
        "raid_modifier": raid_modifier,
        "tactical_tools": [starter_tool_obj],
        "used_event_ids": [first_act_event["id"]],
        "current_event": first_act_event,
        "combat_log": [
            f"🚀 Высадка произведена! Условия рейда: {raid_modifier.get('icon', '⚡')} {raid_modifier.get('name')}.",
            f"🎒 Взято спец-снаряжение: {starter_tool_obj.get('icon', '🧰')} <b>{starter_tool_obj.get('name')}</b> (новые инструменты выбиваются на Вехах 5 и 10, а также в Airdrop)."
        ],
        "perk_phase": False,
        "perk_offers": {},
        "chosen_perks": {},
        "players": {
            p1_uid: {
                "user_id": members[0]["user_id"],
                "username": members[0]["username"],
                "pmc_signature": members[0]["pmc_signature"],
                "custom_pmc_callsign": members[0].get("custom_pmc_callsign") or p1_profile.get("custom_pmc_callsign"),
                "hp": p1_stats["max_hp"],
                "max_hp": p1_stats["max_hp"],
                "perks": {},
                "status": "alive"
            },
            p2_uid: {
                "user_id": members[1]["user_id"],
                "username": members[1]["username"],
                "pmc_signature": members[1]["pmc_signature"],
                "custom_pmc_callsign": members[1].get("custom_pmc_callsign") or p2_profile.get("custom_pmc_callsign"),
                "hp": p2_stats["max_hp"],
                "max_hp": p2_stats["max_hp"],
                "perks": {},
                "status": "alive"
            }
        }
    }

    lobby["raid"] = raid_state
    lobby["status"] = "in_raid"
    save_db(db)

    bot.answer_callback_query(call.id, "🚀 Высадка в рейд началась!")
    sync_duo_raid_ui(lobby, db, bot)

# =====================================================================
# 3. INTERACTIVE DUO RAID SCREEN & SYNC
# =====================================================================
def sync_duo_raid_ui(lobby, db, bot):
    """Refreshes the live raid screen for both players in the Duo."""
    members = lobby.get("members", [])
    for m in members:
        uid = str(m.get("user_id"))
        chat_id = m.get("chat_id")
        msg_id = m.get("message_id")
        if chat_id and msg_id:
            try:
                render_duo_raid_screen(chat_id, msg_id, lobby, uid, db, bot)
            except Exception:
                pass

def render_duo_raid_screen(chat_id, msg_id, lobby, viewer_uid, db, bot):
    raid = lobby.get("raid", {})
    loc_key = lobby.get("diff_key", "factory")
    loc = COOP_LOCATIONS.get(loc_key, COOP_LOCATIONS["factory"])
    players = raid.get("players", {})

    p_ids = list(players.keys())
    p1 = players.get(p_ids[0]) if len(p_ids) > 0 else None
    p2 = players.get(p_ids[1]) if len(p_ids) > 1 else None

    # Calculate live combat stats
    p1_prof = db.get("users", {}).get(p_ids[0], {}) if len(p_ids) > 0 else {}
    p2_prof = db.get("users", {}).get(p_ids[1], {}) if len(p_ids) > 1 else {}
    p1_stats = calculate_player_combat_stats(p1_prof, p1) if p1 else {}
    p2_stats = calculate_player_combat_stats(p2_prof, p2) if p2 else {}

    # Header
    if raid.get("is_evacuating"):
        header = f"🚨 <b>ЭВАКУАЦИЯ ДУО: {loc['badge']} {loc['name']} (АКТ {raid.get('evac_act', 1)} / 3)</b>"
    else:
        header = f"⚔️ <b>ДУО-РЕЙД: {loc['badge']} {loc['name']} (АКТ {raid.get('act', 1)} / 15)</b>"

    txt = f"{header}\n────────────────────────\n👥 <b>ВАША СВЯЗКА ЧВК:</b>\n"

    # Display P1
    if p1:
        p1_bar = format_hp_bar(p1.get("hp", 0), p1_stats.get("max_hp", 100))
        p1_badge = "💀 Без сознания" if p1.get("hp", 0) <= 0 else f"❤️ {p1_bar} | 💥 {p1_stats.get('dmg', 35)} DMG"
        p1_perk_count = sum(p1.get("perks", {}).values())
        p1_pmc = p1_prof.get("custom_pmc_callsign") or p1.get("custom_pmc_callsign") or p1.get("pmc_signature", "Viper")
        txt += f" • @{p1.get('username')} (<b>{p1_pmc}</b>): {p1_badge} [Перков: {p1_perk_count}]\n"

    # Display P2
    if p2:
        p2_bar = format_hp_bar(p2.get("hp", 0), p2_stats.get("max_hp", 100))
        p2_badge = "💀 Без сознания" if p2.get("hp", 0) <= 0 else f"❤️ {p2_bar} | 💥 {p2_stats.get('dmg', 35)} DMG"
        p2_perk_count = sum(p2.get("perks", {}).values())
        p2_pmc = p2_prof.get("custom_pmc_callsign") or p2.get("custom_pmc_callsign") or p2.get("pmc_signature", "Viper")
        txt += f" • @{p2.get('username')} (<b>{p2_pmc}</b>): {p2_badge} [Перков: {p2_perk_count}]\n"

    txt += f"\n💰 <b>Банк хабара:</b> {fmt_rub(raid.get('raid_bank', 0))} | 📦 <b>Трофеев:</b> {len(raid.get('raid_loot', []))} шт.\n"

    # Tactical conditions and equipment
    mod = raid.get("raid_modifier")
    if mod:
        txt += f"🌀 <b>Условия рейда:</b> {mod.get('icon', '⚡')} <b>{mod.get('name')}</b> — <i>{mod.get('desc')}</i>\n"

    tools = raid.get("tactical_tools", [])
    if tools:
        tool_names = ", ".join([f"{t.get('icon', '🧰')} <b>{t.get('name')}</b>" for t in tools])
        txt += f"🧰 <b>Спец-снаряжение отряда:</b> {tool_names}\n"
    else:
        txt += "🧰 <b>Снаряжение:</b> <i>Штатный комплект ЧВК (мультитул, саперный щуп, респиратор, отмычки) готов к бою.</i>\n"

    txt += "────────────────────────\n"

    # Display Book-format Tactical Chronicle
    latest_narrative = raid.get("latest_narrative")
    if latest_narrative:
        txt += f"{latest_narrative}\n"
        txt += "────────────────────────\n"

    # Display Combat Log
    combat_log = raid.get("combat_log", [])
    if combat_log:
        txt += "<b>Боевая сводка:</b>\n"
        for log_line in combat_log[-3:]:
            txt += f"<i>{log_line}</i>\n"
        txt += "────────────────────────\n"

    markup = types.InlineKeyboardMarkup(row_width=1)

    # -------------------------------------------------------------
    # PHASE A: PERK SELECTION (AFTER EACH ACT)
    # -------------------------------------------------------------
    if raid.get("perk_phase"):
        chosen_perks = raid.get("chosen_perks", {})
        my_choice = chosen_perks.get(viewer_uid)
        
        if my_choice:
            p_info = COOP_PERKS.get(my_choice, {})
            txt += f"\n✅ <b>Вы выбрали усиление:</b> {p_info.get('icon', '✨')} <b>{p_info.get('name', my_choice)}</b>\n"
            txt += "⏳ <i>Ожидаем, пока напарник выберет свой перк...</i>"
            markup.add(types.InlineKeyboardButton("🔄 Обновить статус выбора", callback_data=f"refresh_coop_{lobby['id']}"))
            markup.add(types.InlineKeyboardButton("⚡ Напарник задерживается: Авто-перк и далее ▶", callback_data=f"coop_prk_auto::{lobby['id']}"))
        else:
            txt += "\n🎖 <b>ЭТАП ЗАВЕРШЕН! ВЫБЕРИТЕ УСИЛЕНИЕ ОПЕРАТОРА:</b>\n"
            txt += "<i>Выберите 1 из 3 предложенных перков для прокачки своего ЧВК:</i>\n"
            my_offers = raid.get("perk_offers", {}).get(viewer_uid, [])
            for p in my_offers:
                lvl_str = f" [x{p['next_level']}]" if p['cur_level'] > 0 else " [Новый]"
                txt += f"\n{p['icon']} <b>{p['name']}{lvl_str}</b>: {p['desc']}"
                markup.add(
                    types.InlineKeyboardButton(
                        f"{p['icon']} Выбрать: {p['name']}{lvl_str}",
                        callback_data=f"coop_prk_{p['id']}::{lobby['id']}"
                    )
                )
    # -------------------------------------------------------------
    # PHASE B: TACTICAL EVENT / COMBAT
    # -------------------------------------------------------------
    else:
        evt = raid.get("current_event", {})
        txt += f"⚠️ <b>СОБЫТИЕ: {evt.get('title', 'Боевое столкновение')}</b>\n"
        txt += f"{evt.get('desc', '')}\n\n"

        if evt.get("enemy_name"):
            e_cur = max(0, evt.get("enemy_hp", 0))
            e_max = evt.get("enemy_max_hp", 100)
            e_bar = format_hp_bar(e_cur, e_max)
            txt += f"🎯 <b>Противник/Препятствие:</b> {evt.get('enemy_name')}\n"
            txt += f"Прочность/HP: {e_bar} | 💥 Потенциальный урон: {evt.get('enemy_dmg', 20)} DMG\n"

        # Display full tactical choices with risk level indicators
        options = evt.get("options", [])
        if options:
            txt += "\n📋 <b>Варианты решений и риски:</b>\n"
            for idx, opt in enumerate(options, 1):
                r_level = opt.get("risk", "medium")
                if r_level == "safe":
                    r_badge = "🟢 Безопасно (0 урона)"
                elif r_level == "low":
                    r_badge = "🟡 Низкий риск"
                elif r_level == "high":
                    r_badge = "☠️ Высокий риск (+хабар)"
                else:
                    r_badge = "🔴 Штурм/Контакт"
                txt += f" <b>{idx}.</b> {opt.get('text', 'Действие')} [<i>{r_badge}</i>]\n"

        # Action buttons
        for idx, opt in enumerate(options):
            btn_title = opt.get('text', 'Тактическое действие')
            if len(btn_title) > 46:
                btn_title = btn_title[:44] + "..."
            markup.add(
                types.InlineKeyboardButton(
                    f"▶ {idx+1}. {btn_title}",
                    callback_data=f"coop_act_{idx}::{lobby['id']}"
                )
            )

        # Evacuation Button (Available after Act 5 if not already evacuating)
        if raid.get("act", 1) >= 5 and not raid.get("is_evacuating"):
            markup.add(
                types.InlineKeyboardButton(
                    "🚪 НАЧАТЬ ЭВАКУАЦИЮ (3 опасных акта отхода)",
                    callback_data=f"coop_evac::{lobby['id']}"
                )
            )

    try:
        bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
    except Exception:
        try:
            bot.send_message(chat_id, txt, reply_markup=markup)
        except Exception:
            pass

# =====================================================================
# 4. TURN COMBAT & EVENT EXECUTION
# =====================================================================
def handle_duo_action(call, player, db, lobby_id, option_idx, bot):
    """Executes a tactical action chosen by either member of the Duo."""
    lobbies = db.setdefault("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "in_raid":
        bot.answer_callback_query(call.id, "❌ Рейд уже завершен или не найден!")
        return

    raid = lobby.get("raid", {})
    if raid.get("perk_phase"):
        bot.answer_callback_query(call.id, "⚠️ Сначала выберите перк!")
        return

    # Race condition concurrency lock
    if raid.get("action_in_progress"):
        bot.answer_callback_query(call.id, "⏳ Боевое действие уже рассчитывается...")
        return
    raid["action_in_progress"] = True

    evt = raid.get("current_event", {})
    options = evt.get("options", [])
    chosen_opt = options[option_idx] if 0 <= option_idx < len(options) else options[0]

    # Check tactical tool requirements (e.g. keycard, c4, thermal)
    req_tool_id = chosen_opt.get("requires_tool")
    if req_tool_id:
        held_tool_ids = [t["id"] if isinstance(t, dict) else t for t in raid.get("tactical_tools", [])]
        if req_tool_id not in held_tool_ids:
            tool_def = TACTICAL_TOOLS.get(req_tool_id, {})
            tool_name = tool_def.get("name", req_tool_id)
            tool_icon = tool_def.get("icon", "🧰")
            bot.answer_callback_query(
                call.id,
                f"🔒 Требуется спец-инструмент: {tool_icon} {tool_name}!\nДобывается в схронах, у командиров секторов или на этапах Вех.",
                show_alert=True
            )
            return

    caller_name = player.get("username", "Оператор")
    caller_uid = str(player.get("user_id"))

    # Ensure member chat_id and message_id are in sync with current callback message
    for m in lobby.get("members", []):
        if str(m.get("user_id")) == caller_uid:
            m["chat_id"] = call.message.chat.id
            m["message_id"] = call.message.message_id

    players = raid.get("players", {})
    p_ids = list(players.keys())
    p1 = players.get(p_ids[0]) if len(p_ids) > 0 else None
    p2 = players.get(p_ids[1]) if len(p_ids) > 1 else None

    p1_prof = db.get("users", {}).get(p_ids[0], {}) if len(p_ids) > 0 else {}
    p2_prof = db.get("users", {}).get(p_ids[1], {}) if len(p_ids) > 1 else {}
    p1_stats = calculate_player_combat_stats(p1_prof, p1) if p1 else {}
    p2_stats = calculate_player_combat_stats(p2_prof, p2) if p2 else {}

    # Identify caller and partner PMC display callsigns
    p1_callsign = p1_prof.get("custom_pmc_callsign") or (p1.get("username") if p1 else "Боец 1")
    p2_callsign = p2_prof.get("custom_pmc_callsign") or (p2.get("username") if p2 else "Боец 2")
    if p1 and str(p1.get("user_id")) == caller_uid:
        caller_pmc = p1_callsign
        partner_pmc = p2_callsign
    else:
        caller_pmc = p2_callsign
        partner_pmc = p1_callsign

    # Calculate Duo Attack
    round_log = []
    round_log.append(f"💥 @{caller_name} ({caller_pmc}) выбрал: «{chosen_opt['text']}»")

    # 0. Regenerative Nanites at start of turn
    for p_obj, p_st in [(p1, p1_stats), (p2, p2_stats)]:
        if p_obj and p_obj.get("hp", 0) > 0 and p_st.get("turn_regen", 0) > 0:
            p_obj["hp"] = min(p_st["max_hp"], p_obj["hp"] + p_st["turn_regen"])
            round_log.append(f"🧬 Наниты @{p_obj['username']}: +{p_st['turn_regen']} HP")

    total_duo_dmg = 0

    # Player 1 Strike
    if p1 and p1.get("hp", 0) > 0:
        dmg1 = p1_stats.get("dmg", 35) + p2_stats.get("buff_partner_dmg", 0)
        # First hit bonus
        if p1_stats.get("first_hit_dmg", 0) > 0 and evt.get("enemy_hp", 0) == evt.get("enemy_max_hp", 0):
            dmg1 += p1_stats["first_hit_dmg"]
        # Adrenaline frenzy (low hp bonus)
        if p1.get("hp", 0) < p1_stats["max_hp"] * 0.40 and p1_stats.get("low_hp_dmg_mult", 0) > 0:
            dmg1 = int(dmg1 * (1.0 + p1_stats["low_hp_dmg_mult"]))
        # Execute finisher (enemy low hp bonus)
        if evt.get("enemy_hp", 100) < evt.get("enemy_max_hp", 100) * 0.50 and p1_stats.get("execute_mult", 0) > 0:
            dmg1 = int(dmg1 * (1.0 + p1_stats["execute_mult"]))
        # Crit check
        c_chance = min(0.85, p1_stats.get("crit_chance", 0.05) + p2_stats.get("buff_partner_crit", 0.0))
        if random.random() < c_chance:
            dmg1 = int(dmg1 * p1_stats.get("crit_mult", 2.0))
            round_log.append(f"🎯 КРИТИЧЕСКИЙ УДАР от @{p1['username']} на {dmg1} DMG!")
        # Double trigger
        if random.random() < p1_stats.get("double_attack_chance", 0.0):
            dmg1 += p1_stats.get("dmg", 35)
            round_log.append(f"⚡ Двойной выстрел @{p1['username']}!")
        total_duo_dmg += dmg1
        # Start AoE/Underbarrel
        if p1_stats.get("start_aoe", 0) > 0:
            total_duo_dmg += p1_stats["start_aoe"]
            round_log.append(f"💣 Подствол @{p1['username']}: +{p1_stats['start_aoe']} взрывного DMG!")
        # Duo assist synergy
        if p2_stats.get("duo_assist_dmg", 0) > 0:
            total_duo_dmg += p2_stats["duo_assist_dmg"]
        # Bleed damage
        if p1_stats.get("bleed_dmg", 0) > 0:
            total_duo_dmg += p1_stats["bleed_dmg"]

    # Player 2 Strike
    if p2 and p2.get("hp", 0) > 0:
        dmg2 = p2_stats.get("dmg", 35) + p1_stats.get("buff_partner_dmg", 0)
        if p2_stats.get("first_hit_dmg", 0) > 0 and evt.get("enemy_hp", 0) == evt.get("enemy_max_hp", 0):
            dmg2 += p2_stats["first_hit_dmg"]
        if p2.get("hp", 0) < p2_stats["max_hp"] * 0.40 and p2_stats.get("low_hp_dmg_mult", 0) > 0:
            dmg2 = int(dmg2 * (1.0 + p2_stats["low_hp_dmg_mult"]))
        if evt.get("enemy_hp", 100) < evt.get("enemy_max_hp", 100) * 0.50 and p2_stats.get("execute_mult", 0) > 0:
            dmg2 = int(dmg2 * (1.0 + p2_stats["execute_mult"]))
        c_chance2 = min(0.85, p2_stats.get("crit_chance", 0.05) + p1_stats.get("buff_partner_crit", 0.0))
        if random.random() < c_chance2:
            dmg2 = int(dmg2 * p2_stats.get("crit_mult", 2.0))
            round_log.append(f"🎯 КРИТИЧЕСКИЙ УДАР от @{p2['username']} на {dmg2} DMG!")
        if random.random() < p2_stats.get("double_attack_chance", 0.0):
            dmg2 += p2_stats.get("dmg", 35)
            round_log.append(f"⚡ Двойной выстрел @{p2['username']}!")
        total_duo_dmg += dmg2
        if p2_stats.get("start_aoe", 0) > 0:
            total_duo_dmg += p2_stats["start_aoe"]
            round_log.append(f"💣 Подствол @{p2['username']}: +{p2_stats['start_aoe']} взрывного DMG!")
        if p1_stats.get("duo_assist_dmg", 0) > 0:
            total_duo_dmg += p1_stats["duo_assist_dmg"]
        if p2_stats.get("bleed_dmg", 0) > 0:
            total_duo_dmg += p2_stats["bleed_dmg"]

    # Coordinated team multiplier
    team_mult = 1.0 + p1_stats.get("team_dmg_mult", 0) + p2_stats.get("team_dmg_mult", 0)
    total_duo_dmg = int(total_duo_dmg * team_mult)

    # Strategy bonus / risk modifier / multipliers
    strat = chosen_opt.get("strategy", "assault")
    risk_level = chosen_opt.get("risk", "medium")
    dmg_deal_mult = chosen_opt.get("dmg_deal_mult", 1.0)
    loot_mult = chosen_opt.get("loot_mult", 1.0)
    consequence_text = chosen_opt.get("consequence", "")

    # Medical triage option (Field hospital act 9 or medical choice)
    if strat == "med" or "исцеление" in chosen_opt.get("text", "").lower() or "реанимация" in chosen_opt.get("text", "").lower():
        for p, stats in [(p1, p1_stats), (p2, p2_stats)]:
            if p and p.get("hp", 0) > 0:
                p["hp"] = stats.get("max_hp", 100)
        round_log.append("💚 <b>Медицинская стабилизация:</b> Раны перевязаны, здоровье обоих оперативников восстановлено до 100%!")

    # Strategic damage multipliers
    total_duo_dmg = int(total_duo_dmg * dmg_deal_mult)
    if strat in ("flank", "sneak", "pincer", "snipe"):
        total_duo_dmg = int(total_duo_dmg * 1.30)
    elif strat in ("tech", "recon"):
        total_duo_dmg = int(total_duo_dmg * 1.40)
    elif strat in ("all_out", "rush", "smash"):
        total_duo_dmg = int(total_duo_dmg * 1.50)
    elif strat == "exploit":
        total_duo_dmg = int(total_duo_dmg * 2.50)

    # Apply damage to enemy
    evt["enemy_hp"] = max(0, evt.get("enemy_hp", 100) - total_duo_dmg)
    round_log.append(f"⚔️ Дуо нанесло суммарно <b>{total_duo_dmg} DMG</b> врагу!")

    # Display action consequence
    if consequence_text:
        round_log.append(f"📜 <i>{consequence_text}</i>")

    # Award special in-raid tool if event grants one
    award_tool_id = chosen_opt.get("award_tool")
    if award_tool_id and award_tool_id in TACTICAL_TOOLS:
        tool_obj = copy.deepcopy(TACTICAL_TOOLS[award_tool_id])
        held_ids = [t["id"] if isinstance(t, dict) else t for t in raid.get("tactical_tools", [])]
        if award_tool_id not in held_ids:
            raid.setdefault("tactical_tools", []).append(tool_obj)
            round_log.append(f"🎉 <b>ПОЛУЧЕН СПЕЦ-ИНСТРУМЕНТ:</b> {tool_obj.get('icon', '🧰')} <b>{tool_obj.get('name')}</b>! Отряду открыты уникальные тактические решения!")

    # Consume single-use tools if applicable (e.g. C4 charge)
    if req_tool_id == "c4_charge":
        raid["tactical_tools"] = [t for t in raid.get("tactical_tools", []) if (t["id"] if isinstance(t, dict) else t) != "c4_charge"]
        round_log.append("🧨 <b>Заряд C4 израсходован</b> при направленном тактическом подрыве!")

    # Check Vampirism heal
    if p1 and p1.get("hp", 0) > 0 and p1_stats.get("vampirism", 0) > 0:
        heal1 = int(p1_stats["dmg"] * p1_stats["vampirism"])
        p1["hp"] = min(p1_stats["max_hp"], p1["hp"] + heal1)
    if p2 and p2.get("hp", 0) > 0 and p2_stats.get("vampirism", 0) > 0:
        heal2 = int(p2_stats["dmg"] * p2_stats["vampirism"])
        p2["hp"] = min(p2_stats["max_hp"], p2["hp"] + heal2)

    # -------------------------------------------------------------
    # ENEMY RETALIATION (SITUATIONAL DAMAGE BASED ON TACTICAL RISK)
    # -------------------------------------------------------------
    if evt["enemy_hp"] > 0:
        if risk_level == "safe":
            # SAFE MANEUVER: ZERO DAMAGE TAKEN! (Stealth, Sniping with suppressor, Tech defuse, Cover)
            round_log.append("🛡️ <b>Тактическое преимущество:</b> Противник не смог обнаружить группу или открыть огонь (0 урона).")
        else:
            base_e_dmg = evt.get("enemy_dmg", 20)
            if risk_level == "low":
                base_e_dmg = max(3, int(base_e_dmg * 0.40))
            elif risk_level == "high":
                base_e_dmg = int(base_e_dmg * 1.25)

            # Enemy attacks alive players
            for p, stats, partner_st in [(p1, p1_stats, p2_stats), (p2, p2_stats, p1_stats)]:
                if p and p.get("hp", 0) > 0:
                    # Low risk: 50% chance the enemy shoots completely off-target
                    if risk_level == "low" and random.random() < 0.50:
                        round_log.append(f"💨 Вражеская очередь скользнула по укрытию @{p['username']} (0 урона)!")
                        continue

                    # Dodge check
                    if random.random() < stats.get("dodge_chance", 0.0):
                        round_log.append(f"💨 @{p['username']} мастерски уклонился от атаки врага!")
                        continue

                    in_dmg = max(3, base_e_dmg - stats.get("dmg_reduction", 0))
                    in_dmg = int(in_dmg * (1.0 - stats.get("pct_dmg_reduction", 0)))
                    # Suppressing fire protection from partner
                    in_dmg = int(in_dmg * (1.0 - partner_st.get("partner_protect_pct", 0.0)))
                    p["hp"] = max(0, p["hp"] - in_dmg)
                    round_log.append(f"🩸 @{p['username']} получил -{in_dmg} урона! [HP: {p['hp']}]")

                    # Emergency Morphine Injection
                    if p["hp"] > 0 and p["hp"] < stats["max_hp"] * 0.30 and stats.get("emergency_heal", 0) > 0:
                        p["hp"] = min(stats["max_hp"], p["hp"] + stats["emergency_heal"])
                        round_log.append(f"💉 МОРФИЙ активирован у @{p['username']}! Экстренно восстановлено +{stats['emergency_heal']} HP!")

                    # Defibrillator / Revive perk check (1 use per raid)
                    if p["hp"] <= 0 and stats.get("revive_shield", 0) > 0 and not p.get("used_defibrillator"):
                        p["hp"] = stats["revive_shield"]
                        p["used_defibrillator"] = True
                        round_log.append(f"⚡ ДЕФИБРИЛЛЯТОР спас @{p['username']}! Восстановлено {p['hp']} HP (заряд израсходован)!")
                    elif p["hp"] <= 0 and partner_st.get("partner_auto_revive", 0) > 0 and not p.get("used_partner_revive"):
                        p["hp"] = partner_st["partner_auto_revive"]
                        p["used_partner_revive"] = True
                        round_log.append(f"🤝 Напарник экстренно реанимировал @{p['username']} с {p['hp']} HP (1 раз за рейд)!")

        # Check total squad wipe
        if (not p1 or p1.get("hp", 0) <= 0) and (not p2 or p2.get("hp", 0) <= 0):
            round_log.append("☠️ ОБА БОЙЦА ПОТЕРЯЛИ СОЗНАНИЕ! РЕЙД ПРОВАЛЕН!")
            zone_title = evt.get("zone", evt.get("title", "Сектор боестолкновения"))
            enemy_target = evt.get("enemy_name", "отряд противника")
            raid["latest_narrative"] = generate_action_chronicle(
                caller_name=f"{caller_name} ({caller_pmc})",
                partner_name=partner_pmc,
                zone_title=zone_title,
                enemy_name=enemy_target,
                option_text=chosen_opt.get("text", "Штурм"),
                is_kill=False,
                squad_wipe=True,
                took_damage=True
            )
            bot.answer_callback_query(call.id, format_short_alert(f"{caller_name} ({caller_pmc})", is_kill=False, took_damage=True, squad_wipe=True), show_alert=False)
            raid["action_in_progress"] = False
            raid["combat_log"] = round_log
            save_db(db)
            finish_duo_raid(lobby, db, bot, success=False, reason="wipe")
            return

    # -------------------------------------------------------------
    # ENEMY DEFEATED -> ACT COMPLETED!
    # -------------------------------------------------------------
    else:
        loc = COOP_LOCATIONS.get(lobby.get("diff_key"), COOP_LOCATIONS["factory"])
        loc_scale = loc.get("rubles_scale", 1.0)
        team_rub_bonus = 1.0 + p1_stats.get("team_rubles_mult", 0) + p2_stats.get("team_rubles_mult", 0)
        
        act_num = raid.get("evac_act", 1) if raid.get("is_evacuating") else raid.get("act", 1)
        is_boss_act = (act_num == 15 and not raid.get("is_evacuating"))
        is_elite_act = (act_num in (5, 10))

        # Scaled Rubles per Act (higher acts = significantly bigger payout)
        if is_boss_act:
            base_rub = random.randint(2000000, 3500000)
        elif act_num >= 11:
            base_rub = random.randint(550000, 950000)
        elif act_num >= 6:
            base_rub = random.randint(280000, 480000)
        else:
            base_rub = random.randint(120000, 220000)

        loot_rubles = int(base_rub * loc_scale * team_rub_bonus * loot_mult)
        raid["raid_bank"] = raid.get("raid_bank", 0) + loot_rubles

        # Progressive Non-Mythic Item Drops (Excludes any mythic, deeper acts = higher tier)
        extra_items_bonus = p1_stats.get("extra_items", 0) + p2_stats.get("extra_items", 0)
        dropped_items = roll_coop_act_loot(act_num, is_boss=is_boss_act, is_elite=is_elite_act, extra_items_bonus=extra_items_bonus)
        
        for d_item in dropped_items:
            raid.setdefault("raid_loot_items", []).append(d_item)
            rarity_badge = d_item["rarity"].upper()
            raid.setdefault("raid_loot", []).append(f"{d_item['name']} [{rarity_badge}]")

        loot_display_names = [f"<b>{d['name']}</b> ({d['rarity']})" for d in dropped_items]
        round_log.append(f"🎉 <b>СЕКТОР ЗАЧИЩЕН!</b> Награда: +{fmt_rub(loot_rubles)} в банк рейда!")
        if loot_display_names:
            round_log.append(f"📦 <b>Найден ценный лут:</b> {', '.join(loot_display_names)}")

        # Milestone Tactical Tool Trophy (Acts 5 & 10)
        if is_elite_act:
            held_ids = [t["id"] if isinstance(t, dict) else t for t in raid.get("tactical_tools", [])]
            unheld = [k for k in TACTICAL_TOOLS.keys() if k not in held_ids]
            if unheld:
                bonus_tool_id = random.choice(unheld)
                tool_obj = copy.deepcopy(TACTICAL_TOOLS[bonus_tool_id])
                raid.setdefault("tactical_tools", []).append(tool_obj)
                round_log.append(f"🎖 <b>ТАКТИЧЕСКИЙ ТРОФЕЙ:</b> С командира сектора захвачен спец-инструмент: {tool_obj.get('icon', '🧰')} <b>{tool_obj.get('name')}</b>!")

        # If this was Act 15 Boss or Final Evacuation Act -> TRIUMPH IMMEDIATELY!
        if is_boss_act:
            round_log.append(f"👑 <b>ГЛАВНЫЙ БОСС {loc['boss_name']} СОКРУШЕН!</b> Все 15 актов рейда завершены!")
            raid["combat_log"] = round_log
            save_db(db)
            finish_duo_raid(lobby, db, bot, success=True, reason="boss_climax")
            return

        if raid.get("is_evacuating") and raid.get("evac_act", 1) >= 3:
            round_log.append("🚁 <b>ЭВАКУАЦИОННЫЙ ВЕРТОЛЕТ ПРИБЫЛ!</b> Прорыв успешно завершен!")
            raid["action_in_progress"] = False
            raid["combat_log"] = round_log
            save_db(db)
            finish_duo_raid(lobby, db, bot, success=True, reason="evac")
            return

        # Enter Perk Selection Phase between acts!
        raid["perk_phase"] = True
        raid["perk_phase_time"] = time.time()
        raid["chosen_perks"] = {}
        perk_offers = {}
        for pid in p_ids:
            p_obj = players.get(pid, {})
            perk_offers[pid] = get_random_perks_choice(p_obj.get("perks", {}))
        raid["perk_offers"] = perk_offers

    # -------------------------------------------------------------
    # GENERATE BOOK-STYLE CHRONICLE FOR THIS ACTION
    # -------------------------------------------------------------
    is_kill = (evt.get("enemy_hp", 0) <= 0)
    took_dmg = (evt.get("enemy_hp", 0) > 0 and risk_level != "safe")
    zone_title = evt.get("zone", evt.get("title", "Сектор боестолкновения"))
    enemy_target = evt.get("enemy_name", "отряд противника")

    chronicle = generate_action_chronicle(
        caller_name=f"{caller_name} ({caller_pmc})",
        partner_name=partner_pmc,
        zone_title=zone_title,
        enemy_name=enemy_target,
        option_text=chosen_opt.get("text", "Штурм"),
        is_kill=is_kill,
        squad_wipe=False,
        took_damage=took_dmg
    )
    if consequence_text:
        chronicle += f"\n\n📜 <b>Последствие выбора:</b> <i>{consequence_text}</i>"
    raid["latest_narrative"] = chronicle

    # Pop up Telegram alert for the clicking player
    popup_text = format_short_alert(f"{caller_name} ({caller_pmc})", is_kill=is_kill, took_damage=took_dmg, squad_wipe=False)
    bot.answer_callback_query(call.id, popup_text, show_alert=False)

    raid["action_in_progress"] = False
    raid["combat_log"] = round_log
    save_db(db)
    sync_duo_raid_ui(lobby, db, bot)

# =====================================================================
# 5. PERK SELECTION & STACKING
# =====================================================================
def handle_duo_perk_pick(call, player, db, lobby_id, perk_id, bot):
    """Applies the chosen perk to the player and advances stage if both are ready."""
    lobbies = db.setdefault("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "in_raid":
        bot.answer_callback_query(call.id, "❌ Рейд уже завершен!")
        return

    raid = lobby.get("raid", {})
    if not raid.get("perk_phase"):
        bot.answer_callback_query(call.id, "⚠️ Выбор перков сейчас недоступен!")
        return

    uid = str(player["user_id"])

    # Ensure member message tracking is fresh
    for m in lobby.get("members", []):
        if str(m.get("user_id")) == uid:
            m["chat_id"] = call.message.chat.id
            m["message_id"] = call.message.message_id

    players = raid.get("players", {})
    p_data = players.get(uid)
    if not p_data:
        bot.answer_callback_query(call.id, "❌ Вы не участник этого рейда!")
        return

    chosen_perks = raid.setdefault("chosen_perks", {})

    # Support emergency auto-advance if partner is delayed
    if perk_id == "auto":
        if uid not in chosen_perks:
            bot.answer_callback_query(call.id, "Сначала выберите свой перк!", show_alert=True)
            return
        perk_start = raid.get("perk_phase_time", 0)
        if time.time() - perk_start < 10:
            rem = max(1, int(10 - (time.time() - perk_start)))
            bot.answer_callback_query(call.id, f"Подождите напарника ещё {rem} сек.", show_alert=True)
            return
        for p_k, p_obj in players.items():
            if p_k not in chosen_perks and p_obj.get("hp", 0) > 0:
                offers = raid.get("perk_offers", {}).get(p_k, [])
                assigned_perk = offers[0]["id"] if offers else random.choice(list(COOP_PERKS.keys()))
                p_obj.setdefault("perks", {})[assigned_perk] = p_obj.get("perks", {}).get(assigned_perk, 0) + 1
                chosen_perks[p_k] = assigned_perk
        bot.answer_callback_query(call.id, "⚡ Напарнику назначен перк. Переходим к следующему акту!")
    else:
        if uid in chosen_perks:
            bot.answer_callback_query(call.id, "Вы уже выбрали перк. Ожидаем напарника.")
            return

        # Stack perk
        p_def = COOP_PERKS.get(perk_id, {})
        p_data.setdefault("perks", {})[perk_id] = p_data.get("perks", {}).get(perk_id, 0) + 1
        new_lvl = p_data["perks"][perk_id]
        chosen_perks[uid] = perk_id

        # Instant effect (e.g. titanium plates heal)
        if perk_id == "titanium_plates":
            p_data["hp"] = min(p_data.get("max_hp", 100) + 30, p_data.get("hp", 0) + 30)

        bot.answer_callback_query(call.id, f"✅ Выбран перк: {p_def.get('name', perk_id)} [x{new_lvl}]!")

    # Check if both active players made their choice
    all_ready = True
    for p_k, p_obj in players.items():
        if p_obj.get("hp", 0) > 0 and p_k not in chosen_perks:
            all_ready = False
            break

    if all_ready:
        # Both chose perks -> Advance to Next Act!
        raid["perk_phase"] = False
        raid["chosen_perks"] = {}
        raid["perk_offers"] = {}
        raid.pop("latest_narrative", None)

        # End of act team/personal heals & partner field stabilization
        p_ids = list(players.keys())
        p1_obj = players.get(p_ids[0]) if len(p_ids) > 0 else None
        p2_obj = players.get(p_ids[1]) if len(p_ids) > 1 else None

        p1_prof = db.get("users", {}).get(p_ids[0], {}) if len(p_ids) > 0 else {}
        p2_prof = db.get("users", {}).get(p_ids[1], {}) if len(p_ids) > 1 else {}

        p1_st = calculate_player_combat_stats(p1_prof, p1_obj) if p1_obj else {}
        p2_st = calculate_player_combat_stats(p2_prof, p2_obj) if p2_obj else {}

        # 1. Partner Field Stabilization (revive downed partner ONLY IF partner unlocked medical revive perk)
        if p1_obj and p1_obj.get("hp", 0) <= 0 and p2_obj and p2_obj.get("hp", 0) > 0:
            if p2_st.get("partner_auto_revive", 0) > 0:
                revive_hp = p2_st.get("partner_auto_revive", 0)
                p1_obj["hp"] = min(p1_st.get("max_hp", 100), revive_hp)
                p1_obj["status"] = "alive"
                round_log.append(f"🩺 Полевая стабилизация: @{p1_obj.get('username')} возвращен в строй ({p1_obj['hp']} HP)!")
            else:
                p1_obj["hp"] = 0
                p1_obj["status"] = "downed"
        elif p2_obj and p2_obj.get("hp", 0) <= 0 and p1_obj and p1_obj.get("hp", 0) > 0:
            if p1_st.get("partner_auto_revive", 0) > 0:
                revive_hp = p1_st.get("partner_auto_revive", 0)
                p2_obj["hp"] = min(p2_st.get("max_hp", 100), revive_hp)
                p2_obj["status"] = "alive"
                round_log.append(f"🩺 Полевая стабилизация: @{p2_obj.get('username')} возвращен в строй ({p2_obj['hp']} HP)!")
            else:
                p2_obj["hp"] = 0
                p2_obj["status"] = "downed"

        # 2. End of act tactical medical treatment
        if p1_obj and p1_obj.get("hp", 0) > 0:
            max_1 = p1_st.get("max_hp", 100)
            missing_1 = max(0, max_1 - p1_obj["hp"])
            heal_1 = 25 + int(missing_1 * 0.12) + p1_st.get("post_act_heal", 0) + p2_st.get("heal_partner_post_act", 0)
            p1_obj["hp"] = min(max_1, p1_obj["hp"] + heal_1)
            p1_obj["max_hp"] = max_1

        if p2_obj and p2_obj.get("hp", 0) > 0:
            max_2 = p2_st.get("max_hp", 100)
            missing_2 = max(0, max_2 - p2_obj["hp"])
            heal_2 = 25 + int(missing_2 * 0.12) + p2_st.get("post_act_heal", 0) + p1_st.get("heal_partner_post_act", 0)
            p2_obj["hp"] = min(max_2, p2_obj["hp"] + heal_2)
            p2_obj["max_hp"] = max_2

        # Scavenger greed bonus to bank
        bank_bonus = p1_st.get("act_rubles_bonus", 0) + p2_st.get("act_rubles_bonus", 0)
        if bank_bonus > 0:
            raid["raid_bank"] = raid.get("raid_bank", 0) + bank_bonus

        loc_key = lobby.get("diff_key", "factory")

        # 1. If currently Evacuating:
        if raid.get("is_evacuating"):
            raid["evac_act"] = raid.get("evac_act", 1) + 1
            if raid["evac_act"] > 3:
                # 3 Acts of Evacuation Completed -> VICTORY!
                finish_duo_raid(lobby, db, bot, success=True, reason="evac")
                return
            else:
                next_event = roll_event_for_act(loc_key, 0, is_evacuating=True, evac_act=raid["evac_act"])
                raid["current_event"] = next_event
                raid["combat_log"] = [f"🚨 <b>АКТ ЭВАКУАЦИИ {raid['evac_act']} / 3!</b> Пробиваемся к точке встречи!"]
        # 2. Normal Act Progression:
        else:
            raid["act"] = raid.get("act", 1) + 1
            if raid["act"] > 15:
                # Act 15 Super-Boss cleared -> LEGENDARY CLIMAX VICTORY!
                finish_duo_raid(lobby, db, bot, success=True, reason="boss_climax")
                return
            else:
                next_event = roll_event_for_act(loc_key, raid["act"], is_evacuating=False, used_ids=set(raid.get("used_event_ids", [])), raid_modifier=raid.get("raid_modifier"))
                raid.setdefault("used_event_ids", []).append(next_event["id"])
                raid["current_event"] = next_event
                raid["combat_log"] = [f"➡️ <b>АКТ {raid['act']} / 15:</b> Отряд выдвинулся в следующий сектор!"]

    save_db(db)
    sync_duo_raid_ui(lobby, db, bot)

# =====================================================================
# 6. EVACUATION INITIATION
# =====================================================================
def handle_duo_evacuation_start(call, player, db, lobby_id, bot):
    """Switches raid mode to 3-Act Evacuation sequence."""
    lobbies = db.setdefault("coop_lobbies", {})
    lobby = lobbies.get(lobby_id)
    if not lobby or lobby.get("status") != "in_raid":
        bot.answer_callback_query(call.id, "❌ Рейд уже завершен!")
        return

    raid = lobby.get("raid", {})
    if raid.get("act", 1) < 5:
        bot.answer_callback_query(call.id, "❌ Эвакуация доступна только после 5 акта!", show_alert=True)
        return

    if raid.get("is_evacuating"):
        bot.answer_callback_query(call.id, "Вы уже на этапе эвакуации!")
        return

    caller_name = player.get("username", "Оператор")
    bot.answer_callback_query(call.id, "🚪 НАЧАТА ЭВАКУАЦИЯ! 3 опасных акта прорыва!")

    raid["is_evacuating"] = True
    raid["evac_act"] = 1
    loc_key = lobby.get("diff_key", "factory")
    first_evac_event = roll_event_for_act(loc_key, 0, is_evacuating=True, evac_act=1)
    raid["current_event"] = first_evac_event
    raid["combat_log"] = [f"🚪 @{caller_name} запросил эвакуацию! Начинается 3-этапный прорыв к выходу!"]

    save_db(db)
    sync_duo_raid_ui(lobby, db, bot)

# =====================================================================
# 7. RAID RESOLUTION (TRIUMPH & DEFEAT)
# =====================================================================
def finish_duo_raid(lobby, db, bot, success=True, reason="evac"):
    """Distributes spoils or applies defeat medical penalties."""
    lobby["status"] = "finished"
    raid = lobby.get("raid", {})
    members = lobby.get("members", [])
    loc = COOP_LOCATIONS.get(lobby.get("diff_key"), COOP_LOCATIONS["factory"])
    now = int(time.time())

    total_bank = raid.get("raid_bank", 200000)
    loot_items = raid.get("raid_loot", [])
    loot_entries = raid.get("raid_loot_items", [])

    if success:
        # Multiplier bonus if completed full 15 acts
        if reason == "boss_climax":
            total_bank = int(total_bank * 2.0)
            title = "👑 <b>АБСОЛЮТНЫЙ ТРИУМФ ДУО! СВЕРХБОСС УНИЧТОЖЕН!</b>"
            subtitle = f"Оба бойца полностью зачистили 15 актов локации {loc['name']} и сокрушили легендарного босса <b>{loc['boss_name']}</b>!"
        else:
            title = "🚁 <b>УСПЕШНАЯ ЭВАКУАЦИЯ ДУО!</b>"
            subtitle = f"Боевая пара преодолела 3 опасных акта отхода и успешно эвакуировалась с локации {loc['name']}!"

        each_rubles = total_bank

        txt = (
            f"{title}\n"
            f"────────────────────────\n"
            f"{subtitle}\n\n"
            f"💰 <b>Награда каждому бойцу:</b> +<b>{fmt_rub(each_rubles)}</b>\n"
            f"🎖 <b>Опыт ЧВК:</b> +{350 if reason == 'boss_climax' else 200} EXP\n"
        )

        if loot_items:
            txt += f"📦 <b>Эвакуировано трофеев:</b> {len(loot_items)} шт.\n"
            txt += f"<i>(Трофеи: {', '.join(loot_items[:5])}{'...' if len(loot_items) > 5 else ''})</i>\n"

        # Relic container bonus (25% chance or boss climax)
        relic_dropped = (reason == "boss_climax" or random.random() < 0.25)
        if relic_dropped:
            txt += "🌟 <b>РЕЛИКТОВЫЙ КОНТЕЙНЕР!</b> Найден реликтовый кейс рейда (+10 000 000 ₽ каждому)!\n"
            each_rubles += 10000000

        # GUARANTEED MYTHIC CASE FOR ACT 15 CLIMAX ONLY
        if reason == "boss_climax":
            txt += "\n💼 <b>ЛЕГЕНДАРНАЯ НАГРАДА ЗА 15-Й ЭТАП:</b>\n"
            txt += "🔥 <b>Мифический кейс Black Division</b> гарантированно вручен обоим бойцам!\n"

        txt += "────────────────────────\n"

        for m in members:
            uid = str(m.get("user_id"))
            m_user = db.get("users", {}).get(uid) or db.get("users", {}).get(m.get("user_id"))
            if m_user:
                add_player_rubles(m_user, each_rubles)
                add_player_exp(m_user, 350 if reason == "boss_climax" else 200)
                m_user.setdefault("stats", {})["coop_wins"] = m_user.get("stats", {}).get("coop_wins", 0) + 1
                m_user.setdefault("stats", {})["coop_raids_count"] = m_user.get("stats", {}).get("coop_raids_count", 0) + 1
                
                # Bonus battle pass exp if military business
                if has_gd_business(m_user):
                    add_gd_bp_exp(m_user, 1000 if reason == "boss_climax" else 800)

                # Transfer all non-mythic looted items into player's stash
                stored_count = 0
                sold_rubles = 0
                for itm in loot_entries:
                    iid = itm.get("id")
                    iprice = itm.get("price", 50000)
                    if can_store_item(m_user, iid):
                        m_user.setdefault("stash", []).append({
                            "uid": f"coop_{iid}_{now}_{random.randint(1000, 9999)}",
                            "item_id": iid,
                            "equipped_to": None
                        })
                        stored_count += 1
                    else:
                        add_player_rubles(m_user, iprice)
                        sold_rubles += iprice

                # GUARANTEED Mythic Case Black Division for Act 15
                if reason == "boss_climax":
                    add_mythic_item_to_player(m_user, "mythic_black_division_case")

    else:
        # DEFEAT
        txt = (
            "💀 <b>РАЗГРОМ ДУО! БОЙЦЫ ПОТЕРЯЛИ СОЗНАНИЕ!</b>\n"
            "────────────────────────\n"
            f"Отряд попал под перекрестный огонь в глубине локации {loc['name']}.\n"
            "Сигнатурные операторы эвакуированы службой спасения в медблок.\n\n"
            "⚠️ <b>МЕДБЛОК:</b> Восстановление занимает 5 минут (бафф ЧВК временно отключен).\n"
            "🛡 <i>Ваш основной отряд и экипировка на складе остались в полной безопасности!</i>\n"
            "────────────────────────\n"
        )
        for m in members:
            uid = str(m.get("user_id"))
            m_user = db.get("users", {}).get(uid) or db.get("users", {}).get(m.get("user_id"))
            if m_user:
                cd_sec = 300
                if has_boss_set_bonus(m_user, "sanitar"):
                    cd_sec = 60
                elif has_boss_set_bonus(m_user, "killa"):
                    cd_sec = 120
                else:
                    med_lvl = m_user.get("modules", {}).get("medblock", 0)
                    if med_lvl > 0:
                        cd_sec = max(60, cd_sec - (med_lvl * 20))
                m_user["coop_cooldown_until"] = now + cd_sec
                m_user.setdefault("stats", {})["coop_losses"] = m_user.get("stats", {}).get("coop_losses", 0) + 1
                m_user.setdefault("stats", {})["coop_raids_count"] = m_user.get("stats", {}).get("coop_raids_count", 0) + 1

    # Remove completed lobby
    db.get("coop_lobbies", {}).pop(lobby["id"], None)
    save_db(db)

    markup = types.InlineKeyboardMarkup().add(
        types.InlineKeyboardButton("🔙 В Меню Кооператива", callback_data="menu_coop_raids")
    )

    for m in members:
        chat_id = m.get("chat_id")
        msg_id = m.get("message_id")
        if chat_id:
            try:
                bot.edit_message_text(txt, chat_id, msg_id, reply_markup=markup)
            except Exception:
                try:
                    bot.send_message(chat_id, txt, reply_markup=markup)
                except Exception:
                    pass

def simulate_coop_raid(diff_key, party, force_success=True):
    """Legacy helper for balance test suites."""
    from relics_system import ALL_30_RELICS
    rates = {
        "colossal": 0.10,
        "ultra": 0.04,
        "hard": 0.01,
        "normal": 0.0,
        "easy": 0.0
    }
    relic_rate = rates.get(diff_key, 0.0)
    relic_dropped = None
    if random.random() < relic_rate:
        relic_dropped = random.choice(ALL_30_RELICS)
    return {
        "success": force_success,
        "relic_dropped": relic_dropped,
        "rubles": 2000000,
        "exp": 250
    }
