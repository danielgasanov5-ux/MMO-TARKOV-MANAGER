# -*- coding: utf-8 -*-
"""
Builder that writes coop_events_data.py with rich handcrafted events for all 10 locations.
Each location has 15 Acts corresponding to 15 consequential actions.
Each action has clear tactical options with 'safe', 'low', 'medium', 'high' risk and consequences.
"""
import sys

output_path = "/app/applet/coop_events_data.py"

header = '''# -*- coding: utf-8 -*-
"""Cooperative Duo Roguelike System: Data & Events
Completely reworked for high immersion, 15 acts = 15 consequential tactical actions,
realistic damage balancing (no forced damage every turn; safe/stealth tactics take 0 damage),
and unique, non-repetitive events for all 10 Tarkov locations + Evacuation.
"""
import copy
import random

# =====================================================================
# 1. STACKABLE CO-OP PERKS (37+ UNIQUE PERKS WITH SCALING)
# =====================================================================
COOP_PERKS = {
    # --- OFFENSE (АТАКА) ---
    "hollow_point": {
        "id": "hollow_point",
        "name": "Экспансивные пули",
        "icon": "🩸",
        "category": "offense",
        "desc": "+14 к базовому DMG за стак",
        "calc": lambda s: {"dmg": 14 * s}
    },
    "sniper_focus": {
        "id": "sniper_focus",
        "name": "Снайперская оптика",
        "icon": "🎯",
        "category": "offense",
        "desc": "+16% шанс критического удара (2.5x урон) за стак",
        "calc": lambda s: {"crit_chance": 0.16 * s}
    },
    "heavy_barrel": {
        "id": "heavy_barrel",
        "name": "Утяжеленный ствол",
        "icon": "💥",
        "category": "offense",
        "desc": "+20 к DMG, но -5 к максимальному HP за стак",
        "calc": lambda s: {"dmg": 20 * s, "max_hp": -5 * s}
    },
    "bleed_rounds": {
        "id": "bleed_rounds",
        "name": "Зазубренные пули",
        "icon": "🗡️",
        "category": "offense",
        "desc": "Враги истекают кровью, получая 18 урона каждый ход за стак",
        "calc": lambda s: {"bleed_dmg": 18 * s}
    },
    "armor_piercer": {
        "id": "armor_piercer",
        "name": "Вольфрамовый сердечник",
        "icon": "⚡",
        "category": "offense",
        "desc": "+12 чистого пробивающего урона сквозь любые щиты за стак",
        "calc": lambda s: {"pierce_dmg": 12 * s}
    },
    "execute_finisher": {
        "id": "execute_finisher",
        "name": "Добивающий выстрел",
        "icon": "☠️",
        "category": "offense",
        "desc": "+40% урона по врагам с HP ниже 50% за стак",
        "calc": lambda s: {"execute_mult": 0.40 * s}
    },
    "double_trigger": {
        "id": "double_trigger",
        "name": "Двойной спуск",
        "icon": "🔫",
        "category": "offense",
        "desc": "+18% шанс провести вторую бесплатную атаку за ход за стак",
        "calc": lambda s: {"double_attack_chance": 0.18 * s}
    },
    "underbarrel_grenade": {
        "id": "underbarrel_grenade",
        "name": "Подствольный гранатомет",
        "icon": "💣",
        "category": "offense",
        "desc": "Начало каждого боя наносит 45 взрывного урона врагам за стак",
        "calc": lambda s: {"start_aoe": 45 * s}
    },
    "ricochet_master": {
        "id": "ricochet_master",
        "name": "Осколочный рикошет",
        "icon": "✨",
        "category": "offense",
        "desc": "+10 к урону и 10% шанс оглушить цель за стак",
        "calc": lambda s: {"dmg": 10 * s, "stun_chance": 0.10 * s}
    },
    "adrenalin_frenzy": {
        "id": "adrenalin_frenzy",
        "name": "Боевой азарт",
        "icon": "🔥",
        "category": "offense",
        "desc": "+50% DMG, когда ваше здоровье опускается ниже 40%",
        "calc": lambda s: {"low_hp_dmg_mult": 0.50 * s}
    },
    "thermobaric_charge": {
        "id": "thermobaric_charge",
        "name": "Термобарический заряд",
        "icon": "🧨",
        "category": "offense",
        "desc": "+25 к урону по боссам и элитным врагам за стак",
        "calc": lambda s: {"boss_dmg_bonus": 25 * s}
    },

    # --- DEFENSE (ВЫЖИВАЕМОСТЬ) ---
    "titanium_plates": {
        "id": "titanium_plates",
        "name": "Титановые пластины",
        "icon": "🛡️",
        "category": "defense",
        "desc": "+30 к макс. HP и мгновенно восстанавливает +30 HP за стак",
        "calc": lambda s: {"max_hp": 30 * s}
    },
    "vampiric_stim": {
        "id": "vampiric_stim",
        "name": "Биостимулятор вампиризма",
        "icon": "🧪",
        "category": "defense",
        "desc": "Восстанавливает HP в размере 15% от нанесенного урона за стак",
        "calc": lambda s: {"vampirism": 0.15 * s}
    },
    "trench_grit": {
        "id": "trench_grit",
        "name": "Окопная стойкость",
        "icon": "🧱",
        "category": "defense",
        "desc": "Снижает весь входящий урон на 6 единиц за стак",
        "calc": lambda s: {"dmg_reduction": 6 * s}
    },
    "evasion_reflex": {
        "id": "evasion_reflex",
        "name": "Боевой рефлекс",
        "icon": "💨",
        "category": "defense",
        "desc": "+14% шанс полностью уклониться от атаки врага за стак",
        "calc": lambda s: {"dodge_chance": 0.14 * s}
    },
    "field_medic_personal": {
        "id": "field_medic_personal",
        "name": "Аптечка Salewa",
        "icon": "🩹",
        "category": "defense",
        "desc": "Восстанавливает +25 HP после каждого завершенного акта за стак",
        "calc": lambda s: {"post_act_heal": 25 * s}
    },
    "defibrillator_shield": {
        "id": "defibrillator_shield",
        "name": "Портативный дефибриллятор",
        "icon": "⚡",
        "category": "defense",
        "desc": "Один раз за рейд спасает от смертельного урона, давая 50 HP за стак",
        "calc": lambda s: {"revive_shield": 50 * s}
    },
    "iron_lungs": {
        "id": "iron_lungs",
        "name": "Стальные легкие",
        "icon": "🫁",
        "category": "defense",
        "desc": "Иммунитет к газу и +15 к макс. HP за стак",
        "calc": lambda s: {"max_hp": 15 * s}
    },
    "painkillers_morphine": {
        "id": "painkillers_morphine",
        "name": "Ампула Морфия",
        "icon": "💉",
        "category": "defense",
        "desc": "Автоматически лечит на 35 HP при падении ниже 30% HP",
        "calc": lambda s: {"emergency_heal": 35 * s}
    },
    "thick_skin": {
        "id": "thick_skin",
        "name": "Кевларовый подшлемник",
        "icon": "🪖",
        "category": "defense",
        "desc": "Снижает процентный входящий урон на 12% за стак",
        "calc": lambda s: {"pct_dmg_reduction": 0.12 * s}
    },
    "adrenaline_injector": {
        "id": "adrenaline_injector",
        "name": "Инжектор адреналина",
        "icon": "⚡",
        "category": "defense",
        "desc": "+10 к HP каждый ход боя за стак",
        "calc": lambda s: {"turn_regen": 10 * s}
    },
    "ballistic_visor": {
        "id": "ballistic_visor",
        "name": "Баллистическое забрало",
        "icon": "🎭",
        "category": "defense",
        "desc": "+25 к HP и снижает критический урон врага",
        "calc": lambda s: {"max_hp": 25 * s, "dmg_reduction": 4 * s}
    },

    # --- SYNERGY (СИНЕРГИЯ ДУО) ---
    "partner_link": {
        "id": "partner_link",
        "name": "Связка напарников",
        "icon": "🔗",
        "category": "synergy",
        "desc": "Дает +15 к DMG вашему напарнику за стак",
        "calc": lambda s: {"buff_partner_dmg": 15 * s}
    },
    "brotherly_bandage": {
        "id": "brotherly_bandage",
        "name": "Братская перевязка",
        "icon": "🤝",
        "category": "synergy",
        "desc": "Лечит напарника на +20 HP в конце каждого акта за стак",
        "calc": lambda s: {"heal_partner_post_act": 20 * s}
    },
    "suppressive_fire": {
        "id": "suppressive_fire",
        "name": "Огонь на подавление",
        "icon": "🛡️",
        "category": "synergy",
        "desc": "Снижает получаемый напарником урон на 18% за стак",
        "calc": lambda s: {"partner_protect_pct": 0.18 * s}
    },
    "synchronous_volley": {
        "id": "synchronous_volley",
        "name": "Синхронный залп",
        "icon": "⚡",
        "category": "synergy",
        "desc": "Увеличивает суммарный командный урон дуо на 25% за стак",
        "calc": lambda s: {"team_dmg_mult": 0.25 * s}
    },
    "partner_revive_stim": {
        "id": "partner_revive_stim",
        "name": "Инъекция адреналина напарнику",
        "icon": "💉",
        "category": "synergy",
        "desc": "Если напарник падает без сознания, он мгновенно встает с 45 HP за стак",
        "calc": lambda s: {"partner_auto_revive": 45 * s}
    },
    "spotter_guidance": {
        "id": "spotter_guidance",
        "name": "Корректировщик огня",
        "icon": "🔭",
        "category": "synergy",
        "desc": "+12% крит. шанса вашему напарнику за стак",
        "calc": lambda s: {"buff_partner_crit": 0.12 * s}
    },
    "coordinated_breach": {
        "id": "coordinated_breach",
        "name": "Штурмовая слаженность",
        "icon": "🚪",
        "category": "synergy",
        "desc": "+25 DMG при совместной атаке за стак",
        "calc": lambda s: {"duo_assist_dmg": 25 * s}
    },

    # --- UTILITY (ХАБАР И ТАКТИКА) ---
    "scavenger_greed": {
        "id": "scavenger_greed",
        "name": "Жадность барыги",
        "icon": "💰",
        "category": "utility",
        "desc": "+30% к найденным в рейде рублям для всей команды за стак",
        "calc": lambda s: {"team_rubles_mult": 0.30 * s}
    },
    "lockpick_mastery": {
        "id": "lockpick_mastery",
        "name": "Связка отмычек",
        "icon": "🔑",
        "category": "utility",
        "desc": "+1 дополнительный ценный предмет в лут за каждый акт",
        "calc": lambda s: {"extra_items": 1 * s}
    },
    "heartbeat_sensor": {
        "id": "heartbeat_sensor",
        "name": "Датчик сердцебиения",
        "icon": "📡",
        "category": "utility",
        "desc": "Первая атака в каждом акте наносит +40 бонусного DMG за стак",
        "calc": lambda s: {"first_hit_dmg": 40 * s}
    },
    "lucky_token": {
        "id": "lucky_token",
        "name": "Счастливый жетон рейдера",
        "icon": "🪙",
        "category": "utility",
        "desc": "+65 000 ₽ гарантированно в банк рейда после каждого акта",
        "calc": lambda s: {"act_rubles_bonus": 65000 * s}
    },
    "trader_radio": {
        "id": "trader_radio",
        "name": "Радиоперехват Скупщика",
        "icon": "📻",
        "category": "utility",
        "desc": "Увеличивает шанс выпадения легендарного лута в 1.5 раза",
        "calc": lambda s: {"high_tier_drop_bonus": 0.50 * s}
    },
    "stamina_booster": {
        "id": "stamina_booster",
        "name": "Шприц мельдония",
        "icon": "⚡",
        "category": "utility",
        "desc": "+10% шанс уклонения и +15 к макс. HP",
        "calc": lambda s: {"dodge_chance": 0.10 * s, "max_hp": 15 * s}
    },
    "combat_scanner": {
        "id": "combat_scanner",
        "name": "Тактический тепловизор",
        "icon": "👁️",
        "category": "utility",
        "desc": "+15 DMG и исключает промахи по укрытиям",
        "calc": lambda s: {"dmg": 15 * s}
    }
}

# =====================================================================
# 2. LOCATIONS DEFINITION
# =====================================================================
COOP_LOCATIONS = {
    "factory": {
        "id": "factory",
        "name": "🏭 Завод",
        "badge": "🏭",
        "desc": "Тесные коридоры, пар из пробитых труб, звон рикошетов и тяжелые шаги Тагиллы с кувалдой.",
        "difficulty_label": "🟢 CQB и тактический прорыв",
        "base_enemy_hp": (120, 260),
        "base_enemy_dmg": (14, 28),
        "rubles_scale": 1.0,
        "boss_name": "Тагилла с Кувалдой",
        "boss_hp": 650,
        "boss_dmg": 45
    },
    "customs": {
        "id": "customs",
        "name": "🌲 Таможня",
        "badge": "🌲",
        "desc": "Трехэтажные общаги, стройка, ж/д насыпи, брошенные бензовозы и элитная свита Решалы.",
        "difficulty_label": "🟡 Тактический простор и снайперы",
        "base_enemy_hp": (140, 290),
        "base_enemy_dmg": (16, 32),
        "rubles_scale": 1.2,
        "boss_name": "Решала и Золотой ТТ",
        "boss_hp": 720,
        "boss_dmg": 48
    },
    "woods": {
        "id": "woods",
        "name": "🌿 Лес",
        "badge": "🌿",
        "desc": "Минные поля, глухая чаща, снайперские засады на лесопилке и смертоносный карабин Штурмана.",
        "difficulty_label": "🟡 Снайперская дуэль и маскировка",
        "base_enemy_hp": (150, 310),
        "base_enemy_dmg": (18, 35),
        "rubles_scale": 1.3,
        "boss_name": "Штурман (СВДС Охотник)",
        "boss_hp": 750,
        "boss_dmg": 52
    },
    "interchange": {
        "id": "interchange",
        "name": "🛒 Развязка (ТЦ ULTRA)",
        "badge": "🛒",
        "desc": "Темные коридоры мегамолла, витрины KIBA Arms, сирены тревоги и Килла с пулеметом РПК.",
        "difficulty_label": "🟠 Напряжение и ценный лут",
        "base_enemy_hp": (160, 330),
        "base_enemy_dmg": (20, 38),
        "rubles_scale": 1.4,
        "boss_name": "Килла в Шлеме Маска-1Щ",
        "boss_hp": 800,
        "boss_dmg": 55
    },
    "shoreline": {
        "id": "shoreline",
        "name": "🏥 Берег (Санаторий Лазурный)",
        "badge": "🏥",
        "desc": "Корпуса санатория, лаборатории стимуляторов, закрытые люксы и Санитар со свитой.",
        "difficulty_label": "🟠 Медицина и засады в номерах",
        "base_enemy_hp": (160, 330),
        "base_enemy_dmg": (20, 38),
        "rubles_scale": 1.45,
        "boss_name": "Санитар и Охрана в Бронежилетах",
        "boss_hp": 780,
        "boss_dmg": 50
    },
    "reserve": {
        "id": "reserve",
        "name": "🚂 Резерв (База и Гермобункер Д-2)",
        "badge": "🚂",
        "desc": "Герметичные бункеры на глубине, бронепоезд, пулеметные вышки и Глухарь с АШ-12 12.7 мм.",
        "difficulty_label": "🔴 Тяжелая военная фортификация",
        "base_enemy_hp": (170, 350),
        "base_enemy_dmg": (22, 42),
        "rubles_scale": 1.6,
        "boss_name": "Глухарь и Штурмовики АШ-12",
        "boss_hp": 850,
        "boss_dmg": 58
    },
    "lighthouse": {
        "id": "lighthouse",
        "name": "🌊 Маяк (Полуостров и Очистные)",
        "badge": "🌊",
        "desc": "Очистные сооружения Rogues, крупнокалиберные пулеметы, скалы и таинственный Зрячий.",
        "difficulty_label": "🔴 Снайперские рубежи и мины",
        "base_enemy_hp": (180, 360),
        "base_enemy_dmg": (24, 45),
        "rubles_scale": 1.7,
        "boss_name": "Зрячий и Отступники Rogues",
        "boss_hp": 820,
        "boss_dmg": 60
    },
    "streets": {
        "id": "streets",
        "name": "🏢 Улицы Таркова",
        "badge": "🏢",
        "desc": "Городской лабиринт, автосалон LexOs, баррикады, снайперы в окнах и Кабан за пулеметом ПКМ.",
        "difficulty_label": "🟣 Городской кошмар",
        "base_enemy_hp": (180, 380),
        "base_enemy_dmg": (25, 48),
        "rubles_scale": 1.85,
        "boss_name": "Кабан на Пулемете ПКМ",
        "boss_hp": 900,
        "boss_dmg": 62
    },
    "labs": {
        "id": "labs",
        "name": "🔬 Лаборатория TerraGroup",
        "badge": "🔬",
        "desc": "Подземный научно-исследовательский комплекс, ключ-карты, Рейдеры в Hexgrid и Black Division.",
        "difficulty_label": "☠️ Абсолютная элита и хай-тек",
        "base_enemy_hp": (200, 420),
        "base_enemy_dmg": (28, 55),
        "rubles_scale": 2.2,
        "boss_name": "Командир Black Division в Hexgrid",
        "boss_hp": 950,
        "boss_dmg": 65
    },
    "ground_zero": {
        "id": "ground_zero",
        "name": "🎯 Эпицентр (Ground Zero)",
        "badge": "🎯",
        "desc": "Деловой центр Таркова, брошенные высотки TerraGroup, заминированные коридоры и отряды наемников.",
        "difficulty_label": "🟡 Городской штурм и растяжки",
        "base_enemy_hp": (150, 300),
        "base_enemy_dmg": (18, 36),
        "rubles_scale": 1.35,
        "boss_name": "Капитан наемников TerraGroup",
        "boss_hp": 760,
        "boss_dmg": 50
    }
}
'''

print("Building data script...")
