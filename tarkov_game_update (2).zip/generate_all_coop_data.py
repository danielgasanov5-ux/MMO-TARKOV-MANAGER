# -*- coding: utf-8 -*-
"""
Generates the complete coop_events_data.py with all 10 locations (15 acts each) + Evacuation.
"""
import sys

def build_all():
    print("Writing coop_events_data.py...")
    # Import the generator script
    import generate_coop_events
    generate_coop_events.generate_all()

if __name__ == "__main__":
    build_all()
