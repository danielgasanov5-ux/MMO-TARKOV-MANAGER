# -*- coding: utf-8 -*-
"""
Helper script to build the rich, varied, and unpredictable co-op events database.
"""
import json

print("Initializing generator...")
