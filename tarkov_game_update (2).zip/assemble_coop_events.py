# -*- coding: utf-8 -*-
"""
Assembler script to construct the complete coop_events_data.py
"""
import copy
import random
import os
import pprint

from data_common_incidents import TACTICAL_TOOLS, RAID_MODIFIERS, DYNAMIC_INCIDENTS, EVACUATION_EVENTS
from data_factory_customs import FACTORY_ENCOUNTERS, CUSTOMS_ENCOUNTERS
from data_woods_interchange import WOODS_ENCOUNTERS, INTERCHANGE_ENCOUNTERS
from data_shoreline_reserve import SHORELINE_ENCOUNTERS, RESERVE_ENCOUNTERS
from data_lighthouse_streets import LIGHTHOUSE_ENCOUNTERS, STREETS_ENCOUNTERS
from data_lab_groundzero import LAB_ENCOUNTERS, GROUND_ZERO_ENCOUNTERS

print("All location modules imported successfully!")

# Extract COOP_PERKS and COOP_LOCATIONS from build_complete_coop.py
with open("build_complete_coop.py", "r", encoding="utf-8") as f:
    orig_lines = f.readlines()

# Lines 20 to 455 contain COOP_PERKS and COOP_LOCATIONS
perks_and_locs_code = "".join(orig_lines[20:455]) + "\n"

header_code = '''# -*- coding: utf-8 -*-
"""
Cooperative Duo Roguelike System: Data & Events
Completely overhauled:
- 15 Acts with distinct narrative, atmospheric choices, and consequences.
- Truly unpredictable runs: randomized encounters from phase pools + dynamic in-raid incidents.
- Standard PMC Tactical Equipment (free, zero-damage safe options) vs In-Raid Special Tools.
- Dynamic Raid Modifiers (weather, blackout, airdrop, lockdown).
"""

import random
import copy

'''

encounters_code = f'''
# =====================================================================
# 3. TACTICAL TOOLS & IN-RAID SPECIAL GEAR
# =====================================================================
TACTICAL_TOOLS = {repr(TACTICAL_TOOLS)}

# =====================================================================
# 4. DYNAMIC RAID MODIFIERS
# =====================================================================
RAID_MODIFIERS = {repr(RAID_MODIFIERS)}

# =====================================================================
# 5. DYNAMIC IN-RAID INCIDENTS
# =====================================================================
DYNAMIC_INCIDENTS = {repr(DYNAMIC_INCIDENTS)}

# =====================================================================
# 6. EVACUATION CORRIDOR ENCOUNTERS
# =====================================================================
EVACUATION_EVENTS = {repr(EVACUATION_EVENTS)}

# =====================================================================
# 7. LOCATION ENCOUNTERS POOLS (10 ICONIC LOCATIONS)
# =====================================================================
LOCATION_ENCOUNTERS = {{
    "factory": {repr(FACTORY_ENCOUNTERS)},
    "customs": {repr(CUSTOMS_ENCOUNTERS)},
    "woods": {repr(WOODS_ENCOUNTERS)},
    "interchange": {repr(INTERCHANGE_ENCOUNTERS)},
    "shoreline": {repr(SHORELINE_ENCOUNTERS)},
    "reserve": {repr(RESERVE_ENCOUNTERS)},
    "lighthouse": {repr(LIGHTHOUSE_ENCOUNTERS)},
    "streets": {repr(STREETS_ENCOUNTERS)},
    "lab": {repr(LAB_ENCOUNTERS)},
    "labs": {repr(LAB_ENCOUNTERS)},
    "ground_zero": {repr(GROUND_ZERO_ENCOUNTERS)}
}}
'''

functions_code = '''
# =====================================================================
# 8. UTILITY & EVENT ROLLING FUNCTIONS
# =====================================================================

def roll_raid_modifier():
    """Select a random environmental/tactical raid modifier."""
    return copy.deepcopy(random.choice(RAID_MODIFIERS))

def format_hp_bar(cur, max_hp, length=8):
    """Format visual health bar."""
    if max_hp <= 0:
        return "░" * length + " 0/0"
    ratio = max(0.0, min(1.0, cur / max_hp))
    filled = int(round(ratio * length))
    if ratio > 0.6:
        char = "🟩"
    elif ratio > 0.3:
        char = "🟨"
    else:
        char = "🟥"
    empty = "░" * (length - filled)
    return f"{char * filled}{empty} {int(cur)}/{int(max_hp)}"

def calculate_player_combat_stats(profile, player_raid_data):
    """
    Computes effective combat stats for a Duo player:
    - Base HP and DMG from profile/level
    - Accumulates all stackable perk effects
    """
    base_hp = 100
    base_dmg = 35

    pmc_lvl = profile.get("level", 1) if profile else 1
    base_hp += min(50, pmc_lvl * 2)
    base_dmg += min(20, pmc_lvl)

    stats = {
        "max_hp": base_hp,
        "dmg": base_dmg,
        "crit_chance": 0.05,
        "crit_mult": 2.0,
        "dodge_chance": 0.0,
        "dmg_reduction": 0,
        "pct_dmg_reduction": 0.0,
        "first_hit_dmg": 0,
        "low_hp_dmg_mult": 0.0,
        "execute_mult": 0.0,
        "double_attack_chance": 0.0,
        "start_aoe": 0,
        "bleed_dmg": 0,
        "vampirism": 0.0,
        "turn_regen": 0,
        "post_act_heal": 0,
        "emergency_heal": 0,
        "revive_shield": 0,
        "partner_protect_pct": 0.0,
        "partner_auto_revive": 0,
        "heal_partner_post_act": 0,
        "duo_assist_dmg": 0,
        "buff_partner_dmg": 0,
        "buff_partner_crit": 0.0,
        "team_dmg_mult": 0.0,
        "team_rubles_mult": 0.0,
        "act_rubles_bonus": 0,
        "extra_items": 0
    }

    perks = player_raid_data.get("perks", {}) if player_raid_data else {}
    for p_id, stacks in perks.items():
        if stacks <= 0:
            continue
        p_def = COOP_PERKS.get(p_id)
        if not p_def:
            continue
        calc_fn = p_def.get("calc")
        if callable(calc_fn):
            try:
                deltas = calc_fn(stacks)
                if isinstance(deltas, dict):
                    for k, val in deltas.items():
                        if k in stats:
                            stats[k] += val
            except Exception:
                pass

    return stats

def get_random_perks_choice(current_player_perks=None, count=3):
    """Pick non-maxed random perks for choice offer."""
    if current_player_perks is None:
        current_player_perks = {}
    eligible_keys = []
    for p_id, p_info in COOP_PERKS.items():
        curr_lvl = current_player_perks.get(p_id, 0)
        max_lvl = p_info.get("max_level", 5)
        if curr_lvl < max_lvl:
            eligible_keys.append(p_id)
    if not eligible_keys:
        eligible_keys = list(COOP_PERKS.keys())
    sample_count = min(count, len(eligible_keys))
    chosen_keys = random.sample(eligible_keys, sample_count)
    result = []
    for k in chosen_keys:
        p_info = COOP_PERKS[k]
        curr_lvl = current_player_perks.get(k, 0)
        result.append({
            "id": k,
            "name": p_info.get("name", k),
            "icon": p_info.get("icon", "✨"),
            "desc": p_info.get("desc", ""),
            "category": p_info.get("category", "utility"),
            "cur_level": curr_lvl,
            "next_level": curr_lvl + 1
        })
    return result

def roll_event_for_act(location_id, act_number, is_evacuating=False, evac_act=1, used_ids=None, raid_modifier=None, raid=None):
    """
    Rolls an authentic, unpredictable event for the act.
    - Prevents repetitive sequential events by drawing randomly from the stage pool.
    - Never repeats the same event within a single raid.
    - Has a chance to trigger dynamic incidents (airdrop, wounded ally, blackout, etc.).
    - Scales enemy stats smoothly with act number.
    """
    if used_ids is None:
        used_ids = []

    loc_key = str(location_id).lower()
    if loc_key not in LOCATION_ENCOUNTERS:
        loc_key = "factory"

    loc_data = LOCATION_ENCOUNTERS[loc_key]

    # --- EVACUATION FLOW ---
    if is_evacuating:
        evac_idx = min(max(1, evac_act), len(EVACUATION_EVENTS)) - 1
        ev_template = EVACUATION_EVENTS[evac_idx]
        event = copy.deepcopy(ev_template)
        event["location_id"] = loc_key
        event["act_number"] = act_number
        event["is_evacuation"] = True
        return event

    # --- ACT 15: CLIMAX BOSS ---
    if act_number >= 15:
        boss_pool = loc_data.get("climax_boss", [])
        if boss_pool:
            event = copy.deepcopy(boss_pool[0])
        else:
            event = copy.deepcopy(loc_data["stage_3"][0])
        event["location_id"] = loc_key
        event["act_number"] = 15
        event["is_boss"] = True
        return event

    # --- ACT 5: MILESTONE 1 (COMMAND POST / EVAC UNLOCK) ---
    if act_number == 5:
        m1_pool = loc_data.get("milestone_1", [])
        available = [e for e in m1_pool if e["id"] not in used_ids]
        if not available:
            available = m1_pool
        event = copy.deepcopy(random.choice(available))
        event["location_id"] = loc_key
        event["act_number"] = 5
        event["is_milestone"] = True
        return event

    # --- ACT 10: MILESTONE 2 (ELITE SQUAD CONFRONTATION) ---
    if act_number == 10:
        m2_pool = loc_data.get("milestone_2", [])
        available = [e for e in m2_pool if e["id"] not in used_ids]
        if not available:
            available = m2_pool
        event = copy.deepcopy(random.choice(available))
        event["location_id"] = loc_key
        event["act_number"] = 10
        event["is_milestone"] = True
        return event

    # --- CHANCE FOR DYNAMIC INCIDENT (Acts 2-4, 6-9, 11-14) ---
    # 22% chance of an unexpected twist incident
    if act_number > 1 and random.random() < 0.22:
        available_incidents = [inc for inc in DYNAMIC_INCIDENTS if inc["id"] not in used_ids]
        if available_incidents:
            event = copy.deepcopy(random.choice(available_incidents))
            event["location_id"] = loc_key
            event["act_number"] = act_number
            event["is_incident"] = True
            return event

    # --- REGULAR STAGES: UNPREDICTABLE POOL SELECTION ---
    if act_number in (1, 2, 3, 4):
        stage_pool = loc_data.get("stage_1", [])
    elif act_number in (6, 7, 8, 9):
        stage_pool = loc_data.get("stage_2", [])
    else: # 11, 12, 13, 14
        stage_pool = loc_data.get("stage_3", [])

    # Filter out already used events to ensure no repeats in the raid
    available = [e for e in stage_pool if e["id"] not in used_ids]
    if not available:
        available = stage_pool # fallback if all in stage used

    chosen = random.choice(available)
    event = copy.deepcopy(chosen)
    event["location_id"] = loc_key
    event["act_number"] = act_number

    # Apply raid modifier flavor if applicable
    if raid_modifier:
        event["raid_modifier_id"] = raid_modifier.get("id")

    return event
'''

final_content = header_code + perks_and_locs_code + encounters_code + functions_code

with open("coop_events_data.py", "w", encoding="utf-8") as f:
    f.write(final_content)

print("coop_events_data.py assembled successfully!")
print("Size of coop_events_data.py:", os.path.getsize("coop_events_data.py"), "bytes")
