# -*- coding: utf-8 -*-
"""
30 Boss Relics and 6 Boss Set Bonuses (50,000,000 ₽ per full set)
for Escape from Tarkov MMO Telegram Bot.

Bosses:
1. Reshala (Решала) - 5 relics
2. Tagilla (Тагилла) - 5 relics
3. Killa (Килла) - 5 relics
4. Shturman (Штурман) - 5 relics
5. Glukhar (Глухарь) - 5 relics
6. Sanitar (Санитар) - 5 relics
"""

BOSS_SETS = {
    "reshala": {
        "boss_name": "Решала",
        "icon": "👑",
        "badge": "⚜️",
        "set_name": "Сет Авторитета Решалы (5/5)",
        "desc": "+50% к пассивному доходу всех бизнесов, 0% налог на Барахолке.",
        "relics": [
            {
                "id": "relic_reshala_golden_tt",
                "name": "Золотой ТТ Решалы",
                "boss": "reshala",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Именной позолоченный пистолет ТТ с гравировкой криминального авторитета Решалы."
            },
            {
                "id": "relic_reshala_watch",
                "name": "Золотые часы Rolex Решалы",
                "boss": "reshala",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Швейцарские золотые часы с бриллиантами, снятые с запястья Решалы."
            },
            {
                "id": "relic_reshala_ring",
                "name": "Перстень Решалы с печаткой",
                "boss": "reshala",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Массивный золотой перстень с гербом теневого синдиката Норвинской области."
            },
            {
                "id": "relic_reshala_cigar",
                "name": "Кубинская сигара Cohiba Решалы",
                "boss": "reshala",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Редчайшая кубинская сигара в золоченом футляре с личной монограммой."
            },
            {
                "id": "relic_reshala_briefcase",
                "name": "Дипломат Решалы с облигациями",
                "boss": "reshala",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Бронированный кейс с ценными бумагами швейцарских банков и теневыми активами."
            }
        ]
    },
    "tagilla": {
        "boss_name": "Тагилла",
        "icon": "🔨",
        "badge": "🔥",
        "set_name": "Сет Кузнеца Тагиллы (5/5)",
        "desc": "Вместимость всех 4 складов +50%, полное отсутствие поломки и осечки оружия в Даркзоне.",
        "relics": [
            {
                "id": "relic_tagilla_sledgehammer",
                "name": "Смертоносная кувалда Тагиллы",
                "boss": "tagilla",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Оружие",
                "combat": 150,
                "desc": "Тяжеленная кованая кувалда хозяина Завода. Размалывает вражескую броню в пыль."
            },
            {
                "id": "relic_tagilla_mask",
                "name": "Сварочная маска 'Gorilla' Тагиллы",
                "boss": "tagilla",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Экипировка",
                "armor": 120,
                "desc": "Укрепленная титаном сварочная маска с устрашающим оскалом гориллы."
            },
            {
                "id": "relic_tagilla_rig",
                "name": "Усиленный бронежилет Crye CPC Тагиллы",
                "boss": "tagilla",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Экипировка",
                "armor": 130,
                "desc": "Модифицированный бронежилет с керамическими пластинами 6-го класса защиты."
            },
            {
                "id": "relic_tagilla_cap",
                "name": "Фирменная кепка Тагиллы 'Boss'",
                "boss": "tagilla",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Экипировка",
                "armor": 40,
                "desc": "Тактическая кепка, пропитанная машинным маслом и пороховой гарью Завода."
            },
            {
                "id": "relic_tagilla_tattoo",
                "name": "Жетон с кузнечной печатью Тагиллы",
                "boss": "tagilla",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Стальной кузнечный жетон с личным клеймом цехового мастера Тагиллы."
            }
        ]
    },
    "killa": {
        "boss_name": "Килла",
        "icon": "🪖",
        "badge": "⚡",
        "set_name": "Сет Неудержимого Киллы (5/5)",
        "desc": "КД смерти ЧВК сокращен с 2 до 1 часа, баффы классов не отключаются при ранении.",
        "relics": [
            {
                "id": "relic_killa_helmet",
                "name": "Шлем Маска 1Щ Киллы с полосками",
                "boss": "killa",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Экипировка",
                "armor": 140,
                "desc": "Легендарный пуленепробиваемый шлем защитника ТЦ Ультра с тремя полосками."
            },
            {
                "id": "relic_killa_armor",
                "name": "Бронежилет 6Б13 М Киллы",
                "boss": "killa",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Экипировка",
                "armor": 135,
                "desc": "Армейский штурмовой бронежилет высшего класса защиты с индивидуальной подгонкой."
            },
            {
                "id": "relic_killa_rpk",
                "name": "Пулемет РПК-16 Киллы (Барабан)",
                "boss": "killa",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Оружие",
                "combat": 160,
                "desc": "Модернизированный пулемет Калашникова с барабанным магазином на 95 патронов Игольник."
            },
            {
                "id": "relic_killa_chains",
                "name": "Массивная золотая цепь Киллы",
                "boss": "killa",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Тяжелая литая золотая цепь, ставшая визитной карточкой яростного бойца."
            },
            {
                "id": "relic_killa_sneakers",
                "name": "Тактические кроссовки Adidas Киллы",
                "boss": "killa",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Экипировка",
                "combat": 30,
                "desc": "Удобные спринтерские кроссовки, позволяющие Килле совершать молниеносные рывки."
            }
        ]
    },
    "shturman": {
        "boss_name": "Штурман",
        "icon": "🎯",
        "badge": "🌲",
        "set_name": "Снайперский Сет Штурмана (5/5)",
        "desc": "+25% к шансу победы твоего отряда в PvP Даркзоне.",
        "relics": [
            {
                "id": "relic_shturman_svds",
                "name": "Снайперская винтовка СВД-С Штурмана",
                "boss": "shturman",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Оружие",
                "combat": 165,
                "desc": "Прецизионная снайперская винтовка с матчевым стволом и глушителем ротора."
            },
            {
                "id": "relic_shturman_key",
                "name": "Скрытый ключ от тайника Штурмана",
                "boss": "shturman",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Единственный экземпляр ключа от замаскированного ящика на лесопилке."
            },
            {
                "id": "relic_shturman_hood",
                "name": "Маскировочная парка Штурмана",
                "boss": "shturman",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Экипировка",
                "armor": 80,
                "desc": "Теплая камуфляжная парка с капюшоном, скрывающая стрелка в густых лесах."
            },
            {
                "id": "relic_shturman_scope",
                "name": "Снайперский прицел Hensoldt ZF Штурмана",
                "boss": "shturman",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Оружие",
                "combat": 50,
                "desc": "Немецкая высокоточная оптика переменной кратности с дальномерной сеткой."
            },
            {
                "id": "relic_shturman_whistle",
                "name": "Охотничий свисток Штурмана",
                "boss": "shturman",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Костяной свисток для подачи бесшумных условных сигналов снайперской охране."
            }
        ]
    },
    "glukhar": {
        "boss_name": "Глухарь",
        "icon": "🎖️",
        "badge": "🛡️",
        "set_name": "Военный Сет Глухаря (5/5)",
        "desc": "Вместимость Арсенала и Броне-ангара умножается на 2, шанс перехвата грузов таможней 0%.",
        "relics": [
            {
                "id": "relic_glukhar_ash12",
                "name": "Тяжелый автомат АШ-12 Глухаря (12.7 мм)",
                "boss": "glukhar",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Оружие",
                "combat": 170,
                "desc": "Крупнокалиберный штурмовой автомат спецназа под мощнейший патрон 12.7х55 мм."
            },
            {
                "id": "relic_glukhar_cap",
                "name": "Офицерская полевая фуражка Глухаря",
                "boss": "glukhar",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Экипировка",
                "armor": 50,
                "desc": "Парадная полевая фуражка кадрового военного коменданта военной базы Резерв."
            },
            {
                "id": "relic_glukhar_badge",
                "name": "Орден Мужества Глухаря",
                "boss": "glukhar",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Боевая государственная награда за руководство обороной стратегических складов."
            },
            {
                "id": "relic_glukhar_vest",
                "name": "Штурмовая разгрузка AVS Глухаря",
                "boss": "glukhar",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Экипировка",
                "armor": 110,
                "desc": "Тяжелый бронированный плитник с подсумками под увеличенные магазины АШ-12."
            },
            {
                "id": "relic_glukhar_radio",
                "name": "Зашифрованная военная рация Глухаря",
                "boss": "glukhar",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Компоненты",
                "combat": 40,
                "desc": "Защищенный армейский трансивер со спецкодами доступа к подземным тоннелям."
            }
        ]
    },
    "sanitar": {
        "boss_name": "Санитар",
        "icon": "💉",
        "badge": "🧬",
        "set_name": "Медицинский Сет Санитара (5/5)",
        "desc": "Время 2-часовой смерти ЧВК сокращается ровно до 30 минут, Медблок мгновенно восстанавливает наемников.",
        "relics": [
            {
                "id": "relic_sanitar_bag",
                "name": "Медицинская сумка Санитара",
                "boss": "sanitar",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Медицина",
                "armor": 60,
                "desc": "Кожаный саквояж хирурга с экспериментальными полевыми препаратами и гемостатиками."
            },
            {
                "id": "relic_sanitar_stim",
                "name": "Стимулятор Obdolbos-2 Санитара",
                "boss": "sanitar",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Медицина",
                "combat": 60,
                "desc": "Сверхмощный боевой коктейль из нейростимуляторов, форсирующий реакции организма."
            },
            {
                "id": "relic_sanitar_coat",
                "name": "Окровавленный халат Санитара",
                "boss": "sanitar",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Экипировка",
                "armor": 75,
                "desc": "Спецодежда главврача санатория 'Лазурный берег' со следами мутагенных реагентов."
            },
            {
                "id": "relic_sanitar_scalpel",
                "name": "Хирургический скальпель Санитара",
                "boss": "sanitar",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Медицина",
                "combat": 55,
                "desc": "Закаленный медицинский скальпель из хирургической стали с лазерной заточкой."
            },
            {
                "id": "relic_sanitar_key",
                "name": "Синяя ключ-карта лаборатории Санитара",
                "boss": "sanitar",
                "price": 10000000,
                "rarity": "legendary",
                "category": "relic",
                "market_cat": "Драгоценности",
                "desc": "Магнитный пропуск в секретный хирургический блок в крыле санатория."
            }
        ]
    }
}

# Flat list of all 30 relics
ALL_30_RELICS = []
RELICS_BY_ID = {}
for boss_key, b_data in BOSS_SETS.items():
    for r in b_data["relics"]:
        ALL_30_RELICS.append(r)
        RELICS_BY_ID[r["id"]] = r

def get_player_relics(player):
    """Returns set of relic IDs owned in player stash."""
    stash = player.get("stash", [])
    owned = set()
    for itm in stash:
        iid = itm.get("item_id")
        if iid in RELICS_BY_ID:
            owned.add(iid)
    return owned

def get_player_boss_sets(player):
    """
    Returns dict of {boss_key: {"owned_count": int, "is_active": bool, "boss_name": str, ...}}
    """
    owned_relics = get_player_relics(player)
    sets_status = {}
    for boss_key, b_data in BOSS_SETS.items():
        total = len(b_data["relics"])
        owned_count = sum(1 for r in b_data["relics"] if r["id"] in owned_relics)
        sets_status[boss_key] = {
            "boss_name": b_data["boss_name"],
            "icon": b_data["icon"],
            "badge": b_data["badge"],
            "set_name": b_data["set_name"],
            "desc": b_data["desc"],
            "owned_count": owned_count,
            "total_count": total,
            "is_active": (owned_count == total)
        }
    return sets_status

def has_boss_set_bonus(player, boss_key):
    """Returns True if player owns all 5 relics of the given boss set."""
    sets_status = get_player_boss_sets(player)
    return sets_status.get(boss_key, {}).get("is_active", False)

def get_active_boss_bonuses_list(player):
    """Returns list of active set bonus descriptions."""
    active = []
    sets = get_player_boss_sets(player)
    for k, s in sets.items():
        if s["is_active"]:
            active.append(f"{s['icon']} <b>{s['set_name']}:</b> {s['desc']}")
    return active


def get_player_duplicate_relics(player):
    """
    Finds all duplicate relics in player stash (keeping 1 copy of each unique relic ID).
    Returns list of item dicts representing the duplicates.
    """
    stash = player.get("stash", [])
    seen = set()
    duplicates = []
    for itm in stash:
        iid = itm.get("item_id")
        if iid in RELICS_BY_ID:
            if iid in seen:
                duplicates.append(itm)
            else:
                seen.add(iid)
    return duplicates

def sell_duplicate_relics(player):
    """
    Sells all duplicate relics for 10,000,000 rubles each.
    The primary copy of each relic ID is preserved so set bonuses and progress are never harmed.
    Returns (sold_count, total_rubles, sold_names).
    """
    duplicates = get_player_duplicate_relics(player)
    if not duplicates:
        return 0, 0, []
    
    dup_uids = {d.get("uid") for d in duplicates if d.get("uid")}
    sold_count = len(duplicates)
    total_rubles = sold_count * 10000000
    sold_names = [RELICS_BY_ID.get(d.get("item_id"), {}).get("name", d.get("item_id")) for d in duplicates]
    
    # Remove duplicates from player stash
    player["stash"] = [itm for itm in player.get("stash", []) if itm.get("uid") not in dup_uids]
    
    # Add money
    player["money"] = player.get("money", 0) + total_rubles
    st = player.setdefault("stats", {})
    st["total_earned_rubles"] = st.get("total_earned_rubles", 0) + total_rubles
    
    return sold_count, total_rubles, sold_names
