# -*- coding: utf-8 -*-
import json
import time
import os
import sys

# Add path
sys.path.insert(0, os.path.abspath("backend"))

from tarkov_engine import (
    load_db, save_db, create_new_player, has_buff, is_admin,
    calculate_squad_power, check_and_update_economic_crisis, get_crisis_price,
    PMC_DEFINITIONS, ITEMS_BY_ID, ITEMS_LIST
)
from loot_generator import (
    simulate_coop_raid, COOP_DIFFICULTIES, roll_strict_tarkov_loot,
    generate_container_loot
)
from coop_system import get_leader_keycard

print("=== STARTING COMPREHENSIVE VERIFICATION SUITE ===")

# 1. Verification of Items DB (720 items)
assert len(ITEMS_LIST) == 720, f"Expected 720 items, got {len(ITEMS_LIST)}"
print(f"✅ Items count: {len(ITEMS_LIST)} verified")

# Check new item categories
helmets = [i for i in ITEMS_LIST if i.get("subcategory") == "helmet"]
headsets = [i for i in ITEMS_LIST if i.get("subcategory") == "headset" or i.get("market_cat") == "Наушники"]
components = [i for i in ITEMS_LIST if i.get("category") == "components"]
assert len(helmets) >= 100, f"Expected >= 100 helmets, got {len(helmets)}"
assert len(headsets) >= 20, f"Expected >= 20 headsets, got {len(headsets)}"
assert len(components) >= 200, f"Expected >= 200 components, got {len(components)}"
print(f"✅ Helments: {len(helmets)}, Headsets: {len(headsets)}, Components: {len(components)} verified")

# 2. Verification of Economic Crises
db = {"users": {}, "economic_crisis": {}, "p2p_market": []}
is_new, crisis = check_and_update_economic_crisis(db)
assert is_new is True
assert crisis["category"] in ["Оружие", "Экипировка", "Наушники", "Медицина", "Драгоценности", "Компоненты"]
assert 30 <= crisis["shift_pct"] <= 50
assert crisis["expires_at"] > time.time()
print(f"✅ Economic Crisis generated: {crisis['headline']}")

# Check crisis price adjustment
base_price = 100000
adj_price = get_crisis_price(base_price, crisis["category"], db)
assert adj_price != base_price
print(f"✅ Crisis price shift: {base_price} -> {adj_price} ({crisis['multiplier']}x)")

# 3. Verification of Admin @revenuts and Rank
rev_player = create_new_player(111222, "revenuts", None)
assert is_admin(111222, "revenuts") is True
assert is_admin(333444, "player1") is False
assert rev_player["pmc_signature"] == "Revenant"
assert has_buff(rev_player, "market_tax") is True
assert has_buff(rev_player, "prapor_bonus") is True
assert has_buff(rev_player, "pvp_bonus") is True
assert has_buff(rev_player, "loot_bonus") is True
print("✅ Admin @revenuts: all buffs active simultaneously, identity confirmed")

# 4. Verification of Equipment Slots (Weapon, Armor, Helmet, Headset)
normal_player = create_new_player(222333, "OperatorOne", "Nomad")
squad_member = normal_player["squad"][0]
assert "helmet_uid" in squad_member
assert "headset_uid" in squad_member
assert "weapon_uid" in squad_member
assert "armor_uid" in squad_member
print("✅ Squad fighter structure has all 4 slots: weapon, armor, helmet, headset")

# Test squad power with 4 slots
normal_player["stash"].append({"uid": "test_w", "item_id": "ak74m_common", "equipped_to": 1})
normal_player["stash"].append({"uid": "test_a", "item_id": "paca_common", "equipped_to": 1})
normal_player["stash"].append({"uid": "test_h", "item_id": "helm_psh_97_dzeta", "equipped_to": 1})
normal_player["stash"].append({"uid": "test_hs", "item_id": "headset_gssh_01", "equipped_to": 1})
squad_member["weapon_uid"] = "test_w"
squad_member["armor_uid"] = "test_a"
squad_member["helmet_uid"] = "test_h"
squad_member["headset_uid"] = "test_hs"
pow_val, arm_val = calculate_squad_power(normal_player)
assert pow_val > 10, f"Expected pow_val > 10, got {pow_val}"
assert arm_val > 5, f"Expected arm_val > 5, got {arm_val}"
print(f"✅ 4-Slot Squad Power calculation verified: Power={pow_val}, Armor={arm_val}")

# 5. Verification of Coop Raids (6 players, 5 difficulties, failure penalty)
assert len(COOP_DIFFICULTIES) == 5
assert COOP_DIFFICULTIES["hard"]["requires_keycard"] is True
assert COOP_DIFFICULTIES["ultra"]["requires_keycard"] is True
assert COOP_DIFFICULTIES["colossal"]["requires_keycard"] is True
assert COOP_DIFFICULTIES["easy"]["requires_keycard"] is False
assert COOP_DIFFICULTIES["normal"]["requires_keycard"] is False
print("✅ Coop Raid 5 difficulties & keycard requirements verified")

# Check leader keycard detection
has_kc, kc_item = get_leader_keycard(normal_player)
assert has_kc is None
normal_player["stash"].append({"uid": "test_kc", "item_id": "lab_keycard_red_legendary", "equipped_to": None})
has_kc, kc_item = get_leader_keycard(normal_player)
assert has_kc is not None
print("✅ Leader Legendary Keycard detection verified")

# Check Coop Failure Penalty (2 hours cooldown and loss of passive buff)
normal_player["coop_cooldown_until"] = int(time.time() + 7200)
assert has_buff(normal_player, "scav_discount") is False, "Buff must be disabled during coop cooldown!"
print("✅ Coop failure penalty: 2-hour cooldown disables PMC class passive buff verified")

# 6. Verification of Drop Rate Balance
counts = {"legendary": 0, "epic": 0, "rare": 0, "common": 0}
sim_total = 2000
for _ in range(sim_total):
    item = roll_strict_tarkov_loot()
    r = item.get("rarity", "common")
    counts[r] = counts.get(r, 0) + 1

leg_pct = (counts["legendary"] / sim_total) * 100
epic_pct = (counts["epic"] / sim_total) * 100
print(f"✅ Strict drop rates over {sim_total} rolls: Legendary={leg_pct:.2f}% (<0.5%), Epic={epic_pct:.2f}% (~3%)")
assert leg_pct < 1.0, f"Legendary drop rate too high: {leg_pct}%"
assert epic_pct < 6.0, f"Epic drop rate too high: {epic_pct}%"

print("=== ALL COMPREHENSIVE TESTS PASSED SUCCESSFULLY! ===")
