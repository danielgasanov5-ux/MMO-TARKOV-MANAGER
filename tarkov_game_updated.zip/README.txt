MMO Tarkov Manager - Telegram Bot Backend
=========================================

1. Установите зависимости:
   cd backend
   pip install -r requirements.txt

2. Задайте токен вашего бота:
   export BOT_TOKEN="ВАШ_TELEGRAM_BOT_ТОКЕН"

3. Запустите бота:
   python bot.py
